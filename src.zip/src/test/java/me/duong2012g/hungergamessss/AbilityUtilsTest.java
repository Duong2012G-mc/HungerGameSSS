package me.duong2012g.hungergamessss;

import me.duong2012g.hungergamessss.ability.AbilityUtils;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.*;
import org.mockbukkit.mockbukkit.MockBukkit;
import org.mockbukkit.mockbukkit.ServerMock;
import org.mockbukkit.mockbukkit.entity.PlayerMock;

import static org.junit.jupiter.api.Assertions.*;

/**
 * TEST-01: Unit tests for AbilityUtils core logic.
 * Uses MockBukkit to stub Bukkit API without a running server.
 */
@DisplayName("AbilityUtils Tests")
class AbilityUtilsTest {

    private ServerMock server;

    @BeforeEach
    void setUp() {
        server = MockBukkit.mock();
    }

    @AfterEach
    void tearDown() {
        MockBukkit.unmock();
    }

    // ── applyKnockback ────────────────────────────────────────────────────────

    @Test
    @DisplayName("applyKnockback: zero-length vector does not throw")
    void knockback_zeroVector_noThrow() {
        PlayerMock target = server.addPlayer("target");
        PlayerMock source = server.addPlayer("source");
        // Same location — direction vector has length 0
        Location loc = target.getLocation();
        assertDoesNotThrow(() ->
                AbilityUtils.applyKnockback(target, loc, 1.5, 0.4));
    }

    @Test
    @DisplayName("applyKnockback: velocity is applied when vector is non-zero")
    void knockback_nonZeroVector_velocitySet() {
        PlayerMock target = server.addPlayer("t2");
        Location source = target.getLocation().add(3, 0, 0);
        AbilityUtils.applyKnockback(target, source, 2.0, 0.5);
        // Y component should be set to upward value
        assertEquals(0.5, target.getVelocity().getY(), 0.001);
        // X component should be negative (pushed away from source which is +3X)
        assertTrue(target.getVelocity().getX() < 0);
    }

    // ── spawnParticleLine ─────────────────────────────────────────────────────

    @Test
    @DisplayName("spawnParticleLine: null world does not throw")
    void particleLine_nullWorld_noThrow() {
        World w = server.addSimpleWorld("test");
        Location a = new Location(w, 0, 64, 0);
        Location b = new Location(w, 5, 64, 0);
        // Should complete without throwing even for zero-length line
        assertDoesNotThrow(() ->
                AbilityUtils.spawnParticleLine(a, b, Particle.CRIT, 2, 0.5));
    }

    // ── findSafeLanding ───────────────────────────────────────────────────────

    @Test
    @DisplayName("findSafeLanding: returns null when no solid floor within range")
    void safeLanding_noFloor_returnsNull() {
        World w = server.addSimpleWorld("void");
        Location origin = new Location(w, 0, 200, 0);
        // No blocks placed — should return null
        Location result = AbilityUtils.findSafeLanding(origin, 5);
        assertNull(result);
    }

    // ── degradeRandomArmorPiece ───────────────────────────────────────────────

    @Test
    @DisplayName("degradeRandomArmorPiece: no armour → no exception")
    void degradeArmor_noArmor_noThrow() {
        PlayerMock p = server.addPlayer("naked");
        // Player has no armour — should return silently
        assertDoesNotThrow(() -> AbilityUtils.degradeRandomArmorPiece(p, 0.1));
    }
}
