package me.duong2012g.hungergamessss;

import org.junit.jupiter.api.*;
import org.mockbukkit.mockbukkit.MockBukkit;
import org.mockbukkit.mockbukkit.ServerMock;
import org.mockbukkit.mockbukkit.entity.PlayerMock;

import static org.junit.jupiter.api.Assertions.*;

/**
 * TEST-02: Unit tests for CooldownManager set / check / expire logic.
 */
@DisplayName("CooldownManager Tests")
class CooldownManagerTest {

    private ServerMock server;
    private Main plugin;
    private me.duong2012g.hungergamessss.manager.CooldownManager cooldownManager;

    @BeforeEach
    void setUp() {
        server = MockBukkit.mock();
        plugin = MockBukkit.load(Main.class);
        cooldownManager = plugin.getCooldownManager();
    }

    @AfterEach
    void tearDown() {
        MockBukkit.unmock();
    }

    @Test
    @DisplayName("setCooldown then isOnCooldown returns true immediately")
    void setCooldown_immediateCheck_isTrue() {
        PlayerMock p = server.addPlayer("p1");
        cooldownManager.setCooldown(p, "artemis_bow", "Artemis Bow", 5000L);
        assertTrue(cooldownManager.isOnCooldown(p, "artemis_bow"));
    }

    @Test
    @DisplayName("isOnCooldown returns false for unknown ability")
    void isOnCooldown_unknown_isFalse() {
        PlayerMock p = server.addPlayer("p2");
        assertFalse(cooldownManager.isOnCooldown(p, "nonexistent_ability"));
    }

    @Test
    @DisplayName("removePlayer clears cooldown state")
    void removePlayer_clearsState() {
        PlayerMock p = server.addPlayer("p3");
        cooldownManager.setCooldown(p, "mjolnir", "Mjolnir", 10_000L);
        assertTrue(cooldownManager.isOnCooldown(p, "mjolnir"));
        cooldownManager.removePlayer(p.getUniqueId());
        assertFalse(cooldownManager.isOnCooldown(p, "mjolnir"));
    }

    @Test
    @DisplayName("getCooldown returns positive remaining ms when on cooldown")
    void getCooldown_onCooldown_positive() {
        PlayerMock p = server.addPlayer("p4");
        cooldownManager.setCooldown(p, "cloud_sword", "Cloud Sword", 30_000L);
        long remaining = cooldownManager.getCooldown(p, "cloud_sword");
        assertTrue(remaining > 0, "Expected positive remaining time, got: " + remaining);
        assertTrue(remaining <= 30_000L);
    }

    @Test
    @DisplayName("shutdown cancels task and clears all state")
    void shutdown_clearsAllState() {
        PlayerMock p = server.addPlayer("p5");
        cooldownManager.setCooldown(p, "beehive_blaster", "Beehive Blaster", 5000L);
        cooldownManager.shutdown();
        // After shutdown, isOnCooldown should return false (maps cleared)
        assertFalse(cooldownManager.isOnCooldown(p, "beehive_blaster"));
    }
}
