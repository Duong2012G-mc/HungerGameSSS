package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class MigrateCommand implements CommandExecutor {
    private final Main plugin;

    public MigrateCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(ChatColor.RED + "This command can only be used by players.");
            return true;
        }

        if (!p.hasPermission("hg.admin")) {
            p.sendMessage(ChatColor.RED + "You don't have permission to use this command.");
            return true;
        }

        int migrated = 0;
        for (ItemStack item : p.getInventory().getContents()) {
            if (item == null || !item.hasItemMeta()) continue;
            
            String nameBefore = plugin.getAbilityManager().getAbilityName(item);
            plugin.getAbilityManager().migrateItem(item);
            String nameAfter = plugin.getAbilityManager().getAbilityName(item);
            
            if (nameBefore != null && nameAfter != null && nameBefore.equals(nameAfter)) {
                migrated++;
            }
        }

        if (migrated > 0) {
            p.sendMessage(ChatColor.GREEN + "Successfully migrated " + migrated + " legendary item(s) to PDC tags!");
        } else {
            p.sendMessage(ChatColor.YELLOW + "No items in your inventory required migration.");
        }

        return true;
    }
}
