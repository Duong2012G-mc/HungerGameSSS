package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.util.StringUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class HGTabCompleter implements TabCompleter {

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            List<String> subcommands = new ArrayList<>(Arrays.asList("join", "leave", "lobby"));
            if (sender.hasPermission("hg.admin") || sender.isOp()) {
                subcommands.addAll(Arrays.asList(
                    "admin", "create", "delete", "reload", "save", 
                    "setlegendary", "deletelegendary", "setlobby", "setuparena", "start", "wand",
                    "setcornucopia", "border", "lang"
                ));
            }
            return StringUtil.copyPartialMatches(args[0], subcommands, new ArrayList<>());
        }

        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            
            if (sub.equals("join") || sub.equals("delete") || sub.equals("setuparena")) {
                return StringUtil.copyPartialMatches(args[1], Main.getInstance().getArenaManager().getArenas().keySet(), new ArrayList<>());
            }
            if (sub.equals("save")) {
                return StringUtil.copyPartialMatches(args[1], Collections.singletonList("cornucopia"), new ArrayList<>());
            }
            if (sub.equals("create")) {
                return Collections.singletonList(Main.getInstance().getMessageManager().getMessage("tab_create_name"));
            }
            if (sub.equals("setcornucopia")) {
                return StringUtil.copyPartialMatches(args[1], Arrays.asList(
                    "ultimate", "speedsilver", "classic", "ancient", "void", "royal", "industrial", 
                    "modern", "crystal", "jungle", "end", "nether", "grand"
                ), new ArrayList<>());
            }
            if (sub.equals("start")) {
                // Return cooldown options or arena name?
                // HGCommand: start <countdown> [arena]
                return StringUtil.copyPartialMatches(args[1], Arrays.asList("10", "30", "60"), new ArrayList<>());
            }
            if (sub.equals("admin")) {
                return StringUtil.copyPartialMatches(args[1], Collections.singletonList("give"), new ArrayList<>());
            }
            if (sub.equals("setlegendary")) {
                 if (Main.getInstance().getAbilityManager() != null) {
                    return StringUtil.copyPartialMatches(args[1], Main.getInstance().getAbilityManager().getAllLegendaries().stream().map(r -> r.id).toList(), new ArrayList<>());
                 }
            }
            if (sub.equals("deletelegendary")) {
                if (sender instanceof org.bukkit.entity.Player p) {
                    me.duong2012g.hungergamessss.model.Arena arena = Main.getInstance().getArenaManager().getArena(p);
                    if (arena == null) {
                        for (me.duong2012g.hungergamessss.model.Arena a : Main.getInstance().getArenaManager().getArenas().values()) {
                            if (a.getWorld() != null && a.getWorld().equals(p.getWorld())) {
                                arena = a;
                                break;
                            }
                        }
                    }
                    if (arena != null) {
                        List<String> items = arena.getConfiguredLegendaries().values().stream().distinct().toList();
                        return StringUtil.copyPartialMatches(args[1], items, new ArrayList<>());
                    }
                }
            }
            if (sub.equals("border")) {
                return StringUtil.copyPartialMatches(args[1], Arrays.asList("100", "200", "500"), new ArrayList<>());
            }
            if (sub.equals("lang")) {
                return StringUtil.copyPartialMatches(args[1], Arrays.asList("en", "vi", "ru", "fr"), new ArrayList<>());
            }
            
            // Configuration for arena (if first arg was arena name)
            if (Main.getInstance().getArenaManager().getArena(sub) != null) {
                return StringUtil.copyPartialMatches(args[1], Arrays.asList(
                    "border", "disable", "enable", "hardcore", "lifesteal", "nether", "pvp", "theend", "veinminer"
                ), new ArrayList<>());
            }
        }
        
        if (args.length == 3) {
            String sub = args[0].toLowerCase();
            if (sub.equals("border")) {
                return StringUtil.copyPartialMatches(args[2], Arrays.asList("30", "60", "120"), new ArrayList<>());
            }
            if (sub.equals("admin") && args[1].equalsIgnoreCase("give")) {
                 return null; // Player list
            }
            if (sub.equals("save") && args[1].equalsIgnoreCase("cornucopia")) {
                return Collections.singletonList(Main.getInstance().getMessageManager().getMessage("tab_create_name"));
            }
            if (sub.equals("create")) {
                return Collections.singletonList(Main.getInstance().getMessageManager().getMessage("tab_create_max"));
            }
            if (Main.getInstance().getArenaManager().getArena(sub) != null) {
                String setting = args[1].toLowerCase();
                 if (setting.equals("border")) {
                    return StringUtil.copyPartialMatches(args[2], Collections.singletonList("shrink"), new ArrayList<>());
                }
                if (Arrays.asList("nether", "theend", "hardcore", "lifesteal", "pvp", "veinminer").contains(setting)) {
                    return StringUtil.copyPartialMatches(args[2], Arrays.asList("true", "false"), new ArrayList<>());
                }
            }
        }

        if (args.length == 4) {
            String sub = args[0].toLowerCase();
            if (sub.equals("admin") && args[1].equalsIgnoreCase("give")) {
                 if (Main.getInstance().getAbilityManager() != null) {
                    return StringUtil.copyPartialMatches(args[3], Main.getInstance().getAbilityManager().getAllLegendaries().stream().map(r -> r.id).toList(), new ArrayList<>());
                 }
            }
        }

        return Collections.emptyList();
    }
}
