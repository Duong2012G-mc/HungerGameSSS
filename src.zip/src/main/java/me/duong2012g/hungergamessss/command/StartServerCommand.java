package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StartServerCommand implements CommandExecutor {
    private final Main plugin;

    public StartServerCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        if (!(sender instanceof Player)) {
            sender.sendMessage(mm.getMessage("only_players"));
            return true;
        }

        Player player = (Player) sender;
        
        if (!player.isOp()) {
            player.sendMessage(mm.getMessage("no_permission"));
            return true;
        }

        player.sendMessage(mm.getMessage("startserver_header"));
        player.sendMessage(mm.getMessage("startserver_shutting_down"));
        player.sendMessage(mm.getMessage("startserver_restart_hint"));

        // Schedule server restart
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            plugin.getServer().shutdown();
        }, 20L * 3); // 3 seconds delay

        return true;
    }
}
