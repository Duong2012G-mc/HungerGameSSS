package me.duong2012g.hungergamessss.command.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.command.SubCommand;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class LegendarySubCommand implements SubCommand {
    private final Main plugin;

    public LegendarySubCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (!player.isOp()) {
            player.sendMessage(plugin.getMessageManager().getMessage("no_permission"));
            return;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("setlegendary")) {
            if (args.length < 2) {
                player.sendMessage(plugin.getMessageManager().getMessage("hg_usage_setlegendary"));
                return;
            }
            String legendName = args[1];
            if (plugin.getAbilityManager().getLegendaryItem(legendName) == null) {
                player.sendMessage(plugin.getMessageManager().getMessage("legendary_not_found", Map.of("item", legendName)));
                return;
            }
            Arena arena = findArena(player);
            if (arena == null) {
                player.sendMessage(plugin.getMessageManager().getMessage("not_in_arena"));
                return;
            }
            arena.addLegendaryLocation(player.getLocation().getBlock().getLocation(), legendName);
            player.sendMessage(ChatColor.GREEN + "Set legendary spawn for " + legendName + "!");
            plugin.getArenaManager().saveArena(arena);
            if (plugin.getHologramManager() != null) plugin.getHologramManager().updateHolograms();
        } else if (sub.equals("deletelegendary")) {
            Arena arena = findArena(player);
            if (arena == null) {
                player.sendMessage(plugin.getMessageManager().getMessage("not_in_arena"));
                return;
            }
            Location ploc = player.getLocation();
            Location closest = null;
            double minDist = 5.0;
            String filterItem = args.length > 1 ? args[1] : null;

            for (Map.Entry<Location, String> entry : arena.getConfiguredLegendaries().entrySet()) {
                Location l = entry.getKey();
                String itemName = entry.getValue();
                if (filterItem != null && !itemName.equalsIgnoreCase(filterItem)) continue;
                if (l.getWorld().equals(ploc.getWorld()) && l.distance(ploc) < minDist) {
                    minDist = l.distance(ploc);
                    closest = l;
                }
            }

            if (closest != null) {
                arena.removeConfiguredLegendary(closest);
                player.sendMessage(ChatColor.GREEN + "Deleted nearby legendary spawn.");
                plugin.getArenaManager().saveArena(arena);
                if (plugin.getHologramManager() != null) {
                    plugin.getHologramManager().removeHologram(arena.getName(), closest);
                    plugin.getHologramManager().updateHolograms();
                }
            } else {
                player.sendMessage(plugin.getMessageManager().getMessage("no_legendary_nearby"));
            }
        }
    }

    private Arena findArena(Player player) {
        Arena arena = plugin.getArenaManager().getArena(player);
        if (arena == null) {
            for (Arena a : plugin.getArenaManager().getArenas().values()) {
                if (a.getWorld() != null && a.getWorld().equals(player.getWorld())) {
                    return a;
                }
            }
        }
        return arena;
    }
}
