package me.duong2012g.hungergamessss.command.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.command.SubCommand;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Optional;

public class JoinSubCommand implements SubCommand {
    private final Main plugin;

    public JoinSubCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) return;
        Player p = (Player) sender;
        
        String arenaName = args.length > 1 ? args[1] : null;
        Arena a = arenaName != null ? plugin.getArenaManager().getArena(arenaName) : plugin.getArenaManager().getArena(p);
        
        if (a == null) {
            Optional<Arena> open = plugin.getArenaManager().getArenas().values().stream()
                .filter(ar -> ar.getState() == MatchState.WAITING && ar.isEnabled())
                .findFirst();
            if (open.isPresent()) a = open.get();
            else {
                p.sendMessage(plugin.getMessageManager().getMessage("arena_not_found"));
                return;
            }
        }
        
        plugin.getMatchService().joinArena(p, a);
    }
}
