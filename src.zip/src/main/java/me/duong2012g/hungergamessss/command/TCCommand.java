package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.manager.MessageManager;
import me.duong2012g.hungergamessss.model.TeamData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class TCCommand implements CommandExecutor {
    private final Main plugin;

    public TCCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        MessageManager mm = plugin.getMessageManager();
        if (!(sender instanceof Player player)) {
            sender.sendMessage(mm.getMessage("only_players"));
            return true;
        }

        TeamData team = getTeamOf(player);
        if (team == null) {
            player.sendMessage(mm.getMessage("team_not_in"));
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(mm.getMessage("tc_usage"));
            return true;
        }

        String message = String.join(" ", args);
        String formatted = mm.getMessage("team_chat_format", java.util.Map.of(
            "player", player.getName(),
            "message", message
        ));
        for (Player p : team.getOnlinePlayers()) {
            p.sendMessage(formatted);
        }

        return true;
    }

    private TeamData getTeamOf(Player player) {
        return plugin.getTeamManager().getTeamOf(player);
    }
}
