package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.manager.PerformanceOptimizer;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

public class PerformanceCommand implements CommandExecutor {
    private final Main plugin;

    public PerformanceCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command!");
            return true;
        }

        Player player = (Player) sender;
        PerformanceOptimizer optimizer = plugin.getPerformanceOptimizer();

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "stats" -> showStats(player, optimizer);
            case "optimize" -> optimize(player, optimizer);
            case "reload" -> reload(player, optimizer);
            case "gc" -> garbageCollect(player);
            case "chunks" -> showChunks(player);
            case "monitor" -> toggleMonitoring(player, optimizer);
            default -> sendHelp(player);
        }

        return true;
    }

    private void sendHelp(Player player) {
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        player.sendMessage(mm.getMessage("perf_help_header"));
        player.sendMessage(mm.getMessage("perf_help_stats"));
        player.sendMessage(mm.getMessage("perf_help_optimize"));
        player.sendMessage(mm.getMessage("perf_help_reload"));
        player.sendMessage(mm.getMessage("perf_help_gc"));
        player.sendMessage(mm.getMessage("perf_help_chunks"));
        player.sendMessage(mm.getMessage("perf_help_monitor"));
    }

    private void showStats(Player player, PerformanceOptimizer optimizer) {
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        Map<String, Object> stats = optimizer.getPerformanceStats();
        player.sendMessage(mm.getMessage("perf_stats_header"));
        
        for (Map.Entry<String, Object> entry : stats.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            String valStr;
            
            if (value instanceof Number) {
                double num = ((Number) value).doubleValue();
                if (num > 1000) {
                    valStr = String.format("%.1f", num);
                } else {
                    valStr = String.format("%.0f", num);
                }
            } else {
                valStr = String.valueOf(value);
            }
            player.sendMessage(mm.getMessage("perf_stat_format", java.util.Map.of("key", key, "value", valStr)));
        }
    }

    private void optimize(Player player, PerformanceOptimizer optimizer) {
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        player.sendMessage(mm.getMessage("perf_running_opt"));
        optimizer.optimize();
        player.sendMessage(mm.getMessage("perf_opt_complete"));
    }

    private void reload(Player player, PerformanceOptimizer optimizer) {
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        player.sendMessage(mm.getMessage("perf_reloading_config"));
        optimizer.reloadConfig();
        player.sendMessage(mm.getMessage("perf_config_reloaded"));
    }

    private void garbageCollect(Player player) {
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        long before = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        System.gc();
        long after = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        
        long freed = (before - after) / 1024 / 1024; // MB
        player.sendMessage(mm.getMessage("perf_gc_complete"));
        player.sendMessage(mm.getMessage("perf_gc_freed", java.util.Map.of("amount", String.valueOf(freed))));
    }

    private void showChunks(Player player) {
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        int loadedChunks = player.getWorld().getLoadedChunks().length;
        int entities = player.getWorld().getEntities().size();
        
        player.sendMessage(mm.getMessage("perf_chunk_header"));
        player.sendMessage(mm.getMessage("perf_loaded_chunks", java.util.Map.of("count", String.valueOf(loadedChunks))));
        player.sendMessage(mm.getMessage("perf_entities_nearby", java.util.Map.of("count", String.valueOf(entities))));
        player.sendMessage(mm.getMessage("perf_your_chunk", java.util.Map.of("x", String.valueOf(player.getLocation().getChunk().getX()), "z", String.valueOf(player.getLocation().getChunk().getZ()))));
    }

    private void toggleMonitoring(Player player, PerformanceOptimizer optimizer) {
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        boolean enabled = optimizer.toggleMonitoring();
        
        if (enabled) {
            player.sendMessage(mm.getMessage("perf_monitoring_enabled"));
        } else {
            player.sendMessage(mm.getMessage("perf_monitoring_disabled"));
        }
    }
}
