package me.duong2012g.hungergamessss.command.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.command.SubCommand;
import me.duong2012g.hungergamessss.model.LegendaryRecipe;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.Map;

public class AdminSubCommand implements SubCommand {
    private final Main plugin;

    public AdminSubCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!sender.isOp()) {
            sender.sendMessage(plugin.getMessageManager().getMessage("no_permission"));
            return;
        }

        if (args.length < 2) return;

        String sub = args[1].toLowerCase();

        if (sub.equals("give") && args.length >= 4) {
            Player target = Bukkit.getPlayer(args[2]);
            if (target != null) {
                String itemName = String.join(" ", Arrays.copyOfRange(args, 3, args.length));
                LegendaryRecipe match = null;
                for (LegendaryRecipe r : plugin.getAbilityManager().getAllLegendaries()) {
                    if (r.id.equalsIgnoreCase(itemName) || ChatColor.stripColor(r.name).equalsIgnoreCase(itemName)) {
                        match = r;
                        break;
                    }
                }
                if (match != null) {
                    target.getInventory().addItem(match.createItem());
                    sender.sendMessage(ChatColor.GREEN + "Gave " + match.name + " to " + target.getName());
                } else {
                    sender.sendMessage(plugin.getMessageManager().getMessage("admin_item_not_found", Map.of("item", itemName)));
                }
            }
        } else if (sub.equals("reload")) {
            plugin.reloadConfig();
            plugin.getMessageManager().reload();
            sender.sendMessage(plugin.getMessageManager().getMessage("plugin_reloaded"));
        }
    }
}
