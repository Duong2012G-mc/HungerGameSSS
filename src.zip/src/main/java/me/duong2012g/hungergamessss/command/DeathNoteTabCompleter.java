package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class DeathNoteTabCompleter implements TabCompleter {

    private final Main plugin;

    public DeathNoteTabCompleter(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command,
                                      String alias, String[] args) {
        if (!(sender instanceof Player player)) return List.of();
        if (args.length != 1) return List.of();

        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        if (arena == null) return List.of();

        String partial = args[0].toLowerCase();
        List<String> names = new ArrayList<>();

        for (java.util.UUID uuid : arena.getPlayers()) {
            Player p = org.bukkit.Bukkit.getPlayer(uuid);
            if (p == null || p.equals(player)) continue;
            if (plugin.getTeamManager().isFriendlyFire(player, p)) continue;
            if (p.getName().toLowerCase().startsWith(partial)) names.add(p.getName());
        }
        return names;
    }
}
