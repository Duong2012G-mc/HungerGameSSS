package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class StructureCommand implements CommandExecutor {

    private final Main plugin;

    public StructureCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessageManager().getMessage("only_players"));
            return true;
        }

        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        if (plugin.getStructureManager() == null) {
            player.sendMessage(mm.getMessage("schematic_disabled"));
            return true;
        }

        if (args.length == 0) {
            Map<String, Object> stats = plugin.getStructureManager().getStats();
            
            player.sendMessage(mm.getMessage("struct_stats_header"));
            player.sendMessage(mm.getMessage("struct_total", java.util.Map.of("count", String.valueOf(stats.get("totalStructures")))));
            player.sendMessage(mm.getMessage("struct_placed", java.util.Map.of("count", String.valueOf(stats.get("placedCount")))));
            player.sendMessage("");
            player.sendMessage(mm.getMessage("struct_types_header"));
            player.sendMessage(mm.getMessage("struct_small", java.util.Map.of("count", String.valueOf(stats.get("smallCount")))));
            player.sendMessage(mm.getMessage("struct_medium", java.util.Map.of("count", String.valueOf(stats.get("mediumCount")))));
            player.sendMessage(mm.getMessage("struct_large", java.util.Map.of("count", String.valueOf(stats.get("largeCount")))));
            player.sendMessage(mm.getMessage("struct_massive", java.util.Map.of("count", String.valueOf(stats.get("massiveCount")))));
            player.sendMessage("");
            player.sendMessage(mm.getMessage("struct_weights"));
            return true;
        }

        if (args[0].equalsIgnoreCase("reset")) {
            plugin.getStructureManager().resetStructures();
            player.sendMessage(mm.getMessage("struct_reset"));
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            plugin.getStructureManager().reloadStructures();
            player.sendMessage(mm.getMessage("struct_reloaded"));
            return true;
        }

        if (args[0].equalsIgnoreCase("spawn")) {
            if (args.length < 2) {
                player.sendMessage(mm.getMessage("struct_spawn_usage"));
                return true;
            }
            int count;
            try {
                count = Integer.parseInt(args[1]);
                if (count <= 0 || count > 50) {
                    player.sendMessage("§cAmount must be between 1 and 50.");
                    return true;
                }
            } catch (NumberFormatException e) {
                player.sendMessage(mm.getMessage("invalid_number"));
                return true;
            }
            int radius = 1000;
            if (args.length >= 3) {
                try {
                    radius = Integer.parseInt(args[2]);
                    if (radius < 10 || radius > 10000) {
                        player.sendMessage("§cRadius must be between 10 and 10000.");
                        return true;
                    }
                } catch (NumberFormatException e) {
                    player.sendMessage(mm.getMessage("invalid_number"));
                    return true;
                }
            }
            
            plugin.getStructureManager().spawnStructures(player.getWorld(), count, radius);
            player.sendMessage(mm.getMessage("struct_spawning", java.util.Map.of("count", String.valueOf(count))));
            return true;
        }

        return false;
    }
}
