package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

/**
 * AutoFixCommand — DISABLED for safety.
 *
 * The original implementation had critical issues:
 *  1. Ran blocking file copy + HTTP download on the main server thread (server freeze risk).
 *  2. Hard-coded stale JAR name "HungerGamesSSS-1.15.jar" — current version is 4.6.0+.
 *  3. Generated config.yml with outdated keys (database.file, game.waiting-duration,
 *     structures.spawn-interval-ticks) not recognised by current code.
 *  4. Overwrote live plugin files with no backup.
 *
 * Disabled until rewritten with: async I/O, dynamic version detection,
 * pre-modification backups, and config generation from ConfigSchemaValidator.
 */
public class AutoFixCommand implements CommandExecutor {

    private static final String DISABLED_MSG =
        ChatColor.RED + "[AutoFix] This command is disabled pending a safety rewrite. " +
        ChatColor.GRAY + "See AutoFixCommand.java for details.";

    public AutoFixCommand(Main plugin) {
        // intentionally empty — no plugin reference needed while disabled
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        sender.sendMessage(DISABLED_MSG);
        return true;
    }
}
