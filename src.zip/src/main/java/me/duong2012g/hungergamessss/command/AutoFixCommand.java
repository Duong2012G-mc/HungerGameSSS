package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class AutoFixCommand implements CommandExecutor {
    private final Main plugin;

    public AutoFixCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessageManager().getMessage("only_players"));
            return true;
        }

        if (!player.isOp()) {
            player.sendMessage(plugin.getMessageManager().getMessage("no_permission"));
            return true;
        }

        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        player.sendMessage(mm.getMessage("autofix_header"));
        player.sendMessage(mm.getMessage("autofix_starting"));

        // Run in sync for file operations
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            try {
                // Step 1: Check current directory
                File currentDir = new File(".");
                player.sendMessage(ChatColor.GRAY + "Current directory: " + currentDir.getAbsolutePath());

                // Step 2: Download server.jar if missing
                File serverJar = new File("server.jar");
                if (!serverJar.exists()) {
                    player.sendMessage(mm.getMessage("autofix_downloading_paper"));
                    downloadPaperServer(player);
                    player.sendMessage(mm.getMessage("autofix_server_success"));
                } else {
                    player.sendMessage(mm.getMessage("autofix_server_exists"));
                }

                // Step 3: Copy plugin
                player.sendMessage(mm.getMessage("autofix_installing"));
                File sourcePlugin = new File("core-plugin/target/HungerGamesSSS-1.15.jar");
                File pluginsDir = new File("plugins");
                
                if (!pluginsDir.exists()) {
                    pluginsDir.mkdir();
                    player.sendMessage(mm.getMessage("autofix_created_plugins_dir"));
                }
                
                File targetPlugin = new File("plugins/HungerGamesSSS-1.15.jar");
                if (targetPlugin.exists()) {
                    targetPlugin.delete();
                    player.sendMessage(mm.getMessage("autofix_deleted_old"));
                }
                
                if (sourcePlugin.exists()) {
                    Files.copy(sourcePlugin.toPath(), targetPlugin.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    player.sendMessage(mm.getMessage("autofix_install_success"));
                } else {
                    player.sendMessage(mm.getMessage("autofix_source_not_found", java.util.Map.of("path", sourcePlugin.getAbsolutePath())));
                    return;
                }

                // Step 4: Create config
                player.sendMessage(mm.getMessage("autofix_creating_config"));
                createConfig(player);

                player.sendMessage(mm.getMessage("autofix_complete"));
                player.sendMessage(mm.getMessage("autofix_restart_hint"));
                
            } catch (Exception e) {
                player.sendMessage(mm.getMessage("autofix_error", java.util.Map.of("error", e.getMessage())));
                plugin.getLogger().severe("Auto fix error: " + e.getMessage());
                e.printStackTrace();
            }
        });

        return true;
    }

    private void downloadPaperServer(Player player) throws IOException {
        String paperUrl = "https://api.papermc.io/v2/projects/paper/versions/1.21.1/builds/118/downloads/paper-1.21.1-118.jar";
        URL url = new URL(paperUrl);
        
        player.sendMessage(ChatColor.GRAY + "Downloading from: " + paperUrl);
        
        try (var in = url.openStream()) {
            Files.copy(in, new File("server.jar").toPath(), StandardCopyOption.REPLACE_EXISTING);
            player.sendMessage(ChatColor.GRAY + "Download completed");
        }
    }

    private void createConfig(Player player) throws IOException {
        File configDir = new File("plugins/HungerGamesSSS");
        if (!configDir.exists()) {
            configDir.mkdir();
            player.sendMessage(ChatColor.GRAY + "Created config directory");
        }
        
        File configFile = new File(configDir, "config.yml");
        if (!configFile.exists()) {
            String config = """
                    language: en
                    database:
                      type: sqlite
                      file: database.db
                    world:
                      arena-world: world
                      border-size: 2000
                    game:
                      waiting-duration: 120
                      grace-duration: 300
                      main-duration: 1800
                      deathmatch-duration: 600
                    structures:
                      spawn-interval-ticks: 6000
                      spawn-chance: 0.2
                      min-distance-from-cornucopia: 100
                      min-distance-between: 200
                    teams:
                      max-players-per-team: 4
                      max-teams: 50
                      allow-team-chat: true
                      available-colors:
                        - RED
                        - BLUE
                        - GREEN
                        - YELLOW
                        - AQUA
                        - PURPLE
                        - WHITE
                        - GRAY
                    performance:
                      block-processing:
                        max-blocks-per-tick: 500
                      entity-management:
                        max-entities-per-chunk: 100
                      chunk-management:
                        unload-delay-ticks: 6000
                      memory-management:
                        cleanup-interval-ticks: 6000
                    """;
            
            Files.write(configFile.toPath(), config.getBytes());
            player.sendMessage(ChatColor.GREEN + "Configuration created successfully!");
        } else {
            player.sendMessage(ChatColor.GRAY + "Configuration already exists");
        }
    }
}
