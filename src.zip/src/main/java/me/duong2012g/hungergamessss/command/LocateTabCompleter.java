package me.duong2012g.hungergamessss.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.util.StringUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LocateTabCompleter implements TabCompleter {
    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            List<String> commonStructures = Arrays.asList(
                "blacksmith_starter_base_obeq21q2sw.nbt",
                "thepalaceoforderv2_no_ground_lq09vs7odg.nbt",
                "27913.schem"
            );
            return StringUtil.copyPartialMatches(args[0], commonStructures, new ArrayList<>());
        }
        return Collections.emptyList();
    }
}
