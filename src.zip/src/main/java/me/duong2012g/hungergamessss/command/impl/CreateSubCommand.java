package me.duong2012g.hungergamessss.command.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.command.SubCommand;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CreateSubCommand implements SubCommand {
    private final Main plugin;

    public CreateSubCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) return;
        Player p = (Player) sender;
        if (!p.isOp()) { p.sendMessage(plugin.getMessageManager().getMessage("no_permission")); return; }
        if (args.length < 3) { p.sendMessage(plugin.getMessageManager().getMessage("hg_usage_create")); return; }
        
        String baseName = args[1];
        if (!baseName.matches("[a-zA-Z0-9_-]{1,32}")) {
            p.sendMessage(ChatColor.RED + "Invalid arena name! Use only alphanumeric characters, underscores, and dashes (max 32).");
            return;
        }
        int max;
        try { max = Integer.parseInt(args[2]); } catch (NumberFormatException e) { p.sendMessage("Invalid number"); return; }
        
        // Check for advanced flag via command alias or additional arg?
        // Original used label.equalsIgnoreCase("//hg")
        // We'll pass it in args or use a simplified approach
        
        createArenaWithGoodLocation(p, baseName, max);
    }

    private void createArenaWithGoodLocation(Player p, String baseName, int max) {
        p.sendMessage(ChatColor.YELLOW + "Searching for location... (This may take a few seconds)");
        
        World w = Bukkit.getWorld(baseName);
        if (w == null) {
            w = Bukkit.createWorld(new WorldCreator(baseName));
        }
        final World world = w;

        plugin.getArenaManager().findSafeCornucopiaLocation(world, (loc) -> {
            p.teleport(loc);
            createAdvancedArena(p, baseName, max);
        });
    }

    private void createAdvancedArena(Player p, String baseName, int max) {
         Arena arena = new Arena(baseName);
         arena.setMaxPlayers(max);
         arena.setWorld(p.getWorld());
         arena.setCornucopia(p.getLocation());
         
         double radius = 70.0;
         Location center = p.getLocation();
         for (int i=0; i<max; i++) {
             double angle = 2 * Math.PI * i / max;
             double x = center.getX() + radius * Math.cos(angle);
             double z = center.getZ() + radius * Math.sin(angle);
             Location spawn = new Location(center.getWorld(), x, center.getY() + 3, z);
             spawn.setDirection(center.toVector().subtract(spawn.toVector()));
             arena.addConfiguredSpawn(spawn);
         }
         
         String style = plugin.getArenaManager().getPlayerStyle(p.getUniqueId());
         plugin.getArenaManager().addArena(arena);
         plugin.getArenaManager().buildCornucopia(arena, style);
         p.sendMessage(plugin.getMessageManager().getMessage("arena_created", java.util.Map.of("name", baseName)));
    }
}
