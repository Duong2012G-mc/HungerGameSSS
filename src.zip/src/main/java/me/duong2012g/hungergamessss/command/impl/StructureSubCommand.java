package me.duong2012g.hungergamessss.command.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.command.SubCommand;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.Map;

public class StructureSubCommand implements SubCommand {
    private final Main plugin;

    public StructureSubCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (!player.isOp()) return;

        String sub = args[0].toLowerCase();

        if (sub.equals("wand")) {
            ItemStack wand = new ItemStack(Material.GOLDEN_AXE);
            ItemMeta meta = wand.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ChatColor.GOLD + "Hoplite Wand");
                meta.setLore(Arrays.asList(ChatColor.GRAY + "Left click: Pos1", ChatColor.GRAY + "Right click: Pos2"));
                wand.setItemMeta(meta);
            }
            player.getInventory().addItem(wand);
            player.sendMessage(ChatColor.GREEN + "Gave selection wand.");
        } else if (sub.equals("save")) {
            if (args.length < 3 || !args[1].equalsIgnoreCase("cornucopia")) return;
            if (!plugin.getSelectionManager().hasSelection(player.getUniqueId())) {
                player.sendMessage(plugin.getMessageManager().getMessage("make_selection_first"));
                return;
            }
            Location[] sel = plugin.getSelectionManager().getSelection(player.getUniqueId());
            String name = args[2];
            plugin.getStructureManager().saveStructure("cornucopias/" + name, sel[0], sel[1]);
            player.sendMessage(plugin.getMessageManager().getMessage("cornucopia_saved", Map.of("name", name)));
        }
    }
}
