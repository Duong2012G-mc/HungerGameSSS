package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class WithdrawCommand implements CommandExecutor {
    private final Main plugin;

    public WithdrawCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(plugin.getMessageManager().getMessage("only_players"));
            return true;
        }

        Player player = (Player) sender;

        if (args.length != 1) {
            player.sendMessage(plugin.getMessageManager().getMessage("withdraw_usage"));
            return true;
        }

        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        if (arena == null) {
            player.sendMessage(plugin.getMessageManager().getMessage("withdraw_not_in_arena"));
            return true;
        }

        if (!arena.isLifestealEnabled()) {
            player.sendMessage(plugin.getMessageManager().getMessage("withdraw_lifesteal_disabled"));
            return true;
        }

        int amount;
        try {
            amount = Integer.parseInt(args[0]);
            if (amount <= 0) {
                player.sendMessage(plugin.getMessageManager().getMessage("withdraw_invalid_amount"));
                return true;
            }
        } catch (NumberFormatException e) {
            player.sendMessage(plugin.getMessageManager().getMessage("withdraw_invalid_amount"));
            return true;
        }

        double currentMaxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
        double healthToWithdraw = amount * 2.0;

        // Ensure player keeps at least 1 heart (2.0 health)
        if (currentMaxHealth - healthToWithdraw < 2.0) {
            player.sendMessage(plugin.getMessageManager().getMessage("withdraw_not_enough_hearts"));
            return true;
        }

        // Apply withdrawal
        player.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(currentMaxHealth - healthToWithdraw);
        
        // Give heart items
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        ItemStack heart = new ItemStack(Material.RED_DYE, amount);
        ItemMeta meta = heart.getItemMeta();
        if (meta != null) {
            String name = mm.getMessage("stolen_heart_name");
            if (name == null) name = "§c§lStolen Heart";
            meta.displayName(me.duong2012g.hungergamessss.util.ColorUtil.component(name));

            String loreLine = mm.getMessage("stolen_heart_lore");
            if (loreLine == null) loreLine = "§7Right-click to gain 1 max heart!";
            meta.lore(java.util.List.of(me.duong2012g.hungergamessss.util.ColorUtil.component(loreLine)));
            meta.getPersistentDataContainer().set(
                    new org.bukkit.NamespacedKey(plugin, "stolen_heart"),
                    org.bukkit.persistence.PersistentDataType.BYTE, (byte) 1);
            heart.setItemMeta(meta);
        }
        
        // Add to inventory or drop if full
        if (player.getInventory().firstEmpty() != -1) {
            player.getInventory().addItem(heart);
        } else {
            player.getWorld().dropItemNaturally(player.getLocation(), heart);
        }

        player.sendMessage(plugin.getMessageManager().getMessage("withdraw_success", Map.of("amount", String.valueOf(amount))));

        return true;
    }
}
