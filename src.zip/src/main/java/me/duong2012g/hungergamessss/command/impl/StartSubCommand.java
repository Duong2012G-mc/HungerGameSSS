package me.duong2012g.hungergamessss.command.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.command.SubCommand;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StartSubCommand implements SubCommand {
    private final Main plugin;

    public StartSubCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) return;
        Player p = (Player) sender;
        if (!p.isOp()) return;

        Integer countdown = args.length > 1 ? Integer.parseInt(args[1]) : 10;
        Arena startArena = plugin.getArenaManager().getArena(p);
        if (startArena != null) {
            plugin.getMatchService().startMatch(startArena, countdown);
            p.sendMessage(ChatColor.GREEN + "Starting match in " + countdown + "s...");
        }
    }
}
