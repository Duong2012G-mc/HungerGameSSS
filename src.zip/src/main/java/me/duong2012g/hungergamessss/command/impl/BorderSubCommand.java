package me.duong2012g.hungergamessss.command.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.command.SubCommand;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.ChatColor;
import org.bukkit.WorldBorder;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BorderSubCommand implements SubCommand {
    private final Main plugin;

    public BorderSubCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (!player.isOp()) {
            player.sendMessage(plugin.getMessageManager().getMessage("no_permission"));
            return;
        }

        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Usage: /hg border <radius> [seconds]");
            return;
        }

        Arena arena = plugin.getArenaManager().getArena(player);
        if (arena == null) {
            for (Arena a : plugin.getArenaManager().getArenas().values()) {
                if (a.getWorld() != null && a.getWorld().equals(player.getWorld())) {
                    arena = a;
                    break;
                }
            }
        }

        if (arena == null || arena.getWorld() == null) {
            player.sendMessage(plugin.getMessageManager().getMessage("not_in_arena"));
            return;
        }

        try {
            double radius = Double.parseDouble(args[1]);
            long seconds = args.length > 2 ? Long.parseLong(args[2]) : 0;

            WorldBorder border = arena.getWorld().getWorldBorder();
            border.setCenter(arena.getCornucopia());
            border.setSize(radius * 2, seconds);

            player.sendMessage(ChatColor.GREEN + "Border shrinking to radius " + radius + " (" + (radius * 2) + " diam) in " + seconds + "s.");
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Invalid number format.");
        }
    }
}
