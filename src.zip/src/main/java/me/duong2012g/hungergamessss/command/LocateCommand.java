package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LocateCommand implements CommandExecutor {

    private final Main plugin;

    public LocateCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessageManager().getMessage("only_players"));
            return true;
        }

        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();

        if (args.length == 0) {
            player.sendMessage(mm.getMessage("locate_usage"));
            player.sendMessage(mm.getMessage("locate_available"));
            player.sendMessage(mm.getMessage("locate_struct_item", java.util.Map.of("name", "blacksmith_starter_base_obeq21q2sw.nbt")));
            player.sendMessage(mm.getMessage("locate_struct_item", java.util.Map.of("name", "thepalaceoforderv2_no_ground_lq09vs7odg.nbt")));
            player.sendMessage(mm.getMessage("locate_struct_item", java.util.Map.of("name", "27913.schem")));
            return true;
        }

        String structureName = args[0].toLowerCase();
        
        if (plugin.getStructureManager() == null) {
            player.sendMessage(mm.getMessage("schematic_disabled"));
            return true;
        }

        // Find structure locations
        boolean found = false;
        for (var entry : plugin.getStructureManager().getPlacedStructures().entrySet()) {
            Location loc = entry.getKey();
            String fileName = entry.getValue().getName().toLowerCase();
            if (fileName.contains(structureName)) {
                player.sendMessage(mm.getMessage("locate_found", java.util.Map.of("name", entry.getValue().getName())));
                player.sendMessage(mm.getMessage("locate_location", java.util.Map.of(
                    "x", String.valueOf(loc.getBlockX()),
                    "y", String.valueOf(loc.getBlockY()),
                    "z", String.valueOf(loc.getBlockZ())
                )));
                player.sendMessage(mm.getMessage("locate_distance", java.util.Map.of("distance", String.valueOf(Math.round(player.getLocation().distance(loc))))));
                
                // Show compass direction
                String direction = getDirection(player.getLocation(), loc);
                player.sendMessage(mm.getMessage("locate_direction", java.util.Map.of("direction", direction)));
                
                found = true;
            }
        }

        if (!found) {
            player.sendMessage(mm.getMessage("locate_not_found", java.util.Map.of("name", structureName)));
            player.sendMessage(mm.getMessage("locate_try"));
        }

        return true;
    }

    private String getDirection(Location from, Location to) {
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        double angle = Math.toDegrees(Math.atan2(dz, dx));
        angle = (angle + 360) % 360;

        if (angle >= 337.5 || angle < 22.5) return "North";
        if (angle >= 22.5 && angle < 67.5) return "Northeast";
        if (angle >= 67.5 && angle < 112.5) return "East";
        if (angle >= 112.5 && angle < 157.5) return "Southeast";
        if (angle >= 157.5 && angle < 202.5) return "South";
        if (angle >= 202.5 && angle < 247.5) return "Southwest";
        if (angle >= 247.5 && angle < 292.5) return "West";
        if (angle >= 292.5 && angle < 337.5) return "Northwest";
        return "Unknown";
    }
}
