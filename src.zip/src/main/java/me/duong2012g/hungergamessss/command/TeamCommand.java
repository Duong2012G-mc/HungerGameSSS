package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.manager.MessageManager;
import me.duong2012g.hungergamessss.manager.TeamManager;
import me.duong2012g.hungergamessss.model.TeamData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class TeamCommand implements CommandExecutor, TabCompleter {
    private final Main plugin;

    public TeamCommand(Main plugin) {
        this.plugin = plugin;
    }


    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        MessageManager mm = Main.getInstance().getMessageManager();
        TeamManager tm = Main.getInstance().getTeamManager();
        
        if (!(sender instanceof Player player)) {
            sender.sendMessage(mm.getMessage("only_players"));
            return true;
        }

        if (args.length == 0) {
            sendHelp(player, mm);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "create" -> {
                if (args.length < 2) {
                    player.sendMessage(mm.getMessage("team_usage_create"));
                    return true;
                }
                String teamName = args[1];
                TeamData team = tm.createTeam(player, teamName);
                if (team == null) {
                    player.sendMessage(mm.getMessage("team_already_have"));
                    return true;
                }
                player.sendMessage(mm.getMessage("team_created", Map.of("team", teamName, "color", team.getColor().name())));
            }
            case "invite" -> {
                if (args.length < 2) {
                    player.sendMessage(mm.getMessage("team_usage_invite"));
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null || !target.isOnline()) {
                    player.sendMessage(mm.getMessage("player_not_found"));
                    return true;
                }
                TeamData team = tm.getTeamOf(player);
                if (team == null) {
                    player.sendMessage(mm.getMessage("team_not_in"));
                    return true;
                }
                if (!team.isLeader(player)) {
                    player.sendMessage(mm.getMessage("team_not_leader"));
                    return true;
                }
                if (team.getSize() >= Main.getInstance().getConfig().getInt("teams.max-players-per-team", 4)) {
                    player.sendMessage(mm.getMessage("team_full"));
                    return true;
                }
                tm.invitePlayer(player, target);
                target.sendMessage(mm.getMessage("team_invite_received", Map.of("team", team.getName(), "inviter", player.getName())));
                player.sendMessage(mm.getMessage("team_invite_sent", Map.of("player", target.getName())));
            }
            case "join" -> {
                if (args.length < 2) {
                    player.sendMessage(mm.getMessage("team_usage_join"));
                    return true;
                }
                Player inviter = Bukkit.getPlayer(args[1]);
                if (inviter == null || !inviter.isOnline()) {
                    player.sendMessage(mm.getMessage("player_not_found"));
                    return true;
                }
                
                if (!tm.hasInvite(player, inviter)) {
                    player.sendMessage(mm.getMessage("team_no_invite"));
                    return true;
                }
                
                TeamData team = tm.getTeamOf(inviter);
                if (team == null) {
                    player.sendMessage(mm.getMessage("team_not_exist"));
                    return true;
                }
                
                if (tm.joinTeam(player, inviter)) {
                    for (Player p : team.getOnlinePlayers()) {
                        p.sendMessage(mm.getMessage("team_joined", Map.of("player", player.getName(), "team", team.getName())));
                    }
                } else {
                    player.sendMessage(mm.getMessage("team_full"));
                }
            }
            case "leave" -> {
                TeamData team = tm.getTeamOf(player);
                if (team == null) {
                    player.sendMessage(mm.getMessage("team_not_in"));
                    return true;
                }
                
                boolean wasLeader = team.isLeader(player);
                String teamName = team.getName();
                
                // Notify before leaving/disbanding
                if (wasLeader) {
                     for (Player p : team.getOnlinePlayers()) {
                        p.sendMessage(mm.getMessage("team_disbanded", Map.of("team", teamName)));
                    }
                } else {
                    for (Player p : team.getOnlinePlayers()) {
                        if (!p.getUniqueId().equals(player.getUniqueId())) {
                            p.sendMessage(mm.getMessage("team_left", Map.of("player", player.getName(), "team", teamName)));
                        }
                    }
                }
                
                tm.leaveTeam(player);
                player.sendMessage(mm.getMessage("team_you_left", Map.of("team", teamName)));
            }
            case "kick" -> {
                if (args.length < 2) {
                    player.sendMessage(mm.getMessage("team_usage_kick"));
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null || !target.isOnline()) {
                    player.sendMessage(mm.getMessage("player_not_found"));
                    return true;
                }
                TeamData team = tm.getTeamOf(player);
                if (team == null) {
                    player.sendMessage(mm.getMessage("team_not_in"));
                    return true;
                }
                if (!team.isLeader(player)) {
                    player.sendMessage(mm.getMessage("team_not_leader"));
                    return true;
                }
                if (!team.isMember(target)) {
                    player.sendMessage(mm.getMessage("team_not_member", Map.of("player", target.getName())));
                    return true;
                }
                
                tm.kickPlayer(team, target);
                
                for (Player p : team.getOnlinePlayers()) {
                    p.sendMessage(mm.getMessage("team_kicked", Map.of("player", target.getName(), "team", team.getName())));
                }
                target.sendMessage(mm.getMessage("team_you_kicked", Map.of("team", team.getName())));
            }
            case "disband" -> {
                TeamData team = tm.getTeamOf(player);
                if (team == null) {
                    player.sendMessage(mm.getMessage("team_not_in"));
                    return true;
                }
                if (!team.isLeader(player)) {
                    player.sendMessage(mm.getMessage("team_not_leader"));
                    return true;
                }
                for (Player p : team.getOnlinePlayers()) {
                    p.sendMessage(mm.getMessage("team_disbanded", Map.of("team", team.getName())));
                }
                tm.disbandTeam(team);
                player.sendMessage(mm.getMessage("team_you_disbanded", Map.of("team", team.getName())));
            }
            case "info" -> {
                TeamData team = tm.getTeamOf(player);
                if (team == null) {
                    player.sendMessage(mm.getMessage("team_not_in"));
                    return true;
                }
                player.sendMessage(mm.getMessage("team_info_name", Map.of("color", team.getColor().toString(), "name", team.getName())));
                player.sendMessage(mm.getMessage("team_info_leader", Map.of("leader", Bukkit.getOfflinePlayer(team.getLeader()).getName())));
                player.sendMessage(mm.getMessage("team_info_members_header", Map.of("size", String.valueOf(team.getSize()), "max", String.valueOf(Main.getInstance().getConfig().getInt("teams.max-players-per-team", 4)))));
                for (UUID uuid : team.getPlayers()) {
                    String pName = Bukkit.getOfflinePlayer(uuid).getName();
                    player.sendMessage(mm.getMessage("team_info_member_item", Map.of("player", pName != null ? pName : "Unknown")));
                }
            }
            default -> sendHelp(player, mm);
        }

        return true;
    }
    
    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            return List.of("create", "invite", "join", "leave", "kick", "disband", "info");
        }
        return Collections.emptyList();
    }

    private void sendHelp(Player player, MessageManager mm) {
        player.sendMessage(mm.getMessage("team_help_header"));
        player.sendMessage(mm.getMessage("team_help_create"));
        player.sendMessage(mm.getMessage("team_help_invite"));
        player.sendMessage(mm.getMessage("team_help_join"));
        player.sendMessage(mm.getMessage("team_help_leave"));
        player.sendMessage(mm.getMessage("team_help_kick"));
    }
}
