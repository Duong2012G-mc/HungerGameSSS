package me.duong2012g.hungergamessss.command.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.command.SubCommand;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.Map;

public class ArenaSubCommand implements SubCommand {
    private final Main plugin;

    public ArenaSubCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (!player.isOp()) {
            player.sendMessage(plugin.getMessageManager().getMessage("no_permission"));
            return;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("setcornucopia")) {
            if (args.length < 2) {
                player.sendMessage(ChatColor.YELLOW + "Available Styles: ultimate, speedsilver, classic, ancient, void, royal, industrial, modern, crystal, jungle, end, nether, grand");
                return;
            }
            String style = args[1].toLowerCase();
            plugin.getArenaManager().setPlayerStyle(player.getUniqueId(), style);
            player.sendMessage(ChatColor.GREEN + "Selected Cornucopia Style: " + ChatColor.GOLD + style);
        } else if (sub.equals("delete")) {
            if (args.length < 2) {
                player.sendMessage(plugin.getMessageManager().getMessage("delete_usage"));
                return;
            }
            String name = args[1];
            if (plugin.getArenaManager().getArena(name) == null) {
                player.sendMessage(plugin.getMessageManager().getMessage("arena_not_found"));
                return;
            }
            plugin.getArenaManager().removeArena(name);
            player.sendMessage(plugin.getMessageManager().getMessage("arena_deleted", Map.of("name", name)));
        }
    }
}
