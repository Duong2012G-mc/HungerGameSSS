package me.duong2012g.hungergamessss.command.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.command.SubCommand;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class LobbySubCommand implements SubCommand {
    private final Main plugin;

    public LobbySubCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;

        String sub = args[0].toLowerCase();

        if (sub.equals("setlobby")) {
            if (!player.isOp()) {
                player.sendMessage(plugin.getMessageManager().getMessage("no_permission"));
                return;
            }
            plugin.getLobbyManager().setLobbyLocation(player.getLocation());
            player.sendMessage(plugin.getMessageManager().getMessage("lobby_set_success"));
        } else {
            // "lobby"
            Location lobby = plugin.getLobbyManager().getLobbyLocation();
            if (lobby == null) {
                player.sendMessage(plugin.getMessageManager().getMessage("lobby_not_set"));
                return;
            }
            player.teleport(lobby);
            plugin.getLobbyManager().giveLobbyItems(player);
            player.sendMessage(plugin.getMessageManager().getMessage("lobby_teleport"));
        }
    }
}
