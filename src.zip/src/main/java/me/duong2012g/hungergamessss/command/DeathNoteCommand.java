package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.Ability;
import me.duong2012g.hungergamessss.ability.impl.DeathNote;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /dn <username> — Death Note kill command.
 *
 * Usage: Hold the Death Note in main hand, then type /dn <playerName>.
 * The target must be in the same arena and currently alive.
 * Cooldown: 25s per target | Uses: 3 total (book destroyed after 3 kills).
 */
public class DeathNoteCommand implements CommandExecutor {

    private final Main plugin;

    public DeathNoteCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player writer)) {
            sender.sendMessage("§cOnly players can use the Death Note.");
            return true;
        }

        if (args.length < 1) {
            writer.sendMessage("§8[§0☠§8] §7Usage: §f/dn <playerName>");
            writer.sendMessage("§8[§0☠§8] §7Hold the Death Note in your main hand.");
            return true;
        }

        String targetName = args[0];

        // Retrieve the DeathNote ability instance from the registry
        Ability ability = plugin.getAbilityManager().getRegistry().getAbility("Death Note");
        if (!(ability instanceof DeathNote deathNote)) {
            writer.sendMessage("§cDeath Note ability is not loaded.");
            return true;
        }

        // Delegate all validation and kill logic to the ability
        deathNote.executeKill(writer, targetName);
        return true;
    }
}
