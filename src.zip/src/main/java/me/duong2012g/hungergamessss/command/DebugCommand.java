package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.io.File;

public class DebugCommand implements CommandExecutor {
    private final Main plugin;

    public DebugCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        
        if (!(sender instanceof Player player)) {
            sender.sendMessage(mm.getMessage("only_players"));
            return true;
        }

        if (!player.isOp()) {
            player.sendMessage(mm.getMessage("no_permission"));
            return true;
        }

        player.sendMessage(mm.getMessage("debug_header"));
        
        // Check current directory
        File currentDir = new File(".");
        player.sendMessage(mm.getMessage("debug_curr_dir", java.util.Map.of("path", currentDir.getAbsolutePath())));
        
        // Check plugin files
        File pluginJar = new File("core-plugin/target/HungerGamesSSS-1.15.jar");
        player.sendMessage(mm.getMessage("debug_jar_exists", java.util.Map.of("exists", String.valueOf(pluginJar.exists()), "path", pluginJar.getAbsolutePath())));
        
        // Check plugins directory
        File pluginsDir = new File("plugins");
        player.sendMessage(mm.getMessage("debug_plugins_dir", java.util.Map.of("exists", String.valueOf(pluginsDir.exists()))));
        
        if (pluginsDir.exists()) {
            File[] pluginFiles = pluginsDir.listFiles();
            if (pluginFiles != null) {
                player.sendMessage(mm.getMessage("debug_files_in_plugins"));
                for (File file : pluginFiles) {
                    player.sendMessage(mm.getMessage("debug_file_item", java.util.Map.of(
                        "name", file.getName(),
                        "size", String.valueOf(file.length())
                    )));
                }
            }
        }
        
        // Check server jar
        File serverJar = new File("server.jar");
        player.sendMessage(mm.getMessage("debug_server_jar", java.util.Map.of("exists", String.valueOf(serverJar.exists()), "path", serverJar.getAbsolutePath())));
        
        // Check config
        File configDir = new File("plugins/HungerGamesSSS");
        File configFile = new File(configDir, "config.yml");
        player.sendMessage(mm.getMessage("debug_config_dir", java.util.Map.of("exists", String.valueOf(configDir.exists()))));
        player.sendMessage(mm.getMessage("debug_config_file", java.util.Map.of("exists", String.valueOf(configFile.exists()))));
        
        // Test plugin loading
        player.sendMessage(mm.getMessage("debug_plugin_status", java.util.Map.of("status", (plugin.isEnabled() ? "ENABLED" : "DISABLED"))));
        
        return true;
    }
}
