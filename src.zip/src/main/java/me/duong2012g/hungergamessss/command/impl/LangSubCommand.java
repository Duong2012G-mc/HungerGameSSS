package me.duong2012g.hungergamessss.command.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.command.SubCommand;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class LangSubCommand implements SubCommand {
    private final Main plugin;

    public LangSubCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!sender.isOp()) {
            sender.sendMessage(plugin.getMessageManager().getMessage("no_permission"));
            return;
        }

        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /hg lang <en|vi|ru|fr|es|de|pt|zh|ja|ko>");
            return;
        }

        String newLang = args[1].toLowerCase();
        java.util.Set<String> supported = new java.util.HashSet<>(java.util.Arrays.asList(
                "en", "vi", "ru", "fr", "es", "de", "pt", "zh", "ja", "ko"
        ));
        if (!supported.contains(newLang)) {
            sender.sendMessage(ChatColor.RED + "Invalid language! Supported: en, vi, ru, fr, es, de, pt, zh, ja, ko");
            return;
        }

        plugin.getConfig().set("language", newLang);
        plugin.saveConfig();
        plugin.getMessageManager().reload();
        sender.sendMessage(plugin.getMessageManager().getMessage("plugin_reloaded"));
    }
}
