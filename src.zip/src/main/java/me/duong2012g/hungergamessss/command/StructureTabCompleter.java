package me.duong2012g.hungergamessss.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.util.StringUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class StructureTabCompleter implements TabCompleter {
    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            List<String> subcommands = Arrays.asList("reset", "reload", "spawn", "stats");
            return StringUtil.copyPartialMatches(args[0], subcommands, new ArrayList<>());
        }
        
        if (args.length == 2 && args[0].equalsIgnoreCase("spawn")) {
            return Collections.singletonList("<count>");
        }
        
        if (args.length == 3 && args[0].equalsIgnoreCase("spawn")) {
            return Collections.singletonList("<radius>");
        }
        
        return Collections.emptyList();
    }
}
