package me.duong2012g.hungergamessss.command;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.LegendaryRecipe;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.util.*;
import java.util.concurrent.CompletableFuture;

public class HGCommand implements CommandExecutor {
    private final Main plugin;
    private final Map<String, SubCommand> subCommands = new HashMap<>();

    public HGCommand(Main plugin) {
        this.plugin = plugin;
        registerSubCommands();
    }

    private void registerSubCommands() {
        subCommands.put("join", new me.duong2012g.hungergamessss.command.impl.JoinSubCommand(plugin));
        subCommands.put("start", new me.duong2012g.hungergamessss.command.impl.StartSubCommand(plugin));
        subCommands.put("create", new me.duong2012g.hungergamessss.command.impl.CreateSubCommand(plugin));
        
        // New implemented sub-commands
        me.duong2012g.hungergamessss.command.impl.LobbySubCommand lobby = new me.duong2012g.hungergamessss.command.impl.LobbySubCommand(plugin);
        subCommands.put("lobby", lobby);
        subCommands.put("setlobby", lobby);

        me.duong2012g.hungergamessss.command.impl.AdminSubCommand admin = new me.duong2012g.hungergamessss.command.impl.AdminSubCommand(plugin);
        subCommands.put("admin", admin);
        subCommands.put("reload", admin);

        subCommands.put("border", new me.duong2012g.hungergamessss.command.impl.BorderSubCommand(plugin));
        subCommands.put("lang", new me.duong2012g.hungergamessss.command.impl.LangSubCommand(plugin));

        me.duong2012g.hungergamessss.command.impl.LegendarySubCommand legend = new me.duong2012g.hungergamessss.command.impl.LegendarySubCommand(plugin);
        subCommands.put("setlegendary", legend);
        subCommands.put("deletelegendary", legend);

        me.duong2012g.hungergamessss.command.impl.ArenaSubCommand arena = new me.duong2012g.hungergamessss.command.impl.ArenaSubCommand(plugin);
        subCommands.put("setcornucopia", arena);
        subCommands.put("delete", arena);

        me.duong2012g.hungergamessss.command.impl.StructureSubCommand struct = new me.duong2012g.hungergamessss.command.impl.StructureSubCommand(plugin);
        subCommands.put("wand", struct);
        subCommands.put("save", struct);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            return true;
        }
        if (args.length == 0) {
            p.sendMessage(plugin.getMessageManager().getMessage("usage_hg"));
            return true;
        }
        
        String subName = args[0].toLowerCase();
        SubCommand sub = subCommands.get(subName);
        
        if (sub != null) {
            sub.execute(sender, args);
            return true;
        }

        p.sendMessage(plugin.getMessageManager().getMessage("usage_hg"));
        return true;
    }

    private void createAdvancedArena(Player p, String baseName, int max) {
         // Simplified version of decompiled logic
         Arena arena = new Arena(baseName);
         arena.setMaxPlayers(max);
         arena.setWorld(p.getWorld());
         arena.setCornucopia(p.getLocation());
         
         double radius = 70.0;
         Location center = p.getLocation();
         for (int i=0; i<max; i++) {
             double angle = 2 * Math.PI * i / max;
             double x = center.getX() + radius * Math.cos(angle);
             double z = center.getZ() + radius * Math.sin(angle);
             Location spawn = new Location(center.getWorld(), x, center.getY() + 3, z);
             // Look at center
             spawn.setDirection(center.toVector().subtract(spawn.toVector()));
             arena.addConfiguredSpawn(spawn);
         }
         
         String style = plugin.getArenaManager().getPlayerStyle(p.getUniqueId());
         plugin.getArenaManager().addArena(arena);
         plugin.getArenaManager().buildCornucopia(arena, style);
          p.sendMessage(plugin.getMessageManager().getMessage("arena_created", java.util.Map.of("name", baseName)));
    }

    private void createArenaWithGoodLocation(Player p, String baseName, int max) {
        p.sendMessage(ChatColor.YELLOW + "Searching for location... (This may take a few seconds)");
        
        World w = Bukkit.getWorld(baseName);
        if (w == null) {
            w = Bukkit.createWorld(new WorldCreator(baseName));
        }
        final World world = w;

        // Use the new safe/async search
        plugin.getArenaManager().findSafeCornucopiaLocation(world, (loc) -> {
            p.teleport(loc);
            createAdvancedArena(p, baseName, max);
        });
    }
}
