package me.duong2012g.hungergamessss.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import me.duong2012g.hungergamessss.model.TeamData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Logger;

public class DatabaseManager {
    private final Main plugin;
    private final Logger log;
    private HikariDataSource dataSource;
    private final String type;
    private final Map<UUID, CompletableFuture<Void>> saveChain = new ConcurrentHashMap<>();
    private final Map<String, CompletableFuture<Void>> arenaSaveChain = new ConcurrentHashMap<>();

    public DatabaseManager(Main plugin) {
        this.plugin = plugin;
        this.log = plugin.getLogger();
        this.type = plugin.getConfig().getString("database.type", "sqlite").toLowerCase();
        connect();
        createTables();
        updateSchema();
    }

    private void connect() {
        try {
            HikariConfig config = new HikariConfig();
            if (type.equals("sqlite")) {
                String sqliteFile = plugin.getConfig().getString("database.sqlite-file", "database.db");
                config.setJdbcUrl("jdbc:sqlite:" + plugin.getDataFolder().getPath() + "/" + sqliteFile);
                config.setDriverClassName("org.sqlite.JDBC");
            } else {
                String host = plugin.getConfig().getString("database.mysql.host", "localhost");
                int port = plugin.getConfig().getInt("database.mysql.port", 3306);
                String database = plugin.getConfig().getString("database.mysql.database", "hungergames");
                String username = plugin.getConfig().getString("database.mysql.username", "root");
                String password = plugin.getConfig().getString("database.mysql.password", "");
                
                config.setJdbcUrl("jdbc:mysql://" + host + ":" + port + "/" + database);
                config.setUsername(username);
                config.setPassword(password);
                config.addDataSourceProperty("cachePrepStmts", "true");
                config.addDataSourceProperty("prepStmtCacheSize", "250");
                config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
            }
            
            config.setMaximumPoolSize(10);
            config.setConnectionTimeout(30000); // 30 seconds
            config.setLeakDetectionThreshold(60000); // 60 seconds
            
            dataSource = new HikariDataSource(config);
            log.info("Connected to " + type.toUpperCase() + " database with connection pooling.");
        } catch (Exception e) {
            log.severe("Failed to connect to database: " + e.getMessage());
        }
    }

    private void createTables() {
        if (dataSource == null) {
            log.severe("Cannot create tables: No database connection available.");
            return;
        }
        try (Connection connection = dataSource.getConnection();
             Statement stmt = connection.createStatement()) {
            // Arenas
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS arenas (
                    id VARCHAR(36) PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    state VARCHAR(20) NOT NULL,
                    timer INT DEFAULT 0,
                    max_players INT DEFAULT 24,
                    lifesteal BOOLEAN DEFAULT 0,
                    nether BOOLEAN DEFAULT 0,
                    the_end BOOLEAN DEFAULT 0,
                    hardcore BOOLEAN DEFAULT 0,
                    pvp BOOLEAN DEFAULT 1,
                    veinminer BOOLEAN DEFAULT 0,
                    enabled BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """);
            // Players
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS players (
                    uuid VARCHAR(36) PRIMARY KEY,
                    name VARCHAR(16) NOT NULL,
                    kills INT DEFAULT 0,
                    deaths INT DEFAULT 0,
                    wins INT DEFAULT 0,
                    losses INT DEFAULT 0,
                    games_played INT DEFAULT 0,
                    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """);
            // Teams
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS teams (
                    id VARCHAR(36) PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    leader_uuid VARCHAR(36) NOT NULL,
                    color VARCHAR(20) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """);
            // Team members
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS team_members (
                    team_uuid VARCHAR(36) NOT NULL,
                    player_uuid VARCHAR(36) NOT NULL,
                    PRIMARY KEY (team_uuid, player_uuid),
                    FOREIGN KEY (team_uuid) REFERENCES teams(id) ON DELETE CASCADE,
                    FOREIGN KEY (player_uuid) REFERENCES players(uuid) ON DELETE CASCADE
                )
            """);
            // Arena players
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS arena_players (
                    arena_id VARCHAR(36) NOT NULL,
                    player_uuid VARCHAR(36) NOT NULL,
                    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (arena_id, player_uuid),
                    FOREIGN KEY (arena_id) REFERENCES arenas(id) ON DELETE CASCADE,
                    FOREIGN KEY (player_uuid) REFERENCES players(uuid) ON DELETE CASCADE
                )
            """);
            
            // Arena Spawns
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS arena_spawns (
                    arena_id VARCHAR(36) NOT NULL,
                    world VARCHAR(100) NOT NULL,
                    x DOUBLE NOT NULL,
                    y DOUBLE NOT NULL,
                    z DOUBLE NOT NULL,
                    pitch FLOAT NOT NULL,
                    yaw FLOAT NOT NULL,
                    FOREIGN KEY (arena_id) REFERENCES arenas(id) ON DELETE CASCADE
                )
            """);

            // Arena Legendaries
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS arena_legendaries (
                    arena_id VARCHAR(36) NOT NULL,
                    world VARCHAR(100) NOT NULL,
                    x DOUBLE NOT NULL,
                    y DOUBLE NOT NULL,
                    z DOUBLE NOT NULL,
                    item_name VARCHAR(100) NOT NULL,
                    FOREIGN KEY (arena_id) REFERENCES arenas(id) ON DELETE CASCADE
                )
            """);
            log.info("Database tables verified/created.");
        } catch (SQLException e) {
            log.severe("Failed to create tables: " + e.getMessage());
        }
    }

    private void updateSchema() {
        if (dataSource == null) return;
        try (Connection connection = dataSource.getConnection();
             Statement stmt = connection.createStatement()) {
            
            DatabaseMetaData dbm = connection.getMetaData();

            // ── Columns that belong on the `arenas` table ──────────────────────────
            String[] arenaColumns = {
                "max_players INT DEFAULT 24",
                "lifesteal BOOLEAN DEFAULT 0",
                "nether BOOLEAN DEFAULT 0",
                "the_end BOOLEAN DEFAULT 0",
                "hardcore BOOLEAN DEFAULT 0",
                "pvp BOOLEAN DEFAULT 1",
                "veinminer BOOLEAN DEFAULT 0",
                "enabled BOOLEAN DEFAULT 1"
            };

            for (String colInfo : arenaColumns) {
                String colName = colInfo.split(" ")[0];
                try (ResultSet rs = dbm.getColumns(null, null, "arenas", colName)) {
                    if (!rs.next()) {
                        stmt.execute("ALTER TABLE arenas ADD COLUMN " + colInfo);
                    }
                }
            }

            // ── Columns that belong on the `players` table ─────────────────────────
            // BUG FIX: games_played is a player stat — was previously (incorrectly)
            // being added to the `arenas` table, causing save/load failures.
            String[] playerColumns = {
                "games_played INT DEFAULT 0"
            };

            for (String colInfo : playerColumns) {
                String colName = colInfo.split(" ")[0];
                try (ResultSet rs = dbm.getColumns(null, null, "players", colName)) {
                    if (!rs.next()) {
                        stmt.execute("ALTER TABLE players ADD COLUMN " + colInfo);
                    }
                }
            }

        } catch (SQLException e) {
            log.warning("Failed to update schema: " + e.getMessage());
        }
    }

    public void saveArena(Arena arena) {
        if (dataSource == null) {
            log.warning("Cannot save arena: no database connection");
            return;
        }

        // Snapshot collections before async call to avoid ConcurrentModificationException
        final String arenaName = arena.getName();
        final String stateName = arena.getState().name();
        final int timer = arena.getTimer();
        final int maxPlayers = arena.getMaxPlayers();
        final boolean lifesteal = arena.isLifestealEnabled();
        final boolean nether = arena.isNetherEnabled();
        final boolean end = arena.isTheEndEnabled();
        final boolean hardcore = arena.isHardcoreEnabled();
        final boolean pvp = arena.isPvpEnabled();
        final boolean veinminer = arena.isVeinminerEnabled();
        final boolean enabled = arena.isEnabled();
        
        final List<org.bukkit.Location> spawns = new java.util.ArrayList<>(arena.getConfiguredSpawns());
        final Map<org.bukkit.Location, String> legendaries = new java.util.HashMap<>(arena.getLegendaryLocations());
        final List<UUID> players = new java.util.ArrayList<>(arena.getPlayers());
        final long start = System.currentTimeMillis();

        arenaSaveChain.compute(arenaName, (id, currentChain) -> {
            Runnable saveTask = () -> {
                try (Connection connection = dataSource.getConnection()) {
                    connection.setAutoCommit(false);
                    try {
                        // Save main arena data
                        String insertArenaQuery = type.equals("sqlite") ? 
                            "INSERT OR REPLACE INTO arenas (id, name, state, timer, max_players, lifesteal, nether, the_end, hardcore, pvp, veinminer, enabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)" :
                            "REPLACE INTO arenas (id, name, state, timer, max_players, lifesteal, nether, the_end, hardcore, pvp, veinminer, enabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                        try (PreparedStatement ps = connection.prepareStatement(insertArenaQuery)) {
                            ps.setString(1, arenaName);
                            ps.setString(2, arenaName);
                            ps.setString(3, stateName);
                            ps.setInt(4, timer);
                            ps.setInt(5, maxPlayers);
                            ps.setBoolean(6, lifesteal);
                            ps.setBoolean(7, nether);
                            ps.setBoolean(8, end);
                            ps.setBoolean(9, hardcore);
                            ps.setBoolean(10, pvp);
                            ps.setBoolean(11, veinminer);
                            ps.setBoolean(12, enabled);
                            ps.executeUpdate();
                        }

                        // CS-01: Use captured world name
                        String worldName = spawns.isEmpty() ? null : spawns.get(0).getWorld().getName();

                        // Save Spawns
                        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM arena_spawns WHERE arena_id = ?")) {
                            ps.setString(1, arenaName);
                            ps.executeUpdate();
                        }
                        if (!spawns.isEmpty()) {
                            try (PreparedStatement ps = connection.prepareStatement("INSERT INTO arena_spawns (arena_id, world, x, y, z, pitch, yaw) VALUES (?, ?, ?, ?, ?, ?, ?)")) {
                                for (org.bukkit.Location loc : spawns) {
                                    ps.setString(1, arenaName);
                                    ps.setString(2, worldName != null ? worldName : loc.getWorld().getName());
                                    ps.setDouble(3, loc.getX());
                                    ps.setDouble(4, loc.getY());
                                    ps.setDouble(5, loc.getZ());
                                    ps.setFloat(6, loc.getPitch());
                                    ps.setFloat(7, loc.getYaw());
                                    ps.addBatch();
                                }
                                ps.executeBatch();
                            }
                        }

                        // Save Legendaries
                        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM arena_legendaries WHERE arena_id = ?")) {
                            ps.setString(1, arenaName);
                            ps.executeUpdate();
                        }
                        if (!legendaries.isEmpty()) {
                            try (PreparedStatement ps = connection.prepareStatement("INSERT INTO arena_legendaries (arena_id, world, x, y, z, item_name) VALUES (?, ?, ?, ?, ?, ?)")) {
                                for (Map.Entry<org.bukkit.Location, String> entry : legendaries.entrySet()) {
                                    org.bukkit.Location loc = entry.getKey();
                                    ps.setString(1, arenaName);
                                    ps.setString(2, loc.getWorld().getName());
                                    ps.setDouble(3, loc.getX());
                                    ps.setDouble(4, loc.getY());
                                    ps.setDouble(5, loc.getZ());
                                    ps.setString(6, entry.getValue());
                                    ps.addBatch();
                                }
                                ps.executeBatch();
                            }
                        }

                        // Save Players
                        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM arena_players WHERE arena_id = ?")) {
                            ps.setString(1, arenaName);
                            ps.executeUpdate();
                        }
                        if (!players.isEmpty()) {
                            try (PreparedStatement ps = connection.prepareStatement("INSERT INTO arena_players (arena_id, player_uuid) VALUES (?, ?)")) {
                                for (UUID uuid : players) {
                                    ps.setString(1, arenaName);
                                    ps.setString(2, uuid.toString());
                                    ps.addBatch();
                                }
                                ps.executeBatch();
                            }
                        }

                        connection.commit();
                        long elapsed = System.currentTimeMillis() - start;
                        log.info(String.format("Successfully saved arena '%s' to %s (Took %dms, S:%d, L:%d, P:%d)", 
                            arenaName, type.toUpperCase(), elapsed, spawns.size(), legendaries.size(), players.size()));
                    } catch (SQLException e) {
                        connection.rollback();
                        throw e;
                    } finally {
                        connection.setAutoCommit(true);
                    }
                } catch (SQLException e) {
                    log.warning("Failed to save arena '" + arenaName + "': " + e.getMessage());
                }
            };

            if (currentChain == null || currentChain.isDone()) {
                return CompletableFuture.runAsync(saveTask, runnable -> Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable));
            } else {
                return currentChain.thenRunAsync(saveTask, runnable -> Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable));
            }
        });
    }

    public void saveAllArenas() {
        for (Arena arena : plugin.getArenaManager().getArenas().values()) {
            saveArena(arena);
        }
    }

    public void createArena(String name, int max) {
        // CS-01: Input sanitization for SQL injection prevention
        if (!name.matches("[a-zA-Z0-9_-]{1,32}")) {
            log.warning("Invalid arena name: " + name + ". Use only alphanumeric characters, underscores, and dashes (max 32).");
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection connection = dataSource.getConnection();
                 PreparedStatement ps = connection.prepareStatement("""
                        INSERT INTO arenas (id, name, state, timer, max_players, lifesteal, nether, the_end, hardcore, pvp, veinminer, enabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """)) {
                ps.setString(1, name);
                ps.setString(2, name);
                ps.setString(3, MatchState.WAITING.name());
                ps.setInt(4, 0);
                ps.setInt(5, max);
                ps.setBoolean(6, false);
                ps.setBoolean(7, false);
                ps.setBoolean(8, false);
                ps.setBoolean(9, false);
                ps.setBoolean(10, true);
                ps.setBoolean(11, false);
                ps.setBoolean(12, true);
                ps.executeUpdate();
            } catch (SQLException e) {
                log.warning("Failed to create arena: " + e.getMessage());
            }
        });
    }

    public void deleteArena(String name) {
        // CS-01: Input sanitization for SQL injection prevention
        if (!name.matches("[a-zA-Z0-9_-]{1,32}")) {
            log.warning("Invalid arena name for deletion: " + name);
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection connection = dataSource.getConnection();
                 PreparedStatement ps = connection.prepareStatement("""
                        DELETE FROM arenas WHERE id = ?
                    """)) {
                ps.setString(1, name);
                ps.executeUpdate();
            } catch (SQLException e) {
                log.warning("Failed to delete arena: " + e.getMessage());
            }
        });
    }

    public void loadArenas(me.duong2012g.hungergamessss.manager.ArenaManager arenaManager) {
        if (dataSource == null) return;
        try (Connection connection = dataSource.getConnection();
             Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT name FROM arenas");
            while (rs.next()) {
                String name = rs.getString("name");
                Arena arena = new Arena(name);
                loadArena(arena);
                arenaManager.addArena(arena);
                log.info("Loaded arena: " + name);
            }
        } catch (SQLException e) {
            log.warning("Failed to load arenas: " + e.getMessage());
        }
    }

    public void loadArena(Arena arena) {
        try (Connection connection = dataSource.getConnection()) {
            // Load main data
            try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM arenas WHERE id = ?")) {
                ps.setString(1, arena.getName());
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    try {
                        MatchState state = MatchState.valueOf(rs.getString("state"));
                        // If server crashed during STARTING, reset to WAITING
                        if (state == MatchState.STARTING) {
                            state = MatchState.WAITING;
                        }
                        arena.setState(state);
                    } catch (IllegalArgumentException e) {
                        arena.setState(MatchState.WAITING);
                    }
                    arena.setTimer(rs.getInt("timer"));
                    arena.setMaxPlayers(rs.getInt("max_players"));
                    arena.setLifestealEnabled(rs.getBoolean("lifesteal"));
                    arena.setNetherEnabled(rs.getBoolean("nether"));
                    arena.setTheEndEnabled(rs.getBoolean("the_end"));
                    arena.setHardcoreEnabled(rs.getBoolean("hardcore"));
                    arena.setPvpEnabled(rs.getBoolean("pvp"));
                    arena.setVeinminerEnabled(rs.getBoolean("veinminer"));
                    arena.setEnabled(rs.getBoolean("enabled"));
                }
            }

            // Load Spawns
            try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM arena_spawns WHERE arena_id = ?")) {
                ps.setString(1, arena.getName());
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    String worldName = rs.getString("world");
                    org.bukkit.World world = Bukkit.getWorld(worldName);
                    if (world == null) {
                        // B-16: Check if world folder exists to prevent auto-creating empty worlds
                        java.io.File worldDir = new java.io.File(Bukkit.getWorldContainer(), worldName);
                        if (!worldDir.exists()) {
                            plugin.getLogger().warning("World folder for " + worldName + " is missing! Skipping spawn load for arena " + arena.getName());
                            continue;
                        }
                        try {
                            world = Bukkit.createWorld(new org.bukkit.WorldCreator(worldName));
                            plugin.getLogger().info("Loaded world for arena spawn: " + worldName);
                        } catch (Exception e) {
                            plugin.getLogger().warning("Could not load world " + worldName + ": " + e.getMessage());
                        }
                    }
                    
                    if (world != null) {
                        org.bukkit.Location loc = new org.bukkit.Location(world, rs.getDouble("x"), rs.getDouble("y"), rs.getDouble("z"), rs.getFloat("yaw"), rs.getFloat("pitch"));
                        arena.addConfiguredSpawn(loc);
                    }
                }
            }

            // Load Legendaries
            try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM arena_legendaries WHERE arena_id = ?")) {
                ps.setString(1, arena.getName());
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    org.bukkit.World world = Bukkit.getWorld(rs.getString("world"));
                    if (world != null) {
                        org.bukkit.Location loc = new org.bukkit.Location(world, rs.getDouble("x"), rs.getDouble("y"), rs.getDouble("z"));
                        arena.addLegendaryLocation(loc, rs.getString("item_name"));
                    }
                }
            }

            // Load Players
            try (PreparedStatement ps = connection.prepareStatement("SELECT player_uuid FROM arena_players WHERE arena_id = ?")) {
                ps.setString(1, arena.getName());
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    UUID uuid = UUID.fromString(rs.getString("player_uuid"));
                    // FIX H-05: loadPlayer already creates a GamePlayer via new GamePlayer(uuid)
                    // Ensure player is registered in both arena gamePlayers map and arenaManager
                    arena.loadPlayer(uuid);
                    plugin.getArenaManager().registerPlayer(uuid, arena);
                    // Mark alive so checkWin() and EntityDamageListener work correctly after reload
                    me.duong2012g.hungergamessss.model.GamePlayer gp = arena.getGamePlayer(uuid);
                    if (gp != null) gp.setAlive(true);
                }
            }
        } catch (SQLException e) {
            log.warning("Failed to load arena: " + e.getMessage());
        }
    }

    public void savePlayerStats(Player player) {
        if (dataSource == null) return;
        UUID uuid = player.getUniqueId();
        final String name = player.getName();
        me.duong2012g.hungergamessss.model.PlayerData data = plugin.getPlayerManager().getPlayerData(player);
        if (data == null) return;

        final int kills = data.getKills();
        final int deaths = data.getDeaths();
        final int wins = data.getWins();
        final int losses = data.getLosses();
        final int gamesPlayed = data.getGamesPlayed();

        // B-11: Prevent race condition using a per-player save chain
        saveChain.compute(uuid, (id, currentChain) -> {
            if (currentChain == null || currentChain.isDone()) {
                return CompletableFuture.runAsync(() -> executeSave(uuid, name, kills, deaths, wins, losses, gamesPlayed), 
                    runnable -> Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable));
            } else {
                return currentChain.thenRunAsync(() -> executeSave(uuid, name, kills, deaths, wins, losses, gamesPlayed),
                    runnable -> Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable));
            }
        });
    }

    private void executeSave(UUID uuid, String name, int kills, int deaths, int wins, int losses, int gamesPlayed) {
        String query;
        if (type.equals("sqlite")) {
            query = """
                INSERT INTO players (uuid, name, kills, deaths, wins, losses, games_played, last_seen) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(uuid) DO UPDATE SET 
                name = EXCLUDED.name, 
                kills = EXCLUDED.kills, 
                deaths = EXCLUDED.deaths, 
                wins = EXCLUDED.wins, 
                losses = EXCLUDED.losses,
                games_played = EXCLUDED.games_played,
                last_seen = EXCLUDED.last_seen
            """;
        } else {
            query = """
                INSERT INTO players (uuid, name, kills, deaths, wins, losses, games_played, last_seen) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON DUPLICATE KEY UPDATE 
                name = VALUES(name), 
                kills = VALUES(kills), 
                deaths = VALUES(deaths), 
                wins = VALUES(wins), 
                losses = VALUES(losses),
                games_played = VALUES(games_played),
                last_seen = CURRENT_TIMESTAMP
            """;
        }

        try (Connection connection = dataSource.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, name);
            ps.setInt(3, kills);
            ps.setInt(4, deaths);
            ps.setInt(5, wins);
            ps.setInt(6, losses);
            ps.setInt(7, gamesPlayed);
            ps.executeUpdate();
            if (plugin.getConfig().getBoolean("database.debug-logging", false)) {
                log.info("Saved stats for player: " + name);
            }
        } catch (SQLException e) {
            log.warning("Failed to save player stats for " + name + ": " + e.getMessage());
        }
    }

    /**
     * Thread-safe variant for join flow:
     * query DB off-thread, then apply PlayerData changes back on the main thread.
     */
    public void loadPlayerStatsAsync(Player player) {
        if (dataSource == null) return;
        final UUID uuid = player.getUniqueId();

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            int kills = 0;
            int deaths = 0;
            int wins = 0;
            int losses = 0;
            int gamesPlayed = 0;
            boolean found = false;

            try (Connection connection = dataSource.getConnection();
                 PreparedStatement ps = connection.prepareStatement("SELECT kills, deaths, wins, losses, games_played FROM players WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    kills = rs.getInt("kills");
                    deaths = rs.getInt("deaths");
                    wins = rs.getInt("wins");
                    losses = rs.getInt("losses");
                    gamesPlayed = rs.getInt("games_played");
                    found = true;
                }
            } catch (SQLException e) {
                log.warning("Failed to load player stats async: " + e.getMessage());
            }

            if (!found) return;

            final int finalKills = kills;
            final int finalDeaths = deaths;
            final int finalWins = wins;
            final int finalLosses = losses;
            final int finalGamesPlayed = gamesPlayed;

            Bukkit.getScheduler().runTask(plugin, () -> {
                Player online = Bukkit.getPlayer(uuid);
                if (online == null || !online.isOnline()) return;

                me.duong2012g.hungergamessss.model.PlayerData data = plugin.getPlayerManager().getPlayerData(online);
                data.setKills(finalKills);
                data.setDeaths(finalDeaths);
                data.setWins(finalWins);
                data.setLosses(finalLosses);
                data.setGamesPlayed(finalGamesPlayed);
            });
        });
    }

    public void loadPlayerStats(Player player) {
        if (dataSource == null) return;
        UUID uuid = player.getUniqueId();
        try (Connection connection = dataSource.getConnection();
             PreparedStatement ps = connection.prepareStatement("SELECT kills, deaths, wins, losses, games_played FROM players WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                me.duong2012g.hungergamessss.model.PlayerData data = plugin.getPlayerManager().getPlayerData(player);
                data.setKills(rs.getInt("kills"));
                data.setDeaths(rs.getInt("deaths"));
                data.setWins(rs.getInt("wins"));
                data.setLosses(rs.getInt("losses"));
                data.setGamesPlayed(rs.getInt("games_played"));
            }
        } catch (SQLException e) {
            log.warning("Failed to load player stats: " + e.getMessage());
        }
    }

    public void loadTeams(me.duong2012g.hungergamessss.manager.TeamManager teamManager) {
        if (dataSource == null) return;
        try (Connection connection = dataSource.getConnection();
             Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT * FROM teams");
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                String leaderUuid = rs.getString("leader_uuid");
                String colorStr = rs.getString("color");
                
                try {
                    UUID leader = UUID.fromString(leaderUuid);
                    me.duong2012g.hungergamessss.model.TeamData team = new me.duong2012g.hungergamessss.model.TeamData(name, org.bukkit.ChatColor.valueOf(colorStr), plugin.getConfig().getInt("teams.max-players-per-team", 4));
                    
                    // Force set leader if needed, but TeamData constructor sets leader?
                    // TeamData(name, color, max) doesn't take leader.
                    // We need to add leader.
                    // But TeamData.addPlayer sets leader if empty.
                    // So we add leader first.
                    
                    // Load members
                    try (PreparedStatement psMembers = connection.prepareStatement("SELECT player_uuid FROM team_members WHERE team_uuid = ?")) {
                        psMembers.setString(1, id);
                        ResultSet rsMembers = psMembers.executeQuery();
                        while (rsMembers.next()) {
                            UUID memberUuid = UUID.fromString(rsMembers.getString("player_uuid"));
                            team.addPlayer(memberUuid);
                        }
                    }
                    
                    // Ensure leader is set correctly (addPlayer sets it if empty, but we might have loaded members in random order)
                    team.setLeader(leader);
                    
                    // Add to manager
                    teamManager.addTeam(team);
                    log.info("Loaded team: " + name);
                } catch (Exception e) {
                    log.warning("Failed to load team " + id + ": " + e.getMessage());
                }
            }
        } catch (SQLException e) {
            log.warning("Failed to load teams: " + e.getMessage());
        }
    }

    public void saveTeam(TeamData team) {
        if (dataSource == null) { log.warning("Cannot save team: no database connection"); return; }
        
        // Snapshot
        final UUID leaderId = team.getLeader();
        final String teamName = team.getName();
        final String colorName = team.getColor().name();
        final List<UUID> members = new java.util.ArrayList<>(team.getPlayers());

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection connection = dataSource.getConnection()) {
                connection.setAutoCommit(false);
                try {
                    // Delete existing members first
                    try (PreparedStatement psDel = connection.prepareStatement("DELETE FROM team_members WHERE team_uuid = ?")) {
                        psDel.setString(1, leaderId.toString());
                        psDel.executeUpdate();
                    }

                    String insertTeamQuery = type.equals("sqlite") ? 
                        "INSERT OR REPLACE INTO teams (id, name, leader_uuid, color) VALUES (?, ?, ?, ?)" :
                        "REPLACE INTO teams (id, name, leader_uuid, color) VALUES (?, ?, ?, ?)";

                    try (PreparedStatement ps = connection.prepareStatement(insertTeamQuery)) {
                        ps.setString(1, leaderId.toString());
                        ps.setString(2, teamName);
                        ps.setString(3, leaderId.toString());
                        ps.setString(4, colorName);
                        ps.executeUpdate();
                    }
                    
                    // Save members
                    if (!members.isEmpty()) {
                        try (PreparedStatement ps2 = connection.prepareStatement("INSERT INTO team_members (team_uuid, player_uuid) VALUES (?, ?)")) {
                            for (UUID member : members) {
                                ps2.setString(1, leaderId.toString());
                                ps2.setString(2, member.toString());
                                ps2.addBatch();
                            }
                            ps2.executeBatch();
                        }
                    }
                    connection.commit();
                } catch (SQLException e) {
                    connection.rollback();
                    throw e;
                } finally {
                    connection.setAutoCommit(true);
                }
            } catch (SQLException e) {
                log.warning("Failed to save team asynchronously: " + e.getMessage());
            }
        });
    }
    
    public void deleteTeam(UUID leaderId) {
        if (dataSource == null) { log.warning("Cannot delete team: no database connection"); return; }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection connection = dataSource.getConnection()) {
                try (PreparedStatement ps = connection.prepareStatement("DELETE FROM teams WHERE id = ?")) {
                    ps.setString(1, leaderId.toString());
                    ps.executeUpdate();
                }
            } catch (SQLException e) {
                log.warning("Failed to delete team: " + e.getMessage());
            }
        });
    }


    /**
     * FIX M-09: Previous implementation executed a JDBC query synchronously on the
     * calling thread. When called from a command handler or event on the main thread
     * this blocked the server tick for the entire query duration.
     *
     * Now returns a CompletableFuture so callers can attach a callback:
     * <pre>
     *   db.getPlayerStatsAsync(uuid).thenAccept(stats -> {
     *       Bukkit.getScheduler().runTask(plugin, () -> player.sendMessage(...));
     *   });
     * </pre>
     *
     * The old synchronous method is kept as a package-private helper for internal
     * uses that already run on an async thread (e.g. inside saveChain callbacks).
     */
    public java.util.concurrent.CompletableFuture<Map<String, Object>> getPlayerStatsAsync(UUID uuid) {
        return java.util.concurrent.CompletableFuture.supplyAsync(
            () -> getPlayerStatsSync(uuid),
            runnable -> Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable)
        );
    }

    /** Synchronous variant — only call from an already-async context. */
    Map<String, Object> getPlayerStatsSync(UUID uuid) {
        Map<String, Object> stats = new HashMap<>();
        if (dataSource == null) return stats;
        try (Connection connection = dataSource.getConnection();
             PreparedStatement ps = connection.prepareStatement("""
                SELECT kills, deaths, wins, losses FROM players WHERE uuid = ?
            """)) {
            ps.setString(1, uuid.toString());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                stats.put("kills", rs.getInt("kills"));
                stats.put("deaths", rs.getInt("deaths"));
                stats.put("wins", rs.getInt("wins"));
                stats.put("losses", rs.getInt("losses"));
            }
        } catch (SQLException e) {
            log.warning("Failed to get player stats: " + e.getMessage());
        }
        return stats;
    }

    /** @deprecated Use {@link #getPlayerStatsAsync(UUID)} to avoid main-thread blocking. */
    @Deprecated
    public Map<String, Object> getPlayerStats(UUID uuid) {
        return getPlayerStatsSync(uuid);
    }

    /**
     * Wait for pending async save chains (player + arena) before closing datasource.
     */
    public void awaitPendingSaves(long timeoutMillis) {
        List<CompletableFuture<Void>> pending = new ArrayList<>();
        pending.addAll(saveChain.values());
        pending.addAll(arenaSaveChain.values());
        pending.removeIf(f -> f == null || f.isDone());
        if (pending.isEmpty()) return;

        CompletableFuture<Void> all = CompletableFuture.allOf(pending.toArray(new CompletableFuture[0]));
        try {
            all.get(timeoutMillis, TimeUnit.MILLISECONDS);
            log.info("Completed " + pending.size() + " pending database save task(s) before shutdown.");
        } catch (TimeoutException e) {
            log.warning("Timed out waiting for database save tasks (" + pending.size() + " pending).");
        } catch (Exception e) {
            log.warning("Error waiting for database save tasks: " + e.getMessage());
        }
    }

    public void close() {
        try {
            awaitPendingSaves(10000L);
            if (dataSource != null && !dataSource.isClosed()) {
                dataSource.close();
                log.info("Database connection pool closed.");
            }
        } catch (Exception e) {
            log.warning("Failed to close database: " + e.getMessage());
        }
    }

    public HikariDataSource getDataSource() {
        return dataSource;
    }
}
