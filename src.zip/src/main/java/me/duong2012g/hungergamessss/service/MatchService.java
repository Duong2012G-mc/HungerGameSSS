package me.duong2012g.hungergamessss.service;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.events.ArenaStartEvent;
import me.duong2012g.hungergamessss.manager.CornucopiaBuilder;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

public class MatchService {
    private final Main plugin;
    private final CornucopiaBuilder cornucopiaBuilder;
    private final Map<String, List<Block>> arenaCages = new java.util.concurrent.ConcurrentHashMap<>();

    // ARCH-MS-01: Per-arena task handles so they can be cancelled cleanly on reset
    private final Map<String, org.bukkit.scheduler.BukkitTask> borderTasks     = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<String, org.bukkit.scheduler.BukkitTask> feastTasks      = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<String, org.bukkit.scheduler.BukkitTask> deathmatchTasks = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<String, org.bukkit.scheduler.BukkitTask> countdownTasks  = new java.util.concurrent.ConcurrentHashMap<>();

    private static final long TICKS_PER_SECOND = 20L;
    private static final long HARDCORE_KICK_DELAY = 20L;

    public MatchService(Main plugin) {
        this.plugin = plugin;
        this.cornucopiaBuilder = new CornucopiaBuilder(plugin);
    }

    // ── FSM Transition Handler ────────────────────────────────────────────────

    /**
     * ARCH-MS-01: Central FSM transition method. All arena state changes MUST go
     * through here instead of calling {@code arena.setState()} directly.
     * This ensures every transition fires the correct lifecycle hooks:
     *   – cancels tasks that no longer apply to the new state
     *   – fires the appropriate custom event
     *   – updates scoreboards
     */
    public void transition(Arena arena, MatchState newState) {
        MatchState old = arena.getState();
        if (old == newState) return;
        arena.setState(newState);

        if (plugin.getConfig().getBoolean("debug", false)) {
            plugin.getLogger().info("[FSM] Arena '" + arena.getName() + "' " + old + " → " + newState);
        }

        switch (newState) {
            case STARTING -> {
                cancelTask(countdownTasks, arena.getName());
            }
            case PLAYING -> {
                Bukkit.getPluginManager().callEvent(new me.duong2012g.hungergamessss.events.ArenaStartEvent(arena));
                scheduleBorderTask(arena);
                scheduleFeastTask(arena);
            }
            case DEATHMATCH -> {
                cancelTask(borderTasks, arena.getName());
                cancelTask(feastTasks, arena.getName());
                scheduleDeathmatchTask(arena);
                Bukkit.getPluginManager().callEvent(
                        new me.duong2012g.hungergamessss.events.ArenaDeathmatchEvent(arena));
            }
            case ENDING -> {
                cancelTask(borderTasks, arena.getName());
                cancelTask(feastTasks, arena.getName());
                cancelTask(deathmatchTasks, arena.getName());
                cancelTask(countdownTasks, arena.getName());
            }
            case WAITING -> {
                cancelAllTasksFor(arena.getName());
            }
        }

        if (plugin.getScoreboardManager() != null) {
            plugin.getScoreboardManager().updateScoreboards(arena);
        }
    }

    private void cancelTask(Map<String, org.bukkit.scheduler.BukkitTask> map, String key) {
        org.bukkit.scheduler.BukkitTask t = map.remove(key);
        if (t != null && !t.isCancelled()) t.cancel();
    }

    private void cancelAllTasksFor(String arenaName) {
        cancelTask(borderTasks, arenaName);
        cancelTask(feastTasks, arenaName);
        cancelTask(deathmatchTasks, arenaName);
        cancelTask(countdownTasks, arenaName);
    }

    // ── BorderTask ────────────────────────────────────────────────────────────

    /**
     * ARCH-MS-02: Encapsulates the border-shrink schedule in a dedicated runnable.
     * Previously inlined inside the main game loop; now a self-cancelling task that
     * stops when the arena leaves PLAYING state.
     */
    private void scheduleBorderTask(Arena arena) {
        cancelTask(borderTasks, arena.getName());
        if (arena.getWorld() == null) return;

        int phaseSeconds   = plugin.getConfig().getInt("game.border-shrink-phase-seconds", 300);
        int phaseShrink    = plugin.getConfig().getInt("game.border-shrink-per-phase", 50);
        double minSize     = plugin.getConfig().getDouble("game.border-min-size", 20.0);
        double initialSize = plugin.getConfig().getDouble("game.border-initial-size", 1000.0);

        arena.getWorld().getWorldBorder().setSize(initialSize);

        org.bukkit.scheduler.BukkitTask task = new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                if (arena.getState() != MatchState.PLAYING) { cancel(); return; }
                elapsed += phaseSeconds;
                double current = arena.getWorld().getWorldBorder().getSize();
                double next = Math.max(minSize, current - phaseShrink);
                // Smooth shrink over the phase duration
                arena.getWorld().getWorldBorder().setSize(next, phaseSeconds);
                arena.broadcast(plugin.getMessageManager().getMessage(
                        "border_shrinking", Map.of("size", String.format("%.0f", next))));
            }
        }.runTaskTimer(plugin, phaseSeconds * TICKS_PER_SECOND, phaseSeconds * TICKS_PER_SECOND);
        borderTasks.put(arena.getName(), task);
    }

    // ── FeastTask ─────────────────────────────────────────────────────────────

    /**
     * ARCH-MS-02: Schedules the feast event as a standalone task. The feast delay
     * is read from config; the task fires exactly once then cancels itself.
     */
    private void scheduleFeastTask(Arena arena) {
        cancelTask(feastTasks, arena.getName());

        long feastDelaySeconds = plugin.getConfig().getLong("game.feast-delay-seconds", 180L);

        org.bukkit.scheduler.BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (arena.getState() != MatchState.PLAYING) return;
                if (plugin.getFeastManager() != null) {
                    plugin.getFeastManager().spawnFeast(arena);
                    arena.broadcast(plugin.getMessageManager().getMessage("feast_spawning"));
                }
                cancel();
            }
        }.runTaskLater(plugin, feastDelaySeconds * TICKS_PER_SECOND);
        feastTasks.put(arena.getName(), task);
    }

    // ── DeathmatchTask ────────────────────────────────────────────────────────

    /**
     * ARCH-MS-02: Teleports all remaining players to the deathmatch zone and starts
     * a rapid-border shrink. Encapsulated as a discrete task for clean cancellation.
     */
    private void scheduleDeathmatchTask(Arena arena) {
        cancelTask(deathmatchTasks, arena.getName());

        org.bukkit.scheduler.BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (arena.getState() != MatchState.DEATHMATCH) { cancel(); return; }
                // Teleport remaining alive players to cornucopia centre
                Location centre = arena.getCornucopia();
                if (centre == null) return;
                for (UUID uuid : arena.getPlayers()) {
                    Player p = Bukkit.getPlayer(uuid);
                    if (p != null && !arena.getSpectators().contains(uuid)) {
                        p.teleport(centre);
                        p.sendTitle(plugin.getMessageManager().getMessage("deathmatch_title"),
                                plugin.getMessageManager().getMessage("deathmatch_subtitle"), 0, 60, 20);
                    }
                }
                // Rapid shrink: collapse to 10x10 in 60 seconds
                if (arena.getWorld() != null)
                    arena.getWorld().getWorldBorder().setSize(10.0, 60L);
                cancel();
            }
        }.runTaskLater(plugin, 20L); // small delay so state is stable
        deathmatchTasks.put(arena.getName(), task);
    }


    public boolean joinArena(Player player, Arena arena) {
        try {
            if (arena.getState() != MatchState.WAITING && arena.getState() != MatchState.STARTING) {
                player.sendMessage(plugin.getMessageManager().getMessage("game_already_started"));
                return false;
            }
            if (arena.getPlayers().size() >= arena.getMaxPlayers()) {
                player.sendMessage(plugin.getMessageManager().getMessage("arena_full"));
                return false;
            }

            if (arena.getWorld() == null) {
                player.sendMessage(plugin.getMessageManager().getMessage("world_not_found", Map.of("world", arena.getName())));
                return false;
            }

            arena.addPlayer(player);
            plugin.getArenaManager().registerPlayer(player.getUniqueId(), arena);

            // Determine spawn location
            // BUG-NEW-05p2: Use atomic extraction to prevent duplicate spawns
            Location spawn = arena.extractRandomSpawn();
            if (spawn == null) {
                spawn = arena.getWorld().getSpawnLocation();
            }

            // Teleport and set survival (adventure is default in lobby, but cages need survival/adventure toggle)
            Location teleportLoc = spawn.clone().add(0.5, 0.5, 0.5);
            player.teleport(teleportLoc);
            player.getInventory().clear();
            player.setGameMode(GameMode.ADVENTURE);
            player.setHealth(20);
            player.setFoodLevel(20);

            // Create glass cage
            createJoinCage(player, arena, spawn);

            // Broadcast join
            String msg = plugin.getMessageManager().getMessage("player_join_arena", 
                Map.of("player", player.getName(), 
                       "current", String.valueOf(arena.getPlayers().size()), 
                       "max", String.valueOf(arena.getMaxPlayers())));
            
            for (UUID uuid : arena.getPlayers()) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null) {
                    p.sendMessage(msg);
                    if (plugin.getScoreboardManager() != null) {
                        plugin.getScoreboardManager().updateScoreboard(p, arena);
                    }
                }
            }

            return true;
        } catch (Exception e) {
            plugin.getLogger().severe("Error joining arena " + arena.getName() + ": " + e.getMessage());
            e.printStackTrace();
            player.sendMessage(plugin.getMessageManager().getMessage("game_join_error"));
            return false;
        }
    }

    private void createJoinCage(Player player, Arena arena, Location loc) {
        Location base = loc.clone().getBlock().getLocation();
        List<Location> cageLocs = new ArrayList<>();
        
        // 3x3 Base Floor
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                cageLocs.add(base.clone().add(x, -1, z));
            }
        }
        
        // Walls (3 blocks high)
        for (int y = 0; y < 3; y++) {
            for (int x = -1; x <= 1; x++) {
                cageLocs.add(base.clone().add(x, y, 1));
                cageLocs.add(base.clone().add(x, y, -1));
            }
            for (int z = -1; z <= 1; z++) {
                cageLocs.add(base.clone().add(1, y, z));
                cageLocs.add(base.clone().add(-1, y, z));
            }
        }
        
        // Roof
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                cageLocs.add(base.clone().add(x, 3, z));
            }
        }
        
        List<Block> storedBlocks = arenaCages.computeIfAbsent(arena.getName(), k -> new ArrayList<>());
        for (Location l : cageLocs) {
            // Use setBlockSmart to track for final reset
            plugin.getArenaManager().setBlockSmart(l.getWorld(), l, Material.GLASS, arena);
            storedBlocks.add(l.getBlock());
        }
    }

    public void startArena(Arena arena) {
        List<Player> players = new ArrayList<>();
        synchronized (arena.getPlayers()) { // Fix Race Condition
            for (UUID uuid : arena.getPlayers()) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    players.add(p);
                }
            }
        }
        startMatch(arena, players);
    }

    public void startMatch(final Arena arena, final int countdownSeconds) {
        if (arena.getState() != MatchState.WAITING && arena.getState() != MatchState.STARTING) {
            return;
        }
        arena.setState(MatchState.STARTING);
        if (plugin.getScoreboardManager() != null) {
            plugin.getScoreboardManager().updateScoreboards(arena);
        }
        if (countdownSeconds > 0) {
            new BukkitRunnable() {
                int count = countdownSeconds;
                public void run() {
                    if (arena.getState() != MatchState.STARTING) {
                        this.cancel();
                        return;
                    }
                    if (this.count > 0) {
                        for (UUID uuid : arena.getPlayers()) {
                            Player p = Bukkit.getPlayer(uuid);
                            if (p != null) {
                                p.sendTitle(ChatColor.YELLOW + "Starting in", ChatColor.GOLD.toString() + this.count, 0, 25, 5);
                                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 2.0f);
                            }
                        }
                        this.count--;
                    } else {
                        startArena(arena);
                        this.cancel();
                    }
                }
            }.runTaskTimer(plugin, 0L, 20L);
        } else {
            startArena(arena);
        }
    }

    public void startMatch(Arena arena, List<Player> players) {
        if (players.isEmpty()) return;
        
        arena.setState(MatchState.STARTING);
        plugin.getArenaManager().saveArena(arena); // Save state change
        
        // NOTE: ArenaStartEvent is fired in releasePlayers() when state actually becomes PLAYING
        
        // 1. Build Cornucopia & Setup Altars
        Location arenaCenter = arena.getCornucopia();
        if (arenaCenter == null) {
            arenaCenter = new Location(arena.getWorld(), 0, 64, 0); // Default center
            arena.setCornucopia(arenaCenter);
        }
        final Location center = arenaCenter;

        setupCornucopiaAndAltars(arena, players, center, () -> {
            // 2. Teleport players to circle
            teleportPlayersAndCreateCages(arena, players, center);
            
            // 3. Countdown
            startCountdown(arena, players);
        });
    }

    private void setupCornucopiaAndAltars(Arena arena, List<Player> players, Location center, Runnable onComplete) {
        // Initialize builder for this specific match
        cornucopiaBuilder.setWorld(arena.getWorld());
        cornucopiaBuilder.setCenter(center);
        cornucopiaBuilder.setRadius(75); // Default clearance radius

        // 1. Build Cornucopia Structure
        cornucopiaBuilder.buildCornucopia(center, null, players.size(), arena, () -> {
            // 2. Setup Altars
            arena.clearTemporaryLegendaries();
            
            if (!arena.getConfiguredLegendaries().isEmpty()) {
                // Use pre-configured locations
                plugin.getLogger().info("Using " + arena.getConfiguredLegendaries().size() + " configured legendary locations for arena " + arena.getName());
            } else {
                // Auto-generate random legendaries at cardinal points
                plugin.getLogger().info("Auto-generating legendaries for arena " + arena.getName());
                List<String> allRecipes = new ArrayList<>(plugin.getAbilityManager().getRecipes().keySet());
                Collections.shuffle(allRecipes);
                List<String> selectedRecipes = allRecipes.subList(0, Math.min(4, allRecipes.size()));

                int altarDist = Math.max(8, 5 + (players.size() / 2) + 3);
                Location[] dirs = {
                    center.clone().add(altarDist, 1, 0),
                    center.clone().add(-altarDist, 1, 0),
                    center.clone().add(0, 1, altarDist),
                    center.clone().add(0, 1, -altarDist)
                };

                for (int i = 0; i < selectedRecipes.size(); i++) {
                    String recipeId = selectedRecipes.get(i);
                    arena.addTemporaryLegendary(dirs[i], recipeId.replace(' ', '_'));
                }
            }

            // 3. Update Holograms (this creates the actual entities)
            plugin.getHologramManager().updateHolograms();
            
            if (onComplete != null) onComplete.run();
        });
    }

    private void teleportPlayersAndCreateCages(Arena arena, List<Player> players, Location center) {
        double baseRadius = plugin.getConfig().getDouble("game.spawn-base-radius", 10.0);
        double radiusPerPlayer = plugin.getConfig().getDouble("game.spawn-radius-per-player", 1.5);
        double radius = baseRadius + (players.size() * radiusPerPlayer);
        double angleStep = (2 * Math.PI) / players.size();
        int spawnY = plugin.getConfig().getInt("game.spawn-y-level", 100);
        
        arena.clearSpawnPoints(); // Clear old points
        
        for (int i = 0; i < players.size(); i++) {
            Player player = players.get(i);
            double angle = i * angleStep;
            double x = center.getX() + radius * Math.cos(angle);
            double z = center.getZ() + radius * Math.sin(angle);
            
            Location spawnLoc = new Location(center.getWorld(), x, spawnY, z);
            spawnLoc.setDirection(getDirectionToCenter(spawnLoc, center));
            
            // Build Piston Drop Mechanism
            // Structure:
            // Y-1: Redstone Block (Power)
            // Y: Sticky Piston
            // Y+1: Floor Block (Pushed to Y+2)
            // Y+2: Glass (Bottom Ring)
            // Y+3: Glass (Top Ring)
            // Y+4: Glass (Roof)
            
            Location pistonLoc = spawnLoc.clone();
            Location redstoneLoc = spawnLoc.clone().add(0, -1, 0);
            Location floorLoc = spawnLoc.clone().add(0, 1, 0);
            
            // 1. Power (Redstone)
            plugin.getArenaManager().setBlockSmart(center.getWorld(), redstoneLoc, Material.REDSTONE_BLOCK, arena, true);
            
            // 2. Piston
            plugin.getArenaManager().setBlockSmart(center.getWorld(), pistonLoc, Material.STICKY_PISTON, arena, true);
            
            // 3. Floor Block (The one that moves)
            plugin.getArenaManager().setBlockSmart(center.getWorld(), floorLoc, Material.GILDED_BLACKSTONE, arena, true);
            
            // Note: Physics should happen automatically, pushing Gilded Blackstone to Y+2
            // Player stands on Y+2 block, so feet at Y+3
            
            Location playerStandLoc = spawnLoc.clone().add(0, 3, 0);
            
            // Generate cage locations (around Y+2 and Y+3 relative to spawnLoc base, which matches player feet Y+3? No wait)
            // If Block is at Y+2. Player feet are at Y+3.
            // Glass Ring needed at Y+3 (Feet) and Y+4 (Head).
            
            List<Location> cageLocs = new ArrayList<>();
            int[][] offsets = {
                {1, 0}, {-1, 0}, {0, 1}, {0, -1}, // Cardinal
                {1, 1}, {1, -1}, {-1, 1}, {-1, -1} // Corners
            };
            
            // Walls (Level 1 and 2 relative to player feet)
            // Feet at Y+3.
            for (int y = 0; y < 2; y++) { 
                Location layerBase = spawnLoc.clone().add(0, 3 + y, 0);
                for (int[] off : offsets) {
                    Location glass = layerBase.clone().add(off[0], 0, off[1]);
                    plugin.getArenaManager().setBlockSmart(center.getWorld(), glass, Material.GLASS, arena);
                    cageLocs.add(glass);
                }
            }
            
            // Roof (at Y+5)
            Location roof = spawnLoc.clone().add(0, 5, 0);
            plugin.getArenaManager().setBlockSmart(center.getWorld(), roof, Material.GLASS, arena);
            cageLocs.add(roof);
            
            // Store cage blocks for cleanup
            List<Block> storedBlocks = arenaCages.computeIfAbsent(arena.getName(), k -> new ArrayList<>());
            for(Location l : cageLocs) {
                storedBlocks.add(l.getBlock()); // Store as block reference or location? Location is safer but Block is faster if chunk loaded
                // Actually storing Block object is risky if chunk unloads, but for MatchService it's active chunks.
                // Let's store Locations via the map we just built if we want, or just re-query. 
                // The prompt suggested storing 'Block'.
            }
            
            Arena.SpawnPoint point = new Arena.SpawnPoint(spawnLoc, pistonLoc, cageLocs);
            arena.addSpawnPoint(player.getUniqueId(), point);
            
            player.teleport(playerStandLoc.clone().add(0.5, 0.0, 0.5));
            player.setGameMode(GameMode.SURVIVAL);
            player.getInventory().clear();
        }
    }

    private void startCountdown(Arena arena, List<Player> players) {
        final int countdownSec = plugin.getConfig().getInt("game.countdown-seconds", 20);
        final int broadcastInterval = plugin.getConfig().getInt("game.countdown-broadcast-interval", 5);
        new BukkitRunnable() {
            int timeLeft = countdownSec;
            
            @Override
            public void run() {
                // BUG-CD-01 Fix: was checking getGamePlayers().values().stream() for alive count
                // but during STARTING state gamePlayers is not yet populated, so aliveCount
                // was always 0 → countdown immediately cancelled every time.
                // Fix: use arena.getPlayers().size() which reflects the raw joined player list.
                if (arena.getPlayers().size() < 2) {
                    arena.broadcast(plugin.getMessageManager().getMessage("not_enough_players"));
                    arena.setState(MatchState.WAITING);
                    this.cancel();
                    return;
                }
                if (arena.getPlayers().size() < plugin.getConfig().getInt("game.min-players-to-start", 2)) {
                    // NEW-08: Cancel countdown when underpopulated
                    arena.setState(MatchState.WAITING);
                    String cancelMsg = plugin.getMessageManager().getMessage("countdown_cancelled");
                    for (Player p : players) {
                        if (p != null && p.isOnline()) p.sendMessage(cancelMsg);
                    }
                    this.cancel();
                    return;
                }
                if (timeLeft > 0) {
                    if (timeLeft <= broadcastInterval || timeLeft % broadcastInterval == 0) {
                        for (Player p : players) {
                            if (p != null && p.isOnline()) {
                                p.sendTitle(plugin.getMessageManager().getMessage("game_starting_title", Map.of("count", String.valueOf(timeLeft))), "", 0, 20, 10);
                                p.sendMessage(plugin.getMessageManager().getMessage("game_starting_broadcast", Map.of("count", String.valueOf(timeLeft))));
                                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 2f);
                            }
                        }
                    }
                    timeLeft--;
                } else {
                    releasePlayers(arena);
                    this.cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, TICKS_PER_SECOND);
    }

    private void breakGlassCages(Arena arena) {
        List<Block> blocks = arenaCages.remove(arena.getName());
        if (blocks != null) {
            for (Block b : blocks) {
                if (b.getType() == Material.GLASS) {
                    BlockData glassData = b.getBlockData(); // Capture BEFORE changing type
                    b.setType(Material.AIR);
                    b.getWorld().spawnParticle(Particle.BLOCK, b.getLocation().add(0.5, 0.5, 0.5), 10, 0.2, 0.2, 0.2, glassData);
                }
            }
            if (arena.getCornucopia() != null) {
                arena.getCornucopia().getWorld().playSound(arena.getCornucopia(), Sound.BLOCK_GLASS_BREAK, 10f, 1f);
            }
        }
    }

    private void releasePlayers(Arena arena) {
        // ARCH-MS-01: use transition() instead of arena.setState() directly
        transition(arena, MatchState.PLAYING);
        arena.setTimer(0);
        
        // Animated Release (Simulate Piston Pull Down)
        new BukkitRunnable() {
            int step = 0;
            
            @Override
            public void run() {
                if (step == 0) {
                    // Sound effect: Pistons contracting
                    for (UUID uuid : arena.getPlayers()) {
                         Player p = Bukkit.getPlayer(uuid);
                         if (p != null && p.isOnline()) {
                             p.playSound(p.getLocation(), Sound.BLOCK_PISTON_CONTRACT, 1.0f, 1.0f);
                         }
                    }
                }
                
                if (step == 5) {
                    // Release: Remove Redstone Power
                    for (Arena.SpawnPoint point : arena.getSpawnPoints().values()) {
                        if (point.getPistonLoc() != null) {
                            // Redstone was at Piston Y - 1
                            Location redstoneLoc = point.getPistonLoc().clone().add(0, -1, 0);
                            plugin.getArenaManager().setBlockSmart(redstoneLoc.getWorld(), redstoneLoc, Material.AIR, null);
                            
                            // B-06: Ensure piston updates to contract
                            org.bukkit.block.Block piston = point.getPistonLoc().getBlock();
                            if (piston.getType() == Material.STICKY_PISTON || piston.getType() == Material.PISTON) {
                                piston.getState().update(true, true);
                            }
                        }
                    }
                    
                    // FORCE BREAK GLASS CAGES to ensure no one is stuck
                    breakGlassCages(arena);
                    
                    // GO!
                    for (UUID uuid : arena.getPlayers()) {
                         Player p = Bukkit.getPlayer(uuid);
                         if (p != null && p.isOnline()) {
                             p.sendTitle(plugin.getMessageManager().getMessage("go_title"), plugin.getMessageManager().getMessage("go_subtitle"), 0, 20, 10);
                             p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
                             p.playSound(p.getLocation(), Sound.BLOCK_PISTON_CONTRACT, 1.0f, 0.8f);
                         }
                    }
                    
                    this.cancel();
                }
                
                step++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    public void resetArena(Arena arena) {
        // Teleport all players to lobby
        Location lobby = plugin.getLobbyManager().getLobbyLocation();
        if (lobby == null) {
            plugin.getLogger().warning("Cannot reset arena " + arena.getName() + ": lobby location is not set!");
        }
        for (UUID uuid : arena.getPlayers()) {
            plugin.getArenaManager().unregisterPlayer(uuid);
            plugin.getCooldownManager().removePlayer(uuid); // Clear cooldowns on reset
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                p.setHealth(20);
                p.setFoodLevel(20);
                
                // Restore snapshot if available
                me.duong2012g.hungergamessss.model.GamePlayer gp = arena.getGamePlayer(uuid);
                if (gp != null && gp.getSnapshot() != null) {
                    gp.getSnapshot().restore(p);
                }
                
                // CS-05/08: Teleport active players back to lobby or world spawn
                Location target = (lobby != null) ? lobby : p.getWorld().getSpawnLocation();
                p.teleport(target);
            }
        }
        // Handle spectators
        for (UUID uuid : arena.getSpectators()) {
             plugin.getArenaManager().unregisterPlayer(uuid);
             Player p = Bukkit.getPlayer(uuid);
             if (p != null && p.isOnline()) {
                 // CS-08: Null guard for lobby
                 Location target = (lobby != null) ? lobby : p.getWorld().getSpawnLocation();
                 p.teleport(target);
                 p.setGameMode(GameMode.SURVIVAL);
                 // BUG-NEW-12: Cleanup spectator scoreboard
                 if (plugin.getScoreboardManager() != null) {
                     plugin.getScoreboardManager().removeBoard(p);
                 }
             }
        }

        // BUG-NEW-10: Clear cooldowns for spectators and disconnected players BEFORE clearing lists
        for (UUID uuid : arena.getSpectators()) {
            plugin.getCooldownManager().removePlayer(uuid);
        }
        for (UUID uuid : arena.getDisconnectedPlayers().keySet()) {
            plugin.getCooldownManager().removePlayer(uuid);
        }

        // BUG-NEW-09: Clean up feast chests
        // BUG-FM-01 Fix: was calling cleanup() which removed chests but did NOT clear
        // the feastSpawned guard set, so subsequent matches never spawned a feast.
        // Must call resetArena() which does both cleanup() AND feastSpawned.remove().
        if (plugin.getFeastManager() != null) {
            plugin.getFeastManager().resetArena(arena.getName());
        }

        arena.clearSpawnPoints();
        arena.clearTemporaryLegendaries();
        arena.getLegendaryTracker().reset();
        arena.getPlayers().clear();
        arena.getSpectators().clear();
        arena.getDisconnectedPlayers().clear();
        arena.clearStats();
        // ARCH-MS-01: use transition() to enter WAITING — cancels any leftover tasks
        transition(arena, MatchState.WAITING);
        arena.getGameEnded().set(false); // BUG-CON-04: Reset atomic guard

        // A2-20: Restore modified blocks via the ArenaBlockRestorer component.
        // Block restoration is now queued through the existing batch processor so
        // it doesn't spike the main thread — the same async-chunk pre-loading path
        // that processQueue uses handles chunk loading before blocks are set.
        if (arena.getBlockRestorer().hasChanges()) {
            // Queue all restore operations through the block processor
            java.util.Map<org.bukkit.Location, org.bukkit.Material> originals =
                    arena.getBlockRestorer().getOriginalBlocks();
            for (java.util.Map.Entry<org.bukkit.Location, org.bukkit.Material> entry : originals.entrySet()) {
                arena.getBlockRestorer().queue(entry.getKey(), entry.getValue(), false);
            }
            plugin.getArenaManager().processQueue(arena, () -> {
                arena.getBlockRestorer().restore();
                plugin.getLogger().info("[Arena] Block restore complete for " + arena.getName());
            });
        }

        // Restore Map (Fixes Map Rot)
        plugin.getStructureManager().resetStructures(arena);

        // Clear cages if any remain
        breakGlassCages(arena);

        // Save state to DB (empty players)
        plugin.getArenaManager().saveArena(arena);
    }

    private Vector getDirectionToCenter(Location from, Location to) {
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        double dist = Math.sqrt(dx*dx + dz*dz);
        if (dist == 0) return new Vector(0, 0, 0);
        return new Vector(dx/dist, 0, dz/dist);
    }
    
    public void handleDeath(Player player) {
        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        if (arena == null) return;

        // BUGFIX: Mark player as dead immediately so checkWin() sees the correct alive count.
        // Arena.handleDeath also increments the death counter, so we skip the separate
        // arena.addDeath() call that PlayerDeathListener did — but PlayerDeathListener calls
        // arena.addDeath() first, then this method. To avoid double-counting we set alive=false
        // directly here instead of delegating to Arena.handleDeath().
        me.duong2012g.hungergamessss.model.GamePlayer gp = arena.getGamePlayers().get(player.getUniqueId());
        if (gp != null) gp.setAlive(false);

        // Logic for Stolen Heart (Lifesteal Mode)
        if (arena.isLifestealEnabled()) {
            me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
            ItemStack heart = new ItemStack(Material.RED_DYE);
            org.bukkit.inventory.meta.ItemMeta meta = heart.getItemMeta();
            if (meta != null) {
                meta.displayName(me.duong2012g.hungergamessss.util.ColorUtil.component(mm.getMessage("stolen_heart_name")));
                List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
                lore.add(me.duong2012g.hungergamessss.util.ColorUtil.component(mm.getMessage("stolen_heart_lore")));
                meta.lore(lore);
                // BUG-PM-01 Fix: meta.getDisplayName() returns "" for Component-API items.
                // Use a PDC tag so PlayerManager can identify the heart regardless of locale.
                meta.getPersistentDataContainer().set(
                        new org.bukkit.NamespacedKey(plugin, "stolen_heart"),
                        org.bukkit.persistence.PersistentDataType.BYTE, (byte) 1);
                heart.setItemMeta(meta);
            }
            player.getWorld().dropItemNaturally(player.getLocation(), heart);
        }

        // Logic for Hardcore Mode
        if (arena.isHardcoreEnabled()) {
            player.sendMessage(plugin.getMessageManager().getMessage("hardcore_eliminated"));
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                Location lobbyLoc = plugin.getLobbyManager().getLobbyLocation();
                if (lobbyLoc != null) {
                    player.teleport(lobbyLoc);
                } else {
                    player.teleport(player.getWorld().getSpawnLocation());
                }
            }, HARDCORE_KICK_DELAY);
        }

        // Effects
        player.getWorld().strikeLightningEffect(player.getLocation());
        // CS-04: Visual-only effects instead of dangerous WitherSkulls
        player.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, player.getLocation().add(0, 1, 0), 50, 0.5, 1.0, 0.5, 0.1);
        player.getWorld().spawnParticle(Particle.LARGE_SMOKE, player.getLocation().add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.05);
        
        // Broadcast death message and sound
        for (UUID uuid : arena.getPlayers()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) {
                p.sendMessage(plugin.getMessageManager().getMessage("player_eliminated_broadcast", Map.of("player", player.getName())));
                p.playSound(p.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 10f, 1f);
            }
        }
        
        player.setGameMode(GameMode.SPECTATOR);
        
        // B-15: Track loss
        me.duong2012g.hungergamessss.model.PlayerData data = plugin.getPlayerManager().getPlayerData(player);
        if (data != null) {
            data.addLoss();
            data.addGamePlayed();
            plugin.getDatabaseManager().savePlayerStats(player);
        }
        // Check win condition
        checkWin(arena);
        
        // Immediate Update
        if (plugin.getScoreboardManager() != null) {
            plugin.getScoreboardManager().updateScoreboards(arena);
        }
    }
    
    public void playerLeave(Player player) {
        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        if (arena == null) return;
        
        me.duong2012g.hungergamessss.model.GamePlayer gp = arena.getGamePlayer(player.getUniqueId());
        if (gp != null && gp.getSnapshot() != null) {
            gp.getSnapshot().restore(player);
        }
        
        arena.removePlayer(player.getUniqueId());
        plugin.getArenaManager().unregisterPlayer(player.getUniqueId());
        checkWin(arena);
    }
    
    public void restoreSession(Player player, Arena arena) {
        if (arena.getState() == MatchState.PLAYING || arena.getState() == MatchState.DEATHMATCH) {
            // Restore Scoreboard
            if (plugin.getScoreboardManager() != null) {
                plugin.getScoreboardManager().updateScoreboard(player, arena);
            }
            // Restore BossBar (if any)
            // Restore Compass/Tracking
            
            // Ensure gamemode consistency
            if (arena.getSpectators().contains(player.getUniqueId())) {
                if (player.getGameMode() != GameMode.SPECTATOR) {
                    player.setGameMode(GameMode.SPECTATOR);
                }
            } else if (arena.getPlayers().contains(player.getUniqueId())) {
                if (player.getGameMode() != GameMode.SURVIVAL) {
                    player.setGameMode(GameMode.SURVIVAL);
                }
            }
        } else if (arena.getState() == MatchState.WAITING || arena.getState() == MatchState.STARTING || arena.getState() == MatchState.ENDING) {
             if (plugin.getScoreboardManager() != null) {
                plugin.getScoreboardManager().updateScoreboard(player, arena);
            }
            if (player.getGameMode() != GameMode.ADVENTURE) {
                player.setGameMode(GameMode.ADVENTURE);
            }
        }
    }

    public void checkWin(Arena arena) {
        // BUG-NEW-07: Only check win during active gameplay states
        if (arena.getState() != MatchState.PLAYING && arena.getState() != MatchState.DEATHMATCH) return;
        
        // CS-10: Use GamePlayer.isAlive flag as source of truth
        List<Player> alive = new ArrayList<>();
        int aliveCount = 0; // Includes disconnected-alive players
        for (Map.Entry<UUID, me.duong2012g.hungergamessss.model.GamePlayer> entry : arena.getGamePlayers().entrySet()) {
            if (entry.getValue().isAlive()) {
                aliveCount++;
                Player p = Bukkit.getPlayer(entry.getKey());
                if (p != null && p.isOnline()) {
                    alive.add(p);
                }
            }
        }
        
        // Count disconnected players as alive to prevent premature game end
        if (aliveCount == 1 && alive.size() == 1) {
            endGame(arena, alive.get(0));
        } else if (aliveCount == 0) {
            endGame(arena, null);
        }
    }

    public void endGame(Arena arena, Player winner) {
        // BUG-CON-04: Atomic guard to prevent duplicate endGame calls
        if (!arena.getGameEnded().compareAndSet(false, true)) return;
        // ARCH-MS-01: transition() handles ENDING state — cancels all tasks + fires ArenaEndEvent
        transition(arena, MatchState.ENDING);
        // BUG-NEW-06: Fire ArenaEndEvent (transition already fires it for us via switch case)
        Bukkit.getPluginManager().callEvent(new me.duong2012g.hungergamessss.events.ArenaEndEvent(arena, winner));
        
        // Reset World Border
        if (arena.getWorld() != null) {
            arena.getWorld().getWorldBorder().setSize(3000.0);
        }

        String msg;
        if (winner != null) {
            msg = plugin.getMessageManager().getMessage("player_won_broadcast", Map.of("player", winner.getName(), "arena", arena.getName()));
            // Firework or sound?
            winner.playSound(winner.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            
            // B-15: Track win
            me.duong2012g.hungergamessss.model.PlayerData data = plugin.getPlayerManager().getPlayerData(winner);
            if (data != null) {
                data.addWin();
                data.addGamePlayed();
                plugin.getDatabaseManager().savePlayerStats(winner);
            }
        } else {
            msg = plugin.getMessageManager().getMessage("game_draw_broadcast");
        }
        
        for (UUID uuid : arena.getPlayers()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) p.sendMessage(msg);
        }
        
        int resetDelay = plugin.getConfig().getInt("game.reset-delay-seconds", 5);
        new BukkitRunnable() {
            @Override
            public void run() {
                resetArena(arena);
            }
        }.runTaskLater(plugin, resetDelay * 20L);
    }
}
