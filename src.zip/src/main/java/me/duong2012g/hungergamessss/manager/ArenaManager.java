package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.util.ColorUtil;
import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.events.DungeonSpawnEvent;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.Ingredient;
import me.duong2012g.hungergamessss.model.LegendaryRecipe;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Container;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.EulerAngle;

import java.io.File;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ArenaManager {
    private final Main plugin;
    private final Map<String, Arena> arenas = new ConcurrentHashMap<>();
    private final Map<UUID, String> playerArenaMap = new ConcurrentHashMap<>();
    private final Map<UUID, String> selectedStyles = new ConcurrentHashMap<>();
    private final LootTableManager lootManager;
    private final Random random = new Random();

    public ArenaManager(Main plugin) {
        this.plugin = plugin;
        this.lootManager = new LootTableManager(plugin);
    }

    // --- Core Management (Local) ---

    public void addArena(Arena arena) {
        arenas.put(arena.getName(), arena);
    }
    
    public void removeArena(String name) {
        Arena arena = arenas.get(name);
        if (arena != null) {
            // 1. Kick all players
            for (UUID uuid : new ArrayList<>(arena.getPlayers())) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null) {
                    p.teleport(p.getWorld().getSpawnLocation());
                    p.sendMessage("§c§lArena has been deleted!");
                }
                unregisterPlayer(uuid);
            }
            // 2. Remove holograms (CS-13)
            if (plugin.getHologramManager() != null) {
                plugin.getHologramManager().removeArenaHolograms(name);
            }
            if (!arena.getHologramMap().isEmpty()) {
                for (ArmorStand stand : arena.getHologramMap().keySet()) {
                    stand.remove();
                }
                arena.getHologramMap().clear();
            }
            // 3. Clear scoreboards (via ScoreboardManager if exists)
            if (plugin.getScoreboardManager() != null) {
                plugin.getScoreboardManager().clearArenaScoreboards(arena);
            }
        }

        arenas.remove(name);
        if (plugin.getDatabaseManager() != null) {
            plugin.getDatabaseManager().deleteArena(name);
        }
        plugin.getLogger().info("Arena '" + name + "' fully removed");
    }

    public Arena getArena(String name) {
        return arenas.get(name);
    }
    
    public Map<String, Arena> getArenas() {
        return arenas;
    }

    public void saveArenas() {
        if (plugin.getDatabaseManager() != null) {
            plugin.getDatabaseManager().saveAllArenas();
        }
    }

    public void saveArena(Arena arena) {
        if (plugin.getDatabaseManager() != null) {
            plugin.getDatabaseManager().saveArena(arena);
        }
    }
    
    public void registerPlayer(UUID uuid, Arena arena) {
        playerArenaMap.put(uuid, arena.getName());
    }

    public void unregisterPlayer(UUID uuid) {
        String arenaName = playerArenaMap.remove(uuid);
        if (arenaName != null) {
            Arena arena = arenas.get(arenaName);
            if (arena != null) {
                arena.removePlayer(uuid);
            }
        }
        // FORCE CLEANUP: Ensure player is removed from ALL arenas to prevent ghosts
        for (Arena a : arenas.values()) {
            a.removePlayer(uuid);
        }
    }

    public Arena getArenaByPlayer(Player player) {
        String arenaName = playerArenaMap.get(player.getUniqueId());
        if (arenaName != null) {
            return arenas.get(arenaName);
        }
        return null; // Fallback to world check if needed, but Map is safer for multi-world
    }
    

    // Alias for decompiled compatibility
    public Arena getArena(Player p) {
        return getArenaByPlayer(p);
    }
    
    public Arena getArenaByEntity(org.bukkit.entity.Entity entity) {
        if (entity instanceof Player player) return getArenaByPlayer(player);
        // For non-player entities, we might check locations if they are "arena entities"
        // but for now, player-association is primary.
        return getArenaAt(entity.getLocation());
    }

    public Arena getArenaByEntity(UUID uuid) {
        String arenaName = playerArenaMap.get(uuid);
        if (arenaName != null) return arenas.get(arenaName);
        return null;
    }
    
    public void setPlayerStyle(UUID uuid, String style) {
        this.selectedStyles.put(uuid, style);
    }

    public String getPlayerStyle(UUID uuid) {
        return this.selectedStyles.get(uuid);
    }

    public void tick() {
         // Existing Tick Logic
         for (Arena arena : arenas.values()) {
             try {
                // If using external GameTask, call it. 
                // But simplified for now:
                if (arena.getState() == MatchState.PLAYING || arena.getState() == MatchState.STARTING || arena.getState() == MatchState.ENDING) {
                    me.duong2012g.hungergamessss.task.GameTask.tick(arena);
                }
                // Tick Holograms
                tickHolograms(arena);
             } catch (Exception e) {
                 plugin.getLogger().warning("Error ticking arena " + arena.getName());
                 e.printStackTrace();
             }
         }
    }
    
    // --- Decompiled Logic ---

    public Arena getArenaAt(Location loc) {
        if (loc == null || loc.getWorld() == null) return null;
        
        // Primary detection: World-based (Ensures tracking of structures/dungeons throughout the map)
        for (Arena a : arenas.values()) {
            if (a.getWorld() != null && a.getWorld().equals(loc.getWorld())) {
                return a;
            }
        }
        return null;
    }

    public void findSafeCornucopiaLocation(World world, java.util.function.Consumer<Location> callback) {
        int maxSearchRadius = 400;
        Random rand = new Random();
        
        new BukkitRunnable() {
            int attempts = 0;
            
            @Override
            public void run() {
                // Try 5 random spots per tick to keep it fast but responsive
                for (int i = 0; i < 5; i++) {
                    attempts++;
                    int x = rand.nextInt(maxSearchRadius * 2) - maxSearchRadius;
                    int z = rand.nextInt(maxSearchRadius * 2) - maxSearchRadius;
                    
                    // Only check if chunk is loaded to avoid sync load
                    if (world.isChunkLoaded(x >> 4, z >> 4)) {
                        if (isLocationNice(world, x, z, 15)) {
                            this.cancel();
                            callback.accept(new Location(world, x + 0.5, world.getHighestBlockYAt(x, z) + 1, z + 0.5));
                            return;
                        }
                    } else {
                        // Request async load for next time
                        world.getChunkAtAsync(x >> 4, z >> 4);
                    }
                    
                    if (attempts >= 100) { // Fallback after 100 attempts
                        this.cancel();
                        callback.accept(new Location(world, 0.5, world.getHighestBlockYAt(0, 0) + 1, 0.5));
                        return;
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private boolean isLocationNice(World world, int centerX, int centerZ, int checkRadius) {
        // First check if all chunks in the radius are loaded to avoid sync load
        for (int x = centerX - checkRadius; x <= centerX + checkRadius; x += 16) {
            for (int z = centerZ - checkRadius; z <= centerZ + checkRadius; z += 16) {
                if (!world.isChunkLoaded(x >> 4, z >> 4)) {
                    return false; // Can't check yet, skip this spot
                }
            }
        }

        int baseHeight = world.getHighestBlockYAt(centerX, centerZ);
        BlockStateHelper bsh = new BlockStateHelper(world);
        if (!this.isSafeSurface(bsh.getTypeAt(centerX, baseHeight, centerZ)) && !this.isSafeSurface(bsh.getTypeAt(centerX, baseHeight - 1, centerZ))) {
            return false;
        }
        int minHeight = baseHeight;
        int maxHeight = baseHeight;
        for (int x = centerX - checkRadius; x <= centerX + checkRadius; x += 10) {
            for (int z = centerZ - checkRadius; z <= centerZ + checkRadius; z += 10) {
                int y = world.getHighestBlockYAt(x, z);
                Material mat = bsh.getTypeAt(x, y, z);
                if (!this.isSafeSurface(mat)) {
                    if (!this.isSafeSurface(bsh.getTypeAt(x, y - 1, z))) {
                        return false;
                    }
                    --y;
                }
                minHeight = Math.min(minHeight, y);
                if (Math.abs((maxHeight = Math.max(maxHeight, y)) - minHeight) <= 4) continue;
                return false;
            }
        }
        return true;
    }
    
    // Helper class to avoid NMS or complex calls if not needed, simpler:
    private class BlockStateHelper {
        World w;
        BlockStateHelper(World w) { this.w = w; }
        Material getTypeAt(int x, int y, int z) { return w.getBlockAt(x, y, z).getType(); }
    }

    private boolean isSafeSurface(Material mat) {
        if (mat == null) return false;
        String name = mat.name();
        if (name.contains("WATER") || name.contains("LAVA") || name.contains("ICE")) return false;
        if (name.contains("LEAVES") || name.contains("LOG") || name.contains("WOOD")) return false;
        return mat.isSolid() && mat.isBlock();
    }

    public void setBlockSmart(World w, Location loc, Material mat, Arena arena, boolean applyPhysics) {
        if (w == null || loc == null || mat == null) return;
        org.bukkit.block.Block b = w.getBlockAt(loc);
        if (b.getType() != mat) {
            if (arena != null && mat != Material.AIR) {
                arena.getOriginalBlocks().put(loc.clone(), b.getType());
            }
            b.setType(mat, applyPhysics);
        }
    }

    public void setBlockSmart(World w, Location loc, Material mat, Arena arena) {
        setBlockSmart(w, loc, mat, arena, false);
    }

    public void queueBlock(Arena arena, Location loc, Material mat, boolean saveOriginal) {
        if (arena == null || loc == null || mat == null) return;
        arena.getBlockQueue().add(new Arena.BlockUpdate(loc.clone(), mat, saveOriginal));
    }

    public void processQueue(final Arena arena, final Runnable onComplete) {
        final int blocksPerTick = this.plugin.getConfig().getInt("performance.block-processing.max-blocks-per-tick", 200);
        int delay = this.plugin.getConfig().getInt("performance.block-processing.batch-delay", 1);

        // A2-9: pre-load chunks before batch to avoid mid-tick chunk load stalls
        preloadQueuedChunks(arena, () -> {
            final int totalBlocks = arena.getBlockQueue().size();

            // A2-10: BossBar build-progress
            org.bukkit.boss.BossBar bar = null;
            if (plugin.getConfig().getBoolean("arena.show-build-progress", true) && totalBlocks > 0) {
                bar = org.bukkit.Bukkit.createBossBar(
                        "§e⚙ §7Building §e" + arena.getName() + "§7...",
                        org.bukkit.boss.BarColor.YELLOW, org.bukkit.boss.BarStyle.SEGMENTED_10);
                bar.setProgress(0.0);
                for (java.util.UUID uuid : arena.getPlayers()) {
                    org.bukkit.entity.Player p = org.bukkit.Bukkit.getPlayer(uuid);
                    if (p != null) bar.addPlayer(p);
                }
            }
            final org.bukkit.boss.BossBar progressBar = bar;
            final int[] placed = {0};

            new BukkitRunnable() {
                public void run() {
                    if (!arenas.containsKey(arena.getName())) {
                        cancel();
                        if (progressBar != null) progressBar.removeAll();
                        return;
                    }
                    for (int processed = 0; !arena.getBlockQueue().isEmpty() && processed < blocksPerTick; ++processed) {
                        Arena.BlockUpdate update = arena.getBlockQueue().poll();
                        if (update == null) continue;
                        try {
                            setBlockSmart(arena.getWorld(), update.loc, update.mat, update.saveOriginal ? arena : null);
                            placed[0]++;
                        } catch (Exception ignored) {}
                    }
                    if (progressBar != null && totalBlocks > 0)
                        progressBar.setProgress(Math.min(1.0, (double) placed[0] / totalBlocks));

                    if (arena.getBlockQueue().isEmpty()) {
                        cancel();
                        if (progressBar != null) {
                            progressBar.setTitle("§a✔ §7Arena §e" + arena.getName() + " §7ready!");
                            plugin.getServer().getScheduler().runTaskLater(plugin, progressBar::removeAll, 40L);
                        }
                        if (onComplete != null) onComplete.run();
                    }
                }
            }.runTaskTimer(this.plugin, 1L, (long) delay);
        });
    }

    /** A2-9: async chunk pre-loading so block placement never causes chunk-load spikes. */
    private void preloadQueuedChunks(Arena arena, Runnable callback) {
        if (arena.getWorld() == null || arena.getBlockQueue().isEmpty()) { callback.run(); return; }
        java.util.Set<Long> coords = new java.util.HashSet<>();
        for (Arena.BlockUpdate upd : arena.getBlockQueue()) {
            int cx = upd.loc.getBlockX() >> 4, cz = upd.loc.getBlockZ() >> 4;
            coords.add(((long) cx << 32) | (cz & 0xFFFFFFFFL));
        }
        java.util.concurrent.atomic.AtomicInteger rem = new java.util.concurrent.atomic.AtomicInteger(coords.size());
        for (long packed : coords) {
            int cx = (int)(packed >> 32), cz = (int)(packed & 0xFFFFFFFFL);
            arena.getWorld().getChunkAtAsync(cx, cz).thenRun(() -> {
                if (rem.decrementAndGet() == 0)
                    plugin.getServer().getScheduler().runTask(plugin, callback);
            });
        }
    }

    public void buildCornucopia(Arena arena, String style) {
        World w = arena.getWorld();
        Location center = arena.getCornucopia();
        // FIX L-09: was arena.getOriginalBlocks().clear() — wiped all previously tracked blocks
        // (spawn cages, dungeon structures) before adding Cornucopia blocks, so those could
        // never be restored on reset. Now we preserve existing entries and only append new ones.
        // CornucopiaBuilder itself calls originalBlocks.put() for each block it touches.
        ArrayList<Location> chestLocations = new ArrayList<>();
        int radius = this.plugin.getConfig().getInt("arena.cornucopia-radius", 75);
        // A2-11: CornucopiaBuilder is now injectable — ArenaManager holds no direct 'new' calls.
        // The builder is obtained from plugin.getCornucopiaBuilder() which returns the shared
        // instance registered in Main.registerManagers(). Tests can inject a mock via
        // plugin.setCornucopiaBuilder(mockBuilder).
        CornucopiaBuilder builder = plugin.getCornucopiaBuilder();
        builder.configure(w, center, radius);
        builder.clearArea(() -> this.startCornucopiaPhase2(arena, chestLocations, style));
    }

    private void startCornucopiaPhase2(final Arena arena, final List<Location> chestLocations, final String forcedStyle) {
        final Location center = arena.getCornucopia();
        // Use AbilityManager to get legendaries
        List<LegendaryRecipe> pool = new ArrayList<>();
        // FIX L-07: was a hardcoded list of internal test item IDs ("gerald_sniffer",
        // "gruntilda", "tim_enchanter") that leaked into production code.
        // Now reads from config key legendary.excluded-ids so server owners can manage
        // this list without recompiling. Defaults to an empty list (no exclusions).
        java.util.List<String> excluded = plugin.getConfig().getStringList("legendary.excluded-ids");
        for (LegendaryRecipe lr : this.plugin.getAbilityManager().getAllLegendaries()) {
            if (excluded.contains(lr.id)) continue;
            pool.add(lr);
        }
        Collections.shuffle(pool);
        arena.setActiveLegendaries(new java.util.ArrayList<>(pool.subList(0, Math.min(4, pool.size()))));
        
        new BukkitRunnable(){
            public void run() {
                if (!arenas.containsKey(arena.getName())) return;
                
                boolean customPlaced = false;
                // Try custom structures first if allowed
                // CS-06: Guard against null StructureManager (FAWE absent)
                if (plugin.getStructureManager() != null && plugin.getConfig().getBoolean("allow-custom-structure", true)) {
                    // This logic was complex in decompiled, simplified here to use StructureManager
                    // We just pick a random structure from "cornucopias" folder if possible
                    File cornFolder = new File(plugin.getStructureManager().getStructureFolder(), "cornucopias");
                    if (cornFolder.exists() && cornFolder.isDirectory()) {
                         File[] files = cornFolder.listFiles((dir, name) -> name.endsWith(".nbt") || name.endsWith(".schem"));
                         if (files != null && files.length > 0) {
                             File picked = files[random.nextInt(files.length)];
                             String name = picked.getName();
                             plugin.getStructureManager().placeStructure("cornucopias/" + name, center).thenAccept(success -> {
                                 if (success) {
                                     // BUG-CON-05: Scan only after paste is complete, and on main thread
                                     plugin.getServer().getScheduler().runTask(plugin, () -> {
                                         scanForChests(arena, center, chestLocations, () -> startPhase3(arena, chestLocations));
                                     });
                                 }
                             });
                             customPlaced = true; // Set customPlaced here
                             return; // Exit this runnable's run method
                         }
                    }
                }
                
                if (!customPlaced) {
                    plugin.getLogger().info("Generating procedural Majestic Cornucopia...");
                    int radius = plugin.getConfig().getInt("arena.cornucopia-radius", 75);
                    CornucopiaBuilder builder = new CornucopiaBuilder(plugin, center.getWorld(), center, radius);
                    
                    builder.buildMajesticCornucopia(center, arena.getMaxPlayers(), arena, () -> {
                        // Scan for the chests built by the Majestic builder
                        scanForChests(arena, center, chestLocations, () -> startPhase3(arena, chestLocations));
                    });
                }
            }
        }.runTaskLater(plugin, 1L);
    }
    
    private void scanForChests(Arena arena, Location center, List<Location> chestLocations, Runnable onComplete) {
         new BukkitRunnable(){
            int x = -50;
            public void run() {
                if (!arenas.containsKey(arena.getName())) { this.cancel(); return; }
                int endX = Math.min(x + 5, 50);
                for (int currX = x; currX <= endX; ++currX) {
                    for (int y = -15; y <= 35; ++y) {
                        for (int z = -50; z <= 50; ++z) {
                            Location l = center.clone().add((double)currX, (double)y, (double)z);
                             Material type = l.getBlock().getType();
                             if (type != Material.CHEST && type != Material.TRAPPED_CHEST && type != Material.BARREL) continue;
                             chestLocations.add(l);
                             arena.getOriginalBlocks().put(l, type);
                        }
                    }
                }
                x += 6;
                if (x > 50) {
                    this.cancel();
                    if (onComplete != null) onComplete.run();
                }
            }
         }.runTaskTimer(plugin, 1L, 1L);
    }

    private void startPhase3(final Arena arena, final List<Location> chestLocations) {
        final World w = arena.getWorld();
        int spawnsPerTick = 2;
        
        for (Location spawn : arena.getConfiguredSpawns()) {
            Location ground = spawn.clone().subtract(0.0, 1.0, 0.0);
            for (int x = -2; x <= 2; ++x) {
                for (int z = -2; z <= 2; ++z) {
                    for (int y = 0; y <= 5; ++y) {
                        queueBlock(arena, spawn.clone().add(x, y, z), Material.AIR, false);
                    }
                    Material floorMat = Math.abs(x) <= 1 && Math.abs(z) <= 1 ? Material.DEEPSLATE_BRICKS : Material.POLISHED_ANDESITE;
                    queueBlock(arena, ground.clone().add(x, 0.0, z), floorMat, true);
                }
            }
        }
        
        processQueue(arena, () -> finalizeArena(arena, chestLocations));
    }

    private void finalizeArena(final Arena arena, final List<Location> chestLocations) {
        final Location center = arena.getCornucopia();
        new BukkitRunnable(){
            public void run() {
                if (!arenas.containsKey(arena.getName())) return;
                
                Collections.shuffle(chestLocations);
                int maxChests = Math.max(8, (arena.getMaxPlayers() * 3 + 3) / 4);
                List<Location> toFill = new ArrayList<>();
                
                for (int i = 0; i < chestLocations.size(); i++) {
                     Location loc = chestLocations.get(i);
                     if (i < maxChests) {
                         toFill.add(loc);
                     } else {
                         // Remove excess chests
                         loc.getBlock().setType(Material.AIR);
                     }
                }
                
                int filledCount = 0;
                int emptyCount = 0;
                double emptyRatio = plugin.getConfig().getDouble("arena.empty-chest-ratio", 0.25);
                for (Location cl : toFill) {
                    if (cl.getBlock().getState() instanceof Container container) {
                         if (random.nextDouble() < emptyRatio) {
                             // Leave this chest empty
                             container.getInventory().clear();
                             emptyCount++;
                         } else {
                             fillChest(container.getInventory(), arena);
                             filledCount++;
                         }
                    }
                }
                
                if (filledCount > 0) plugin.getLogger().info("[Cornucopia] Filled " + filledCount + " chests! (" + emptyCount + " empty)");
                
                // Spawn Legendaries Holograms
                double radius = 40.0;
                int count = arena.getActiveLegendaries().size();
                for (int i = 0; i < count; i++) {
                    LegendaryRecipe rec = arena.getActiveLegendaries().get(i);
                    double angle = Math.PI * 2 * i / count;
                    double x = radius * Math.cos(angle);
                    double z = radius * Math.sin(angle);
                    Location holoBase = center.clone().add(x, 1.0, z);
                    spawnLegendaryHologram(arena, rec, holoBase);
                }
                
                spawnDungeons(arena);
                
                arena.getWorld().setTime(6000L);
                arena.getWorld().setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
                arena.getWorld().setGameRule(GameRule.DO_WEATHER_CYCLE, false);
            }
        }.runTaskLater(plugin, 5L);
    }
    
    public void fillChest(Inventory inv, Arena arena) {
         Location center = arena.getCornucopia();
         double maxRadius = this.plugin.getConfig().getInt("arena.cornucopia-radius", 75);
         // If inventory is a chest, calculate distance
         double distance = 0;
         if (inv.getHolder() instanceof org.bukkit.block.Container container) {
             distance = container.getLocation().distance(center);
         }
         lootManager.fillChest(inv, distance, maxRadius);
    }

    public void spawnLegendaryHologram(Arena arena, LegendaryRecipe rec, Location holoBase) {
        World w = holoBase.getWorld();
        for (int x = -1; x <= 1; ++x) {
            for (int z = -1; z <= 1; ++z) {
                Location loc = holoBase.clone().add((double)x, 0.0, (double)z);
                Material mat = x == 0 && z == 0 ? Material.CRYING_OBSIDIAN : Material.GILDED_BLACKSTONE;
                this.queueBlock(arena, loc, mat, true);
                this.queueBlock(arena, loc.clone().subtract(0.0, 1.0, 0.0), Material.SEA_LANTERN, false);
                if (Math.abs(x) != 1 || Math.abs(z) != 1) continue;
                this.queueBlock(arena, loc.clone().add(0.0, 1.0, 0.0), Material.POLISHED_BLACKSTONE_SLAB, true);
                w.spawnParticle(Particle.SOUL_FIRE_FLAME, loc.clone().add(0.5, 1.2, 0.5), 5, 0.1, 0.1, 0.1, 0.02);
            }
        }
        this.queueBlock(arena, holoBase.clone().add(0.0, 1.0, 0.0), Material.CHISELED_POLISHED_BLACKSTONE, true);
        
        // Let the queue process before spawning the entities to ensure the platform exists
        processQueue(arena, () -> {
            Location holo = holoBase.clone().add(0.5, 3.2, 0.5);
            ArmorStand itemStand = (ArmorStand)w.spawnEntity(holo.clone().add(0.0, 0.8, 0.0), EntityType.ARMOR_STAND);
            itemStand.setGravity(false);
            itemStand.setVisible(false);
            itemStand.setSmall(false);
            itemStand.setInvulnerable(true);
            itemStand.getEquipment().setHelmet(rec.createItem());
            arena.getHologramMap().put(itemStand, rec);
        
            ArmorStand nameStand = (ArmorStand)w.spawnEntity(holo.clone().add(0.0, 0.4, 0.0), EntityType.ARMOR_STAND);
            nameStand.setGravity(false);
            nameStand.setVisible(false);
            nameStand.setSmall(true);
            String fancyName = ColorUtil.colorize("§6&l✧ &e&l" + ChatColor.stripColor(rec.name).toUpperCase() + " §6&l✧");
            nameStand.setCustomName(fancyName);
            nameStand.setCustomNameVisible(true);
            arena.getHologramMap().put(nameStand, rec);
            
            ArmorStand headerStand = (ArmorStand)w.spawnEntity(holo.clone().add(0.0, 0.1, 0.0), EntityType.ARMOR_STAND);
            headerStand.setGravity(false);
            headerStand.setVisible(false);
            headerStand.setSmall(true);
            headerStand.setCustomName(plugin.getMessageManager().getMessage("recipe_header"));
            headerStand.setCustomNameVisible(true);
            arena.getHologramMap().put(headerStand, rec);
            
            StringBuilder ingText = new StringBuilder();
            int xpCost = plugin.getConfig().getInt("legendary.crafting-xp-cost", 15);
            String xpLabel = plugin.getMessageManager().getMessage("hologram_xp");
            ingText.append("§e⚡ ").append(xpCost).append(" ").append(xpLabel);
            
            int heartCost = rec.heartCost;
            if (heartCost > 0) {
                String heartLabel = plugin.getMessageManager().getMessage("hologram_heart");
                ingText.append(" §8| §c❤ ").append(heartCost).append(" ").append(heartLabel);
            }
            
            for (Ingredient ing : rec.ingredients) {
                String matName = ing.material().name().replace("_", " ").toLowerCase();
                String[] words = matName.split(" ");
                StringBuilder capitalized = new StringBuilder();
                for (String word : words) {
                    if (word.isEmpty()) continue;
                    capitalized.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1)).append(" ");
                }
                ingText.append("\n§b▸ §f").append(ing.amount()).append("x §7").append(capitalized.toString().trim());
            }
            
            String[] lines = ingText.toString().split("\n");
            for (int j = 0; j < lines.length; ++j) {
                ArmorStand lineStand = (ArmorStand)w.spawnEntity(holo.clone().add(0.0, -0.3 - (double)j * 0.3, 0.0), EntityType.ARMOR_STAND);
                lineStand.setGravity(false);
                lineStand.setVisible(false);
                lineStand.setSmall(true);
                lineStand.setCustomName(lines[j]);
                lineStand.setCustomNameVisible(true);
                arena.getHologramMap().put(lineStand, rec);
                arena.getHolograms().computeIfAbsent(rec, k -> new ArrayList<>()).add(lineStand);
            }
            
            ArmorStand clickStand = (ArmorStand)w.spawnEntity(holo.clone().add(0.0, -0.7 - (double)lines.length * 0.3, 0.0), EntityType.ARMOR_STAND);
            clickStand.setGravity(false);
            clickStand.setVisible(false);
            clickStand.setSmall(true);
            String clickText = plugin.getMessageManager().getMessage("hologram_craft_click");
            clickStand.setCustomName(clickText);
            clickStand.setCustomNameVisible(true);
            arena.getHologramMap().put(clickStand, rec);
            
            arena.getHolograms().computeIfAbsent(rec, k -> new ArrayList<>()).addAll(Arrays.asList(itemStand, nameStand, headerStand, clickStand));
            
            w.playSound(holoBase, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.0f);
            w.spawnParticle(Particle.FLASH, holo.clone().add(0.0, 1.0, 0.0), 1);
            w.spawnParticle(Particle.ENTITY_EFFECT, holo.clone().add(0.0, 1.0, 0.0), 50, 0.5, 0.5, 0.5, 0.1);
        });
    }
    
    public void tickHolograms(Arena arena) {
        if (arena.getHologramMap().isEmpty() || arena.getPlayers().isEmpty()) return;
        for (ArmorStand stand : arena.getHologramMap().keySet()) {
             // BUG-PERF-01: Only rotate item-display stands (those with helmets), skip text-only stands
             if (stand.isValid() && !stand.isVisible()
                     && stand.getEquipment() != null
                     && stand.getEquipment().getHelmet() != null
                     && stand.getEquipment().getHelmet().getType() != Material.AIR) {
                  EulerAngle old = stand.getHeadPose();
                  double newY = (old.getY() + 0.1) % (2 * Math.PI);
                  stand.setHeadPose(new EulerAngle(0, newY, 0));
                  if (random.nextInt(5) == 0) {
                      stand.getWorld().spawnParticle(Particle.END_ROD, stand.getLocation().add(0, 1.8, 0), 1, 0.2, 0.2, 0.2, 0.02);
                  }
             }
        }
    }

    private void spawnDungeons(Arena arena) {
         // Using stub DungeonManager
         if (plugin.getDungeonManager() != null) {
              // Logic to spawn dungeon event
              Location loc = arena.getCornucopia().clone().add(random.nextInt(100)-50, 0, random.nextInt(100)-50);
              loc.setY(loc.getWorld().getHighestBlockYAt(loc));
              DungeonSpawnEvent event = new DungeonSpawnEvent(arena, loc, "RANDOM");
              Bukkit.getPluginManager().callEvent(event);
              if(!event.isCancelled()) {
                   plugin.getDungeonManager().spawnRandomDungeon(arena.getWorld(), event.getLocation(), arena);
              }
         }
    }
}

