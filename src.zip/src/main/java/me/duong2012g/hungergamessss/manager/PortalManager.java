package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages VoidStaff portal pairs.
 *
 * FIX M-03: Previous code used Map<Location, UUID> for portal block lookup.
 * Location.equals() compares world + x + y + z + yaw + pitch. block.getLocation()
 * always returns yaw=0/pitch=0, but locations from player movement carry non-zero
 * yaw/pitch — so containsKey/get silently failed and portals never triggered.
 *
 * The fix uses a canonical String key "worldName:bx,by,bz" built by locKey().
 * Block integer coordinates make floating-point rounding irrelevant.
 */
public class PortalManager {
    private final Main plugin;
    private final Map<UUID, PortalPair> playerPortals = new ConcurrentHashMap<>();
    // FIX M-03: was Map<Location, UUID> — now keyed by "world:bx,by,bz" string
    private final Map<String, UUID> portalLocations = new ConcurrentHashMap<>();
    private final Set<UUID> playersInPortal = Collections.newSetFromMap(new ConcurrentHashMap<>());

    public PortalManager(Main plugin) {
        this.plugin = plugin;
    }

    /** Stable block-coordinate key; immune to yaw/pitch and floating-point drift. */
    private static String locKey(Location loc) {
        return loc.getWorld().getName() + ":"
                + loc.getBlockX() + ","
                + loc.getBlockY() + ","
                + loc.getBlockZ();
    }

    public boolean createPortal(Player player, Location location) {
        UUID playerId = player.getUniqueId();
        PortalPair existingPair = playerPortals.get(playerId);

        if (existingPair == null) {
            Location portal1 = placePortalBlock(location);
            if (portal1 != null) {
                playerPortals.put(playerId, new PortalPair(portal1, null, playerId));
                portalLocations.put(locKey(portal1), playerId);
                startPortalEffects(portal1);
                return false;
            }
        } else if (existingPair.getPortal2() == null) {
            Location portal2 = placePortalBlock(location);
            if (portal2 != null) {
                existingPair.setPortal2(portal2);
                portalLocations.put(locKey(portal2), playerId);
                startPortalEffects(portal2);
                schedulePortalRemoval(playerId);
                return true;
            }
        } else {
            player.sendMessage("§cYou already have two portals! Wait for them to expire.");
        }
        return false;
    }

    public void removePortals(UUID playerId) {
        PortalPair pair = playerPortals.remove(playerId);
        if (pair != null) {
            if (pair.getPortal1() != null) {
                pair.getPortal1().getBlock().setType(Material.AIR);
                portalLocations.remove(locKey(pair.getPortal1()));
            }
            if (pair.getPortal2() != null) {
                pair.getPortal2().getBlock().setType(Material.AIR);
                portalLocations.remove(locKey(pair.getPortal2()));
            }
            Player player = plugin.getServer().getPlayer(playerId);
            if (player != null && player.isOnline()) {
                player.sendMessage("§d[Void] §7Your portals have vanished.");
            }
        }
    }

    public void handlePortalTouch(Player player, Location portalLocation) {
        UUID playerId = player.getUniqueId();
        if (playersInPortal.contains(playerId)) return;

        String key = locKey(portalLocation); // FIX M-03: String key lookup
        UUID portalOwner = portalLocations.get(key);
        if (portalOwner == null) return;

        PortalPair pair = playerPortals.get(portalOwner);
        if (pair == null || pair.getPortal2() == null) return;

        Location destination = null;
        if (key.equals(locKey(pair.getPortal1()))) {
            destination = pair.getPortal2().clone().add(0.5, 1.0, 0.5);
        } else if (key.equals(locKey(pair.getPortal2()))) {
            destination = pair.getPortal1().clone().add(0.5, 1.0, 0.5);
        }

        if (destination != null) {
            playersInPortal.add(playerId);
            player.teleport(destination);
            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
            player.getWorld().spawnParticle(Particle.PORTAL, player.getLocation(), 50, 0.5, 1.0, 0.5, 0.1);
            new BukkitRunnable() {
                @Override public void run() { playersInPortal.remove(playerId); }
            }.runTaskLater(plugin, 20L);
        }
    }

    public boolean isPortalBlock(Location location) {
        return portalLocations.containsKey(locKey(location)); // FIX M-03
    }

    private Location placePortalBlock(Location location) {
        Block block = location.getBlock();
        if (block.isEmpty() || block.isPassable()) {
            block.setType(Material.END_GATEWAY);
            return block.getLocation();
        }
        return null;
    }

    private void startPortalEffects(Location location) {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (location.getBlock().getType() != Material.END_GATEWAY) { cancel(); return; }
                location.getWorld().spawnParticle(Particle.PORTAL,
                        location.clone().add(0.5, 0.5, 0.5), 10, 0.3, 0.3, 0.3, 0.1);
            }
        }.runTaskTimer(plugin, 0L, 10L);
    }

    private void schedulePortalRemoval(UUID playerId) {
        new BukkitRunnable() {
            @Override public void run() { removePortals(playerId); }
        }.runTaskLater(plugin, 600L);
    }

    private static class PortalPair {
        private final Location portal1;
        private Location portal2;
        @SuppressWarnings("unused")
        private final UUID owner;

        public PortalPair(Location portal1, Location portal2, UUID owner) {
            this.portal1 = portal1; this.portal2 = portal2; this.owner = owner;
        }
        public Location getPortal1() { return portal1; }
        public Location getPortal2() { return portal2; }
        public void setPortal2(Location portal2) { this.portal2 = portal2; }
    }
}
