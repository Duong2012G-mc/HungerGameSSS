package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.Bukkit;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.CompletableFuture;

public class UpdateManager {
    private final Main plugin;
    private String latestVersion;
    private boolean updateAvailable = false;

    public UpdateManager(Main plugin) {
        this.plugin = plugin;
    }

    public void checkForUpdates() {
        if (!plugin.getConfig().getBoolean("update-checker.enabled", true)) return;

        String slug = plugin.getConfig().getString("update-checker.modrinth-slug", "hungergamessss");
        String currentVersion = plugin.getDescription().getVersion();

        CompletableFuture.runAsync(() -> {
            try {
                URL url = new URL("https://api.modrinth.com/v2/project/" + slug + "/version");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("User-Agent", "HungerGamesSSS-UpdateChecker/" + currentVersion);
                // FIX BUG-UM-01: missing timeouts caused the async thread to block indefinitely
                // if Modrinth was unreachable (network issue, DNS failure, server down).
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                if (conn.getResponseCode() == 200) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    // Modrinth returns a JSON array of versions. The first one is typically the latest.
                    // Minimal JSON parsing for version_number
                    String json = response.toString();
                    int versionIdx = json.indexOf("\"version_number\":\"");
                    if (versionIdx != -1) {
                        int start = versionIdx + 18;
                        int end = json.indexOf("\"", start);
                        latestVersion = json.substring(start, end);

                        if (!currentVersion.equalsIgnoreCase(latestVersion)) {
                            updateAvailable = true;
                            plugin.getLogger().info("A new version of HungerGamesSSS is available: " + latestVersion + " (Current: " + currentVersion + ")");
                            plugin.getLogger().info("Download it at: https://modrinth.com/plugin/" + slug);
                        }
                    }
                }
                conn.disconnect();
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to check for updates: " + e.getMessage());
            }
        });
    }

    public boolean isUpdateAvailable() {
        return updateAvailable;
    }

    public String getLatestVersion() {
        return latestVersion;
    }
}
