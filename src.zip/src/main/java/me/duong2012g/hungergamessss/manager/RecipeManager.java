package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;

public class RecipeManager {
    private final Main plugin;
    private final AbilityManager abilityManager;

    public RecipeManager(Main plugin, AbilityManager abilityManager) {
        this.plugin = plugin;
        this.abilityManager = abilityManager;
    }

    public void registerRecipes() {
        for (java.util.Map.Entry<String, java.util.Map<String, Object>> entry : abilityManager.getRecipes().entrySet()) {
            String id = entry.getKey();
            java.util.Map<String, Object> config = entry.getValue();
            
            if (!config.containsKey("ingredients")) continue;
            
            String name = (String) config.getOrDefault("name", id);
            
            // Check for shape in YAML, fallback to a default if missing
            String[] shape = null;
            if (config.containsKey("shape") && config.get("shape") instanceof java.util.List) {
                java.util.List<String> shapeList = (java.util.List<String>) config.get("shape");
                shape = shapeList.toArray(new String[0]);
            }
            
            // If no shape, we skip workbench registration and let Altar Crafting handle it
            if (shape == null) {
                plugin.getLogger().info("Skipping workbench recipe for " + name + " (no shape defined). Will be available via Altar Crafting.");
                continue;
            }

            java.util.Map<Character, Material> ingredientMap = new java.util.HashMap<>();
            Object ingredientsObj = config.get("ingredients");
            if (ingredientsObj instanceof java.util.Map) {
                java.util.Map<String, Object> yamlIngredients = (java.util.Map<String, Object>) ingredientsObj;
                
                // We need to map characters from the shape to materials
                // For simplicity in YAML, we can expect a 'mapping' section or just use the first letter of the material
                // But since existing code used specific mapping, let's look for a 'mapping' key
                if (config.containsKey("mapping") && config.get("mapping") instanceof java.util.Map) {
                    java.util.Map<String, String> mapping = (java.util.Map<String, String>) config.get("mapping");
                    for (java.util.Map.Entry<String, String> mapEntry : mapping.entrySet()) {
                        Material mat = Material.matchMaterial(mapEntry.getValue());
                        if (mat != null && mapEntry.getKey().length() > 0) {
                            ingredientMap.put(mapEntry.getKey().charAt(0), mat);
                        } else if (mat == null) {
                            plugin.getLogger().warning("Invalid material '" + mapEntry.getValue() + "' in recipe for: " + id);
                        }
                    }
                }
            }

            if (!ingredientMap.isEmpty()) {
                // B-19: NamespacedKey keys must be [a-z0-9/._-]
                String sanitizedId = id.toLowerCase().replaceAll("[^a-z0-9/._-]", "_");
                registerRecipe(sanitizedId, name, shape, ingredientMap);
            }
        }
    }

    private void registerRecipe(String key, String itemName, String[] shape, java.util.Map<Character, Material> ingredients) {
        ItemStack result = abilityManager.getLegendaryItem(itemName);
        if (result == null) {
            plugin.getLogger().warning("Could not find legendary item: " + itemName + " for recipe registration.");
            return;
        }

        NamespacedKey nsKey = new NamespacedKey(plugin, key);
        Bukkit.removeRecipe(nsKey);

        try {
            ShapedRecipe recipe = new ShapedRecipe(nsKey, result);
            recipe.shape(shape);
            for (java.util.Map.Entry<Character, Material> entry : ingredients.entrySet()) {
                recipe.setIngredient(entry.getKey(), entry.getValue());
            }
            Bukkit.addRecipe(recipe);
            plugin.getLogger().info("Registered workbench recipe for " + itemName);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to register recipe for " + itemName + ": " + e.getMessage());
        }
    }
}
