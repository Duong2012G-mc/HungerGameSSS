package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.util.ColorUtil;
import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.AbilityRegistry;
import me.duong2012g.hungergamessss.ability.Ability;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.*;

import me.duong2012g.hungergamessss.model.Ingredient;
import me.duong2012g.hungergamessss.model.LegendaryRecipe;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.EulerAngle;
import org.bukkit.attribute.Attribute;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.*;

public class AbilityManager {
    private final Main plugin;
    private final Map<String, Map<String, Object>> recipes;
    private final AbilityRegistry registry;

    public AbilityManager(Main plugin) {
        this.plugin = plugin;
        this.recipes = new HashMap<>();
        this.registry = new AbilityRegistry(plugin);
        saveDefaultRecipes();
        loadRecipes();
        startUnifiedPassiveTicker();
    }

    /**
     * FIX M-01: Single global passive ticker that replaces the 9 individual
     * BukkitRunnables previously spawned by individual ability constructors.
     *
     * Runs every 20 ticks. For each player in an active arena, calls
     * {@link me.duong2012g.hungergamessss.ability.BaseAbility#passiveTick} on
     * whichever ability the player is holding in their main hand or wearing as
     * armour. This eliminates duplicated arena/player iteration loops and ensures
     * all passive task cleanup happens in one place (see {@link #shutdown()}).
     *
     * Abilities that still own their own BukkitRunnable (legacy) continue to work —
     * the hook is a no-op by default, so there is no double-execution until each
     * ability is fully migrated.
     */
    private org.bukkit.scheduler.BukkitTask unifiedPassiveTask;

    private void startUnifiedPassiveTicker() {
        unifiedPassiveTask = new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                for (me.duong2012g.hungergamessss.model.Arena arena : plugin.getArenaManager().getArenas().values()) {
                    if (arena.getState() != me.duong2012g.hungergamessss.model.MatchState.PLAYING &&
                        arena.getState() != me.duong2012g.hungergamessss.model.MatchState.DEATHMATCH) continue;

                    for (java.util.UUID uuid : arena.getPlayers()) {
                        org.bukkit.entity.Player player = org.bukkit.Bukkit.getPlayer(uuid);
                        if (player == null) continue;

                        // Main-hand item passive
                        org.bukkit.inventory.ItemStack mainHand = player.getInventory().getItemInMainHand();
                        if (mainHand != null && mainHand.getType() != org.bukkit.Material.AIR) {
                            String abilityName = getAbilityName(mainHand);
                            if (abilityName != null) {
                                me.duong2012g.hungergamessss.ability.Ability ability = registry.getAbility(abilityName);
                                if (ability instanceof me.duong2012g.hungergamessss.ability.BaseAbility ba) {
                                    try { ba.passiveTick(player, mainHand); } catch (Exception e) {
                                        plugin.getLogger().warning("[PassiveTick] " + abilityName + ": " + e.getMessage());
                                    }
                                }
                            }
                        }

                        // Armour slot passives (helm, chestplate, leggings, boots)
                        org.bukkit.inventory.ItemStack[] armour = player.getInventory().getArmorContents();
                        for (org.bukkit.inventory.ItemStack piece : armour) {
                            if (piece == null || piece.getType() == org.bukkit.Material.AIR) continue;
                            String abilityName = getAbilityName(piece);
                            if (abilityName != null) {
                                me.duong2012g.hungergamessss.ability.Ability ability = registry.getAbility(abilityName);
                                if (ability instanceof me.duong2012g.hungergamessss.ability.BaseAbility ba) {
                                    try { ba.passiveTick(player, piece); } catch (Exception e) {
                                        plugin.getLogger().warning("[PassiveTick-armour] " + abilityName + ": " + e.getMessage());
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    /**
     * Cancel the unified passive ticker and invoke cleanup() on every registered ability.
     * This supersedes the manual DeathNote.cleanup() call in Main.onDisable() — all
     * standalone tasks (GolemHammer, HypnosisStaff, ObsidianDagger, DeathNote, …) are
     * now cancelled through the unified Ability.cleanup() contract.
     */
    public void shutdown() {
        if (unifiedPassiveTask != null && !unifiedPassiveTask.isCancelled()) {
            unifiedPassiveTask.cancel();
        }
        registry.shutdownAll();
    }
    
    private void saveDefaultRecipes() {
        String[] defaults = {
            "aiglos.yml", "armadillo_detonator.yml", "artemis_bow.yml", "beehive_blaster.yml",
            "cloud_sword.yml", "corrupted_crossbow.yml", "crimson_chainsword.yml",
            "death_note.yml", "dragon_katana.yml", "emerald_sword.yml",
            "ender_bow.yml", "excalibur.yml", "fountain_of_youth.yml", "ghastly_whistle.yml",
            "golem_hammer.yml", "guardian_cannon.yml", "hades_helm.yml", "harpoon_launcher.yml",
            "hermes_boots.yml", "horn_of_winter.yml", "hypnosis_staff.yml", "lich_staff.yml",
            "magma_club.yml", "midas_sword.yml", "mjolnir.yml", "obsidian_dagger.yml",
            "phantom_longbow.yml", "poseidons_trident.yml", "pufferfish_cannon.yml", "ravager_horn.yml",
            "reaper_scythe.yml", "reinforced_elytra.yml", "ribbit_reel.yml", "sculkweavers_lantern.yml",
            "shadow_blade.yml", "shrink_ray.yml", "soul_gauntlet.yml",
            "villager_wand.yml", "void_staff.yml", "warden_crossbow.yml", "warpick.yml",
            "wither_sickles.yml"
        };
        
        File dir = new File(plugin.getDataFolder(), "legend-items");
        if (!dir.exists()) dir.mkdirs();
        
        for (String name : defaults) {
            File file = new File(dir, name);
            if (!file.exists()) {
                try {
                    plugin.saveResource("legend-items/" + name, false);
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("Could not save default recipe: " + name);
                }
            }
        }
    }

    private final Map<String, String> customModelDataMap = new HashMap<>();

    public AbilityRegistry getRegistry() {
        return registry;
    }

    public Ability getAbility(String name) {
        return registry.getAbility(name);
    }

    private void loadRecipes() {
        File dir = new File(plugin.getDataFolder(), "legend-items");
        if (!dir.exists()) dir.mkdirs();

        File[] files = dir.listFiles((d, name) -> name.endsWith(".yml"));
        if (files == null) return;

        customModelDataMap.clear();
        for (File file : files) {
            YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
            Map<String, Object> map = new HashMap<>();
            
            for (String key : config.getKeys(false)) {
                if (key.equals("ingredients")) {
                    org.bukkit.configuration.ConfigurationSection ingSection = config.getConfigurationSection("ingredients");
                    if (ingSection != null) {
                        Map<String, Integer> ingMap = new java.util.LinkedHashMap<>();
                        for (String ingKey : ingSection.getKeys(false)) {
                            ingMap.put(ingKey, ingSection.getInt(ingKey));
                        }
                        map.put("ingredients", ingMap);
                    }
                } else if (key.equals("enchantments")) {
                    org.bukkit.configuration.ConfigurationSection enchSection = config.getConfigurationSection("enchantments");
                    if (enchSection != null) {
                        Map<String, Integer> enchMap = new java.util.LinkedHashMap<>();
                        for (String enchKey : enchSection.getKeys(false)) {
                            enchMap.put(enchKey, enchSection.getInt(enchKey));
                        }
                        map.put("enchantments", enchMap);
                    }
                } else if (config.isList(key)) {
                    map.put(key, config.getList(key));
                } else {
                    map.put(key, config.get(key));
                }
            }
            
            String abilityName = file.getName().replace(".yml", "").replace("_", " ");
            recipes.put(abilityName, map);

            String matName = config.getString("material", "STICK");
            int cmd = config.getInt("custom-model-data", -1);
            if (cmd != -1) {
                String cmdKey = matName.toUpperCase() + ":" + cmd;
                customModelDataMap.put(cmdKey, abilityName);
            }
        }
    }

    public Set<String> getRecipeNames() {
        return recipes.keySet();
    }

    public Map<String, Map<String, Object>> getRecipes() {
        return recipes;
    }

    public boolean giveLegendaryItem(Player player, String name) {
        ItemStack item = getLegendaryItem(name);
        if (item != null) {
            player.getInventory().addItem(item);
            return true;
        }
        return false;
    }
    
    public ItemStack getLegendaryItem(String name) {
        String key = name.toLowerCase().replace("_", " ");
        for (String recipeName : recipes.keySet()) {
            if (recipeName.equalsIgnoreCase(key)) {
                return createItem(recipeName, recipes.get(recipeName));
            }
        }
        for (String recipeName : recipes.keySet()) {
            if (recipeName.contains(key)) {
                return createItem(recipeName, recipes.get(recipeName));
            }
        }
        return null;
    }

    private ItemStack createItem(String name, Map<String, Object> config) {
        Material mat = Material.matchMaterial((String) config.getOrDefault("material", "STICK"));
        if (mat == null) return null;

        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            String key = name.toLowerCase().replace(" ", "_");
            String localizedName = plugin.getMessageManager().getMessage("legend_" + key + "_name");

            if (localizedName.equals("legend_" + key + "_name")) {
                localizedName = ColorUtil.colorize((String) config.getOrDefault("name", name));
            }
            // FIX L-FONT-01: Component API with italic=false prevents 1.20.5+ auto-italic
            meta.displayName(ColorUtil.component(localizedName));

            String localizedDesc = plugin.getMessageManager().getMessage("legend_" + key + "_desc");
            if (!localizedDesc.equals("legend_" + key + "_desc")) {
                List<net.kyori.adventure.text.Component> loreComp = new ArrayList<>();
                for (String line : localizedDesc.split("\\|")) {
                    if (line != null && !line.trim().isEmpty()) {
                        loreComp.add(ColorUtil.componentOf(line.trim()));
                    }
                }
                meta.lore(loreComp);
            } else {
                List<String> lore = (List<String>) config.get("lore");
                if (lore != null) {
                    List<net.kyori.adventure.text.Component> loreComp = new ArrayList<>();
                    for (String line : lore) {
                        loreComp.add(ColorUtil.componentOf(line));
                    }
                    meta.lore(loreComp);
                }
            }
            
            if (config.containsKey("custom-model-data")) {
                meta.setCustomModelData((Integer) config.get("custom-model-data"));
            }
            
            meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "hg_ability"), PersistentDataType.STRING, name.replace(" ", "_"));
            
            if (config.containsKey("enchantments")) {
                Object enchObj = config.get("enchantments");
                if (enchObj instanceof Map) {
                    Map<String, Object> enchMap = (Map<String, Object>) enchObj;
                    for (Map.Entry<String, Object> entry : enchMap.entrySet()) {
                        Enchantment ench = Enchantment.getByKey(NamespacedKey.minecraft(entry.getKey().toLowerCase()));
                        if (ench != null) {
                            int level = (entry.getValue() instanceof Number) ? ((Number) entry.getValue()).intValue() : 1;
                            meta.addEnchant(ench, level, true);
                        }
                    }
                }
            }

            // ── Unbreakable ───────────────────────────────────────────────────────
            if (Boolean.TRUE.equals(config.get("unbreakable"))) {
                ItemMeta unbrMeta = item.getItemMeta();
                if (unbrMeta != null) {
                    unbrMeta.setUnbreakable(true);
                    item.setItemMeta(unbrMeta);
                }
            }

            item.setItemMeta(meta);

            // ── Attribute Modifiers ───────────────────────────────────────────
            // Supported YAML format (list under "attributes"):
            //   attributes:
            //     - attribute: "GENERIC_ATTACK_DAMAGE"
            //       value: 6.0
            //       operation: "ADD_NUMBER"   # ADD_NUMBER | ADD_SCALAR | MULTIPLY_SCALAR_1
            //       slot: "MAINHAND"          # MAINHAND | ANY | ARMOR | etc.
            if (config.containsKey("attributes")) {
                Object attrObj = config.get("attributes");
                if (attrObj instanceof java.util.List<?> attrList) {
                    ItemMeta attrMeta = item.getItemMeta();
                    if (attrMeta != null) {
                        for (Object entry : attrList) {
                            if (!(entry instanceof Map<?, ?> rawMap)) continue;
                            try {
                                @SuppressWarnings("unchecked")
                                Map<String, Object> attrMap = (Map<String, Object>) rawMap;
                                String attrName = String.valueOf(attrMap.get("attribute")).toUpperCase();
                                double value = ((Number) attrMap.getOrDefault("value", 0)).doubleValue();
                                String opStr = String.valueOf(attrMap.getOrDefault("operation", "ADD_NUMBER")).toUpperCase();
                                String slotStr = String.valueOf(attrMap.getOrDefault("slot", "MAINHAND")).toUpperCase();

                                org.bukkit.attribute.Attribute attr = org.bukkit.attribute.Attribute.valueOf(attrName);
                                org.bukkit.attribute.AttributeModifier.Operation op =
                                    org.bukkit.attribute.AttributeModifier.Operation.valueOf(opStr);
                                org.bukkit.inventory.EquipmentSlotGroup slotGroup =
                                    org.bukkit.inventory.EquipmentSlotGroup.getByName(slotStr.toLowerCase());
                                if (slotGroup == null) slotGroup = org.bukkit.inventory.EquipmentSlotGroup.MAINHAND;

                                NamespacedKey modKey = new NamespacedKey(plugin, "hg_attr_" + attrName.toLowerCase());
                                org.bukkit.attribute.AttributeModifier mod =
                                    new org.bukkit.attribute.AttributeModifier(modKey, value, op, slotGroup);
                                attrMeta.addAttributeModifier(attr, mod);
                            } catch (Exception ex) {
                                plugin.getLogger().warning("[AbilityManager] Bad attribute entry: " + ex.getMessage());
                            }
                        }
                        item.setItemMeta(attrMeta);
                    }
                }
            }
        }
        return item;
    }

    public void handleAbility(Player player, ItemStack item, org.bukkit.event.player.PlayerInteractEvent event) {
        if (item == null || !item.hasItemMeta()) return;
        
        String name = getAbilityName(item);
        if (name == null) return;
        
        boolean debug = plugin.getConfig().getBoolean("debug", false);
        if (debug) {
            plugin.getLogger().info("[Ability] handleAbility: abilityName='" + name + "' action=" + event.getAction());
        }
        
        Ability ability = registry.getAbility(name);
        if (ability != null) {
            if (event.getAction().name().contains("RIGHT")) {
                ability.onRightClick(player, item, event);
            } else if (event.getAction().name().contains("LEFT")) {
                ability.onLeftClick(player, item, event);
            }
        } else if (debug) {
            plugin.getLogger().warning("[Ability] handleAbility: NO ability found in registry for name='" + name + "'");
        }
    }

    public void applyOnHitEffects(Player attacker, Entity victim, String name, org.bukkit.event.entity.EntityDamageByEntityEvent event) {
        Ability ability = registry.getAbility(name);
        if (ability != null && victim instanceof LivingEntity) {
            LivingEntity living = (LivingEntity) victim;
            ability.onHit(attacker, living, attacker.getInventory().getItemInMainHand(), event);
        }
    }

    public void handleProjectileLaunch(Player shooter, Projectile projectile, ItemStack item) {
        String name = getAbilityName(item);
        if (name == null) return;
        
        projectile.setMetadata("hg_ability", new org.bukkit.metadata.FixedMetadataValue(plugin, name));
        
        Ability ability = registry.getAbility(name);
        if (ability != null) {
            ability.onProjectileLaunch(shooter, projectile, item);
        }
    }

    public void handleProjectileHit(Projectile projectile, org.bukkit.event.entity.ProjectileHitEvent event) {
        if (projectile.getShooter() instanceof Player) {
            Player shooter = (Player) projectile.getShooter();
            if (projectile.hasMetadata("hg_ability")) {
                String name = projectile.getMetadata("hg_ability").get(0).asString();
                Ability ability = registry.getAbility(name);
                if (ability != null) {
                    ability.onProjectileHit(projectile, event);
                }
            }
        }
    }

    public void handleDamage(Player victim, ItemStack item, org.bukkit.event.entity.EntityDamageEvent event) {
        String name = getAbilityName(item);
        if (name == null) return;
        
        Ability ability = registry.getAbility(name);
        if (ability != null) {
            ability.onDamaged(victim, item, event);
        }
    }

    public void handleRiptide(Player player, ItemStack item, org.bukkit.event.player.PlayerRiptideEvent event) {
        String name = getAbilityName(item);
        if (name == null) return;
        
        Ability ability = registry.getAbility(name);
        if (ability != null) {
            ability.onRiptide(player, item, event);
        }
    }

    public void handleSneak(Player player, ItemStack item, org.bukkit.event.player.PlayerToggleSneakEvent event) {
        String name = getAbilityName(item);
        if (name == null) return;
        
        Ability ability = registry.getAbility(name);
        if (ability != null) {
            ability.onSneak(player, item, event);
        }
    }

    public void handleDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        for (Ability ability : registry.getAbilities()) {
            ability.onDeath(player, event);
        }
    }

    public void handleQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        for (Ability ability : registry.getAbilities()) {
            ability.onQuit(player, event);
        }
    }

    public void handleEntityChangeBlock(Entity entity, org.bukkit.event.entity.EntityChangeBlockEvent event) {
        if (entity.hasMetadata("hg_ability")) {
            String name = entity.getMetadata("hg_ability").get(0).asString();
            Ability ability = registry.getAbility(name);
            if (ability != null) {
                ability.onEntityChangeBlock(entity, event);
            }
        }
    }

    public void handleEntityTarget(Entity entity, org.bukkit.event.entity.EntityTargetEvent event) {
        if (entity.hasMetadata("hg_ability")) {
            String name = entity.getMetadata("hg_ability").get(0).asString();
            Ability ability = registry.getAbility(name);
            if (ability != null) {
                ability.onEntityTarget(entity, event);
            }
        }
    }

    public void handleEntityDamage(Entity entity, org.bukkit.event.entity.EntityDamageEvent event) {
        if (entity.hasMetadata("hg_ability")) {
            String name = entity.getMetadata("hg_ability").get(0).asString();
            Ability ability = registry.getAbility(name);
            if (ability != null) {
                ability.onEntityDamage(entity, event);
            }
        }
    }

    public void handleMove(Player player, ItemStack item, org.bukkit.event.player.PlayerMoveEvent event) {
        String name = getAbilityName(item);
        if (name == null) return;
        
        Ability ability = registry.getAbility(name);
        if (ability != null) {
            ability.onMove(player, item, event);
        }
    }

    public String getAbilityName(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        NamespacedKey key = new NamespacedKey(plugin, "hg_ability");
        
        if (meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)) {
            String abilityId = meta.getPersistentDataContainer().get(key, PersistentDataType.STRING);
            return abilityId.replace("_", " ");
        }
        
        if (meta.hasCustomModelData()) {
            String matKey = item.getType().name() + ":" + meta.getCustomModelData();
            if (customModelDataMap.containsKey(matKey)) {
                return customModelDataMap.get(matKey);
            }
        }
        
        // REMOVED: Tier 3 display name lookup for security reasons
        // Players can no longer trigger abilities by renaming items in anvil
        // This prevents ability spoof attacks (BUG-02)
        /*
        if (meta.hasDisplayName()) {
            String displayName = ChatColor.stripColor(meta.getDisplayName()).toLowerCase();
            for (String recipeName : recipes.keySet()) {
                if (recipeName.toLowerCase().equals(displayName)) {
                    // BUG-SEC-01: Validate material matches the recipe's configured material
                    // to prevent Anvil-renamed items from triggering abilities
                    Map<String, Object> recipeConfig = recipes.get(recipeName);
                    if (recipeConfig != null) {
                        String configMat = (String) recipeConfig.get("material");
                        if (configMat != null && item.getType().name().equalsIgnoreCase(configMat)) {
                            return recipeName;
                        }
                    }
                }
            }
        }
        */
        return null;
    }

    public void migrateItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return;
        String name = getAbilityName(item);
        if (name != null) {
            ItemMeta meta = item.getItemMeta();
            meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "hg_ability"), PersistentDataType.STRING, name.replace(" ", "_"));
            item.setItemMeta(meta);
        }
    }

    public static boolean isAbilityItem(ItemStack item, String name) {
        if (item == null || !item.hasItemMeta()) return false;
        
        ItemMeta meta = item.getItemMeta();
        try {
                NamespacedKey key = new NamespacedKey(Main.getInstance(), "hg_ability");
                if (meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)) {
                    String id = meta.getPersistentDataContainer().get(key, PersistentDataType.STRING).replace("_", " ");
                    return id.equalsIgnoreCase(name.replace("_", " "));
                }
            } catch (Exception e) {
                if (Main.getInstance().getConfig().getBoolean("debug", false)) {
                    Main.getInstance().getLogger().warning("Error checking PDC for ability item: " + e.getMessage());
                }
            }

        if (!meta.hasDisplayName()) return false;
        String itemName = ChatColor.stripColor(meta.getDisplayName()).toLowerCase();
        return itemName.equalsIgnoreCase(name.toLowerCase().replace("_", " "));
    }



    public List<LegendaryRecipe> getAllLegendaries() {
        List<LegendaryRecipe> list = new ArrayList<>();
        for (String key : recipes.keySet()) {
            Map<String, Object> config = recipes.get(key);
            String name = (String) config.getOrDefault("name", key);
            Material mat = Material.matchMaterial((String) config.getOrDefault("material", "STICK"));
            if (mat == null) continue;
            
            String desc = (String) config.getOrDefault("description", "");
            List<String> lore = (List<String>) config.get("lore");
            int cmd = config.get("custom-model-data") != null ? (Integer) config.get("custom-model-data") : 0;
            
            List<Ingredient> ingredients = new ArrayList<>();
            if (config.containsKey("ingredients")) {
                Object ingObj = config.get("ingredients");
                if (ingObj instanceof Map) {
                    Map<String, Object> ingMap = (Map<String, Object>) ingObj;
                    for (Map.Entry<String, Object> entry : ingMap.entrySet()) {
                        Material ingMat = Material.matchMaterial(entry.getKey());
                        if (ingMat != null) {
                            int amount = (Integer) entry.getValue();
                            ingredients.add(new Ingredient(ingMat, amount));
                        }
                    }
                }
            }
            
            Ingredient[] ingArray = ingredients.toArray(new Ingredient[0]);
            LegendaryRecipe recipe = new LegendaryRecipe(key.replace(" ", "_"), name, mat, desc, ingArray);
            if (lore != null) recipe.lore = lore;
            recipe.customModelData = cmd;
            recipe.heartCost = (Integer) config.getOrDefault("heart-cost", 0);
            
            if (config.containsKey("enchantments")) {
                Object enchObj = config.get("enchantments");
                if (enchObj instanceof Map) {
                    Map<String, Object> enchMap = (Map<String, Object>) enchObj;
                    for (Map.Entry<String, Object> entry : enchMap.entrySet()) {
                        Enchantment ench = Enchantment.getByKey(NamespacedKey.minecraft(entry.getKey().toLowerCase()));
                        if (ench != null) {
                            int level = (entry.getValue() instanceof Number) ? ((Number) entry.getValue()).intValue() : 1;
                            recipe.enchants.put(ench, level);
                        }
                    }
                }
            }

            recipe.config = config;
            list.add(recipe);
        }
        return list;
    }
}
