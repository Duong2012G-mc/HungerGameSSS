package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.util.ColorUtil;
import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.EulerAngle;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class HologramManager {
    private final Main plugin;
    private final Map<String, Map<Location, List<Entity>>> activeHologramsByArena = new ConcurrentHashMap<>();

    public HologramManager(Main plugin) {
        this.plugin = plugin;
    }

    public void updateHolograms() {
        for (Arena arena : plugin.getArenaManager().getArenas().values()) {
            String arenaName = arena.getName();
            Map<Location, List<Entity>> arenaHolograms = activeHologramsByArena.computeIfAbsent(arenaName, k -> new ConcurrentHashMap<>());
            
            for (Map.Entry<Location, String> entry : arena.getAllLegendaryLocations().entrySet()) {
                Location loc = entry.getKey();
                String itemName = entry.getValue();
                
                if (!arenaHolograms.containsKey(loc)) {
                    createLegendaryAltar(arena, loc, itemName);
                }
            }
        }
        
        // Cleanup old holograms and invalid entities
        Iterator<Map.Entry<String, Map<Location, List<Entity>>>> arenaIt = activeHologramsByArena.entrySet().iterator();
        while (arenaIt.hasNext()) {
            Map.Entry<String, Map<Location, List<Entity>>> arenaEntry = arenaIt.next();
            String arenaName = arenaEntry.getKey();
            Map<Location, List<Entity>> arenaHolograms = arenaEntry.getValue();
            
            Arena arena = plugin.getArenaManager().getArena(arenaName);
            boolean arenaExists = arena != null;
            
            Iterator<Map.Entry<Location, List<Entity>>> locIt = arenaHolograms.entrySet().iterator();
            while (locIt.hasNext()) {
                Map.Entry<Location, List<Entity>> locEntry = locIt.next();
                Location loc = locEntry.getKey();
                List<Entity> entities = locEntry.getValue();
                
                // Cleanup: check if arena still has this legendary location
                boolean stillValid = arenaExists && arena.getAllLegendaryLocations().containsKey(loc);
                
                if (!stillValid) {
                    for (Entity e : entities) {
                        if (e.isValid()) e.remove();
                    }
                    locIt.remove();
                } else {
                    // Cleanup individual invalid entities within valid locations
                    entities.removeIf(e -> !e.isValid());
                }
            }
            
            if (arenaHolograms.isEmpty()) {
                arenaIt.remove();
            }
        }
        
        // Rotate items
        for (Arena arena : plugin.getArenaManager().getArenas().values()) {
            Map<Location, List<Entity>> arenaHolograms = activeHologramsByArena.get(arena.getName());
            if (arenaHolograms == null || arenaHolograms.isEmpty()) continue;

            // PERF-01: Skip rotation if no players are nearby (50 blocks)
            boolean nearby = false;
            for (UUID uuid : arena.getPlayers()) {
                org.bukkit.entity.Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline() && arena.getCornucopia() != null) {
                    if (p.getLocation().getWorld().equals(arena.getCornucopia().getWorld()) &&
                        p.getLocation().distanceSquared(arena.getCornucopia()) < 2500) {
                        nearby = true;
                        break;
                    }
                }
            }
            if (!nearby) continue;

            for (List<Entity> entities : arenaHolograms.values()) {
                for (Entity e : entities) {
                    if (e instanceof ArmorStand as && !as.isVisible()) {
                        try {
                            // Only rotate the item stand (the one with the helmet)
                            if (as.getEquipment().getHelmet() != null && as.getEquipment().getHelmet().getType() != Material.AIR) {
                                EulerAngle old = as.getHeadPose();
                                double newY = (old.getY() + 0.1) % (2 * Math.PI);
                                as.setHeadPose(new EulerAngle(0, newY, 0));
                            }
                        } catch (Exception ex) {
                            // Ignore rare IllegalStateException
                        }
                    }
                }
            }
        }
    }

    public void removeAllHolograms() {
        for (Map<Location, List<Entity>> arenaHolograms : activeHologramsByArena.values()) {
            for (List<Entity> entities : arenaHolograms.values()) {
                for (Entity e : entities) {
                    if (e.isValid()) e.remove();
                }
            }
        }
        activeHologramsByArena.clear();
    }

    public void removeArenaHolograms(String arenaName) {
        Map<Location, List<Entity>> arenaHolograms = activeHologramsByArena.remove(arenaName);
        if (arenaHolograms != null) {
            for (List<Entity> entities : arenaHolograms.values()) {
                for (Entity e : entities) {
                    if (e.isValid()) e.remove();
                }
            }
        }
    }

    public void removeHologram(String arenaName, Location loc) {
        Map<Location, List<Entity>> arenaHolograms = activeHologramsByArena.get(arenaName);
        if (arenaHolograms != null) {
            List<Entity> entities = arenaHolograms.remove(loc);
            if (entities != null) {
                for (Entity e : entities) {
                    if (e.isValid()) e.remove();
                }
            }
        }
    }

    public void createLegendaryAltar(Arena arena, Location loc, String itemName) {
        Map<Location, List<Entity>> arenaHolograms = activeHologramsByArena.computeIfAbsent(arena.getName(), k -> new ConcurrentHashMap<>());
        if (arenaHolograms.containsKey(loc)) return;

        Map<String, Map<String, Object>> recipes = plugin.getAbilityManager().getRecipes();
        Map<String, Object> recipe = null;
        String realName = "";
        
        String searchKey = itemName.replace("_", " ");
        for (Map.Entry<String, Map<String, Object>> entry : recipes.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(searchKey)) {
                recipe = entry.getValue();
                realName = entry.getKey();
                break;
            }
        }

        if (recipe == null) {
            plugin.getLogger().severe("Failed to create legendary altar: Recipe '" + itemName + "' not found.");
            return;
        }

        List<Entity> entities = new ArrayList<>();
        Location current = loc.clone().add(0.5, 0.2, 0.5);

        // 1. Title
        entities.add(createLine(current.clone().add(0, 0.1, 0), "§e§lRight Click to Craft!"));

        // 2. Ingredients
        Object ingredientsObj = recipe.get("ingredients");
        double yOffset = 0.4;
        if (ingredientsObj instanceof Map) {
            try {
                @SuppressWarnings("unchecked")
                Map<String, Integer> ingredients = (Map<String, Integer>) ingredientsObj;
                List<String> keys = new ArrayList<>(ingredients.keySet());
                Collections.reverse(keys);
                for (String key : keys) {
                    Integer amount = ingredients.get(key);
                    String matName = key.replace("_", " ");
                    matName = matName.substring(0, 1).toUpperCase() + matName.substring(1).toLowerCase();
                    String line = "§b▪ §f" + amount + "x " + matName;
                    entities.add(createLine(current.clone().add(0, yOffset, 0), line));
                    yOffset += 0.25;
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Error displaying ingredients for " + realName);
            }
        }

        // 3. XP Cost
        int xp = 15;
        if (recipe.containsKey("xp-cost")) {
            Object xpObj = recipe.get("xp-cost");
            if (xpObj instanceof Integer) xp = (Integer) xpObj;
        }
        entities.add(createLine(current.clone().add(0, yOffset, 0), "§e§l⚡ " + xp + " XP"));
        yOffset += 0.35;

        // 4. Item Name
        String displayName = realName;
        Object nameObj = recipe.get("name");
        if (nameObj instanceof String) {
            displayName = ColorUtil.colorize((String) nameObj);
        }
        entities.add(createLine(current.clone().add(0, yOffset, 0), "§8§l» " + displayName.toUpperCase() + " «"));
        yOffset += 0.6;

        // 5. Floating Item
        Object matObj = recipe.get("material");
        Material mat = matObj instanceof String ? Material.matchMaterial((String) matObj) : Material.STICK;
        if (mat == null) mat = Material.STICK;
        
        ArmorStand as = (ArmorStand) loc.getWorld().spawnEntity(current.clone().add(0, yOffset, 0), EntityType.ARMOR_STAND);
        as.setVisible(false);
        as.setGravity(false);
        as.setSmall(true);
        as.setMarker(true);
        as.setBasePlate(false);
        
        ItemStack item = new ItemStack(mat);
        org.bukkit.inventory.meta.ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            Object cmdObj = recipe.get("custom-model-data");
            if (cmdObj instanceof Integer) {
                meta.setCustomModelData((Integer) cmdObj);
            }
            item.setItemMeta(meta);
        }
        
        as.getEquipment().setHelmet(item);
        entities.add(as);

        arenaHolograms.put(loc, entities);
    }

    private ArmorStand createLine(Location loc, String text) {
        ArmorStand as = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
        as.setCustomName(text);
        as.setCustomNameVisible(true);
        as.setVisible(false);
        as.setGravity(false);
        as.setMarker(true);
        return as;
    }
    
    public void removeAll() {
        removeAllHolograms();
    }
}

