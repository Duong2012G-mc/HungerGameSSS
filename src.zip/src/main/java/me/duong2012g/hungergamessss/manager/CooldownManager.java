package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class CooldownManager {
    private final Main plugin;
    private final Map<UUID, Map<String, CooldownInfo>> cooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, String> activeDisplayItem = new ConcurrentHashMap<>();

    public CooldownManager(Main plugin) {
        this.plugin = plugin;
        startUpdateTask();
    }

    public void setCooldown(Player player, String internalName, String displayName, long durationMillis) {
        UUID uuid = player.getUniqueId();
        CooldownInfo info = new CooldownInfo(displayName, durationMillis);
        cooldowns.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>()).put(internalName, info);
        activeDisplayItem.put(uuid, internalName);
    }

    public boolean isOnCooldown(Player player, String itemName) {
        Map<String, CooldownInfo> playerCooldowns = cooldowns.get(player.getUniqueId());
        if (playerCooldowns == null) return false;
        CooldownInfo info = playerCooldowns.get(itemName);
        return info != null && System.currentTimeMillis() < info.endTime;
    }

    public CooldownInfo getCooldownInfo(Player player, String itemName) {
        Map<String, CooldownInfo> playerCooldowns = cooldowns.get(player.getUniqueId());
        if (playerCooldowns == null) return null;
        return playerCooldowns.get(itemName);
    }

    public long getCooldown(Player player, String itemName) {
        CooldownInfo info = getCooldownInfo(player, itemName);
        return info != null ? Math.max(0, info.endTime - System.currentTimeMillis()) : 0;
    }

    public void removePlayer(UUID uuid) {
        cooldowns.remove(uuid);
        activeDisplayItem.remove(uuid);
    }

    private void startUpdateTask() {
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks += 2;
                
                // Periodic Cleanup (every 60 seconds = 1200 ticks)
                if (ticks >= 1200) {
                    ticks = 0;
                    cleanupExpiredCooldowns();
                }

                for (UUID uuid : activeDisplayItem.keySet()) {
                    Player player = Bukkit.getPlayer(uuid);
                    if (player == null || !player.isOnline()) {
                        removePlayer(uuid);
                        continue;
                    }

                    String itemName = activeDisplayItem.get(uuid);
                    CooldownInfo info = getCooldownInfo(player, itemName);

                    if (info == null || System.currentTimeMillis() >= info.endTime) {
                        activeDisplayItem.remove(uuid);
                        // FIX L-01: was player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(...))
                        // BungeeCord API is deprecated on Paper 1.21. Use Paper-native sendActionBar().
                        String readyMsg = Main.getInstance().getMessageManager().getMessage("cooldown_ready_actionbar",
                                Map.of("item", ChatColor.stripColor(info != null ? info.itemName : itemName)));
                        player.sendActionBar(LegacyComponentSerializer.legacyAmpersand().deserialize(readyMsg));
                        
                        // Phase 3: Trigger onCooldownEnd hook
                        if (info != null) {
                            me.duong2012g.hungergamessss.ability.Ability ability = plugin.getAbilityManager().getAbility(itemName);
                            if (ability != null) {
                                ItemStack item = player.getInventory().getItemInMainHand();
                                if (item == null || item.getType() == org.bukkit.Material.AIR) {
                                    item = player.getInventory().getItemInOffHand();
                                }
                                ability.onCooldownEnd(player, item);
                            }
                        }
                        continue;
                    }

                    String bar = generateProgressBar(info.getProgress(), 40);
                    String message = String.format("%s " + ChatColor.WHITE + "- " + ChatColor.WHITE + "%.1fs %s", 
                            itemName, info.getRemainingSeconds(), bar);
                    
                    // FIX L-01: Paper-native action bar
                    player.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(message));
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private void cleanupExpiredCooldowns() {
        long now = System.currentTimeMillis();
        for (Map<String, CooldownInfo> map : cooldowns.values()) {
            map.values().removeIf(info -> now >= info.endTime);
        }
        cooldowns.values().removeIf(Map::isEmpty);
    }

    private String generateProgressBar(double progress, int bars) {
        int completedBars = (int) (progress * bars);
        StringBuilder sb = new StringBuilder();
        sb.append(ChatColor.GREEN);
        for (int i = 0; i < completedBars; i++) {
            sb.append("|");
        }
        sb.append(ChatColor.GRAY);
        for (int i = completedBars; i < bars; i++) {
            sb.append("|");
        }
        return "[" + sb.toString() + "]";
    }

    public static class CooldownInfo {
        public long startTime;
        public long endTime;
        public String itemName;

        public CooldownInfo(String itemName, long durationMillis) {
            this.itemName = itemName;
            this.startTime = System.currentTimeMillis();
            this.endTime = this.startTime + durationMillis;
        }

        public double getProgress() {
            long total = endTime - startTime;
            long current = System.currentTimeMillis() - startTime;
            return Math.min(1.0, (double) current / total);
        }

        public double getRemainingSeconds() {
            return Math.max(0, (endTime - System.currentTimeMillis()) / 1000.0);
        }
    }
}
