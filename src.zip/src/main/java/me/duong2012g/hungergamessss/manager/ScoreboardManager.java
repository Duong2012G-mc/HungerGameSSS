package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.util.ColorUtil;
import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;

public class ScoreboardManager {
    private final Main plugin;
    private final Logger log;
    private final Map<UUID, Scoreboard> boards = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID, List<String>> lastLines = new java.util.concurrent.ConcurrentHashMap<>();
    private FileConfiguration config;

    public ScoreboardManager(Main plugin) {
        this.plugin = plugin;
        this.log = plugin.getLogger();
        loadConfig();
    }

    public void loadConfig() {
        File file = new File(plugin.getDataFolder(), "scoreboard.yml");
        if (!file.exists()) {
            plugin.saveResource("scoreboard.yml", false);
        }
        config = YamlConfiguration.loadConfiguration(file);
    }

    public void removePlayer(UUID uuid) {
        boards.remove(uuid);
        lastLines.remove(uuid);
        Player player = Bukkit.getPlayer(uuid);
        if (player != null) {
            player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
    }

    public void clearArenaScoreboards(Arena arena) {
        for (UUID uuid : arena.getPlayers()) {
            removePlayer(uuid);
        }
    }

    public void updateScoreboards(Arena arena) {
        for (UUID uuid : arena.getPlayers()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                updateScoreboard(p, arena);
            }
        }
        for (UUID uuid : arena.getSpectators()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                updateScoreboard(p, arena);
            }
        }
    }

    public void updateScoreboard(Player player, Arena arena) {
        UUID uuid = player.getUniqueId();
        List<String> rawLines = config.getStringList("lines");
        if (rawLines.size() > 16) rawLines = rawLines.subList(0, 16);
        
        List<String> formattedLines = new ArrayList<>();
        for (String line : rawLines) {
            formattedLines.add(replacePlaceholders(line, player, arena));
        }
        
        // Check if anything changed
        List<String> last = lastLines.get(uuid);
        if (last != null && last.equals(formattedLines)) return;
        
        lastLines.put(uuid, formattedLines);
        
        Scoreboard board = boards.computeIfAbsent(uuid, id -> {
            Scoreboard b = Bukkit.getScoreboardManager().getNewScoreboard();
            player.setScoreboard(b);
            return b;
        });
        
        Objective obj = board.getObjective("hg");
        if (obj == null) {
            obj = board.registerNewObjective("hg", "dummy", ColorUtil.colorize(config.getString("title", "&6&lHunger Games")));
            obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        } else {
            obj.setDisplayName(ColorUtil.colorize(config.getString("title", "&6&lHunger Games")));
        }

        int score = formattedLines.size();
        for (String formatted : formattedLines) {
            setLine(board, obj, formatted, score--);
        }
    }

    private String replacePlaceholders(String line, Player player, Arena arena) {
        String res = line;
        res = res.replace("%arena%", arena.getName());
        res = res.replace("%state_formatted%", formatState(arena.getState()));
        res = res.replace("%alive%", String.valueOf(arena.getGamePlayers().values().stream().filter(gp -> gp.isAlive()).count()));
        res = res.replace("%total%", String.valueOf(arena.getConfiguredSpawns().size()));
        // Team Placeholder
        me.duong2012g.hungergamessss.model.TeamData team = plugin.getTeamManager().getTeamOf(player);
        res = res.replace("%team%", team != null ? team.getColor() + team.getName() : "None");
        
        res = res.replace("%border%", arena.getWorld() != null ? String.valueOf((int) (arena.getWorld().getWorldBorder().getSize() / 2)) : "N/A");
        res = res.replace("%pvp_status%", arena.isPvpEnabled() ? plugin.getMessageManager().getMessage("scoreboard_pvp_enabled") : plugin.getMessageManager().getMessage("scoreboard_pvp_protected"));
        res = res.replace("%kills%", String.valueOf(arena.getKills(player.getUniqueId())));
        res = res.replace("%deaths%", String.valueOf(arena.getDeaths(player.getUniqueId())));
        // Feast Timer
    if (arena.getState() == MatchState.PLAYING) {
        int feastTime = plugin.getConfig().getInt("arena.feast.time-minutes", 20) * 60;
        int remaining = Math.max(0, feastTime - arena.getTimer());
        if (remaining > 0) {
            String timeStr = String.format("%02d:%02d", remaining / 60, remaining % 60);
            res = res.replace("%feast_timer%", timeStr);
        } else {
            res = res.replace("%feast_timer%", "Spawned!");
        }
    } else {
        res = res.replace("%feast_timer%", "N/A");
    }

    // CS-09: World placeholder with null check
    res = res.replace("%world%", arena.getWorld() != null ? arena.getWorld().getName() : "Unknown");
    return ColorUtil.colorize(res);
    }

    private String formatState(MatchState state) {
        return switch (state) {
            case WAITING -> plugin.getMessageManager().getMessage("scoreboard_state_waiting");
            case STARTING -> plugin.getMessageManager().getMessage("scoreboard_state_starting");
            case PLAYING -> plugin.getMessageManager().getMessage("scoreboard_state_playing");
            case DEATHMATCH -> plugin.getMessageManager().getMessage("scoreboard_state_deathmatch");
            case ENDING -> plugin.getMessageManager().getMessage("scoreboard_state_ending");
        };
    }

    private void setLine(Scoreboard board, Objective obj, String text, int score) {
        String entry = getEntry(score);
        Team team = board.getTeam("line_" + score);
        if (team == null) {
            team = board.registerNewTeam("line_" + score);
            team.addEntry(entry);
            obj.getScore(entry).setScore(score);
        }

        if (text.length() <= 64) {
            team.setPrefix(text);
            team.setSuffix("");
        } else {
            team.setPrefix(text.substring(0, 64));
            team.setSuffix(text.substring(64));
        }
    }

    private String getEntry(int score) {
        return ChatColor.values()[score].toString() + ChatColor.RESET;
    }

    public void removeBoard(Player player) {
        boards.remove(player.getUniqueId());
        player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
    }

    public void resetAll() {
        for (UUID uuid : new ArrayList<>(boards.keySet())) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) removeBoard(p);
        }
        boards.clear();
    }
}
