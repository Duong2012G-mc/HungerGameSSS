package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.TeamData;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TeamManager {
    private final Main plugin;
    private final Map<UUID, TeamData> teams = new ConcurrentHashMap<>(); // Leader UUID -> Team
    private final Map<UUID, InviteSession> invites = new ConcurrentHashMap<>(); // Target UUID -> InviteSession
    
    private static class InviteSession {
        final UUID inviterId;
        final long timestamp;
        
        InviteSession(UUID inviterId) {
            this.inviterId = inviterId;
            this.timestamp = System.currentTimeMillis();
        }
    }
    
    // Fast lookup for player -> team
    private final Map<UUID, TeamData> playerTeamMap = new ConcurrentHashMap<>();

    private final List<ChatColor> availableColors = new ArrayList<>();
    private int colorIndex = 0;
    
    private static final long INVITE_EXPIRY_TICKS = 1200L;

    public TeamManager(Main plugin) {
        this.plugin = plugin;
        loadColors();
    }

    public void loadColors() {
        availableColors.clear();
        List<String> configColors = plugin.getConfig().getStringList("teams.available-colors");
        
        if (configColors != null && !configColors.isEmpty()) {
            for (String colorName : configColors) {
                try {
                    ChatColor color = ChatColor.valueOf(colorName.toUpperCase());
                    availableColors.add(color);
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("Invalid team color in config: " + colorName);
                }
            }
        }
        
        // Fallback if no valid colors found
        if (availableColors.isEmpty()) {
            availableColors.add(ChatColor.RED);
            availableColors.add(ChatColor.BLUE);
            availableColors.add(ChatColor.GREEN);
            availableColors.add(ChatColor.YELLOW);
            availableColors.add(ChatColor.AQUA);
            availableColors.add(ChatColor.GOLD);
            availableColors.add(ChatColor.LIGHT_PURPLE);
            availableColors.add(ChatColor.DARK_RED);
            availableColors.add(ChatColor.DARK_BLUE);
            availableColors.add(ChatColor.DARK_GREEN);
            availableColors.add(ChatColor.DARK_AQUA);
            availableColors.add(ChatColor.DARK_PURPLE);
        }
    }

    public void addTeam(TeamData team) {
        if (team.getLeader() != null) {
            teams.put(team.getLeader(), team);
            for (UUID member : team.getMembers()) {
                playerTeamMap.put(member, team);
            }
        }
    }

    public TeamData createTeam(Player leader, String name) {
        if (getTeamOf(leader) != null) return null;
        
        int maxTeams = plugin.getConfig().getInt("teams.max-teams", 50);
        if (teams.size() >= maxTeams) {
            leader.sendMessage(plugin.getMessageManager().getMessage("team_limit_reached"));
            return null;
        }
        
        ChatColor color = getNextColor();
        int maxSize = plugin.getConfig().getInt("teams.max-players-per-team", 4);
        TeamData team = new TeamData(name, color, maxSize);
        team.addPlayer(leader);
        
        teams.put(leader.getUniqueId(), team);
        playerTeamMap.put(leader.getUniqueId(), team);
        
        // Save to DB
        plugin.getDatabaseManager().saveTeam(team);
        
        return team;
    }

    public void disbandTeam(TeamData team) {
        // Delete from DB first
        plugin.getDatabaseManager().deleteTeam(team.getLeader());
        
        for (UUID memberId : team.getPlayers()) {
            playerTeamMap.remove(memberId);
        }
        teams.remove(team.getLeader());
    }

    public boolean joinTeam(Player player, Player inviter) {
        TeamData team = getTeamOf(inviter);
        if (team == null) return false;
        
        if (team.getSize() >= plugin.getConfig().getInt("teams.max-players-per-team", 4)) return false;
        
        team.addPlayer(player);
        playerTeamMap.put(player.getUniqueId(), team);
        invites.remove(player.getUniqueId());
        
        // Save to DB
        plugin.getDatabaseManager().saveTeam(team);
        
        return true;
    }

    public boolean hasInvite(Player player, Player inviter) {
        InviteSession session = invites.get(player.getUniqueId());
        return session != null && session.inviterId.equals(inviter.getUniqueId());
    }
    
    public void invitePlayer(Player inviter, Player target) {
        InviteSession session = new InviteSession(inviter.getUniqueId());
        invites.put(target.getUniqueId(), session);
        
        // Auto expire after 60 seconds
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            InviteSession current = invites.get(target.getUniqueId());
            if (current != null && current == session) { // Ref check for exact session
                invites.remove(target.getUniqueId());
                if (target.isOnline()) {
                    target.sendMessage(plugin.getMessageManager().getMessage("team_invite_expired"));
                }
            }
        }, INVITE_EXPIRY_TICKS);
    }

    public void leaveTeam(Player player) {
        TeamData team = getTeamOf(player);
        if (team == null) return;
        
        // Check if player is the current key leader in map
        boolean wasLeaderKey = teams.containsKey(player.getUniqueId());
        
        team.removePlayer(player);
        playerTeamMap.remove(player.getUniqueId());
        
        if (team.getSize() == 0) {
            disbandTeam(team); // handles DB delete
        } else if (team.getLeader() == null) {
             // Should not happen if size > 0 due to removePlayer logic
             if (!team.getMembers().isEmpty()) {
                 if (wasLeaderKey) {
                     teams.remove(player.getUniqueId());
                     teams.put(team.getLeader(), team);
                     
                     // DB: Delete old key, save new key
                     plugin.getDatabaseManager().deleteTeam(player.getUniqueId());
                     plugin.getDatabaseManager().saveTeam(team);
                 }
             }
        } else {
             if (wasLeaderKey) {
                 teams.remove(player.getUniqueId());
                 teams.put(team.getLeader(), team);
                 
                 // DB: Delete old key, save new key
                 plugin.getDatabaseManager().deleteTeam(player.getUniqueId());
                 plugin.getDatabaseManager().saveTeam(team);
             } else {
                 // Just a member left, update DB
                 plugin.getDatabaseManager().saveTeam(team);
             }
        }
    }
    
    public void kickPlayer(TeamData team, Player target) {
        team.removePlayer(target);
        playerTeamMap.remove(target.getUniqueId());
        
        // Save to DB
        plugin.getDatabaseManager().saveTeam(team);
    }

    public TeamData getTeamOf(Player player) {
        return playerTeamMap.get(player.getUniqueId());
    }

    private ChatColor getNextColor() {
        Set<ChatColor> usedColors = new HashSet<>();
        for (TeamData team : teams.values()) {
            usedColors.add(team.getColor());
        }

        // Try to find a color that isn't used
        for (int i = 0; i < availableColors.size(); i++) {
            ChatColor color = availableColors.get(colorIndex);
            colorIndex = (colorIndex + 1) % availableColors.size();
            if (!usedColors.contains(color)) {
                return color;
            }
        }
        
        // If all available colors are used, just return the next one in round-robin
        ChatColor color = availableColors.get(colorIndex);
        colorIndex = (colorIndex + 1) % availableColors.size();
        return color;
    }
    
    public boolean isFriendlyFire(Player p1, Player p2) {
        TeamData t1 = getTeamOf(p1);
        TeamData t2 = getTeamOf(p2);
        return t1 != null && t2 != null && t1.equals(t2);
    }

    public Collection<TeamData> getAllTeams() {
        return teams.values();
    }
}
