package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Chest;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class FeastManager {
    private final Main plugin;
    // BUG-NEW-09: Track feast chest locations per arena for cleanup
    private final Map<String, List<Location>> feastChests = new ConcurrentHashMap<>();

    public FeastManager(Main plugin) {
        this.plugin = plugin;
    }

    // FIX H-04: Track which arenas have already had their feast spawned, preventing double-spawn
    // on servers where tick() might be called more than once at the boundary second.
    private final java.util.Set<String> feastSpawned = java.util.Collections.newSetFromMap(new ConcurrentHashMap<>());

    public void tick(Arena arena) {
        if (arena.getState() != MatchState.PLAYING) return;
        
        FileConfiguration config = plugin.getConfig();
        if (!config.getBoolean("arena.feast.enabled", true)) return;

        int timerSeconds = arena.getTimer();
        // FIX H-04: timer starts at 0 — announcements at timerSeconds==0 would fire the very
        // instant the match begins (when feastSeconds - announceSeconds == 0, i.e. a 0-minute
        // announce against a 20-minute feast). Guard against timerSeconds == 0 entirely.
        if (timerSeconds <= 0) return;

        int feastTimeMinutes = config.getInt("arena.feast.time-minutes", 20);
        int feastSeconds = feastTimeMinutes * 60;
        
        // Handle Announcements
        List<Integer> announceMinutes = config.getIntegerList("arena.feast.announce-minutes");
        for (int min : announceMinutes) {
            int announceSeconds = min * 60;
            if (timerSeconds == feastSeconds - announceSeconds) {
                String msg = plugin.getMessageManager().getMessage("feast_announcement", Map.of("minutes", String.valueOf(min)));
                arena.broadcast(msg);
                break;
            }
        }

        // Spawn Feast — guard with feastSpawned to prevent double-spawn
        if (timerSeconds == feastSeconds && feastSpawned.add(arena.getName())) {
            spawnFeast(arena);
        }
    }

    /** Called by MatchService.resetArena() so the feast-spawned flag is cleared between matches. */
    public void resetArena(String arenaName) {
        feastSpawned.remove(arenaName);
        cleanup(arenaName);
    }

    private void spawnFeast(Arena arena) {
        Location center = arena.getCornucopia();
        if (center == null || center.getWorld() == null) return;

        FileConfiguration config = plugin.getConfig();
        int radius = config.getInt("arena.feast.radius", 10);
        int chestCount = config.getInt("arena.feast.chest-count", 8);

        arena.broadcast(plugin.getMessageManager().getMessage("feast_spawned"));
        center.getWorld().strikeLightningEffect(center);

        // BUG-NEW-09: Track feast chest locations
        List<Location> locations = new java.util.ArrayList<>();

        // Spawn high-tier chests in a circle around the Cornucopia
        for (int i = 0; i < chestCount; i++) {
            double angle = 2 * Math.PI * i / chestCount;
            double x = center.getX() + radius * Math.cos(angle);
            double z = center.getZ() + radius * Math.sin(angle);
            Location chestLoc = new Location(center.getWorld(), x, center.getWorld().getHighestBlockYAt((int)x, (int)z) + 1, z);
            
            chestLoc.getBlock().setType(Material.CHEST);
            locations.add(chestLoc.clone());
            if (chestLoc.getBlock().getState() instanceof Chest) {
                Chest chest = (Chest) chestLoc.getBlock().getState();
                // Pass distance 0 to maximize loot rarity
                plugin.getLootTableManager().fillChest(chest.getInventory(), 0, 100);
            }
        }
        feastChests.put(arena.getName(), locations);
    }

    /**
     * BUG-NEW-09: Clean up feast chests when arena resets.
     */
    public void cleanup(String arenaName) {
        List<Location> locations = feastChests.remove(arenaName);
        if (locations != null) {
            for (Location loc : locations) {
                if (loc.getWorld() != null && loc.getBlock().getType() == Material.CHEST) {
                    loc.getBlock().setType(Material.AIR);
                }
            }
        }
    }
}
