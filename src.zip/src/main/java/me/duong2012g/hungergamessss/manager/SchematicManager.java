package me.duong2012g.hungergamessss.manager;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.WorldEditException;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardWriter;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldedit.session.ClipboardHolder;
import me.duong2012g.hungergamessss.Main;
import org.bukkit.Location;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;

import java.util.concurrent.CompletableFuture;

public class SchematicManager {
    private final Main plugin;
    private final File schematicsFolder;

    public SchematicManager(Main plugin) {
        this.plugin = plugin;
        String path = plugin.getConfig().getString("schematics-path", "structures");
        this.schematicsFolder = new File(plugin.getDataFolder(), path); // Ensure relative to plugin folder
        if (!schematicsFolder.exists()) {
            schematicsFolder.mkdirs();
        }
    }

    public CompletableFuture<Boolean> pasteSchematicAsync(final String fileName, final Location location) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        // Run asynchronously to prevent main thread blocking (Watchdog)
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            // SEC-03: Sanitize fileName to prevent path traversal
            String sanitized = new File(fileName).getName();
            if (sanitized.isEmpty()) {
                plugin.getLogger().warning("Invalid schematic file name: " + fileName);
                future.complete(false);
                return;
            }
            File tempFile = new File(schematicsFolder, sanitized.endsWith(".schem") ? sanitized : sanitized + ".schem");
            if (!tempFile.exists()) {
                tempFile = new File(schematicsFolder, sanitized.endsWith(".schematic") ? sanitized : sanitized + ".schematic");
            }
            final File file = tempFile;
            
            // SEC-03: Validate canonical path stays within schematics folder
            try {
                if (!file.getCanonicalPath().startsWith(schematicsFolder.getCanonicalPath())) {
                    plugin.getLogger().warning("Path traversal attempt blocked: " + fileName);
                    future.complete(false);
                    return;
                }
            } catch (IOException ioEx) {
                plugin.getLogger().warning("Failed to validate schematic path: " + fileName);
                future.complete(false);
                return;
            }

            if (!file.exists()) {
                plugin.getLogger().warning("Schematic file not found: " + fileName);
                future.complete(false);
                return;
            }

            ClipboardFormat format = ClipboardFormats.findByFile(file);
            if (format == null) {
                plugin.getLogger().warning("Unknown schematic format: " + file.getName());
                future.complete(false);
                return;
            }

            try (ClipboardReader reader = format.getReader(new FileInputStream(file))) {
                Clipboard clipboard = reader.read();
                
                // SCH-02: Safety check for async edits
                Runnable task = () -> {
                    try (EditSession editSession = WorldEdit.getInstance().newEditSession(BukkitAdapter.adapt(location.getWorld()))) {
                        // FAWE optimization if available
                        try {
                            editSession.getClass().getMethod("setFlushQueue", boolean.class).invoke(editSession, true);
                        } catch (Exception e) {
                            plugin.getLogger().warning("Failed to enable FAWE optimization: " + e.getMessage());
                            if (plugin.getConfig().getBoolean("debug", false)) {
                                e.printStackTrace();
                            }
                        }
                        
                        Operation operation = new ClipboardHolder(clipboard)
                                .createPaste(editSession)
                                .to(BlockVector3.at(location.getX(), location.getY(), location.getZ()))
                                .ignoreAirBlocks(false)
                                .build();
                        Operations.complete(operation);
                        plugin.getLogger().info("Successfully pasted schematic: " + file.getName() + " at " + location);
                        future.complete(true);
                    } catch (WorldEditException e) {
                        plugin.getLogger().log(Level.SEVERE, "Error pasting schematic: " + file.getName(), e);
                        future.complete(false);
                    }
                };

                // If FAWE is present, we can run async. Otherwise, we should return to main thread.
                if (org.bukkit.Bukkit.getPluginManager().getPlugin("FastAsyncWorldEdit") != null) {
                   task.run();
                } else {
                   plugin.getServer().getScheduler().runTask(plugin, task);
                }
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Error reading schematic: " + file.getName(), e);
                future.complete(false);
            }
        });
        
        return future;
    }

    /**
     * @deprecated Use {@link #pasteSchematicAsync(String, Location)} to avoid blocking the main thread.
     * Calling this on the main thread will throw an IllegalStateException.
     */
    @Deprecated
    public void pasteSchematic(String fileName, Location location) {
        if (org.bukkit.Bukkit.isPrimaryThread()) {
            throw new IllegalStateException("Schematic pasting must be done asynchronously to prevent server freezes.");
        }
        pasteSchematicAsync(fileName, location).join(); // Blocking call (legacy support)
    }

    public void saveSchematic(String fileName, Location pos1, Location pos2, Location origin) {
        // SEC-03: Sanitize fileName to prevent path traversal
        String sanitized = new File(fileName).getName();
        if (sanitized.isEmpty()) {
            plugin.getLogger().warning("Invalid schematic file name: " + fileName);
            return;
        }
        File file = new File(schematicsFolder, sanitized.endsWith(".schem") ? sanitized : sanitized + ".schem");
        // SEC-03: Validate canonical path
        try {
            if (!file.getCanonicalPath().startsWith(schematicsFolder.getCanonicalPath())) {
                plugin.getLogger().warning("Path traversal attempt blocked in saveSchematic: " + fileName);
                return;
            }
        } catch (IOException ioEx) {
            plugin.getLogger().warning("Failed to validate schematic path: " + fileName);
            return;
        }
        
        BlockVector3 min = BlockVector3.at(
            Math.min(pos1.getX(), pos2.getX()),
            Math.min(pos1.getY(), pos2.getY()),
            Math.min(pos1.getZ(), pos2.getZ())
        );
        BlockVector3 max = BlockVector3.at(
            Math.max(pos1.getX(), pos2.getX()),
            Math.max(pos1.getY(), pos2.getY()),
            Math.max(pos1.getZ(), pos2.getZ())
        );
        
        CuboidRegion region = new CuboidRegion(BukkitAdapter.adapt(pos1.getWorld()), min, max);
        Clipboard clipboard = new com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard(region);
        clipboard.setOrigin(BlockVector3.at(origin.getX(), origin.getY(), origin.getZ()));

        try (EditSession editSession = WorldEdit.getInstance().newEditSession(BukkitAdapter.adapt(pos1.getWorld()))) {
            com.sk89q.worldedit.function.operation.ForwardExtentCopy forwardExtentCopy = new com.sk89q.worldedit.function.operation.ForwardExtentCopy(
                editSession, region, clipboard, region.getMinimumPoint()
            );
            // B-16: Ensure origin is correctly handled by shifting ForwardExtentCopy if needed
            // Actually WorldEdit's clipboard.setOrigin(origin) makes paste relative to origin.
            // The copy should use region.getMinimumPoint() if clipboard is BlockArrayClipboard(region).
            // No changes needed here if origin is set correctly on the clipboard, but let's be explicit.
            forwardExtentCopy.setCopyingEntities(true);
            Operations.complete(forwardExtentCopy);
        } catch (WorldEditException e) {
            plugin.getLogger().log(Level.SEVERE, "Error copying region to clipboard", e);
            return;
        }

        ClipboardFormat format = ClipboardFormats.findByAlias("schem");
        if (format == null) format = ClipboardFormats.findByAlias("sponge");
        
        try (ClipboardWriter writer = format.getWriter(new FileOutputStream(file))) {
            writer.write(clipboard);
            plugin.getLogger().info("Successfully saved schematic: " + file.getName());
        } catch (IOException | NullPointerException e) {
            plugin.getLogger().log(Level.SEVERE, "Error saving schematic: " + file.getName(), e);
        }
    }

    public CompletableFuture<Void> clearAreaAsync(Location center, int radius) {
        CompletableFuture<Void> future = new CompletableFuture<>();
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try (EditSession editSession = WorldEdit.getInstance().newEditSession(BukkitAdapter.adapt(center.getWorld()))) {
                BlockVector3 min = BlockVector3.at(center.getX() - radius, center.getY() - 5, center.getZ() - radius);
                BlockVector3 max = BlockVector3.at(center.getX() + radius, center.getY() + 20, center.getZ() + radius);
                CuboidRegion region = new CuboidRegion(BukkitAdapter.adapt(center.getWorld()), min, max);
                
                // Set to AIR
                editSession.setBlocks((com.sk89q.worldedit.regions.Region) region, com.sk89q.worldedit.world.block.BlockTypes.AIR.getDefaultState());
                
                // Set floor
                BlockVector3 floorMin = BlockVector3.at(center.getX() - radius, center.getY() - 1, center.getZ() - radius);
                BlockVector3 floorMax = BlockVector3.at(center.getX() + radius, center.getY() - 1, center.getZ() + radius);
                CuboidRegion floorRegion = new CuboidRegion(BukkitAdapter.adapt(center.getWorld()), floorMin, floorMax);
                
                editSession.setBlocks((com.sk89q.worldedit.regions.Region) floorRegion, com.sk89q.worldedit.world.block.BlockTypes.GRASS_BLOCK.getDefaultState());
                
                editSession.close(); // Ensure flush
                future.complete(null);
            } catch (WorldEditException e) {
                plugin.getLogger().log(Level.SEVERE, "Error clearing area", e);
                future.completeExceptionally(e);
            }
        });
        return future;
    }

    public File getSchematicsFolder() {
        return schematicsFolder;
    }
}
