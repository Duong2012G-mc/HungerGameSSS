package me.duong2012g.hungergamessss.manager;

import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.math.BlockVector3;
import me.duong2012g.hungergamessss.Main;
import java.util.concurrent.CompletableFuture;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import me.duong2012g.hungergamessss.model.Arena;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;
import java.util.logging.Logger;

public class StructureManager {
    private final Main plugin;
    private final Logger log;
    private final List<StructureInfo> structures;
    private final Map<Location, StructureInfo> placedStructures;

    public StructureManager(Main plugin) {
        this.structures = new ArrayList<>();
        this.placedStructures = new java.util.concurrent.ConcurrentHashMap<>();
        this.plugin = plugin;
        this.log = plugin.getLogger();
        loadStructures();
    }

    public void loadStructures() {
        structures.clear();
        File dataFolder = plugin.getDataFolder();
        File dir = new File(dataFolder, "structures");
        
        if (!dir.exists()) {
            dir.mkdirs();
            log.info("Created structures directory: " + dir.getPath());
            // Create a default readme or example?
        }

        File[] files = dir.listFiles((d, name) -> name.endsWith(".schem") || name.endsWith(".nbt") || name.endsWith(".schematic"));
        if (files == null) {
            log.warning("Failed to list files in " + dir.getPath());
            return;
        }

        for (File file : files) {
            String name = file.getName().toLowerCase();
            StructureInfo info = classifyStructure(file, name);
            if (info != null) {
                structures.add(info);
                log.info("Loaded structure: " + info.name + " (" + info.type + ") Size: " + info.getSize());
            }
        }
        log.info("Total structures loaded: " + structures.size());
    }

    public void reloadStructures() {
        loadStructures();
    }

    private StructureInfo classifyStructure(File file, String name) {
        List<LootItem> loot = new ArrayList<>();
        List<EntityType> mobs = new ArrayList<>();
        StructureType type = StructureType.SMALL;
        BlockVector3 dimensions = BlockVector3.at(10, 10, 10); // Default
        int size = 10;

        // 1. Try to determine type from filename keywords (User Override)
        if (name.contains("tier4") || name.contains("massive") || name.contains("palace") || name.contains("temple") || name.contains("city")) {
            type = StructureType.MASSIVE;
        } else if (name.contains("tier3") || name.contains("large") || name.contains("fortress") || name.contains("castle")) {
            type = StructureType.LARGE;
        } else if (name.contains("tier2") || name.contains("medium") || name.contains("tower") || name.contains("outpost")) {
            type = StructureType.MEDIUM;
        } else if (name.contains("tier1") || name.contains("small") || name.contains("hut") || name.contains("house")) {
            type = StructureType.SMALL;
        } else {
            // SM-04: Default to SMALL and let getSize() load actual size if needed
            type = StructureType.SMALL;
        }

        boolean requiresOcean = name.contains("boat") || name.contains("ship") || name.contains("dutchman") || name.contains("ocean") || name.contains("water");

        // 3. Assign base loot/mobs based on Type
        loot.addAll(getLootForType(type));
        mobs.addAll(getMobsForType(type));

        // 4. Augment with filename specific mobs
        if (name.contains("zombie")) mobs.add(EntityType.ZOMBIE);
        if (name.contains("skeleton")) mobs.add(EntityType.SKELETON);
        if (name.contains("creeper")) mobs.add(EntityType.CREEPER);
        if (name.contains("spider")) mobs.add(EntityType.SPIDER);
        if (name.contains("witch")) mobs.add(EntityType.WITCH);
        if (name.contains("pillager")) mobs.add(EntityType.PILLAGER);
        if (name.contains("evoker")) mobs.add(EntityType.EVOKER);
        if (name.contains("blaze")) mobs.add(EntityType.BLAZE);
        if (name.contains("wither")) mobs.add(EntityType.WITHER_SKELETON);
        if (name.contains("piglin")) mobs.add(EntityType.PIGLIN);
        if (name.contains("brute")) mobs.add(EntityType.PIGLIN_BRUTE);
        if (name.contains("enderman")) mobs.add(EntityType.ENDERMAN);
        if (name.contains("ravager")) mobs.add(EntityType.RAVAGER);
        if (name.contains("iron_golem") || name.contains("golem")) mobs.add(EntityType.IRON_GOLEM);
        if (name.contains("villager")) mobs.add(EntityType.VILLAGER);

        // Remove duplicates if any
        mobs = new ArrayList<>(new HashSet<>(mobs));
        
        return new StructureInfo(file, name, type, dimensions, loot, mobs, requiresOcean);
    }
    
    private List<LootItem> getLootForType(StructureType type) {
        List<LootItem> loot = new ArrayList<>();
        switch (type) {
            case SMALL:
                // Food
                loot.add(new LootItem(Material.APPLE, 1, 3, 0.6));
                loot.add(new LootItem(Material.BREAD, 1, 3, 0.7));
                loot.add(new LootItem(Material.MELON_SLICE, 2, 5, 0.5));
                loot.add(new LootItem(Material.SWEET_BERRIES, 2, 6, 0.4));
                // Tools & Combat
                loot.add(new LootItem(Material.WOODEN_SWORD, 1, 1, 0.3));
                loot.add(new LootItem(Material.STONE_AXE, 1, 1, 0.2));
                loot.add(new LootItem(Material.BOW, 1, 1, 0.1));
                loot.add(new LootItem(Material.ARROW, 2, 5, 0.3));
                // Armor
                loot.add(new LootItem(Material.LEATHER_HELMET, 1, 1, 0.3));
                loot.add(new LootItem(Material.LEATHER_CHESTPLATE, 1, 1, 0.3));
                loot.add(new LootItem(Material.LEATHER_LEGGINGS, 1, 1, 0.3));
                loot.add(new LootItem(Material.LEATHER_BOOTS, 1, 1, 0.3));
                // Resources
                loot.add(new LootItem(Material.COBBLESTONE, 4, 16, 0.5));
                loot.add(new LootItem(Material.OAK_PLANKS, 4, 16, 0.5));
                loot.add(new LootItem(Material.COAL, 1, 3, 0.4));
                loot.add(new LootItem(Material.STICK, 1, 4, 0.6));
                break;
            case MEDIUM:
                // Food
                loot.add(new LootItem(Material.COOKED_BEEF, 2, 4, 0.6));
                loot.add(new LootItem(Material.COOKED_PORKCHOP, 2, 4, 0.6));
                loot.add(new LootItem(Material.GOLDEN_APPLE, 1, 1, 0.15));
                loot.add(new LootItem(Material.BAKED_POTATO, 2, 5, 0.5));
                // Tools & Combat
                loot.add(new LootItem(Material.IRON_SWORD, 1, 1, 0.25));
                loot.add(new LootItem(Material.IRON_AXE, 1, 1, 0.2));
                loot.add(new LootItem(Material.BOW, 1, 1, 0.3));
                loot.add(new LootItem(Material.CROSSBOW, 1, 1, 0.1));
                loot.add(new LootItem(Material.SHIELD, 1, 1, 0.2));
                loot.add(new LootItem(Material.TNT, 1, 2, 0.15));
                // Armor
                loot.add(new LootItem(Material.CHAINMAIL_HELMET, 1, 1, 0.3));
                loot.add(new LootItem(Material.CHAINMAIL_CHESTPLATE, 1, 1, 0.3));
                loot.add(new LootItem(Material.CHAINMAIL_LEGGINGS, 1, 1, 0.3));
                loot.add(new LootItem(Material.CHAINMAIL_BOOTS, 1, 1, 0.3));
                loot.add(new LootItem(Material.IRON_HELMET, 1, 1, 0.1));
                loot.add(new LootItem(Material.IRON_BOOTS, 1, 1, 0.1));
                // Resources
                loot.add(new LootItem(Material.IRON_INGOT, 1, 4, 0.4));
                loot.add(new LootItem(Material.GOLD_INGOT, 2, 5, 0.4));
                loot.add(new LootItem(Material.LAPIS_LAZULI, 3, 8, 0.3));
                loot.add(new LootItem(Material.FLINT_AND_STEEL, 1, 1, 0.2));
                break;
            case LARGE:
                // Food
                loot.add(new LootItem(Material.GOLDEN_CARROT, 2, 5, 0.6));
                loot.add(new LootItem(Material.COOKED_MUTTON, 4, 8, 0.6));
                loot.add(new LootItem(Material.PUMPKIN_PIE, 2, 4, 0.5));
                loot.add(new LootItem(Material.GOLDEN_APPLE, 1, 1, 0.15));
                // Tools & Combat
                loot.add(new LootItem(Material.DIAMOND_SWORD, 1, 1, 0.15));
                loot.add(new LootItem(Material.DIAMOND_AXE, 1, 1, 0.1));
                loot.add(new LootItem(Material.TRIDENT, 1, 1, 0.05));
                loot.add(new LootItem(Material.SPECTRAL_ARROW, 5, 10, 0.3));
                // Armor
                loot.add(new LootItem(Material.IRON_CHESTPLATE, 1, 1, 0.4));
                loot.add(new LootItem(Material.IRON_LEGGINGS, 1, 1, 0.4));
                loot.add(new LootItem(Material.DIAMOND_HELMET, 1, 1, 0.1));
                loot.add(new LootItem(Material.DIAMOND_BOOTS, 1, 1, 0.1));
                // Resources
                loot.add(new LootItem(Material.DIAMOND, 1, 3, 0.25));
                loot.add(new LootItem(Material.EMERALD, 1, 5, 0.3));
                loot.add(new LootItem(Material.EXPERIENCE_BOTTLE, 3, 12, 0.5));
                loot.add(new LootItem(Material.ENDER_PEARL, 1, 3, 0.35));
                loot.add(new LootItem(Material.BLAZE_ROD, 1, 2, 0.2));
                loot.add(new LootItem(Material.ANVIL, 1, 1, 0.1));
                loot.add(new LootItem(Material.ENCHANTING_TABLE, 1, 1, 0.1));
                break;
            case MASSIVE:
                // Rare Food
                loot.add(new LootItem(Material.ENCHANTED_GOLDEN_APPLE, 1, 1, 0.02));
                loot.add(new LootItem(Material.GOLDEN_APPLE, 1, 2, 0.4));
                loot.add(new LootItem(Material.CAKE, 1, 1, 0.3));
                // Top Tier Gear
                loot.add(new LootItem(Material.DIAMOND_CHESTPLATE, 1, 1, 0.25));
                loot.add(new LootItem(Material.DIAMOND_LEGGINGS, 1, 1, 0.25));
                loot.add(new LootItem(Material.NETHERITE_HELMET, 1, 1, 0.05));
                loot.add(new LootItem(Material.NETHERITE_BOOTS, 1, 1, 0.05));
                loot.add(new LootItem(Material.NETHERITE_SWORD, 1, 1, 0.05));
                // Resources & Utility
                loot.add(new LootItem(Material.NETHERITE_INGOT, 1, 1, 0.08));
                loot.add(new LootItem(Material.DIAMOND_BLOCK, 1, 2, 0.15));
                loot.add(new LootItem(Material.TOTEM_OF_UNDYING, 1, 1, 0.15));
                loot.add(new LootItem(Material.END_CRYSTAL, 1, 4, 0.2));
                loot.add(new LootItem(Material.DRAGON_BREATH, 1, 3, 0.2));
                loot.add(new LootItem(Material.NETHER_STAR, 1, 1, 0.02));
                loot.add(new LootItem(Material.BEACON, 1, 1, 0.02));
                loot.add(new LootItem(Material.SHULKER_BOX, 1, 1, 0.1));
                loot.add(new LootItem(Material.ELYTRA, 1, 1, 0.05));
                break;
        }
        return loot;
    }
    
    private List<EntityType> getMobsForType(StructureType type) {
        List<EntityType> mobs = new ArrayList<>();
        switch (type) {
            case SMALL:
                mobs.add(EntityType.ZOMBIE);
                mobs.add(EntityType.SKELETON);
                break;
            case MEDIUM:
                mobs.add(EntityType.ZOMBIE);
                mobs.add(EntityType.SKELETON);
                mobs.add(EntityType.SPIDER);
                mobs.add(EntityType.CREEPER);
                break;
            case LARGE:
                mobs.add(EntityType.VINDICATOR);
                mobs.add(EntityType.WITCH);
                mobs.add(EntityType.STRAY);
                mobs.add(EntityType.PILLAGER);
                break;
            case MASSIVE:
                mobs.add(EntityType.EVOKER);
                mobs.add(EntityType.WITHER_SKELETON);
                mobs.add(EntityType.BLAZE);
                mobs.add(EntityType.RAVAGER);
                mobs.add(EntityType.PIGLIN_BRUTE);
                break;
        }
        return mobs;
    }

    public CompletableFuture<Boolean> placeStructure(String name, Location loc) {
        // Try to find in loaded structures first
        for (StructureInfo info : structures) {
            String cleanName = info.name.replace(".schem", "").replace(".nbt", "").replace(".schematic", "");
            if (cleanName.equalsIgnoreCase(name) || info.name.equalsIgnoreCase(name)) {
                return placeStructure(loc, info);
            }
        }
        // If not found, try direct paste via SchematicManager if it's just a file path/name
        if (plugin.getSchematicManager() != null) {
            return plugin.getSchematicManager().pasteSchematicAsync(name, loc); 
            // Note: This bypasses the loot generation logic of StructureManager, 
            // but ArenaManager logic usually handles its own loot if it's a cornucopia.
        }
        return CompletableFuture.completedFuture(false);
    }

    public void saveStructure(String name, Location pos1, Location pos2) {
        if (plugin.getSchematicManager() != null) {
            plugin.getSchematicManager().saveSchematic(name, pos1, pos2, pos1);
        }
    }

    public File getStructureFolder() {
        return new File(plugin.getDataFolder(), "structures");
    }

    public CompletableFuture<Boolean> placeStructure(Location loc, StructureInfo info) {
        // Use SchematicManager to paste the structure asynchronously
        if (plugin.getSchematicManager() != null) {
            final Arena arena = plugin.getArenaManager().getArenaAt(loc);
            
            // Record original blocks before pasting for cleanup
            if (arena != null) {
                int halfSize = info.getSize() / 2;
                World world = loc.getWorld();
                for (int x = -halfSize; x <= halfSize; x++) {
                    for (int y = 0; y <= info.getSize(); y++) {
                        for (int z = -halfSize; z <= halfSize; z++) {
                            Location current = loc.clone().add(x, y, z);
                            Block b = world.getBlockAt(current);
                            if (b.getType() != Material.AIR && !arena.getOriginalBlocks().containsKey(current)) {
                                arena.getOriginalBlocks().put(current.clone(), b.getType());
                            }
                        }
                    }
                }
            }

            return plugin.getSchematicManager().pasteSchematicAsync(info.file.getName(), loc).thenApply(success -> {
                if (success) {
                    // Schedule follow-up tasks on main thread to handle Bukkit API calls
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        // Spawn Loot and Mobs
                        World world = loc.getWorld();
                        if (world != null && (info.loot != null || info.mobs != null)) {
                            // Spawn Mobs
                            if (info.mobs != null && !info.mobs.isEmpty()) {
                                // Calculate mob count based on structure size (approx 1 mob per 5 units of size)
                                // Minimum 3 mobs, Maximum 30 mobs to prevent lag
                                int totalMobs = Math.max(3, Math.min(30, info.getSize() / 5));
                                Random random = new Random();
                                
                                for (int i = 0; i < totalMobs; i++) {
                                    EntityType type = info.mobs.get(random.nextInt(info.mobs.size()));
                                    Location spawnLoc = getSafeSpawnLocation(loc, info.getSize() / 2);
                                    if (spawnLoc != null) {
                                        world.spawnEntity(spawnLoc, type);
                                    }
                                }
                            }
                            
                            // Fill Chests and Barrels
                            if (info.loot != null && !info.loot.isEmpty()) {
                                fillContainers(loc, info);
                            }
                        }
                        placedStructures.put(loc, info);
                    });
                } else {
                    log.warning("Failed to paste structure " + info.name);
                }
                return success;
            });
        } else {
            log.warning("SchematicManager not initialized, cannot paste " + info.name);
            return CompletableFuture.completedFuture(false);
        }
    }

    public void spawnRandomStructureNearPlayers(Arena arena, int minDistance, int maxDistance) {
        if (structures.isEmpty()) return;
        
        List<UUID> players = arena.getPlayers();
        if (players.isEmpty()) return;
        
        // Filter alive players
        List<Player> alivePlayers = new ArrayList<>();
        for (UUID uuid : players) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline() && !p.isDead()) {
                alivePlayers.add(p);
            }
        }
        
        if (alivePlayers.isEmpty()) return;
        
        Random random = new Random();
        Player targetPlayer = alivePlayers.get(random.nextInt(alivePlayers.size()));
        Location playerLoc = targetPlayer.getLocation();
        World world = playerLoc.getWorld();
        if (world == null) return;
        
        org.bukkit.WorldBorder border = world.getWorldBorder();
        
        for (int i = 0; i < 10; i++) {
            double angle = random.nextDouble() * 2 * Math.PI;
            double distance = minDistance + random.nextInt(maxDistance - minDistance);
            
            double x = playerLoc.getX() + Math.cos(angle) * distance;
            double z = playerLoc.getZ() + Math.sin(angle) * distance;
            
            // Check border
            Location checkLoc = new Location(world, x, 0, z);
            if (border != null && !border.isInside(checkLoc)) continue;
            
            // Get Highest Y (Solid Ground)
            int y = world.getHighestBlockYAt((int)x, (int)z);
            Block b = world.getBlockAt((int)x, y, (int)z);
            
            // Scan down to find solid ground (ignore leaves, logs, foliage)
            while (y > 0 && (b.getType().name().contains("LEAVES") || 
                             b.getType().name().contains("LOG") || 
                             !b.getType().isSolid() || 
                             b.getType().name().contains("GRASS") || 
                             b.getType().name().contains("FLOWER") || 
                             b.getType().name().contains("MUSHROOM"))) {
                if (b.getType().isSolid() && !b.getType().name().contains("LEAVES") && !b.getType().name().contains("LOG")) {
                    break; // Found solid ground
                }
                y--;
                b = world.getBlockAt((int)x, y, (int)z);
            }
            checkLoc.setY(y + 1);
            
            StructureInfo info = structures.get(random.nextInt(structures.size()));
            
            // Check water/land
            Block block = checkLoc.clone().subtract(0, 1, 0).getBlock();
            boolean isWater = block.getType().name().contains("WATER");
            
            if (info.requiresOcean && !isWater) continue;
            if (!info.requiresOcean && isWater) continue;
            
            // Check proximity to other structures
            boolean tooClose = false;
            for (Location placed : placedStructures.keySet()) {
                if (placed.getWorld() == world && placed.distance(checkLoc) < 100) {
                    tooClose = true;
                    break;
                }
            }
            if (tooClose) continue;
            
            // Place
            placeStructure(checkLoc, info);
            
            // Notify
            String msg = "§c§lWARNING: §eA mysterious structure has appeared near X:" + (int)x + " Z:" + (int)z + "!";
            for (Player p : alivePlayers) {
                p.sendMessage(msg);
            }
            log.info("Auto-spawned structure " + info.name + " near " + targetPlayer.getName());
            return;
        }
    }
    
    private void fillContainers(Location loc, StructureInfo info) {
        int halfSize = info.getSize() / 2;
        int startX = loc.getBlockX() - halfSize;
        int startZ = loc.getBlockZ() - halfSize;
        int endX = loc.getBlockX() + halfSize;
        int endZ = loc.getBlockZ() + halfSize;
        int startY = loc.getBlockY();
        int endY = Math.min(loc.getWorld().getMaxHeight(), loc.getBlockY() + info.getSize());

        World world = loc.getWorld();
        
        // Chunk optimization: Iterate chunks to find TileEntities
        // This is much faster than iterating every block in the volume
        int minChunkX = startX >> 4;
        int maxChunkX = endX >> 4;
        int minChunkZ = startZ >> 4;
        int maxChunkZ = endZ >> 4;

        for (int cx = minChunkX; cx <= maxChunkX; cx++) {
            for (int cz = minChunkZ; cz <= maxChunkZ; cz++) {
                if (world.isChunkLoaded(cx, cz)) {
                    org.bukkit.Chunk chunk = world.getChunkAt(cx, cz);
                    for (org.bukkit.block.BlockState state : chunk.getTileEntities()) {
                        if (state.getX() >= startX && state.getX() <= endX &&
                            state.getY() >= startY && state.getY() <= endY &&
                            state.getZ() >= startZ && state.getZ() <= endZ) {
                            
                            if (state instanceof org.bukkit.block.Container container) {
                                if (state.getType() == Material.CHEST || state.getType() == Material.BARREL) {
                                     fillInventory(container.getInventory(), info.loot);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void fillInventory(org.bukkit.inventory.Inventory inventory, List<LootItem> lootTable) {
        inventory.clear();
        Random random = new Random();
        
        // Fill 3-10 slots randomly
        int slotsToFill = 3 + random.nextInt(8);
        List<Integer> availableSlots = new ArrayList<>();
        for (int i = 0; i < inventory.getSize(); i++) {
            availableSlots.add(i);
        }
        Collections.shuffle(availableSlots);
        
        for (int i = 0; i < slotsToFill && i < availableSlots.size(); i++) {
            int slot = availableSlots.get(i);
            
            // Pick random loot item based on chance
            for (LootItem item : lootTable) {
                if (random.nextDouble() <= item.chance) {
                    int amount = item.min + random.nextInt(item.max - item.min + 1);
                    org.bukkit.inventory.ItemStack stack = new org.bukkit.inventory.ItemStack(item.material, amount);
                    inventory.setItem(slot, stack);
                    break; // Move to next slot
                }
            }
        }
    }
    
    private void spawnMobs(Location center, StructureInfo info) {
        World world = center.getWorld();
        if (world == null || info.mobs == null || info.mobs.isEmpty()) return;
        
        Random random = new Random();
        int totalMobs = Math.max(3, Math.min(30, info.getSize() / 5));
        
        for (int i = 0; i < totalMobs; i++) {
            EntityType type = info.mobs.get(random.nextInt(info.mobs.size()));
            Location spawnLoc = getSafeSpawnLocation(center, info.getSize() / 2);
            if (spawnLoc != null) {
                world.spawnEntity(spawnLoc, type);
            }
        }
    }

    private Location getSafeSpawnLocation(Location center, int radius) {
        World world = center.getWorld();
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            int x = random.nextInt(radius * 2) - radius;
            int z = random.nextInt(radius * 2) - radius;
            Location loc = center.clone().add(x, 0, z);
            loc.setY(world.getHighestBlockYAt(loc) + 1);
            if (loc.getBlock().getType() == Material.AIR) {
                return loc;
            }
        }
        return null;
    }

    public void spawnStructures(World world, int count, int radius) {
        Random random = new Random();
        int attempts = 0;
        int spawned = 0;
        
        log.info("Attempting to spawn " + count + " structures in world " + world.getName());

        while (spawned < count && attempts < count * 10) {
            attempts++;
            if (structures.isEmpty()) break;

            StructureInfo info = structures.get(random.nextInt(structures.size()));
            
            int x = random.nextInt(radius * 2) - radius;
            int z = random.nextInt(radius * 2) - radius;
            int y = world.getHighestBlockYAt(x, z);
            
            Location loc = new Location(world, x, y, z);
            Block block = loc.clone().subtract(0, 1, 0).getBlock();
            
            boolean isWater = block.getType() == Material.WATER || block.getType() == Material.SEAGRASS || block.getType() == Material.KELP;
            
            if (info.requiresOcean) {
                if (!isWater && block.getBiome() != org.bukkit.block.Biome.OCEAN && block.getBiome() != org.bukkit.block.Biome.DEEP_OCEAN && block.getBiome() != org.bukkit.block.Biome.WARM_OCEAN && block.getBiome() != org.bukkit.block.Biome.LUKEWARM_OCEAN && block.getBiome() != org.bukkit.block.Biome.COLD_OCEAN && block.getBiome() != org.bukkit.block.Biome.FROZEN_OCEAN) {
                    continue; // Skip if not ocean
                }
                // For ocean structures, spawn at sea level (usually 63) or slightly above
                loc.setY(63);
            } else {
                if (isWater) {
                    continue; // Skip if water for non-ocean structures
                }
            }

            // Check distance from other structures
            boolean tooClose = false;
            for (Location placed : placedStructures.keySet()) {
                // SM-01: Prevent IllegalArgumentException if worlds are different
                if (placed.getWorld() != loc.getWorld()) continue;
                
                if (placed.distance(loc) < 100) { // Min distance 100 blocks
                    tooClose = true;
                    break;
                }
            }
            if (tooClose) continue;

            placeStructure(loc, info);
            spawned++;
            log.info("Spawned " + info.name + " at " + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ());
        }
        
        if (spawned < count) {
            log.warning("Could only spawn " + spawned + "/" + count + " structures after " + attempts + " attempts.");
        }
    }

    public void resetStructures(Arena arena) {
        if (arena == null) return;
        World world = arena.getWorld();
        if (world == null) return;

        // SM-03: Use originalBlocks for precise restoration instead of generic AIR fill
        for (Location loc : new java.util.ArrayList<>(arena.getOriginalBlocks().keySet())) {
            // Only restore if this location was part of a structure (optional optimization: 
            // check against placedStructures but placedStructures usually center locs)
            // For now, we restore everything in the arena's originalBlocks that looks like it belongs to structures
            // or just everything in originalBlocks that we tracked.
            
            Material original = arena.getOriginalBlocks().get(loc);
            world.getBlockAt(loc).setType(original, false);
            arena.getOriginalBlocks().remove(loc);
        }
        
        placedStructures.entrySet().removeIf(e -> e.getKey().getWorld().equals(world));
        log.info("Reset all structures in arena " + arena.getName());
    }

    public void resetStructures() {
        // Legacy fallback
        for (Location loc : new java.util.ArrayList<>(placedStructures.keySet())) {
             World world = loc.getWorld();
             if (world != null) {
                 // Try to find arena and use smarter reset
                 Arena arena = plugin.getArenaManager().getArenaAt(loc);
                 if (arena != null) {
                     resetStructures(arena);
                     continue;
                 }
                 // If no arena found, simple clear (less safe)
                 for (int x = -10; x <= 10; x++) {
                    for (int z = -10; z <= 10; z++) {
                        for (int y = 0; y <= 10; y++) {
                            world.getBlockAt(loc.getBlockX() + x, loc.getBlockY() + y, loc.getBlockZ() + z).setType(Material.AIR);
                        }
                    }
                }
             }
        }
        placedStructures.clear();
        log.info("Reset all structures.");
    }

    public Map<String, Object> getStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalStructures", structures.size());
        stats.put("placedCount", placedStructures.size());
        stats.put("smallCount", structures.stream().filter(s -> s.type == StructureType.SMALL).count());
        stats.put("mediumCount", structures.stream().filter(s -> s.type == StructureType.MEDIUM).count());
        stats.put("largeCount", structures.stream().filter(s -> s.type == StructureType.LARGE).count());
        stats.put("massiveCount", structures.stream().filter(s -> s.type == StructureType.MASSIVE).count());
        return stats;
    }

    public Map<Location, File> getPlacedStructures() {
        Map<Location, File> map = new HashMap<>();
        for (Map.Entry<Location, StructureInfo> entry : placedStructures.entrySet()) {
            map.put(entry.getKey(), entry.getValue().file);
        }
        return map;
    }

    private static class StructureInfo {
        File file;
        String name;
        StructureType type;
        BlockVector3 dimensions; // Changed from int size
        List<LootItem> loot;
        List<EntityType> mobs;
        boolean requiresOcean;

        public StructureInfo(File file, String name, StructureType type, BlockVector3 dimensions, List<LootItem> loot, List<EntityType> mobs, boolean requiresOcean) {
            this.file = file;
            this.name = name;
            this.type = type;
            this.dimensions = dimensions;
            this.loot = loot;
            this.mobs = mobs;
            this.requiresOcean = requiresOcean;
        }
        
        public int getSize() {
            if (dimensions == null) {
                // SM-04: Lazy load dimensions if they weren't determined by filename
                try {
                    ClipboardFormat format = ClipboardFormats.findByFile(file);
                    if (format != null) {
                        try (ClipboardReader reader = format.getReader(new java.io.FileInputStream(file))) {
                            Clipboard clipboard = reader.read();
                            dimensions = clipboard.getDimensions();
                        }
                    }
                } catch (java.io.IOException e) {
                    // Fallback to default small if read fails
                    dimensions = BlockVector3.at(10, 10, 10);
                }
            }
            return Math.max(dimensions.x(), Math.max(dimensions.y(), dimensions.z()));
        }
    }

    private enum StructureType {
        SMALL, MEDIUM, LARGE, MASSIVE
    }

    private static class LootItem {
        Material material;
        int min;
        int max;
        double chance;

        public LootItem(Material material, int min, int max, double chance) {
            this.material = material;
            this.min = min;
            this.max = max;
            this.chance = chance;
        }
    }
}
