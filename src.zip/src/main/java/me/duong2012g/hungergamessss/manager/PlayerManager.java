package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.PlayerData;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerManager implements Listener {
    private final Main plugin;
    private final Map<UUID, PlayerData> playerData = new HashMap<>();

    public PlayerManager(Main plugin) {
        this.plugin = plugin;
    }

    public PlayerData getPlayerData(Player player) {
        return playerData.computeIfAbsent(player.getUniqueId(), 
            uuid -> new PlayerData(uuid));
    }

    public void removePlayerData(Player player) {
        playerData.remove(player.getUniqueId());
    }

    public Map<UUID, PlayerData> getAllPlayerData() {
        return playerData;
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        // Delay to ensure database is loaded if needed, or just apply immediate if cached
        // For now, simple delay to apply health
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;
                updateHealth(player);
            }
        }.runTaskLater(plugin, 20L);
    }

    @EventHandler
    public void onPlayerQuit(org.bukkit.event.player.PlayerQuitEvent event) {
        // BUG-DB-01: Invalidate cache on quit
        removePlayerData(event.getPlayer());
    }
    
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = event.getItem();
        if (item == null || item.getType() != Material.RED_DYE) return;
        if (!item.hasItemMeta()) return;
        // BUG-PM-01 Fix: meta.getDisplayName() returns "" for Component-API display names
        // (set via meta.displayName(Component)). Use a PDC tag to identify stolen hearts.
        org.bukkit.NamespacedKey heartKey = new org.bukkit.NamespacedKey(plugin, "stolen_heart");
        if (!item.getItemMeta().getPersistentDataContainer()
                .has(heartKey, org.bukkit.persistence.PersistentDataType.BYTE)) return;

        event.setCancelled(true);
        Player player = event.getPlayer();

        // Check max health limit
        double currentMax = player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
        double hardCap = plugin.getConfig().getDouble("arena.lifesteal-max-health", 40.0);

        if (currentMax >= hardCap) {
            player.sendMessage(plugin.getMessageManager().getMessage("max_health_reached"));
            return;
        }

        // Consume item
        item.setAmount(item.getAmount() - 1);

        // Add health
        PlayerData data = getPlayerData(player);
        data.setLifestealHearts(data.getLifestealHearts() + 1);
        updateHealth(player);

        player.sendMessage(plugin.getMessageManager().getMessage("stolen_heart_consumed"));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
    }
    
    public void updateHealth(Player player) {
        PlayerData data = getPlayerData(player);
        double base = 20.0;
        double bonus = data.getLifestealHearts() * 2.0;
        double max = Math.min(base + bonus, plugin.getConfig().getDouble("arena.lifesteal-max-health", 40.0));
        
        if (player.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            player.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(max);
        }
    }
}
