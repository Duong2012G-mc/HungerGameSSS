package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.Location;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SelectionManager {
    private final Main plugin;
    private final Map<UUID, Location[]> selections = new HashMap<>();

    public SelectionManager(Main plugin) {
        this.plugin = plugin;
    }

    public void setPos1(UUID uuid, Location loc) {
        Location[] locs = this.selections.computeIfAbsent(uuid, k -> new Location[2]);
        locs[0] = loc;
    }

    public void setPos2(UUID uuid, Location loc) {
        Location[] locs = this.selections.computeIfAbsent(uuid, k -> new Location[2]);
        locs[1] = loc;
    }

    public Location[] getSelection(UUID uuid) {
        return this.selections.get(uuid);
    }

    public boolean hasSelection(UUID uuid) {
        Location[] locs = this.selections.get(uuid);
        return locs != null && locs[0] != null && locs[1] != null;
    }

    public void clearSelection(org.bukkit.entity.Player player) {
        this.selections.remove(player.getUniqueId());
    }
}
