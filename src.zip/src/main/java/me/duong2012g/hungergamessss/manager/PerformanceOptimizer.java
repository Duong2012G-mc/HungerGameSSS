package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import me.duong2012g.hungergamessss.model.Arena;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class PerformanceOptimizer {
    private final Main plugin;
    private final Map<String, Queue<Runnable>> blockChangeQueues = new ConcurrentHashMap<>();
    private final Map<String, Long> lastOptimizationTime = new ConcurrentHashMap<>();
    private final Set<Chunk> loadedChunks = ConcurrentHashMap.newKeySet();
    private final AtomicInteger activeTasks = new AtomicInteger(0);
    // FIX M-10: was missing — toggleMonitoring() always returned true because it checked activeTasks >= 0
    private final java.util.concurrent.atomic.AtomicBoolean monitoringEnabled = new java.util.concurrent.atomic.AtomicBoolean(true);
    private static final int MAX_BLOCKS_PER_TICK = 1000;

    public PerformanceOptimizer(Main plugin) {
        this.plugin = plugin;
        startOptimizationTask();
    }

    public void queueBlockChange(final Location loc, final Material material, final ArenaManager arenaManager) {
        if (loc == null || loc.getWorld() == null) return;
        String worldName = loc.getWorld().getName();
        final Arena arena = arenaManager.getArenaAt(loc);
        
        blockChangeQueues.computeIfAbsent(worldName, k -> new ConcurrentLinkedQueue<>()).add(() -> setBlockOptimized(loc, material, arenaManager, arena));
    }

    public void processBlockChanges(String worldName) {
        Queue<Runnable> queue = blockChangeQueues.get(worldName);
        if (queue == null || queue.isEmpty()) return;
        
        int maxPerTick = plugin.getPerformanceConfig().getInt("block-processing.max-blocks-per-tick", 1000);
        int processed = 0;
        while (!queue.isEmpty() && processed < maxPerTick) {
            Runnable task = queue.poll();
            if (task != null) {
                task.run();
                processed++;
            }
        }
    }

    public void setBlockOptimized(Location loc, Material material, ArenaManager arenaManager, Arena arena) {
        World world = loc.getWorld();
        if (world == null) return;
        
        // Only load chunk if absolutely necessary and configured
        if (plugin.getPerformanceConfig().getBoolean("advanced.chunk-ticket-optimization", true)) {
            Chunk chunk = loc.getChunk();
            if (!chunk.isLoaded()) {
                chunk.load();
                loadedChunks.add(chunk);
            }
        }

        // CS-01: setBlockSmart already handles setType and original block tracking.
        // Doing the setType here first is redundant and might cause double physics/overhead.
        if (arenaManager != null) {
            arenaManager.setBlockSmart(world, loc, material, arena);
        } else {
            loc.getBlock().setType(material, false);
        }
    }

    private void startOptimizationTask() {
        int interval = plugin.getPerformanceConfig().getInt("monitoring.stats-log-interval", 200);
        plugin.getServer().getScheduler().runTaskTimer(plugin, this::optimizeServer, interval, interval);
    }

    private void optimizeServer() {
        for (String worldName : new HashSet<>(blockChangeQueues.keySet())) {
            processBlockChanges(worldName);
        }
        
        if (plugin.getPerformanceConfig().getBoolean("entity-management.enable-entity-limiting", true)) {
            optimizeEntities();
        }
        
        if (plugin.getPerformanceConfig().getBoolean("large-server.aggressive-chunk-unloading", false)) {
            unloadUnusedChunks();
        }
        
        clearOldCaches();
    }

    private void optimizeEntities() {
        int itemDelay = plugin.getPerformanceConfig().getInt("entity-management.item-cleanup-delay", 300) * 20; // to ticks
        int maxEntities = plugin.getPerformanceConfig().getInt("entity-management.max-entities-per-chunk", 50);

        for (World world : Bukkit.getWorlds()) {
            boolean isArenaWorld = plugin.getArenaManager().getArenas().values().stream()
                .anyMatch(a -> a.getWorld() != null && a.getWorld().equals(world));
            if (!isArenaWorld) continue;

            world.getEntities().stream()
                .filter(e -> e instanceof Item)
                .map(e -> (Item) e)
                .filter(item -> item.getTicksLived() > itemDelay)
                .forEach(Entity::remove);

            for (Chunk chunk : world.getLoadedChunks()) {
                Entity[] entities = chunk.getEntities();
                if (entities.length > maxEntities) {
                    Arrays.stream(entities)
                        .filter(e -> e instanceof Item)
                        .limit(entities.length - maxEntities)
                        .forEach(Entity::remove);
                }
            }
        }
    }

    private void unloadUnusedChunks() {
        long currentTime = System.currentTimeMillis();
        long unloadDelay = plugin.getPerformanceConfig().getLong("chunk-management.chunk-unload-delay", 3000L);

        loadedChunks.removeIf(chunk -> {
            World world = chunk.getWorld();
            boolean isArenaWorld = plugin.getArenaManager().getArenas().values().stream()
                .anyMatch(a -> a.getWorld() != null && a.getWorld().equals(world));
            if (isArenaWorld) return false;

            boolean shouldUnload = (currentTime - lastOptimizationTime.getOrDefault(world.getName(), 0L) > unloadDelay)
                && chunk.isLoaded() 
                && Arrays.stream(chunk.getEntities()).noneMatch(e -> e instanceof Player);
            if (shouldUnload) {
                chunk.unload();
                return true;
            }
            return false;
        });
        for (World world : Bukkit.getWorlds()) {
            lastOptimizationTime.put(world.getName(), currentTime);
        }
    }

    private void clearOldCaches() {
        blockChangeQueues.entrySet().removeIf(e -> e.getValue().isEmpty());
    }

    public BukkitTask scheduleAsyncTask(Runnable task, long delay) {
        activeTasks.incrementAndGet();
        return plugin.getServer().getScheduler().runTaskLaterAsynchronously(plugin, () -> {
            try {
                task.run();
            } finally {
                activeTasks.decrementAndGet();
            }
        }, delay);
    }

    public void reloadConfig() {
        // Clear all caches and restart optimization task
        blockChangeQueues.clear();
        lastOptimizationTime.clear();
        loadedChunks.clear();
        
        // Restart optimization task with new config
        startOptimizationTask();
    }

    /** FIX M-10: was always returning true (activeTasks.get() >= 0 is always true).
     *  Now properly toggles the monitoring flag and returns the new state. */
    public boolean toggleMonitoring() {
        boolean newState = !monitoringEnabled.get();
        monitoringEnabled.set(newState);
        return newState;
    }

    public Map<String, Object> getPerformanceStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("Active Tasks", activeTasks.get());
        stats.put("Queued Block Changes", blockChangeQueues.values().stream().mapToInt(Queue::size).sum());
        stats.put("Loaded Chunks", loadedChunks.size());
        return stats;
    }

    public void optimize() { this.optimizeServer(); }

    public double getParticleMultiplier() {
        if (plugin.getPerformanceConfig().getBoolean("effects-optimization.reduce-particles-crowded", true)) {
            int countThreshold = plugin.getPerformanceConfig().getInt("effects-optimization.particle-reduction-threshold", 20);
            if (Bukkit.getOnlinePlayers().size() >= countThreshold) {
                return 0.25; // Significant reduction for crowded areas
            }
        }

        double[] tps = Bukkit.getTPS();
        if (tps == null || tps.length == 0) return 1.0;
        double currentTps = tps[0];
        if (currentTps >= 18.0) return 1.0;
        if (currentTps >= 15.0) return 0.5;
        if (currentTps >= 10.0) return 0.25;
        return 0.1;
    }
}
