package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.scheduler.BukkitRunnable;

public class CornucopiaBuilder {
    private final Main plugin;
    private World world;
    private Location center;
    private int radius;

    public CornucopiaBuilder(Main plugin, World world, Location center, int radius) {
        this.plugin = plugin;
        this.world = world;
        this.center = center;
        this.radius = radius;
    }

    public void setWorld(World world) { this.world = world; }
    public void setCenter(Location center) { this.center = center; }
    public void setRadius(int radius) { this.radius = radius; }
    
    public void configure(World world, Location center, int radius) {
        this.world = world;
        this.center = center;
        this.radius = radius;
    }
    
    // Constructor for Main class initialization (if needed as a service, though likely instantiated per arena build)
    public CornucopiaBuilder(Main plugin) {
        this.plugin = plugin;
        this.world = null;
        this.center = null;
        this.radius = 0;
    }

    public void clearArea(final Runnable onComplete) {
        if (world == null || center == null) return;
        
        int chunkRadius = (radius >> 4) + 1;
        int centerX = center.getBlockX() >> 4;
        int centerZ = center.getBlockZ() >> 4;
        
        final java.util.List<java.util.concurrent.CompletableFuture<org.bukkit.Chunk>> chunkFutures = new java.util.ArrayList<>();
        plugin.getLogger().info("[Cornucopia] Pre-loading chunks...");

        for (int x = -chunkRadius; x <= chunkRadius; x++) {
            for (int z = -chunkRadius; z <= chunkRadius; z++) {
                chunkFutures.add(world.getChunkAtAsync(centerX + x, centerZ + z));
            }
        }

        java.util.concurrent.CompletableFuture.allOf(chunkFutures.toArray(new java.util.concurrent.CompletableFuture[0]))
            .thenRun(() -> {
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        startClearingTask(onComplete);
                    }
                }.runTask(plugin);
            });
    }

    private void startClearingTask(final Runnable onComplete) {
        new BukkitRunnable(){
            int x;
            int z;
            int blocksPerTick;
            long processedCount = 0;
            long totalBlocks;
            int lastPercent = 0;

            {
                this.x = -CornucopiaBuilder.this.radius;
                this.z = -CornucopiaBuilder.this.radius;
                this.blocksPerTick = Math.max(5000, CornucopiaBuilder.this.plugin.getConfig().getInt("performance.block-processing.max-blocks-per-tick", 5000));
                this.totalBlocks = (long) (CornucopiaBuilder.this.radius * 2 + 1) * (CornucopiaBuilder.this.radius * 2 + 1);
                plugin.getLogger().info("[Cornucopia] Clearing area (radius " + CornucopiaBuilder.this.radius + ")...");
            }

            public void run() {
                int tickProcessed = 0;
                while (this.x <= CornucopiaBuilder.this.radius && tickProcessed < this.blocksPerTick) {
                    while (this.z <= CornucopiaBuilder.this.radius && tickProcessed < this.blocksPerTick) {
                        int absX = CornucopiaBuilder.this.center.getBlockX() + this.x;
                        int absZ = CornucopiaBuilder.this.center.getBlockZ() + this.z;
                        int absY = CornucopiaBuilder.this.center.getBlockY();
                        
                        // Ensure chunk is loaded (though we pre-loaded it)
                        if (!world.isChunkLoaded(absX >> 4, absZ >> 4)) {
                            this.z++; // Skip if not loaded for some reason to avoid sync lock
                            continue;
                        }

                        int highestY = CornucopiaBuilder.this.world.getHighestBlockYAt(absX, absZ);
                        int endY = Math.max(absY + 30, highestY);
                        
                        for (int y = absY + 1; y <= endY && tickProcessed < this.blocksPerTick; ++y) {
                            org.bukkit.block.Block b = CornucopiaBuilder.this.world.getBlockAt(absX, y, absZ);
                            if (b.getType() != Material.AIR) {
                                b.setType(Material.AIR, false);
                                ++tickProcessed;
                            }
                        }
                        if (tickProcessed >= this.blocksPerTick) break;

                        org.bukkit.block.Block base = CornucopiaBuilder.this.world.getBlockAt(absX, absY, absZ);
                        if (base.getType() != Material.GRASS_BLOCK) {
                            base.setType(Material.GRASS_BLOCK, false);
                            ++tickProcessed;
                        }
                        if (tickProcessed >= this.blocksPerTick) break;

                        for (int y = absY - 1; y >= absY - 15 && tickProcessed < this.blocksPerTick; --y) {
                            org.bukkit.block.Block sub = CornucopiaBuilder.this.world.getBlockAt(absX, y, absZ);
                            Material type = sub.getType();
                            if (type == Material.AIR || type == Material.WATER || type == Material.LAVA || !type.isSolid()) {
                                sub.setType(Material.DIRT, false);
                                ++tickProcessed;
                            } else {
                                break;
                            }
                        }
                        
                        if (tickProcessed >= this.blocksPerTick) continue;
                        
                        processedCount++;
                        int percent = (int) ((processedCount * 100) / totalBlocks);
                        if (percent >= lastPercent + 25 && percent < 100) {
                            plugin.getLogger().info("[Cornucopia] Clearing... " + percent + "%");
                            lastPercent = percent;
                        }

                        ++this.z;
                    }
                    if (tickProcessed >= this.blocksPerTick) break;
                    this.z = -CornucopiaBuilder.this.radius;
                    ++this.x;
                }
                if (this.x > CornucopiaBuilder.this.radius) {
                    this.cancel();
                    // CB-02: Better message scoping
                    CornucopiaBuilder.this.plugin.getLogger().info("Cornucopia area cleared at " + CornucopiaBuilder.this.center);
                    if (onComplete != null) {
                        onComplete.run();
                    }
                }
            }
        }.runTaskTimer(this.plugin, 1L, (long)this.plugin.getConfig().getInt("performance.block-processing.batch-delay", 1));
    }

    public void buildCornucopia(final Location loc, final String style, final int playerCount, final me.duong2012g.hungergamessss.model.Arena arena, final Runnable onComplete) {
        buildMajesticCornucopia(loc, playerCount, arena, onComplete);
    }
    
    public void buildMajesticCornucopia(final Location center, final int playerCount, final me.duong2012g.hungergamessss.model.Arena arena, final Runnable onComplete) {
        if (center == null || world == null || arena == null) {
            if (onComplete != null) onComplete.run();
            return;
        }

        plugin.getLogger().info("Building Majestic Cornucopia for " + playerCount + " players at " + center);
        arena.broadcast("§6[Cornucopia] §eBuilding Majestic structure...");

        // Calculate geometry — cap chestRadius to keep loot within 0-10 blocks of center
        int chestRadius = Math.min(10, Math.max(6, 4 + (playerCount / 2)));
        int innerRadius = Math.max(3, chestRadius / 2);
        double angleStep = (2 * Math.PI) / playerCount;
        
        // Materials from config
        Material floorMat = Material.valueOf(plugin.getConfig().getString("cornucopia.materials.floor", "QUARTZ_BRICKS"));
        Material decorMat = Material.valueOf(plugin.getConfig().getString("cornucopia.materials.decor", "GOLD_BLOCK"));
        Material pillarMat = Material.valueOf(plugin.getConfig().getString("cornucopia.materials.pillar", "CHISELED_QUARTZ_BLOCK"));
        Material lightMat = Material.valueOf(plugin.getConfig().getString("cornucopia.materials.light", "SEA_LANTERN"));

        // Local Clearing (only if clearArea() was not called beforehand)
        int clearRadius = chestRadius + 3;
        for (int x = -clearRadius; x <= clearRadius; x++) {
            for (int z = -clearRadius; z <= clearRadius; z++) {
                for (int y = 0; y <= 10; y++) {
                    plugin.getArenaManager().queueBlock(arena, center.clone().add(x, y, z), Material.AIR, false);
                }
                plugin.getArenaManager().queueBlock(arena, center.clone().add(x, -1, z), Material.GRASS_BLOCK, true);
            }
        }

        // 2. Platform
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                plugin.getArenaManager().queueBlock(arena, center.clone().add(x, -1, z), floorMat, true);
            }
        }
        plugin.getArenaManager().queueBlock(arena, center.clone().add(0, -1, 0), decorMat, true);
        plugin.getArenaManager().queueBlock(arena, center.clone().add(0, 0, 0), lightMat, true);
        plugin.getArenaManager().queueBlock(arena, center.clone().add(0, 1, 0), Material.LIGHT_BLUE_STAINED_GLASS, true);

        // Inner ring chests
        int innerChests = Math.max(4, playerCount / 2);
        double innerAngleStep = (2 * Math.PI) / innerChests;
        for (int i = 0; i < innerChests; i++) {
            double angle = i * innerAngleStep;
            double dx = Math.cos(angle);
            double dz = Math.sin(angle);
            Location innerChestLoc = center.clone().add(dx * innerRadius, 0, dz * innerRadius);
            plugin.getArenaManager().queueBlock(arena, innerChestLoc.clone().add(0, -1, 0), floorMat, true);
            plugin.getArenaManager().queueBlock(arena, innerChestLoc, Material.CHEST, true);
        }

        // 3. Outer Spokes
        for (int i = 0; i < playerCount; i++) {
            double angle = i * angleStep;
            double dx = Math.cos(angle);
            double dz = Math.sin(angle);
            for (int r = 2; r <= chestRadius; r++) {
                plugin.getArenaManager().queueBlock(arena, center.clone().add(dx * r, -1, dz * r), floorMat, true);
            }
            Location chestLoc = center.clone().add(dx * chestRadius, 0, dz * chestRadius);
            plugin.getArenaManager().queueBlock(arena, chestLoc, Material.CHEST, true);
            Location pillarLoc = center.clone().add(dx * (chestRadius + 1), 0, dz * (chestRadius + 1));
            plugin.getArenaManager().queueBlock(arena, pillarLoc, pillarMat, true);
            plugin.getArenaManager().queueBlock(arena, pillarLoc.clone().add(0, 1, 0), lightMat, true);
        }

        // Use ArenaManager's processQueue to handle all the blocks we just queued
        plugin.getArenaManager().processQueue(arena, () -> {
            center.getWorld().strikeLightningEffect(center);
            center.getWorld().spawnParticle(org.bukkit.Particle.EXPLOSION_EMITTER, center.clone().add(0, 2, 0), 1);
            center.getWorld().playSound(center, org.bukkit.Sound.ENTITY_WITHER_SPAWN, 1.0f, 1.0f);
            if (onComplete != null) onComplete.run();
        });
    }
}
