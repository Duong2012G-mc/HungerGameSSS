package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.logging.Logger;

/**
 * Manages chest loot generation for Cornucopia, dungeon, and feast chests.
 */
public class LootTableManager {
    private final Main plugin;
    private final Random random = new Random();
    private final Logger log;

    public enum LootTier {
        COMMON(0.7),
        UNCOMMON(0.25),
        RARE(0.05);

        private final double weight;
        LootTier(double weight) { this.weight = weight; }
        public double getWeight() { return weight; }
    }

    // A2-18: LootEntry is pure immutable data — converted to a record.
    // Records provide equals/hashCode/toString automatically.
    private record LootEntry(Material material, int minAmount, int maxAmount) {
        LootEntry {
            java.util.Objects.requireNonNull(material, "LootEntry material must not be null");
            if (minAmount < 1) throw new IllegalArgumentException("minAmount must be >= 1");
            if (maxAmount < minAmount) throw new IllegalArgumentException("maxAmount must be >= minAmount");
        }
    }

    private final List<LootEntry> commonLoot   = new ArrayList<>();
    private final List<LootEntry> uncommonLoot = new ArrayList<>();
    private final List<LootEntry> rareLoot     = new ArrayList<>();

    public LootTableManager(Main plugin) {
        this.plugin = plugin;
        this.log    = plugin.getLogger();
        // Save default loot.yml if absent
        plugin.saveResource("loot.yml", false);
        reload();
    }

    public void reload() {
        commonLoot.clear();
        uncommonLoot.clear();
        rareLoot.clear();

        File file = new File(plugin.getDataFolder(), "loot.yml");
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        loadTier(cfg, "loot.common",   commonLoot);
        loadTier(cfg, "loot.uncommon", uncommonLoot);
        loadTier(cfg, "loot.rare",      rareLoot);

        log.info("[LootTableManager] Loaded "
                + commonLoot.size()   + " common, "
                + uncommonLoot.size() + " uncommon, "
                + rareLoot.size()     + " rare loot entries from loot.yml");
    }

    private void loadTier(FileConfiguration cfg, String path, List<LootEntry> target) {
        List<?> entries = cfg.getList(path);
        if (entries == null) {
            log.warning("[LootTableManager] Missing section '" + path + "' in loot.yml");
            return;
        }
        for (Object obj : entries) {
            // FIX: Sử dụng Raw Map để tránh lỗi 'capture#1 of ?' trong Java 21
            if (!(obj instanceof Map map)) continue; 
            
            try {
                String matName = String.valueOf(map.get("material"));
                Material mat = Material.matchMaterial(matName);
                if (mat == null) {
                    log.warning("[LootTableManager] Unknown material '" + matName + "' — skipping");
                    continue;
                }

                // Sử dụng Pattern Matching để lấy giá trị số an toàn
                Object minObj = map.getOrDefault("min", 1);
                Object maxObj = map.getOrDefault("max", 1);
                
                int min = (minObj instanceof Number n) ? n.intValue() : 1;
                int max = (maxObj instanceof Number n) ? n.intValue() : 1;

                target.add(new LootEntry(mat, min, max));
            } catch (Exception e) {
                log.warning("[LootTableManager] Bad entry in " + path + ": " + e.getMessage());
            }
        }
    }

    // -------------------------------------------------------------------------

    public void fillChest(Inventory inv, double distanceFromCenter, double maxRadius) {
        inv.clear();
        double rarityBonus = Math.max(0, 1.0 - (distanceFromCenter / maxRadius));

        int slotCount = inv.getSize();
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < slotCount; i++) slots.add(i);
        Collections.shuffle(slots);

        int minItems = plugin.getConfig().getInt("loot.min-items", 2);
        int maxItems = plugin.getConfig().getInt("loot.max-items", 4);
        int itemCount = minItems + random.nextInt(Math.max(1, maxItems - minItems + 1));

        for (int i = 0; i < itemCount && i < slots.size(); i++) {
            LootTier selectedTier = selectTier(rarityBonus);
            LootEntry entry = getRandomEntry(selectedTier);
            if (entry != null) {
                int amount = entry.minAmount() + random.nextInt(Math.max(1, entry.maxAmount() - entry.minAmount() + 1));
                inv.setItem(slots.get(i), new ItemStack(entry.material(), amount));
            }
        }
    }

    private LootTier selectTier(double rarityBonus) {
        double roll = random.nextDouble();
        double rareProb     = LootTier.RARE.getWeight()     + (rarityBonus * 0.15);
        double uncommonProb = LootTier.UNCOMMON.getWeight() + (rarityBonus * 0.20);

        if (roll < rareProb) return LootTier.RARE;
        if (roll < rareProb + uncommonProb) return LootTier.UNCOMMON;
        return LootTier.COMMON;
    }

    private LootEntry getRandomEntry(LootTier tier) {
        List<LootEntry> pool = switch (tier) {
            case RARE     -> rareLoot;
            case UNCOMMON -> uncommonLoot;
            default        -> commonLoot;
        };
        if (pool.isEmpty()) return null;
        return pool.get(random.nextInt(pool.size()));
    }
}