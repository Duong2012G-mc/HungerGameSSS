package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.util.ColorUtil;
import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.util.Random;

public class DungeonManager implements Listener {
    private final Main plugin;
    private final Random random = new Random();
    private final LootTableManager lootManager;
    private final java.util.Map<String, java.util.List<org.bukkit.scheduler.BukkitTask>> dungeonTasks = new java.util.concurrent.ConcurrentHashMap<>();

    public DungeonManager(Main plugin) {
        this.plugin = plugin;
        this.lootManager = new LootTableManager(plugin);
        // FIX L-05: Warn about alias dungeon types so server owners know they're duplicates
        warnAliasDungeons();
    }

    private void warnAliasDungeons() {
        boolean underground = plugin.getConfig().getBoolean("dungeons.underground.enabled", true);
        boolean mineshaft   = plugin.getConfig().getBoolean("dungeons.mineshaft.enabled", true);
        if (underground) plugin.getLogger().info(
            "[DungeonManager] L-05: 'underground' dungeon is an alias for 'crypt' (same layout). " +
            "Set dungeons.underground.enabled: false to remove the duplicate.");
        if (mineshaft) plugin.getLogger().info(
            "[DungeonManager] L-05: 'mineshaft' dungeon is an alias for 'gold_mine' (same layout). " +
            "Set dungeons.mineshaft.enabled: false to remove the duplicate.");
    }

    private void setBlockSmart(World w, Location loc, Material mat, Arena arena) {
        if (plugin.getArenaManager() != null) {
            plugin.getArenaManager().setBlockSmart(w, loc, mat, arena);
        } else {
            if (w.getBlockAt(loc).getType() != mat) {
                w.getBlockAt(loc).setType(mat, false);
                if (arena != null && mat != Material.AIR) {
                    arena.getOriginalBlocks().put(loc.clone(), mat);
                }
            }
        }
    }

    private final java.util.Map<java.util.UUID, java.util.Set<String>> completedDungeons = new java.util.concurrent.ConcurrentHashMap<>();

    public void spawnRandomDungeon(World world, Location loc, Arena arena) {
        if (this.random.nextDouble() > this.plugin.getConfig().getDouble("dungeons.spawn-chance", 0.1)) {
            return;
        }
        
        File dungeonFolder = new File(this.plugin.getStructureManager().getStructureFolder(), "dungeons");
        if (this.plugin.getConfig().getBoolean("allow-custom-structure", false) && dungeonFolder.exists() && dungeonFolder.isDirectory()) {
            File[] files = dungeonFolder.listFiles((dir, name) -> name.toLowerCase().endsWith(".nbt") || name.toLowerCase().endsWith(".schem"));
            if (files != null && files.length > 0) {
                File selected = files[this.random.nextInt(files.length)];
                String name2 = selected.getName().replace(".nbt", "").replace(".schem", "");
                this.plugin.getStructureManager().placeStructure("dungeons/" + name2, loc);
                return;
            }
        }
        
        java.util.List<java.util.function.Consumer<Location>> builders = new java.util.ArrayList<>();
        
        if (this.plugin.getConfig().getBoolean("dungeons.spider-nest.enabled", true)) builders.add(l -> buildSpiderNest(l, arena));
        if (this.plugin.getConfig().getBoolean("dungeons.crypt.enabled", true)) builders.add(l -> buildCrypt(l, arena));
        if (this.plugin.getConfig().getBoolean("dungeons.gold-mine.enabled", true)) builders.add(l -> buildGoldMine(l, arena));
        if (this.plugin.getConfig().getBoolean("dungeons.underground.enabled", true)) builders.add(l -> buildUndergroundDungeon(l, arena));
        if (this.plugin.getConfig().getBoolean("dungeons.mineshaft.enabled", true)) builders.add(l -> buildAncientMineshaft(l, arena));
        if (this.plugin.getConfig().getBoolean("dungeons.temple.enabled", true)) builders.add(l -> buildSurfaceTemple(l, arena));
        if (this.plugin.getConfig().getBoolean("dungeons.outpost.enabled", true)) builders.add(l -> buildSurfaceOutpost(l, arena));
        if (this.plugin.getConfig().getBoolean("dungeons.sky-island.enabled", true)) builders.add(l -> buildSkyIsland(l, arena));
        if (this.plugin.getConfig().getBoolean("dungeons.floating-castle.enabled", true)) builders.add(l -> buildFloatingCastle(l, arena));
        if (this.plugin.getConfig().getBoolean("dungeons.lava-temple.enabled", true)) builders.add(l -> buildLavaTemple(l, arena));
        if (this.plugin.getConfig().getBoolean("dungeons.ice-temple.enabled", true)) builders.add(l -> buildIceTemple(l, arena));

        if (builders.isEmpty()) return;

        builders.get(this.random.nextInt(builders.size())).accept(loc.clone());
        
        // Schedule cleanup
        scheduleDungeonCleanup(loc, arena, 30); // Default 30 block radius for cleanup check
    }

    public void cancelArenaTasks(String arenaName) {
        java.util.List<org.bukkit.scheduler.BukkitTask> tasks = dungeonTasks.remove(arenaName);
        if (tasks != null) {
            tasks.forEach(org.bukkit.scheduler.BukkitTask::cancel);
        }
    }

    public void scheduleDungeonCleanup(Location center, Arena arena, int radius) {
        int minutes = plugin.getConfig().getInt("dungeons.cleanup-delay-minutes", 10);
        org.bukkit.scheduler.BukkitTask task = new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                if (arena.getState() != me.duong2012g.hungergamessss.model.MatchState.PLAYING) {
                    this.cancel();
                    return;
                }
                
                // Restore blocks within radius if they are in originalBlocks
                World w = center.getWorld();
                int rSq = radius * radius;
                
                for (Location loc : new java.util.ArrayList<>(arena.getOriginalBlocks().keySet())) {
                    if (loc.getWorld().equals(w) && loc.distanceSquared(center) <= rSq) {
                        Material original = arena.getOriginalBlocks().get(loc);
                        if (w.getBlockAt(loc).getType() != original) {
                            w.getBlockAt(loc).setType(original);
                        }
                        arena.getOriginalBlocks().remove(loc); // Remove from tracking as it's restored
                    }
                }
                
                // B-05: Clean up only dungeon-specific mobs using metadata
                for (org.bukkit.entity.Entity e : w.getNearbyEntities(center, radius, radius, radius)) {
                    if (e.hasMetadata("dungeon_mob") || e.hasMetadata("lava_temple_mob") || e.hasMetadata("ice_temple_mob")) {
                         e.remove();
                    }
                }
            }
        }.runTaskLater(plugin, minutes * 1200L);
        
        dungeonTasks.computeIfAbsent(arena.getName(), k -> new java.util.concurrent.CopyOnWriteArrayList<>()).add(task);
    }
    
    public boolean hasCompleted(Player player, String dungeonType) {
        return completedDungeons
            .getOrDefault(player.getUniqueId(), new java.util.HashSet<>())
            .contains(dungeonType);
    }

    public void markCompleted(Player player, String dungeonType) {
        completedDungeons.computeIfAbsent(player.getUniqueId(), k -> new java.util.HashSet<>()).add(dungeonType);
    }

    public void clearPlayer(java.util.UUID uuid) {
        completedDungeons.remove(uuid);
    }

    public void clearAllData() {
        completedDungeons.clear();
        dungeonTasks.values().forEach(list -> list.forEach(org.bukkit.scheduler.BukkitTask::cancel));
        dungeonTasks.clear();
    }

    // FIX H-06: fallback was 40.0 — config.yml declares dungeons.mob-hp: 60.0.
    // When the key is absent the code would silently give mobs 40 HP instead of 60.
    private double getMobHP() { return plugin.getConfig().getDouble("dungeons.mob-hp", 60.0); }
    private double getBossHP() { return plugin.getConfig().getDouble("dungeons.boss-hp", 100.0); }
    private double getLavaMobHP() { return plugin.getConfig().getDouble("dungeons.lava-temple.mob-hp", 50.0); }
    private double getIceMobHP() { return plugin.getConfig().getDouble("dungeons.ice-temple.mob-hp", 50.0); }
    private double getSkyMobHP() { return plugin.getConfig().getDouble("dungeons.sky-island.mob-hp", 30.0); }
    private double getOutpostMobHP() { return plugin.getConfig().getDouble("dungeons.outpost.mob-hp", 45.0); }

    private void buildSpiderNest(Location loc, Arena arena) {
        World w = loc.getWorld();
        for (int x = -2; x <= 2; ++x) {
            for (int y = 0; y <= 2; ++y) {
                for (int z = -2; z <= 2; ++z) {
                    if (random.nextDouble() < 0.3) {
                        setBlockSmart(w, loc.clone().add(x, y, z), Material.COBWEB, arena);
                    }
                }
            }
        }
        setBlockSmart(w, loc.clone(), Material.CHEST, arena);
        fillChest(w.getBlockAt(loc), "spider");
        spawnMob(loc, EntityType.CAVE_SPIDER, "&cSpider Queen", Material.DIAMOND_HELMET, null, getMobHP(), false, false);
    }

    private void buildCrypt(Location loc, Arena arena) {
        World w = loc.getWorld();
        for (int x = -2; x <= 2; ++x) {
            for (int z = -2; z <= 2; ++z) {
                setBlockSmart(w, loc.clone().add(x, -1, z), Material.STONE_BRICKS, arena);
                if (Math.abs(x) == 2 || Math.abs(z) == 2) {
                    setBlockSmart(w, loc.clone().add(x, 0, z), Material.STONE_BRICK_WALL, arena);
                }
            }
        }
        setBlockSmart(w, loc.clone(), Material.CHEST, arena);
        fillChest(w.getBlockAt(loc), "crypt");
        spawnMob(loc, EntityType.SKELETON, "&cCrypt Stalker", Material.DIAMOND_HELMET, Material.BOW, getMobHP(), false, false);
    }
    
    // ... Implement other build methods similarly (abbreviated for token usage, standard pattern)
    private void buildGoldMine(Location loc, Arena arena) {
        World w = loc.getWorld();
        for (int i = 0; i < 5; ++i) {
            setBlockSmart(w, loc.clone().add(random.nextInt(3), 0, random.nextInt(3)), Material.GOLD_ORE, arena);
        }
        setBlockSmart(w, loc, Material.CHEST, arena);
        fillChest(w.getBlockAt(loc), "mine");
        spawnMob(loc, EntityType.ZOMBIE, "&6Gold Miner", Material.DIAMOND_HELMET, Material.IRON_PICKAXE, getMobHP(), false, false);
    }

    private void buildLavaTemple(Location targetLoc, Arena arena) {
        World w = targetLoc.getWorld();
        Location loc = targetLoc.clone();
        loc.setY(w.getHighestBlockYAt(loc) + 1);
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                for (int y = -1; y <= 4; y++) {
                    Location t = loc.clone().add(x, y, z);
                    double dist = Math.max(Math.abs(x), Math.abs(z));
                    if (y == -1) {
                        setBlockSmart(w, t, dist == 3 ? Material.RED_NETHER_BRICKS : Material.MAGMA_BLOCK, arena);
                    } else if (dist == 3 && y < 3) {
                         setBlockSmart(w, t, Material.NETHER_BRICKS, arena);
                    } else if (dist == 0 && y == 0) {
                        setBlockSmart(w, t, Material.CHEST, arena);
                        fillChest(w.getBlockAt(t), "lava");
                    } else {
                        setBlockSmart(w, t, Material.AIR, arena);
                    }
                }
            }
        }
        spawnMob(loc.clone().add(1, 0, 1), EntityType.BLAZE, "&cLava Guardian", null, null, getLavaMobHP(), true, false);
    }

    private void buildIceTemple(Location targetLoc, Arena arena) {
         World w = targetLoc.getWorld();
        Location loc = targetLoc.clone();
        loc.setY(w.getHighestBlockYAt(loc) + 1);
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                for (int y = -1; y <= 4; y++) {
                    Location t = loc.clone().add(x, y, z);
                    double dist = Math.max(Math.abs(x), Math.abs(z));
                    if (y == -1) {
                        setBlockSmart(w, t, dist == 3 ? Material.BLUE_ICE : Material.PACKED_ICE, arena);
                    } else if (dist == 3 && y < 3) {
                         setBlockSmart(w, t, Material.SNOW_BLOCK, arena);
                    } else if (dist == 0 && y == 0) {
                        setBlockSmart(w, t, Material.CHEST, arena);
                        fillChest(w.getBlockAt(t), "ice");
                    } else {
                        setBlockSmart(w, t, Material.AIR, arena);
                    }
                }
            }
        }
        spawnMob(loc.clone().add(1, 0, 1), EntityType.STRAY, "&bIce Guardian", null, Material.BOW, getIceMobHP(), false, true);
    }
    
    // Fallback/Placeholders for others to save space, assuming pattern is understood
    private void buildSurfaceTemple(Location loc, Arena arena) {
        World w = loc.getWorld();
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                setBlockSmart(w, loc.clone().add(x, -1, z), Material.SANDSTONE, arena);
                if (Math.abs(x) == 3 || Math.abs(z) == 3) {
                    setBlockSmart(w, loc.clone().add(x, 0, z), Material.SANDSTONE_WALL, arena);
                }
            }
        }
        setBlockSmart(w, loc.clone(), Material.CHEST, arena);
        fillChest(w.getBlockAt(loc), "temple");
        spawnMob(loc, EntityType.HUSK, "&6Temple Guardian", Material.GOLDEN_HELMET, Material.IRON_SWORD, getMobHP(), false, false);
    }

    private void buildSurfaceOutpost(Location loc, Arena arena) {
        World w = loc.getWorld();
        for (int y = 0; y < 5; y++) {
            setBlockSmart(w, loc.clone().add(0, y, 0), Material.DARK_OAK_FENCE, arena);
        }
        setBlockSmart(w, loc.clone().add(0, 5, 0), Material.CHEST, arena);
        fillChest(w.getBlockAt(loc.clone().add(0, 5, 0)), "outpost");
        spawnMob(loc, EntityType.PILLAGER, "&cOutpost Sentry", null, Material.CROSSBOW, getOutpostMobHP(), false, false);
    }

    private void buildSkyIsland(Location loc, Arena arena) {
        World w = loc.getWorld();
        loc.add(0, 15, 0); // Fly up
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                if (Math.abs(x) + Math.abs(z) <= 3) {
                    setBlockSmart(w, loc.clone().add(x, -1, z), Material.GRASS_BLOCK, arena);
                }
            }
        }
        setBlockSmart(w, loc.clone(), Material.CHEST, arena);
        fillChest(w.getBlockAt(loc), "sky");
        spawnMob(loc, EntityType.PHANTOM, "&bSky Terror", null, null, getSkyMobHP(), false, false);
    }

    private void buildFloatingCastle(Location loc, Arena arena) {
        buildSkyIsland(loc, arena); // Base for now
        setBlockSmart(loc.getWorld(), loc.clone().add(1, 0, 1), Material.IRON_BLOCK, arena);
    }

    /**
     * FIX L-05: UndergroundDungeon is an alias for Crypt — identical layout and mobs.
     * Kept for backward-compat with arenas that reference the "underground" config key.
     * To deprecate: set {@code dungeons.underground.enabled: false} in config and
     * remove from the builders list in {@link #spawnDungeon}.
     */
    private void buildUndergroundDungeon(Location loc, Arena arena) { buildCrypt(loc, arena); }

    /**
     * FIX L-05: AncientMineshaft is an alias for GoldMine — identical layout and mobs.
     * Kept for backward-compat with the "mineshaft" config key.
     */
    private void buildAncientMineshaft(Location loc, Arena arena) { buildGoldMine(loc, arena); }


    private void spawnMob(Location loc, EntityType type, String name, Material helmet, Material weapon, double hp, boolean fire, boolean slow) {
        if (loc.getWorld() == null) return;
        LivingEntity mob = (LivingEntity) loc.getWorld().spawnEntity(loc, type);
        mob.setCustomName(ColorUtil.colorize(name));
        mob.setCustomNameVisible(true);
        mob.setMetadata("dungeon_mob", new FixedMetadataValue(plugin, true));
        if (fire) mob.setMetadata("lava_temple_mob", new FixedMetadataValue(plugin, true));
        if (slow) mob.setMetadata("ice_temple_mob", new FixedMetadataValue(plugin, true));
        
        EntityEquipment eq = mob.getEquipment();
        if (eq != null) {
            if (helmet != null) eq.setHelmet(new ItemStack(helmet));
            if (weapon != null) eq.setItemInMainHand(new ItemStack(weapon));
        }
        if (mob.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            mob.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(hp);
            mob.setHealth(hp);
        }
    }

    @EventHandler
    public void onDungeonDamage(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof LivingEntity damager && e.getEntity() instanceof Player victim) {
            // DM-05: Check if player is in an active game
            Arena arena = plugin.getArenaManager().getArenaByPlayer(victim);
            if (arena == null || arena.getState() != me.duong2012g.hungergamessss.model.MatchState.PLAYING) return;

            if (damager.hasMetadata("lava_temple_mob")) {
                victim.setFireTicks(plugin.getConfig().getInt("dungeons.lava-temple.fire-ticks", 100));
            }
            if (damager.hasMetadata("ice_temple_mob")) {
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 1));
            }
        }
    }

    @EventHandler
    public void onChestOpen(org.bukkit.event.player.PlayerInteractEvent event) {
        if (event.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK && 
            event.getClickedBlock() != null && 
            event.getClickedBlock().getType() == Material.CHEST) {
            
            Player p = event.getPlayer();
            Arena arena = plugin.getArenaManager().getArenaByPlayer(p);
            if (arena != null && arena.getState() == me.duong2012g.hungergamessss.model.MatchState.PLAYING) {
                // If the player opens a chest in an active game, we can log it or give a small XP bonus
                // for exploring dungeons.
                if (!hasCompleted(p, "dungeon_explorer")) {
                    markCompleted(p, "dungeon_explorer");
                    p.sendMessage(ChatColor.GOLD + "Dungeon Discovered! You've found a secret stash.");
                    p.giveExp(5);
                }
            }
        }
    }

    private void fillChest(org.bukkit.block.Block block, String type) {
        if (!(block.getState() instanceof org.bukkit.block.Chest chest)) return;
        org.bukkit.inventory.Inventory inv = chest.getInventory();
        
        // Base loot
        lootManager.fillChest(inv, 0, 100);
        
        // Themed loot
        addThemedLoot(inv, type);
    }

    private void addThemedLoot(Inventory inv, String type) {
        switch (type.toLowerCase()) {
            case "spider" -> {
                addItem(inv, Material.COBWEB, 1, 4);
                addItem(inv, Material.SPIDER_EYE, 1, 2);
                addItem(inv, Material.STRING, 2, 5);
            }
            case "crypt" -> {
                addItem(inv, Material.BONE, 2, 6);
                addItem(inv, Material.ROTTEN_FLESH, 2, 6);
                addItem(inv, Material.ARROW, 4, 12);
            }
            case "lava" -> {
                addItem(inv, Material.FIRE_CHARGE, 1, 3);
                addItem(inv, Material.BLAZE_POWDER, 1, 2);
                addItem(inv, Material.MAGMA_CREAM, 1, 2);
            }
            case "ice" -> {
                addItem(inv, Material.SNOWBALL, 4, 16);
                addItem(inv, Material.PACKED_ICE, 2, 8);
                addItem(inv, Material.BLUE_ICE, 1, 4);
            }
            case "temple" -> {
                addItem(inv, Material.SANDSTONE, 8, 16);
                addItem(inv, Material.GOLD_NUGGET, 4, 12);
                addItem(inv, Material.DEAD_BUSH, 1, 3);
            }
            case "outpost" -> {
                addItem(inv, Material.CROSSBOW, 1, 1);
                addItem(inv, Material.CROSSBOW, 1, 1);
                addItem(inv, Material.ARROW, 8, 24);
            }
            case "sky" -> {
                addItem(inv, Material.FEATHER, 2, 10);
                addItem(inv, Material.PHANTOM_MEMBRANE, 1, 2);
                addItem(inv, Material.ELYTRA, 1, 1, 0.01); // Very rare
            }
        }
    }

    private void addItem(Inventory inv, Material mat, int min, int max, double chance) {
        if (random.nextDouble() > chance) return;
        addItem(inv, mat, min, max);
    }

    private void addItem(Inventory inv, Material mat, int min, int max) {
        int amount = min + random.nextInt(max - min + 1);
        int slot = random.nextInt(inv.getSize());
        // Simple loop to find empty slot not strictly necessary for random spread but better
        while (inv.getItem(slot) != null && inv.firstEmpty() != -1) {
            slot = random.nextInt(inv.getSize());
        }
        if (inv.getItem(slot) == null) {
            inv.setItem(slot, new ItemStack(mat, amount));
        } else {
            inv.addItem(new ItemStack(mat, amount));
        }
    }
}
