package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.util.ColorUtil;
import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class LobbyManager implements Listener {
    private final Main plugin;
    private final String compassName;

    public LobbyManager(Main plugin) {
        this.plugin = plugin;
        this.compassName = ColorUtil.colorize(plugin.getMessageManager().getMessage("arena_selector_name"));
    }

    public Location getLobbyLocation() {
        if (!plugin.getConfig().contains("lobby.world")) {
            return null;
        }
        World world = Bukkit.getWorld(plugin.getConfig().getString("lobby.world"));
        if (world == null) {
            return null;
        }
        double x = plugin.getConfig().getDouble("lobby.x");
        double y = plugin.getConfig().getDouble("lobby.y");
        double z = plugin.getConfig().getDouble("lobby.z");
        float yaw = (float) plugin.getConfig().getDouble("lobby.yaw");
        float pitch = (float) plugin.getConfig().getDouble("lobby.pitch");
        return new Location(world, x, y, z, yaw, pitch);
    }
    
    public void setLobbyLocation(Location loc) {
        plugin.getConfig().set("lobby.world", loc.getWorld().getName());
        plugin.getConfig().set("lobby.x", loc.getX());
        plugin.getConfig().set("lobby.y", loc.getY());
        plugin.getConfig().set("lobby.z", loc.getZ());
        plugin.getConfig().set("lobby.yaw", loc.getYaw());
        plugin.getConfig().set("lobby.pitch", loc.getPitch());
        plugin.saveConfig();
        plugin.getLogger().info("Lobby location set to: " + loc.getWorld().getName() + " " + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ());
    }

    public boolean isInLobbyWorld(Player p) {
        Location lobby = getLobbyLocation();
        return lobby != null && p.getWorld().equals(lobby.getWorld());
    }
    
    // Compatibility alias
    public boolean isInLobby(Player p) {
        return isInLobbyWorld(p);
    }

    public void giveLobbyItems(Player p) {
        p.getInventory().clear();
        ItemStack compass = new ItemStack(Material.COMPASS);
        ItemMeta meta = compass.getItemMeta();
        meta.displayName(ColorUtil.component(compassName));
        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        lore.add(ColorUtil.componentOf(plugin.getMessageManager().getMessage("arena_selector_lore")));
        meta.lore(lore);
        compass.setItemMeta(meta);
        int compassSlot = plugin.getConfig().getInt("lobby.compass-slot", 4);
        p.getInventory().setItem(compassSlot, compass);
        p.setGameMode(GameMode.ADVENTURE);
        p.setHealth(20);
        p.setFoodLevel(20);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Location lobby = getLobbyLocation();
        // If player is not in database/saved data (implying new or finished game), send to lobby
        // Decompiled check: if (!plugin.getPlayerManager().getSavedPlayerData().containsKey(p.getUniqueId()))
        // My PlayerManager handles data differently. 
        // Logic: if not in an active game, send to lobby.
        if (plugin.getArenaManager().getArenaByPlayer(p) == null && lobby != null) {
            p.teleport(lobby);
            giveLobbyItems(p);
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Location lobby = getLobbyLocation();
        if (plugin.getArenaManager().getArenaByPlayer(p) == null && lobby != null) {
            e.setRespawnLocation(lobby);
            Bukkit.getScheduler().runTaskLater(plugin, () -> giveLobbyItems(p), 1L);
        }
    }

    @EventHandler
    public void onSpawn(CreatureSpawnEvent e) {
        Location lobby = getLobbyLocation();
        if (lobby != null && e.getLocation().getWorld().equals(lobby.getWorld()) && e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.CUSTOM) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player player && isInLobbyWorld(player)) {
            // Skip if player is in an active arena (arena can be in lobby world)
            if (plugin.getArenaManager().getArenaByPlayer(player) != null) return;
            e.setCancelled(true);
            if (e.getCause() == EntityDamageEvent.DamageCause.VOID) {
                Location lobby = getLobbyLocation();
                if (lobby != null) {
                    player.teleport(lobby);
                }
            }
        }
    }

    @EventHandler
    public void onHunger(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player && isInLobbyWorld((Player) e.getEntity())) {
            e.setCancelled(true);
            ((Player) e.getEntity()).setFoodLevel(20);
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        ItemStack item = e.getItem();
        if (item != null && item.getType() == Material.COMPASS && item.hasItemMeta() && item.getItemMeta().getDisplayName().equals(compassName)) {
            openArenaMenu(p);
            e.setCancelled(true);
        }
    }

    public void openArenaMenu(Player p) {
        List<Arena> arenas = new ArrayList<>(plugin.getArenaManager().getArenas().values());
        int size = (arenas.size() / 9 + 1) * 9;
        Inventory inv = Bukkit.createInventory(null, size, ColorUtil.colorize(plugin.getMessageManager().getMessage("arena_menu_title")));
        
        for (Arena arena : arenas) {
            ItemStack item = new ItemStack(Material.GRASS_BLOCK);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(ColorUtil.component(ChatColor.GREEN + arena.getName()));
            List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
            lore.add(ColorUtil.component(ChatColor.GRAY + "Players: " + arena.getPlayers().size() + "/" + arena.getMaxPlayers()));
            lore.add(ColorUtil.component(ChatColor.GRAY + "State: " + arena.getState()));
            lore.add(ColorUtil.component(""));
            lore.add(ColorUtil.component(ChatColor.YELLOW + "Click to join!"));
            meta.lore(lore);
            item.setItemMeta(meta);
            inv.addItem(item);
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (e.getView().getTitle().equals(ColorUtil.colorize(plugin.getMessageManager().getMessage("arena_menu_title")))) {
            e.setCancelled(true);
            if (e.getCurrentItem() == null || e.getCurrentItem().getType() == Material.AIR || !e.getCurrentItem().hasItemMeta()) {
                return;
            }
            Player p = (Player) e.getWhoClicked();
            String arenaName = ChatColor.stripColor(e.getCurrentItem().getItemMeta().getDisplayName());
            p.closeInventory();
            p.performCommand("hg join " + arenaName);
            return;
        }
        if (e.getWhoClicked() instanceof Player && isInLobbyWorld((Player) e.getWhoClicked())) {
            // Check if player is OP or in creative? Maybe allow inventory management if Op/Creative.
            if (!e.getWhoClicked().isOp() && e.getWhoClicked().getGameMode() != GameMode.CREATIVE) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (isInLobbyWorld(e.getPlayer())) {
             if (!e.getPlayer().isOp() && e.getPlayer().getGameMode() != GameMode.CREATIVE) {
                e.setCancelled(true);
             }
        }
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (isInLobbyWorld(e.getPlayer())) {
             if (!e.getPlayer().isOp() && e.getPlayer().getGameMode() != GameMode.CREATIVE) {
                e.setCancelled(true);
             }
        }
    }
}
