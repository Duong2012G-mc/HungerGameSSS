package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.util.ColorUtil;
import me.duong2012g.hungergamessss.Main;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class MessageManager {
    private final Main plugin;
    private FileConfiguration langConfig;
    private final Map<String, String> messageCache = new HashMap<>();

    public MessageManager(Main plugin) {
        this.plugin = plugin;
        loadMessages();
    }

    public void loadMessages() {
        String lang = plugin.getConfig().getString("language", "en");
        
        File langDir = new File(plugin.getDataFolder(), "languages");
        if (!langDir.exists()) {
            langDir.mkdirs();
        }

        String[] supportedLangs = {"en.yml", "vi.yml", "ru.yml", "fr.yml"};
        for (String langFileName : supportedLangs) {
            File langFile = new File(langDir, langFileName);
            if (!langFile.exists()) {
                try {
                    plugin.saveResource("languages/" + langFileName, false);
                } catch (Exception e) {
                    plugin.getLogger().warning("Failed to save language file " + langFileName + ": " + e.getMessage());
                    if (plugin.getConfig().getBoolean("debug", false)) {
                        e.printStackTrace();
                    }
                }
            }
        }

        String fileName = lang + ".yml";
        File langFile = new File(plugin.getDataFolder(), "languages/" + fileName);
        if (!langFile.exists()) {
            fileName = "en.yml";
            langFile = new File(plugin.getDataFolder(), "languages/en.yml");
        }

        if (langFile.exists()) {
            try {
                langConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(new java.io.FileInputStream(langFile), StandardCharsets.UTF_8));
            } catch (java.io.FileNotFoundException e) {
                langConfig = YamlConfiguration.loadConfiguration(langFile);
            }
        } else {
            langConfig = new YamlConfiguration();
        }

        // Update missing keys from embedded resource
        java.io.InputStream defStream = plugin.getResource("languages/" + fileName);
        if (defStream != null) {
            YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(defStream, StandardCharsets.UTF_8));
            boolean changesMade = false;
            
            if (defConfig.getConfigurationSection("messages") != null) {
                for (String key : defConfig.getConfigurationSection("messages").getKeys(false)) {
                    if (!langConfig.contains("messages." + key)) {
                        langConfig.set("messages." + key, defConfig.getString("messages." + key));
                        changesMade = true;
                    }
                }
            }
            
            if (changesMade) {
                try {
                    langConfig.save(langFile);
                    plugin.getLogger().info("Updated language file " + fileName + " with missing keys.");
                } catch (Exception e) {
                    plugin.getLogger().warning("Could not save updated language file: " + e.getMessage());
                }
            }
        }
        
        messageCache.clear();

        if (langConfig.getConfigurationSection("messages") != null) {
            for (String key : langConfig.getConfigurationSection("messages").getKeys(false)) {
                if (langConfig.isList("messages." + key)) {
                    java.util.List<String> list = langConfig.getStringList("messages." + key);
                    String joined = String.join("\n", list);
                    messageCache.put(key, ColorUtil.colorize(joined));
                } else {
                    String msg = langConfig.getString("messages." + key);
                    if (msg != null) {
                        messageCache.put(key, ColorUtil.colorize(msg));
                    }
                }
            }
        }
    }

    public String getMessage(String key) {
        return messageCache.getOrDefault(key, "§cMessage not found: " + key);
    }

    /**
     * Returns true if the given message key exists in the loaded language file.
     * Use this before calling getMessage() when you need a fallback instead of the
     * "§cMessage not found:" placeholder (e.g. for optional ability name/desc keys).
     */
    public boolean hasMessage(String key) {
        return messageCache.containsKey(key);
    }

    public String getMessage(String key, Map<String, String> placeholders) {
        String msg = getMessage(key);
        if (placeholders != null) {
            for (Map.Entry<String, String> entry : placeholders.entrySet()) {
                msg = msg.replace("%" + entry.getKey() + "%", entry.getValue());
            }
        }
        return msg;
    }

    public String getStrippedMessage(String key) {
        return ChatColor.stripColor(getMessage(key));
    }

    public java.util.List<String> getMessageList(String key) {
        if (!langConfig.contains("messages." + key)) {
            return java.util.Collections.singletonList("§cList not found: " + key);
        }
        java.util.List<String> list = langConfig.getStringList("messages." + key);
        java.util.List<String> translated = new java.util.ArrayList<>();
        for (String s : list) {
            translated.add(ColorUtil.colorize(s));
        }
        return translated;
    }

    public void reload() {
        loadMessages();
    }
}
