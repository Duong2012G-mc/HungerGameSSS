package me.duong2012g.hungergamessss.manager;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Logger;

/**
 * A1-S3 / A2-S3: Unified tracker for all custom entities spawned by abilities.
 *
 * <h3>Problem this solves</h3>
 * Previously each ability maintained its own {@code Map<UUID, List<EntityType>>} to
 * track spawned entities (bees, armadillos, ghasts, display entities, floating items…).
 * This meant:
 * <ul>
 *   <li>Entities could leak if the ability's own cleanup path missed a case.</li>
 *   <li>No central view of how many custom entities are alive per arena.</li>
 *   <li>Arena reset had to call cleanup on every ability individually.</li>
 * </ul>
 *
 * <h3>Usage</h3>
 * <pre>{@code
 * // In any ability — register at spawn time:
 * Bee bee = world.spawn(loc, Bee.class);
 * plugin.getEntityTracker().track(bee, player.getUniqueId(), "BeehiveBlaster");
 *
 * // On player quit/death — release all entities owned by that player:
 * plugin.getEntityTracker().releaseOwner(player.getUniqueId(), entity -> entity.remove());
 *
 * // On arena reset — remove all custom entities in the arena:
 * plugin.getEntityTracker().releaseArena(arena.getName(), entity -> entity.remove());
 * }</pre>
 */
public class ArenaEntityTracker {

    /** Immutable snapshot of a tracked entity's registration. */
    private record TrackedEntity(
            UUID entityUUID,
            UUID ownerUUID,
            String arenaName,
            String abilityName,
            long spawnedAt
    ) {}

    private final Main plugin;
    private final Logger log;

    /** entityUUID → TrackedEntity */
    private final Map<UUID, TrackedEntity> byEntity  = new ConcurrentHashMap<>();
    /** ownerUUID  → Set<entityUUID> */
    private final Map<UUID, Set<UUID>>     byOwner   = new ConcurrentHashMap<>();
    /** arenaName  → Set<entityUUID> */
    private final Map<String, Set<UUID>>   byArena   = new ConcurrentHashMap<>();

    /** Repeating task that prunes stale (dead/invalid) entries every 100 ticks (5 s). */
    private org.bukkit.scheduler.BukkitTask pruneTask;

    public ArenaEntityTracker(Main plugin) {
        this.plugin = plugin;
        this.log    = plugin.getLogger();
        startPruneTask();
    }

    // ── Registration ──────────────────────────────────────────────────────────

    /**
     * Registers a newly spawned entity so it can be cleaned up by arena, owner,
     * or ability name.
     *
     * @param entity      the entity just spawned
     * @param ownerUUID   UUID of the player who triggered the spawn (may be null for
     *                    arena-level entities)
     * @param abilityName display name of the ability that spawned it (e.g. "BeehiveBlaster")
     */
    public void track(Entity entity, UUID ownerUUID, String abilityName) {
        if (entity == null || !entity.isValid()) return;

        String arenaName = resolveArena(ownerUUID);
        TrackedEntity te = new TrackedEntity(
                entity.getUniqueId(), ownerUUID,
                arenaName, abilityName, System.currentTimeMillis());

        byEntity.put(entity.getUniqueId(), te);
        if (ownerUUID != null)
            byOwner.computeIfAbsent(ownerUUID, k -> ConcurrentHashMap.newKeySet()).add(entity.getUniqueId());
        if (arenaName != null)
            byArena.computeIfAbsent(arenaName, k -> ConcurrentHashMap.newKeySet()).add(entity.getUniqueId());
    }

    /** Convenience overload that infers the arena from the entity's current world/location. */
    public void track(Entity entity, UUID ownerUUID, String abilityName, String arenaName) {
        if (entity == null || !entity.isValid()) return;
        TrackedEntity te = new TrackedEntity(
                entity.getUniqueId(), ownerUUID,
                arenaName, abilityName, System.currentTimeMillis());
        byEntity.put(entity.getUniqueId(), te);
        if (ownerUUID != null)
            byOwner.computeIfAbsent(ownerUUID, k -> ConcurrentHashMap.newKeySet()).add(entity.getUniqueId());
        if (arenaName != null)
            byArena.computeIfAbsent(arenaName, k -> ConcurrentHashMap.newKeySet()).add(entity.getUniqueId());
    }

    /**
     * Manually un-tracks an entity (e.g. after it naturally died or was removed by
     * the ability itself). Does not call any consumer.
     */
    public void untrack(UUID entityUUID) {
        TrackedEntity te = byEntity.remove(entityUUID);
        if (te == null) return;
        Set<UUID> ownerSet = byOwner.get(te.ownerUUID());
        if (ownerSet != null) ownerSet.remove(entityUUID);
        Set<UUID> arenaSet = byArena.get(te.arenaName());
        if (arenaSet != null) arenaSet.remove(entityUUID);
    }

    // ── Bulk release ──────────────────────────────────────────────────────────

    /**
     * Applies {@code action} to every tracked entity owned by {@code ownerUUID},
     * then removes them from tracking.
     * Typical action: {@code entity -> entity.remove()}.
     */
    public void releaseOwner(UUID ownerUUID, Consumer<Entity> action) {
        Set<UUID> owned = byOwner.remove(ownerUUID);
        if (owned == null) return;
        for (UUID id : owned) {
            byEntity.remove(id);
            Entity e = Bukkit.getEntity(id);
            if (e != null && e.isValid()) {
                try { action.accept(e); } catch (Exception ex) {
                    log.warning("[EntityTracker] action failed for entity " + id + ": " + ex.getMessage());
                }
            }
        }
    }

    /**
     * Applies {@code action} to every tracked entity in {@code arenaName}, then
     * removes them from tracking. Called by arena reset.
     */
    public void releaseArena(String arenaName, Consumer<Entity> action) {
        Set<UUID> arenaSet = byArena.remove(arenaName);
        if (arenaSet == null) return;
        for (UUID id : arenaSet) {
            TrackedEntity te = byEntity.remove(id);
            if (te != null && te.ownerUUID() != null) {
                Set<UUID> ownerSet = byOwner.get(te.ownerUUID());
                if (ownerSet != null) ownerSet.remove(id);
            }
            Entity e = Bukkit.getEntity(id);
            if (e != null && e.isValid()) {
                try { action.accept(e); } catch (Exception ex) {
                    log.warning("[EntityTracker] arena-release action failed for entity " + id + ": " + ex.getMessage());
                }
            }
        }
    }

    /**
     * Applies {@code action} to every tracked entity spawned by {@code abilityName}
     * in any arena. Used by ability-level {@code cleanup()}.
     */
    public void releaseAbility(String abilityName, Consumer<Entity> action) {
        List<UUID> toRemove = byEntity.entrySet().stream()
                .filter(e -> abilityName.equalsIgnoreCase(e.getValue().abilityName()))
                .map(Map.Entry::getKey)
                .toList();
        for (UUID id : toRemove) {
            untrack(id);
            Entity e = Bukkit.getEntity(id);
            if (e != null && e.isValid()) {
                try { action.accept(e); } catch (Exception ex) {
                    log.warning("[EntityTracker] ability-release action failed for entity " + id + ": " + ex.getMessage());
                }
            }
        }
    }

    // ── Query ─────────────────────────────────────────────────────────────────

    /** Returns the number of live tracked entities owned by {@code ownerUUID}. */
    public int countByOwner(UUID ownerUUID) {
        Set<UUID> owned = byOwner.get(ownerUUID);
        return owned == null ? 0 : (int) owned.stream()
                .map(Bukkit::getEntity)
                .filter(e -> e != null && e.isValid())
                .count();
    }

    /** Returns the total number of live tracked entities in {@code arenaName}. */
    public int countByArena(String arenaName) {
        Set<UUID> arenaSet = byArena.get(arenaName);
        return arenaSet == null ? 0 : (int) arenaSet.stream()
                .map(Bukkit::getEntity)
                .filter(e -> e != null && e.isValid())
                .count();
    }

    /** Returns {@code true} if the given entity is currently tracked. */
    public boolean isTracked(UUID entityUUID) {
        return byEntity.containsKey(entityUUID);
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    /** Cancels the prune task and clears all tracking state. Called on plugin disable. */
    public void shutdown() {
        if (pruneTask != null && !pruneTask.isCancelled()) pruneTask.cancel();
        byEntity.clear();
        byOwner.clear();
        byArena.clear();
    }

    // ── Internals ─────────────────────────────────────────────────────────────

    private void startPruneTask() {
        pruneTask = new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                // Remove entries for entities that are no longer valid (dead/removed)
                List<UUID> stale = byEntity.keySet().stream()
                        .filter(id -> {
                            Entity e = Bukkit.getEntity(id);
                            return e == null || !e.isValid();
                        })
                        .toList();
                stale.forEach(ArenaEntityTracker.this::untrack);
                if (!stale.isEmpty() && plugin.getConfig().getBoolean("debug", false)) {
                    log.info("[EntityTracker] Pruned " + stale.size() + " stale entity entries.");
                }
            }
        }.runTaskTimer(plugin, 100L, 100L);
    }

    private String resolveArena(UUID ownerUUID) {
        if (ownerUUID == null) return null;
        org.bukkit.entity.Player p = Bukkit.getPlayer(ownerUUID);
        if (p == null) return null;
        Arena arena = plugin.getArenaManager().getArenaByPlayer(p);
        return arena != null ? arena.getName() : null;
    }
}
