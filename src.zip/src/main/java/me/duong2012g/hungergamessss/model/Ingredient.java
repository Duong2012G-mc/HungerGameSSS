package me.duong2012g.hungergamessss.model;

import org.bukkit.Material;

/**
 * A2-18: Converted from POJO to Java 21 record — Ingredient is purely immutable
 * data (material + amount). Records provide equals/hashCode/toString for free.
 *
 * <p>Migration note: All {@code ingredient.mat} → {@code ingredient.material()},
 * and {@code ingredient.amount} → {@code ingredient.amount()}.
 */
public record Ingredient(Material material, int amount) {

    /** Compact constructor that validates amount is positive. */
    public Ingredient {
        if (amount <= 0) throw new IllegalArgumentException("Ingredient amount must be > 0, got: " + amount);
        java.util.Objects.requireNonNull(material, "Ingredient material must not be null");
    }

    /** Convenience factory mirroring the old {@code new Ingredient(mat, amount)} call-site. */
    public static Ingredient of(Material material, int amount) {
        return new Ingredient(material, amount);
    }
}
