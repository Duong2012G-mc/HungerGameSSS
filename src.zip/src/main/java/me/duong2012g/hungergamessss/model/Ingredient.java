package me.duong2012g.hungergamessss.model;

import org.bukkit.Material;

public class Ingredient {
    public Material mat;
    public int amount;

    public Ingredient(Material m, int a) {
        this.mat = m;
        this.amount = a;
    }
}
