package me.duong2012g.hungergamessss.model;

import java.util.UUID;

public class PlayerData {
    private final UUID uuid;
    private int kills;
    private int deaths;
    private int wins;
    private int losses;
    private int gamesPlayed;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getUuid() {
        return uuid;
    }

    public int getKills() {
        return kills;
    }

    public void addKill() {
        this.kills++;
    }
    
    public void setKills(int kills) {
        this.kills = kills;
    }

    public int getDeaths() {
        return deaths;
    }

    public void addDeath() {
        this.deaths++;
    }
    
    public void setDeaths(int deaths) {
        this.deaths = deaths;
    }

    public int getWins() {
        return wins;
    }

    public void addWin() {
        this.wins++;
    }
    
    public void setWins(int wins) {
        this.wins = wins;
    }
    
    public int getGamesPlayed() {
        return gamesPlayed;
    }
    
    public void addGamePlayed() {
        this.gamesPlayed++;
    }
    
    public void setGamesPlayed(int gamesPlayed) {
        this.gamesPlayed = gamesPlayed;
    }

    public int getLosses() {
        return losses;
    }

    public void addLoss() {
        this.losses++;
    }

    public void setLosses(int losses) {
        this.losses = losses;
    }
    
    // Lifesteal Data
    private int lifestealHearts;
    
    public int getLifestealHearts() {
        return lifestealHearts;
    }
    
    public void setLifestealHearts(int lifestealHearts) {
        this.lifestealHearts = lifestealHearts;
    }
}
