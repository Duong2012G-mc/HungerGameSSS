package me.duong2012g.hungergamessss.model;

import me.duong2012g.hungergamessss.util.ColorUtil;
import me.duong2012g.hungergamessss.Main;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class LegendaryRecipe {
    public String id;
    public String name;
    public Material resultItem;
    public List<Ingredient> ingredients = new ArrayList<>();
    public Function<ItemStack, ItemStack> modifier;
    public String description;
    public List<String> lore = new ArrayList<>();
    public int customModelData = 0;
    public Map<Enchantment, Integer> enchants = new HashMap<>();
    public long cooldown = 0L;
    public boolean unbreakable = false;
    public int amount = 1;
    public Map<String, Double> stats = new HashMap<>();
    public int heartCost = 0;
    public Map<String, Object> config = new HashMap<>();

    public LegendaryRecipe(String id, String n, Material r, String desc, Ingredient ... ings) {
        this(id, n, r, (ItemStack item) -> item, desc, ings);
    }

    public LegendaryRecipe(String id, String n, Material r, Function<ItemStack, ItemStack> mod, String desc, Ingredient ... ings) {
        this.id = id;
        this.name = n;
        this.resultItem = r;
        this.modifier = mod;
        this.description = desc;
        this.ingredients.addAll(Arrays.asList(ings));
    }

    public ItemStack createItem() {
        ItemStack item = new ItemStack(this.resultItem, this.amount);
        this.enchants.forEach((ench, level) -> item.addUnsafeEnchantment(ench, level.intValue()));
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            NamespacedKey key = new NamespacedKey(Main.getInstance(), "hg_ability");
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, this.id);
            if (this.name != null) {
                meta.displayName(ColorUtil.componentOf(this.name));
            }
            if (!this.lore.isEmpty()) {
                java.util.List<net.kyori.adventure.text.Component> loreComp = new ArrayList<>();
                for (String line : this.lore) {
                    loreComp.add(ColorUtil.componentOf(line));
                }
                meta.lore(loreComp);
            }
            if (this.customModelData > 0) {
                meta.setCustomModelData(Integer.valueOf(this.customModelData));
            }
            meta.setUnbreakable(this.unbreakable);
            item.setItemMeta(meta);
        }
        return this.modifier != null ? this.modifier.apply(item) : item;
    }
}
