package me.duong2012g.hungergamessss.model;

import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A2-17: Encapsulates legendary-item placement, hologram lifecycle, and
 * temporary-legendary tracking for an arena.
 *
 * <p>These responsibilities were previously scattered across {@link Arena}'s
 * {@code activeLegendaries}, {@code hologramMap}, {@code holograms},
 * {@code configuredLegendaries}, and {@code temporaryLegendaries} maps.
 */
public class ArenaLegendaryTracker {

    private final List<LegendaryRecipe> activeLegendaries = new ArrayList<>();
    private final Map<ArmorStand, LegendaryRecipe> hologramMap = new ConcurrentHashMap<>();
    private final Map<LegendaryRecipe, List<ArmorStand>> holograms = new ConcurrentHashMap<>();
    private final Map<Location, String> configuredLegendaries = new ConcurrentHashMap<>();
    private final Map<Location, String> temporaryLegendaries  = new ConcurrentHashMap<>();

    // ── Active legendaries ────────────────────────────────────────────────────

    public synchronized List<LegendaryRecipe> getActiveLegendaries() { return activeLegendaries; }

    public synchronized void addActiveLegendary(LegendaryRecipe recipe) {
        if (!activeLegendaries.contains(recipe)) activeLegendaries.add(recipe);
    }

    public synchronized void removeActiveLegendary(LegendaryRecipe recipe) {
        activeLegendaries.remove(recipe);
    }

    // ── Holograms ─────────────────────────────────────────────────────────────

    public Map<ArmorStand, LegendaryRecipe> getHologramMap() { return hologramMap; }
    public Map<LegendaryRecipe, List<ArmorStand>> getHolograms() { return holograms; }

    public void clearHolograms() {
        hologramMap.forEach((stand, recipe) -> {
            if (stand != null && stand.isValid()) stand.remove();
        });
        hologramMap.clear();
        holograms.clear();
    }

    // ── Placed legendary locations ────────────────────────────────────────────

    public Map<Location, String> getConfiguredLegendaries() { return configuredLegendaries; }
    public Map<Location, String> getTemporaryLegendaries()  { return temporaryLegendaries; }

    public void addTemporaryLegendary(Location loc, String itemName) {
        temporaryLegendaries.put(loc, itemName);
    }

    public void clearTemporaryLegendaries() { temporaryLegendaries.clear(); }

    /** Combined view: configured + temporary (temporary overrides configured for same location). */
    public Map<Location, String> getAllLegendaries() {
        Map<Location, String> all = new HashMap<>(configuredLegendaries);
        all.putAll(temporaryLegendaries);
        return all;
    }

    /** Removes all state. Call on arena reset. */
    public void reset() {
        clearHolograms();
        activeLegendaries.clear();
        temporaryLegendaries.clear();
        // configuredLegendaries persists between matches (loaded from config)
    }
}
