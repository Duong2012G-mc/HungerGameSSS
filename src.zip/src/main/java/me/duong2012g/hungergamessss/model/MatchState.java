package me.duong2012g.hungergamessss.model;

/**
 * A2-S6: MatchState enum extended with Java 21 pattern-matching helpers.
 *
 * <p>The enum itself is unchanged for backwards compatibility (all existing
 * {@code switch} / {@code if} on {@code MatchState} continue to compile).
 * The new methods make common guards more readable:
 *
 * <pre>{@code
 * // Before
 * if (state == MatchState.PLAYING || state == MatchState.DEATHMATCH) { … }
 *
 * // After
 * if (state.isActive()) { … }
 * }</pre>
 */
public enum MatchState {
    WAITING,
    STARTING,
    PLAYING,
    DEATHMATCH,
    ENDING;

    // ── A2-S6: Pattern-matching convenience predicates ────────────────────────

    /** @return {@code true} when players are actively fighting (PLAYING or DEATHMATCH). */
    public boolean isActive() {
        return this == PLAYING || this == DEATHMATCH;
    }

    /** @return {@code true} when the arena is idle and accepting joins (WAITING or STARTING). */
    public boolean isJoinable() {
        return this == WAITING || this == STARTING;
    }

    /** @return {@code true} if the match is winding down or resetting. */
    public boolean isEnding() {
        return this == ENDING;
    }

    /**
     * A2-S6: Pattern-matching exhaustive switch via a functional interface.
     * Lets callers express all five states without a raw {@code switch} statement.
     *
     * <pre>{@code
     * String label = state.match(
     *     ()  -> "Waiting",   // WAITING
     *     ()  -> "Starting",  // STARTING
     *     ()  -> "In Game",   // PLAYING
     *     ()  -> "Deathmatch",// DEATHMATCH
     *     ()  -> "Ending"     // ENDING
     * );
     * }</pre>
     */
    public <T> T match(
            java.util.function.Supplier<T> onWaiting,
            java.util.function.Supplier<T> onStarting,
            java.util.function.Supplier<T> onPlaying,
            java.util.function.Supplier<T> onDeathmatch,
            java.util.function.Supplier<T> onEnding) {
        return switch (this) {
            case WAITING    -> onWaiting.get();
            case STARTING   -> onStarting.get();
            case PLAYING    -> onPlaying.get();
            case DEATHMATCH -> onDeathmatch.get();
            case ENDING     -> onEnding.get();
        };
    }
}
