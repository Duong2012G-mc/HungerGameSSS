package me.duong2012g.hungergamessss.model;

public enum MatchState {
    WAITING,
    STARTING,
    PLAYING,
    DEATHMATCH,
    ENDING
}
