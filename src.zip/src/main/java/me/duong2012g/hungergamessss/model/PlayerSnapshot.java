package me.duong2012g.hungergamessss.model;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;

public class PlayerSnapshot {
    private final ItemStack[] inventory;
    private final ItemStack[] armor;
    private final GameMode gamemode;
    private final float exp;
    private final int level;
    private final double health;
    private final int foodLevel;
    private final Location location;

    public PlayerSnapshot(Player player) {
        this.inventory = Arrays.stream(player.getInventory().getContents())
                .map(item -> item == null ? null : item.clone())
                .toArray(ItemStack[]::new);
        this.armor = Arrays.stream(player.getInventory().getArmorContents())
                .map(item -> item == null ? null : item.clone())
                .toArray(ItemStack[]::new);
        this.gamemode = player.getGameMode();
        this.exp = player.getExp();
        this.level = player.getLevel();
        this.health = player.getHealth();
        this.foodLevel = player.getFoodLevel();
        this.location = player.getLocation().clone();
    }

    public void restore(Player player) {
        player.getInventory().setContents(inventory);
        player.getInventory().setArmorContents(armor);
        player.setGameMode(gamemode);
        player.setExp(exp);
        player.setLevel(level);
        player.setHealth(Math.min(health, player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue()));
        player.setFoodLevel(foodLevel);
        player.teleport(location);
    }
}
