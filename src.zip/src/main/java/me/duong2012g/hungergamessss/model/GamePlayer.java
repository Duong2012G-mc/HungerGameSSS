package me.duong2012g.hungergamessss.model;

import java.util.UUID;
import org.bukkit.Location;

public class GamePlayer {
    private final UUID uuid;
    private PlayerSnapshot snapshot;
    private boolean alive;
    private int kills;
    private int deaths;
    // FIX L-08: Track last known location so reconnecting players are teleported back
    private Location lastLocation;

    public GamePlayer(UUID uuid) {
        this.uuid = uuid;
        this.alive = true;
        this.kills = 0;
        this.deaths = 0;
    }

    public UUID getUuid() {
        return uuid;
    }

    public PlayerSnapshot getSnapshot() {
        return snapshot;
    }

    public void setSnapshot(PlayerSnapshot snapshot) {
        this.snapshot = snapshot;
    }

    public boolean isAlive() {
        return alive;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }

    public int getKills() {
        return kills;
    }

    public void addKill() {
        this.kills++;
    }

    public int getDeaths() {
        return deaths;
    }

    public void addDeath() {
        this.deaths++;
    }

    /** FIX L-08: Last known in-game location — updated by PlayerMoveEvent, used for reconnect teleport. */
    public Location getLastLocation() { return lastLocation; }
    public void setLastLocation(Location loc) { this.lastLocation = loc; }
}
