package me.duong2012g.hungergamessss.model;

import me.duong2012g.hungergamessss.util.ColorUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import me.duong2012g.hungergamessss.Main;

public class Arena {
    // FIX BUG-ARENA-01: All fields were public — callers could bypass thread-safe setters.
    // Now private; existing getters/setters already cover all legitimate access paths.
    private String name;
    private World world;
    private Location cornucopia;
    private final List<Location> spawns = new ArrayList<>();
    private int maxPlayers = 40;

    // A2-17: Extracted component objects — responsibilities previously embedded in Arena
    private final ArenaBlockRestorer  blockRestorer   = new ArenaBlockRestorer();
    private final ArenaLegendaryTracker legendaryTracker = new ArenaLegendaryTracker();

    // Settings — all have synchronized getters/setters below
    private boolean pvpEnabled = true;
    private boolean netherEnabled = true;
    private boolean endEnabled = true;
    private boolean lifestealEnabled = false;
    private boolean hardcoreEnabled = false;
    private boolean veinminerEnabled = false;
    private boolean enabled = true;
    private World netherWorld = null;
    
    private final Map<UUID, GamePlayer> gamePlayers = new ConcurrentHashMap<>();
    private final List<UUID> spectators = Collections.synchronizedList(new ArrayList<>());
    private volatile MatchState state = MatchState.WAITING;
    private final AtomicBoolean gameEnded = new AtomicBoolean(false);
    private final Map<UUID, Long> combatTimestamps = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> lastAttackers = new ConcurrentHashMap<>();
    private volatile int timer = 0;
    
    // Gameplay Fixes: Player Reconnection
    private final Map<UUID, Long> disjointedPlayers = new ConcurrentHashMap<>();
    
    // Legendary item management
    private Map<Location, String> configuredLegendaries = new HashMap<>();
    private Map<ArmorStand, org.bukkit.inventory.ItemStack> hologramMap = new ConcurrentHashMap<>();
    private Map<Location, String> temporaryLegendaries = new HashMap<>();

    public void setDisconnected(UUID uuid, long timestamp) {
        disjointedPlayers.put(uuid, timestamp);
    }
    
    public void removeDisconnected(UUID uuid) {
        disjointedPlayers.remove(uuid);
    }
    
    public boolean isDisconnected(UUID uuid) {
        return disjointedPlayers.containsKey(uuid);
    }
    
    public Map<UUID, Long> getDisconnectedPlayers() {
        return disjointedPlayers;
    }

    public Arena(String name) {
        this.name = name;
    }

    public static class BlockUpdate {
        public Location loc;
        public Material mat;
        public boolean saveOriginal;

        public BlockUpdate(Location loc, Material mat, boolean saveOriginal) {
            this.loc = loc;
            this.mat = mat;
            this.saveOriginal = saveOriginal;
        }
    }
    
    // Getters/Setters for compatibility with existing code
    public String getName() { return name; }
    public MatchState getState() { return state; }
    public synchronized void setState(MatchState state) { this.state = state; }
    public AtomicBoolean getGameEnded() { return gameEnded; }
    
    public List<UUID> getPlayers() { 
        return new ArrayList<>(gamePlayers.keySet()); 
    }

    /** Returns the key set directly for iteration without copying. Use for read-only hot loops. */
    public java.util.Set<UUID> getPlayerIds() {
        return gamePlayers.keySet();
    }
    
    public Map<UUID, GamePlayer> getGamePlayers() {
        return gamePlayers;
    }

    public GamePlayer getGamePlayer(UUID uuid) {
        return gamePlayers.get(uuid);
    }

    public List<UUID> getSpectators() { return spectators; }
    public Map<UUID, Long> getCombatTimestamps() { return combatTimestamps; }
    public Map<UUID, UUID> getLastAttackers() { return lastAttackers; }
    public World getWorld() { return world; }
    public void setWorld(World world) { this.world = world; }
    
    public synchronized void setTimer(int timer) { this.timer = timer; }
    public synchronized int getTimer() { return timer; }
    
    public List<Location> getConfiguredSpawns() { return spawns; }
    public Location getCornucopia() { return cornucopia; }
    public void setCornucopia(Location loc) { this.cornucopia = loc; }
    
    public synchronized boolean isVeinminerEnabled() { return veinminerEnabled; }
    public synchronized void setVeinminerEnabled(boolean enabled) { this.veinminerEnabled = enabled; }
    
    public synchronized boolean isLifestealEnabled() { return lifestealEnabled; }
    public synchronized void setLifestealEnabled(boolean enabled) { this.lifestealEnabled = enabled; }

    public synchronized boolean isHardcoreEnabled() { return hardcoreEnabled; }
    public synchronized void setHardcoreEnabled(boolean enabled) { this.hardcoreEnabled = enabled; }

    public synchronized boolean isPvpEnabled() { return pvpEnabled; }
    public synchronized void setPvpEnabled(boolean enabled) { this.pvpEnabled = enabled; }

    public synchronized boolean isNetherEnabled() { return netherEnabled; }
    public synchronized void setNetherEnabled(boolean enabled) { this.netherEnabled = enabled; }

    public synchronized boolean isTheEndEnabled() { return endEnabled; }
    public synchronized void setTheEndEnabled(boolean enabled) { this.endEnabled = enabled; }
    public synchronized boolean isEndEnabled() { return endEnabled; }
    
    public Map<Location, String> getLegendaryLocations() {
        // Return configured ones for saving
        return configuredLegendaries;
    }
    
    public Map<Location, String> getActiveLegendaryLocations() {
        Map<Location, String> map = new HashMap<>();
        if (hologramMap != null) {
            hologramMap.forEach((stand, recipe) -> {
                if (stand != null && stand.isValid()) {
                    String itemName = recipe.hasItemMeta() && recipe.getItemMeta().hasDisplayName() ? 
                        recipe.getItemMeta().getDisplayName() : recipe.getType().name();
                    map.put(stand.getLocation().getBlock().getLocation(), itemName);
                }
            });
        }
        return map;
    }

    public void addConfiguredSpawn(Location loc) {
        if (!spawns.contains(loc)) {
            spawns.add(loc);
        }
    }

    public void removeConfiguredSpawn(Location loc) {
        spawns.remove(loc);
    }

    public void addTemporaryLegendary(Location loc, String itemName) {
        temporaryLegendaries.put(loc, itemName);
    }
    
    public void clearTemporaryLegendaries() {
        temporaryLegendaries.clear();
    }
    
    public Map<Location, String> getAllLegendaryLocations() {
        Map<Location, String> all = new HashMap<>(configuredLegendaries);
        all.putAll(temporaryLegendaries);
        return all;
    }

    public boolean isEnabled() { return enabled; }
    public void setMaxPlayers(int max) { this.maxPlayers = max; }
    
    public void addPlayer(org.bukkit.entity.Player player) {
        if (!gamePlayers.containsKey(player.getUniqueId())) {
            GamePlayer gp = new GamePlayer(player.getUniqueId());
            gp.setSnapshot(new PlayerSnapshot(player));
            gamePlayers.put(player.getUniqueId(), gp);
        }
    }

    /**
     * Internal method for database restoration. Addresses CS-03.
     */
    public void loadPlayer(UUID uuid) {
        if (!gamePlayers.containsKey(uuid)) {
            gamePlayers.put(uuid, new GamePlayer(uuid));
        }
    }

    public void removePlayer(UUID uuid) {
        gamePlayers.remove(uuid);
    }
    public static class SpawnPoint {
        private final Location loc;
        private final Location pistonLoc;
        private final List<Location> cageLocs;

        public SpawnPoint(Location loc, Location pistonLoc, List<Location> cageLocs) {
            this.loc = loc;
            this.pistonLoc = pistonLoc;
            this.cageLocs = cageLocs;
        }

        public Location getLoc() { return loc; }
        public Location getPistonLoc() { return pistonLoc; }
        public List<Location> getCageLocs() { return cageLocs; }
    }

    private final Map<UUID, SpawnPoint> spawnPoints = new ConcurrentHashMap<>();

    public void addSpawnPoint(UUID uuid, SpawnPoint point) {
        spawnPoints.put(uuid, point);
    }

    public Map<UUID, SpawnPoint> getSpawnPoints() {
        return spawnPoints;
    }

    public void clearSpawnPoints() {
        spawnPoints.clear();
        availableSpawns.clear();
    }

    private final List<Location> availableSpawns = new ArrayList<>();

    public synchronized Location extractRandomSpawn() {
        if (availableSpawns.isEmpty()) {
            availableSpawns.addAll(spawns);
            Collections.shuffle(availableSpawns);
        }
        if (availableSpawns.isEmpty()) return null;
        return availableSpawns.remove(0);
    }

    public void clearStats() {
        combatTimestamps.clear();
        lastAttackers.clear();
        timer = 0;
    }

    public int getMaxPlayers() { return maxPlayers; }

    // ── Collection accessors — delegated to component objects (A2-17) ─────────

    /** A2-17: Block-change tracking and restoration component. */
    public ArenaBlockRestorer getBlockRestorer() { return blockRestorer; }

    /** A2-17: Legendary item placement and hologram lifecycle component. */
    public ArenaLegendaryTracker getLegendaryTracker() { return legendaryTracker; }

    /** @deprecated Use {@code getBlockRestorer().getBlockQueue()} */
    @Deprecated(since = "5.1.0", forRemoval = true)
    public java.util.Queue<BlockUpdate> getBlockQueue() { return blockRestorer.getBlockQueue(); }

    /** @deprecated Use {@code getBlockRestorer().getOriginalBlocks()} */
    @Deprecated(since = "5.1.0", forRemoval = true)
    public Map<Location, Material> getOriginalBlocks() { return blockRestorer.getOriginalBlocks(); }

    /** @deprecated Use {@code getLegendaryTracker().getHologramMap()} */
    @Deprecated(since = "5.1.0", forRemoval = true)
    public Map<ArmorStand, LegendaryRecipe> getHologramMap() { return legendaryTracker.getHologramMap(); }

    /** @deprecated Use {@code getLegendaryTracker().getHolograms()} */
    @Deprecated(since = "5.1.0", forRemoval = true)
    public Map<LegendaryRecipe, List<ArmorStand>> getHolograms() { return legendaryTracker.getHolograms(); }

    /** @deprecated Use {@code getLegendaryTracker().getActiveLegendaries()} */
    @Deprecated(since = "5.1.0", forRemoval = true)
    public List<LegendaryRecipe> getActiveLegendaries() { return legendaryTracker.getActiveLegendaries(); }

    public void setActiveLegendaries(List<LegendaryRecipe> list) {
        legendaryTracker.getActiveLegendaries().clear();
        legendaryTracker.getActiveLegendaries().addAll(list);
    }

    /** @deprecated Use {@code getLegendaryTracker().getAllLegendaries()} */
    @Deprecated(since = "5.1.0", forRemoval = true)
    public Map<Location, String> getTemporaryLegendaries() { return legendaryTracker.getAllLegendaries(); }

    public World getNetherWorld() { return netherWorld; }
    public void setNetherWorld(World w) { this.netherWorld = w; }

    public void addLegendaryLocation(Location loc, String itemName) {
        legendaryTracker.getConfiguredLegendaries().put(loc, itemName);
    }
    
    public Map<Location, String> getConfiguredLegendaries() {
        return configuredLegendaries;
    }
    
    public void removeConfiguredLegendary(Location loc) {
        configuredLegendaries.remove(loc);
    }

    public void addKill(UUID uuid) {
        GamePlayer gp = gamePlayers.get(uuid);
        if (gp != null) {
            gp.addKill();
            org.bukkit.entity.Player player = org.bukkit.Bukkit.getPlayer(uuid);
            if (player != null) {
                Main.getInstance().getPlayerManager().getPlayerData(player).addKill();
            }
        }
    }

    public void addDeath(UUID uuid) {
        GamePlayer gp = gamePlayers.get(uuid);
        if (gp != null) {
            gp.addDeath();
            org.bukkit.entity.Player player = org.bukkit.Bukkit.getPlayer(uuid);
            if (player != null) {
                Main.getInstance().getPlayerManager().getPlayerData(player).addDeath();
            }
        }
    }

    public int getKills(UUID uuid) { 
        GamePlayer gp = gamePlayers.get(uuid);
        return gp != null ? gp.getKills() : 0; 
    }

    public int getDeaths(UUID uuid) { 
        GamePlayer gp = gamePlayers.get(uuid);
        return gp != null ? gp.getDeaths() : 0; 
    }

    public UUID getLastAttacker(UUID uuid) {
        return lastAttackers.get(uuid);
    }

    public void handleDamage(org.bukkit.event.entity.EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof org.bukkit.entity.Player victim)) return;
        
        if (!pvpEnabled && event.getDamager() instanceof org.bukkit.entity.Player) {
            event.setCancelled(true);
            return;
        }

        // Handle Temple Mob effects (moved from listener)
        if (event.getDamager() instanceof org.bukkit.entity.LivingEntity mob) {
            if (mob.hasMetadata("TEMPLE_MOB")) {
                String type = mob.getMetadata("TEMPLE_MOB").get(0).asString();
                if (type.equals("lava-temple")) {
                    victim.setFireTicks(100);
                } else if (type.equals("ice-temple")) {
                    victim.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.SLOWNESS, 100, 1));
                }
            }
        }
    }

    public void handlePortal(org.bukkit.event.player.PlayerPortalEvent event) {
        org.bukkit.entity.Player player = event.getPlayer();
        if (event.getTo() == null || event.getTo().getWorld() == null) return;
        org.bukkit.World.Environment targetEnv = event.getTo().getWorld().getEnvironment();
        Main plugin = Main.getInstance();

        if (targetEnv == org.bukkit.World.Environment.NETHER) {
            if (!isNetherEnabled()) {
                event.setCancelled(true);
                player.sendMessage(plugin.getMessageManager().getMessage("nether_disabled"));
                return;
            }
            
            // B-23: Redirect to per-arena Nether
            String netherName = world.getName() + "_nether";
            org.bukkit.World nether = org.bukkit.Bukkit.getWorld(netherName);
            if (nether == null) {
                nether = org.bukkit.Bukkit.createWorld(new org.bukkit.WorldCreator(netherName).environment(org.bukkit.World.Environment.NETHER));
            }
            
            if (nether != null) {
                org.bukkit.Location from = event.getFrom();
                org.bukkit.Location to = new org.bukkit.Location(nether, from.getX() / 8.0, from.getY(), from.getZ() / 8.0, from.getYaw(), from.getPitch());
                event.setTo(to);
            }
        } else if (targetEnv == org.bukkit.World.Environment.THE_END) {
            if (!isEndEnabled()) {
                event.setCancelled(true);
                player.sendMessage(plugin.getMessageManager().getMessage("end_disabled"));
                return;
            }
            // Same for End if needed, but End Gateways are handled by PortalManager
        }
    }

    public void handleDeath(UUID uuid) {
        GamePlayer gp = gamePlayers.get(uuid);
        if (gp != null) {
            gp.setAlive(false);
            // This now increments PlayerData too via addDeath() call
            addDeath(uuid);
            
            // Check win condition (moved from task)
            long aliveCount = gamePlayers.values().stream().filter(GamePlayer::isAlive).count();
            if (aliveCount <= 1 && state != MatchState.WAITING && state != MatchState.ENDING) {
                Main.getInstance().getMatchService().checkWin(this);
            }
        }
    }

    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public void broadcast(String message) {
        if (message == null || message.isEmpty()) return;
        String colored = ColorUtil.colorize(message);
        for (UUID uuid : gamePlayers.keySet()) {
            org.bukkit.entity.Player player = org.bukkit.Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline()) {
                player.sendMessage(colored);
            }
        }
    }
}
