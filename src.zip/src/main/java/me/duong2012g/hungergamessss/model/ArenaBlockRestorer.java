package me.duong2012g.hungergamessss.model;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A2-17: Encapsulates block-change tracking and restoration for an arena.
 *
 * <p>Previously this responsibility was split across {@link Arena}'s
 * {@code originalBlocks}, {@code blockQueue}, and multiple methods in
 * {@code ArenaManager}. This component owns all three concerns:
 * <ul>
 *   <li>Recording the original material of every block touched during a match.</li>
 *   <li>Queuing pending block placements for the throttled batch processor.</li>
 *   <li>Restoring all changed blocks on arena reset.</li>
 * </ul>
 */
public class ArenaBlockRestorer {

    private final Map<Location, Material> originalBlocks = new ConcurrentHashMap<>();
    private final java.util.Queue<Arena.BlockUpdate> blockQueue = new java.util.concurrent.ConcurrentLinkedQueue<>();

    // ── Recording ─────────────────────────────────────────────────────────────

    /**
     * Records the original material of the block at {@code loc} if it has not
     * already been recorded. Call this before placing or changing any block.
     */
    public void recordOriginal(Location loc, Material original) {
        originalBlocks.putIfAbsent(loc, original);
    }

    /**
     * Queues a block change for the throttled batch processor.
     *
     * @param loc          target location
     * @param mat          material to set
     * @param saveOriginal if true, the block's current material is recorded before
     *                     it is changed (pass false for purely decorative blocks that
     *                     should not be restored on reset)
     */
    public void queue(Location loc, Material mat, boolean saveOriginal) {
        blockQueue.add(new Arena.BlockUpdate(loc.clone(), mat, saveOriginal));
    }

    // ── Restoration ───────────────────────────────────────────────────────────

    /**
     * Restores all recorded blocks synchronously.
     * Should be called during arena reset (already on the main thread via
     * {@code MatchService.resetArena()}).
     */
    public void restore() {
        for (Map.Entry<Location, Material> entry : originalBlocks.entrySet()) {
            Location loc = entry.getKey();
            if (loc.getWorld() == null) continue;
            Block block = loc.getBlock();
            block.setType(entry.getValue(), false);
        }
        originalBlocks.clear();
        blockQueue.clear();
    }

    // ── Accessors ─────────────────────────────────────────────────────────────

    public java.util.Queue<Arena.BlockUpdate> getBlockQueue()           { return blockQueue; }
    public Map<Location, Material>            getOriginalBlocks()       { return originalBlocks; }
    public boolean                            hasChanges()              { return !originalBlocks.isEmpty(); }
    public int                                queueSize()               { return blockQueue.size(); }
}
