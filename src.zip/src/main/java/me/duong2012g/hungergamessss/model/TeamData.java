package me.duong2012g.hungergamessss.model;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class TeamData {
    private String name;
    private ChatColor color;
    private List<UUID> members;
    private int maxSize;
    private UUID leader;

    public TeamData(String name, ChatColor color, int maxSize) {
        this.name = name;
        this.color = color;
        this.maxSize = maxSize;
        this.members = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public ChatColor getColor() {
        return color;
    }

    public List<UUID> getMembers() {
        return members;
    }
    
    public List<Player> getOnlinePlayers() {
        return members.stream()
                .map(Bukkit::getPlayer)
                .filter(p -> p != null && p.isOnline())
                .collect(Collectors.toList());
    }
    
    public void addPlayer(Player player) {
        addPlayer(player.getUniqueId());
    }
    
    public void addPlayer(UUID uuid) {
        if (members.size() < maxSize && !members.contains(uuid)) {
            members.add(uuid);
            if (leader == null) {
                leader = uuid;
            }
        }
    }
    
    public void removePlayer(Player player) {
        removePlayer(player.getUniqueId());
    }

    public void removePlayer(UUID uuid) {
        members.remove(uuid);
        if (uuid.equals(leader)) {
            leader = members.isEmpty() ? null : members.get(0);
        }
    }

    public void setLeader(UUID leader) {
        this.leader = leader;
    }
    
    public boolean isFull() {
        return members.size() >= maxSize;
    }
    
    public boolean isLeader(Player player) {
        return leader != null && leader.equals(player.getUniqueId());
    }
    
    public UUID getLeader() {
        return leader;
    }
    
    public boolean isMember(Player player) {
        return members.contains(player.getUniqueId());
    }
    
    public int getSize() {
        return members.size();
    }
    
    public List<UUID> getPlayers() {
        return members;
    }
}
