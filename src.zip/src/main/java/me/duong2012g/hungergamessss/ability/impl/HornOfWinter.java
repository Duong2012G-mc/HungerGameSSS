package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class HornOfWinter extends BaseAbility {

    public HornOfWinter(Main plugin) {
        super(plugin);
    }

    @Override
    public String getName() {
        return "Horn of Winter";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 22000); // 22s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);
        // Horn Whirlwind
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_GOAT_HORN_SOUND_1, 1.5f, 0.7f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.8f, 0.5f);
        player.sendMessage("§b[Horn of Winter] §7A blizzard is approaching...");

        int blizzardDuration = getConfigInt("blizzard_duration_ticks", 120);
        double radius = getConfigDouble("blizzard_radius", 10.0);
        int freezeTicks = getConfigInt("freeze_ticks", 40);
        int slownessAmp = getConfigInt("slowness_amplifier", 2);
        double damage = getConfigDouble("blizzard_damage", 1.0);

        new BukkitRunnable() {
            private int ticks = 0;
            @Override
            public void run() {
                if (ticks > blizzardDuration || !player.isOnline()) {
                    cancel();
                    return;
                }

                // Visual Blizzard
                for (int i = 0; i < 5; i++) {
                    double r = 1 + Math.random() * (radius - 1);
                    double angle = Math.random() * Math.PI * 2;
                    double x = Math.cos(angle) * r;
                    double z = Math.sin(angle) * r;
                    player.getWorld().spawnParticle(Particle.SNOWFLAKE, player.getLocation().add(x, 0.1 + Math.random() * 3, z), 1, 0, 0, 0, 0.05);
                }

                if (ticks % 10 == 0) {
                    for (Entity e : player.getNearbyEntities(radius, 5, radius)) {
                        if (e instanceof LivingEntity target && e != player) {
                            // Team Check
                            if (target instanceof Player pTarget) {
                                if (plugin.getTeamManager().isFriendlyFire(player, pTarget)) continue;
                            }
                            
                            target.setFreezeTicks(Math.min(target.getFreezeTicks() + freezeTicks, 300));
                            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, slownessAmp));
                            target.damage(damage, player);
                        }
                    }
                }
                ticks += 5;
            }
        }.runTaskTimer(plugin, 0L, 5L);
    }
}
