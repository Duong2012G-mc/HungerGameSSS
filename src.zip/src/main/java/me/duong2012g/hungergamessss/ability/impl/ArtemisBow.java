package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Artemis Bow
 *
 * PROC 1 — Homing Arrow (25% chance per shot)
 *   The fired arrow tracks the nearest enemy within 16 blocks.
 *   Tracking speed starts at 1.4 and accelerates by 0.08 every 10 ticks (max 3.0).
 *   Only visible targets are homed upon. Golden WAX_ON particles mark a homing arrow.
 *   Capped at 12 concurrent homing runnables per player (AB-OPEN-01 fix retained).
 *
 * PROC 2 — Lightning Strike (20% chance per hit)
 *   On any arrow impact: visual lightning + 8-heart raw damage with 40% armor bypass
 *   + 3 seconds of fire on the struck entity.
 *   Team-safe; never hits shooter.
 *
 * No global cooldown — both are passive per-shot procs.
 */
public class ArtemisBow extends BaseAbility {

    // ── Constants ──────────────────────────────────────────────────────────────
    private static final int    DEFAULT_HOMING_RADIUS    = 16;
    private static final double DEFAULT_HOMING_SPEED     = 1.4;
    private static final double DEFAULT_HOMING_ACCEL     = 0.08;
    private static final int    MAX_HOMING_TICKS         = 120;
    private static final double DEFAULT_HOMING_CHANCE    = 0.25;
    private static final double DEFAULT_LIGHTNING_CHANCE = 0.20;
    private static final double DEFAULT_LIGHTNING_DAMAGE = 16.0;  // raw HP (~8 hearts)
    private static final double DEFAULT_ARMOR_BYPASS     = 0.40;
    private static final int    DEFAULT_FIRE_TICKS       = 60;
    private static final int    MAX_ACTIVE_ARROWS        = 12;

    // ── State ──────────────────────────────────────────────────────────────────
    private final Map<UUID, AtomicInteger> activeArrows = new ConcurrentHashMap<>();
    private final Random random = new Random();

    public ArtemisBow(Main plugin) {
        super(plugin);
    }

    @Override public String getName()      { return "Artemis Bow"; }
    @Override public long   getCooldown()  { return 0; }

    // ── Config shortcuts ───────────────────────────────────────────────────────
    private double homingChance()    { return getConfigDouble("homing_chance",    DEFAULT_HOMING_CHANCE);   }
    private double lightningChance() { return getConfigDouble("lightning_chance", DEFAULT_LIGHTNING_CHANCE); }
    private double lightningDmg()    { return getConfigDouble("lightning_damage", DEFAULT_LIGHTNING_DAMAGE); }
    private double armorBypass()     { return getConfigDouble("armor_bypass",     DEFAULT_ARMOR_BYPASS);    }
    private int    homingRadius()    { return getConfigInt("homing_radius",       DEFAULT_HOMING_RADIUS);   }
    private double homingSpeed()     { return getConfigDouble("homing_speed",     DEFAULT_HOMING_SPEED);    }
    private double homingAccel()     { return getConfigDouble("homing_accel",     DEFAULT_HOMING_ACCEL);    }
    private int    fireTicks()       { return getConfigInt("fire_ticks",          DEFAULT_FIRE_TICKS);      }

    // ── PROC 1: Homing Arrow — triggered on launch ─────────────────────────────

    @Override
    protected void performProjectileLaunch(Player player, org.bukkit.entity.Projectile projectile, ItemStack item) {
        if (projectile.hasMetadata("artemis_extra")) return;
        if (!(projectile instanceof AbstractArrow arrow)) return;

        // Tag every arrow from this bow so PROC 2 can identify it on hit
        arrow.setMetadata("artemis_bow",
                new FixedMetadataValue(plugin, player.getUniqueId().toString()));

        // 25% homing chance
        if (random.nextDouble() < homingChance()) {
            AtomicInteger counter = activeArrows.computeIfAbsent(
                    player.getUniqueId(), k -> new AtomicInteger(0));
            if (counter.get() < MAX_ACTIVE_ARROWS) {
                makeHoming(player.getUniqueId(), arrow, counter);
                player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                    .legacySection().deserialize("§e[Artemis] §6★ Homing arrow!"));
            }
        }
    }

    private void makeHoming(UUID shooterUUID, AbstractArrow arrow, AtomicInteger counter) {
        counter.incrementAndGet();
        new BukkitRunnable() {
            int ticks = 0;
            double speed = homingSpeed();

            @Override
            public void run() {
                if (!arrow.isValid() || arrow.isDead() || arrow.isOnGround() || ticks++ > MAX_HOMING_TICKS) {
                    counter.decrementAndGet();
                    cancel();
                    return;
                }
                // Golden sparkle trail
                arrow.getWorld().spawnParticle(Particle.WAX_ON,
                        arrow.getLocation(), 2, 0.04, 0.04, 0.04, 0.01);

                // Accelerate every 10 ticks, cap at 3.0
                if (ticks % 10 == 0) {
                    speed = Math.min(speed + homingAccel(), 3.0);
                }

                // Steer toward nearest target every 3 ticks
                if (ticks % 3 == 0) {
                    LivingEntity target = findNearest(shooterUUID, arrow.getLocation());
                    if (target != null) {
                        Vector dir = target.getEyeLocation()
                                .subtract(arrow.getLocation())
                                .toVector().normalize().multiply(speed);
                        arrow.setVelocity(dir);
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private LivingEntity findNearest(UUID shooterUUID, Location from) {
        Player shooter = Bukkit.getPlayer(shooterUUID);
        LivingEntity nearest = null;
        double minDist = Double.MAX_VALUE;
        int r = homingRadius();

        for (Entity e : from.getWorld().getNearbyEntities(from, r, r, r)) {
            if (!(e instanceof LivingEntity living)) continue;
            if (shooter != null && e.equals(shooter)) continue;
            if (living instanceof Player tp && shooter != null
                    && plugin.getTeamManager().isFriendlyFire(shooter, tp)) continue;
            double dist = e.getLocation().distanceSquared(from);
            if (dist < minDist) { minDist = dist; nearest = living; }
        }
        return nearest;
    }

    // ── PROC 2: Lightning Strike — triggered on any hit ────────────────────────

    @Override
    protected void performProjectileHit(org.bukkit.entity.Projectile projectile, ProjectileHitEvent event) {
        if (!projectile.hasMetadata("artemis_bow")) return;
        if (random.nextDouble() >= lightningChance()) return;
        if (!(projectile.getShooter() instanceof Player shooter)) return;

        Location impact = projectile.getLocation();
        World world = impact.getWorld();

        // Visual-only lightning — no block destruction
        world.strikeLightningEffect(impact);
        world.spawnParticle(Particle.FLASH, impact, 1);
        world.spawnParticle(Particle.ELECTRIC_SPARK, impact, 25, 0.4, 0.4, 0.4, 0.1);
        world.playSound(impact, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.9f, 1.0f);

        if (event.getHitEntity() instanceof LivingEntity target) {
            if (target instanceof Player tp && plugin.getTeamManager().isFriendlyFire(shooter, tp)) return;

            double dmg = calcBypassDamage(target, lightningDmg(), armorBypass());
            target.damage(dmg, shooter);
            target.setFireTicks(fireTicks());
            world.spawnParticle(Particle.FLAME,
                    target.getLocation().add(0, 1, 0), 15, 0.3, 0.5, 0.3, 0.05);

            if (target instanceof Player tp) {
                tp.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                    .legacySection().deserialize("§e⚡ §cArtemis Lightning Strike! §7Armour partially bypassed."));
            }
        }
    }

    /**
     * Damage with partial armour bypass.
     *   effectiveArmour = armour * (1 - bypassFraction)
     *   reduction       = effectiveArmour / (effectiveArmour + 25)   [linear approx]
     *   finalDamage     = raw * (1 - reduction)
     */
    private double calcBypassDamage(LivingEntity target, double raw, double bypass) {
        if (!(target instanceof Player)) return raw;
        try {
            double armour = target.getAttribute(Attribute.GENERIC_ARMOR).getValue();
            double effective = armour * (1.0 - bypass);
            double reduction = effective / (effective + 25.0);
            return raw * (1.0 - reduction);
        } catch (Exception ignored) {
            return raw;
        }
    }

    // ── passiveTick: HUD hint ──────────────────────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§e⚡ §7Homing §625% §8| §7Lightning §620% §8| §7Power III→VII via Anvil"));
    }

    // ── cleanup ────────────────────────────────────────────────────────────────

    @Override
    protected void performQuit(Player p, org.bukkit.event.player.PlayerQuitEvent e)  { activeArrows.remove(p.getUniqueId()); }
    @Override
    protected void performDeath(Player p, org.bukkit.event.entity.PlayerDeathEvent e) { activeArrows.remove(p.getUniqueId()); }
    @Override
    public void cleanup() { activeArrows.clear(); }
}
