package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Ghastly Whistle — Summons a rideable "Happy Ghast" companion.
 *
 * RIGHT-CLICK (CD 45s):
 *   Spawns a GHAST above the player and forces the player to ride it.
 *   (Happy Ghast entity type was added in 1.21.5 — not available on Paper 1.21.1.
 *    We simulate it using a regular Ghast with setAI(false), gravity off, glowing,
 *    and manual fireball logic. Visually identical from the player's perspective.)
 *
 *   RIDING:
 *     Player mounts the ghast. WASD steers, jump = ascend, sneak = descend.
 *     Ghast follows player eye direction for steering.
 *
 *   AUTO FIREBALL:
 *     Every 40 ticks (2s) the ghast fires a fireball at the nearest enemy
 *     within 25 blocks. Fireball yield = 1 (no block break, damage only).
 *     Team-safe: won't target teammates.
 *
 *   DURATION: 20 seconds, then ghast removed + player dismounts.
 *   VISUAL: HAPPY_VILLAGER (happy) particles around ghast + HEART trail.
 */
public class GhastlyWhistle extends BaseAbility {

    private static final long   DEFAULT_CD_MS         = 45_000L;
    private static final int    DEFAULT_DURATION_S    = 20;
    private static final double DEFAULT_SEARCH_RADIUS = 25.0;
    private static final long   DEFAULT_SHOOT_PERIOD  = 40L;   // ticks between fireballs

    private final Map<UUID, Ghast> activeGhasts = new ConcurrentHashMap<>();

    public GhastlyWhistle(Main plugin) {
        super(plugin);
    }

    @Override public String getName()     { return "Ghastly Whistle"; }
    @Override public long   getCooldown() { return getConfigLong("cooldown", DEFAULT_CD_MS); }

    private int    durationS()     { return getConfigInt   ("duration_s",     DEFAULT_DURATION_S);    }
    private double searchRadius()  { return getConfigDouble("search_radius",  DEFAULT_SEARCH_RADIUS); }
    private long   shootPeriod()   { return getConfigLong  ("shoot_period",   DEFAULT_SHOOT_PERIOD);  }

    // ── RIGHT-CLICK: Summon Happy Ghast ──────────────────────────────────────

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);

        // Dismiss existing ghast first if somehow still active
        dismissGhast(player.getUniqueId());

        UUID ownerUUID = player.getUniqueId();
        final int durationTicks = durationS() * 20;

        // Spawn ghast 3 blocks above player
        Location spawnLoc = player.getLocation().clone().add(0, 3, 0);
        Ghast ghast = (Ghast) player.getWorld().spawnEntity(spawnLoc, EntityType.GHAST);
        ghast.setRemoveWhenFarAway(true); // A1-26
        ghast.setAI(false);
        ghast.setGravity(false);
        ghast.setInvulnerable(false); // can be killed — counterplay
        ghast.setGlowing(true);
        ghast.setSilent(false);

        activeGhasts.put(ownerUUID, ghast);

        // Mount player on ghast
        ghast.addPassenger(player);
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§f👻 §7Happy Ghast summoned! §8(§f" + durationS() + "s§8) "
                + "§8| §7WASD=steer §7Jump=up §7Sneak=down"));
        player.getWorld().playSound(spawnLoc, Sound.ENTITY_GHAST_WARN, 1.2f, 1.6f);
        player.getWorld().playSound(spawnLoc, Sound.ENTITY_GHAST_AMBIENT, 1.0f, 1.8f);

        // Happy particles burst on spawn
        player.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, spawnLoc, 25, 1.5, 1.0, 1.5, 0.1);
        player.getWorld().spawnParticle(Particle.HEART, spawnLoc, 8, 0.8, 0.6, 0.8, 0.05);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                Player p = Bukkit.getPlayer(ownerUUID);
                if (p == null || !p.isOnline() || !ghast.isValid() || ticks >= durationTicks) {
                    dismissGhast(ownerUUID);
                    cancel();
                    return;
                }

                // ── Manual steering: move ghast toward player's look direction ──
                // (Ghast AI is off, so we drive it manually)
                if (p.isInsideVehicle() && ghast.getPassengers().contains(p)) {
                    Vector lookDir = p.getEyeLocation().getDirection();
                    double speed = 0.4;
                    Location newLoc = ghast.getLocation().clone()
                            .add(lookDir.multiply(speed));
                    // Clamp Y to avoid going underground
                    newLoc.setY(Math.max(newLoc.getY(), p.getWorld().getMinHeight() + 5));
                    ghast.teleport(newLoc);
                }

                // ── Visual: happy particles every 5 ticks ──────────────────────
                if (ticks % 5 == 0) {
                    ghast.getWorld().spawnParticle(Particle.HAPPY_VILLAGER,
                            ghast.getLocation(), 3, 1.2, 0.8, 1.2, 0.05);
                }

                // ── Auto fireball every shootPeriod ticks ──────────────────────
                if (ticks % shootPeriod() == 0 && ticks > 0) {
                    shootFireball(p, ghast);
                }

                ticks++;
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void shootFireball(Player owner, Ghast ghast) {
        // Find nearest enemy
        double r = searchRadius();
        LivingEntity target = null;
        double minDist = Double.MAX_VALUE;

        for (Entity e : ghast.getNearbyEntities(r, r, r)) {
            if (!(e instanceof LivingEntity living)) continue;
            if (living.equals(owner)) continue;
            if (living instanceof Player tp && plugin.getTeamManager().isFriendlyFire(owner, tp)) continue;
            double dist = e.getLocation().distanceSquared(ghast.getLocation());
            if (dist < minDist) { minDist = dist; target = living; }
        }

        Vector dir = (target != null)
                ? target.getEyeLocation().toVector().subtract(ghast.getLocation().toVector()).normalize()
                : owner.getEyeLocation().getDirection();

        Fireball fireball = ghast.getWorld().spawn(
                ghast.getLocation().clone().add(dir.clone().multiply(2)), Fireball.class);
        fireball.setDirection(dir.multiply(2.0));
        fireball.setShooter(owner);
        fireball.setYield(1.5f);    // small explosion — damage without griefing
        fireball.setIsIncendiary(false);

        ghast.getWorld().playSound(ghast.getLocation(), Sound.ENTITY_GHAST_SHOOT, 1.0f, 1.4f);
        ghast.getWorld().spawnParticle(Particle.FLAME,
                ghast.getLocation(), 8, 0.4, 0.4, 0.4, 0.05);
    }

    private void dismissGhast(UUID ownerUUID) {
        Ghast g = activeGhasts.remove(ownerUUID);
        if (g != null && g.isValid()) {
            // Eject passengers before removal
            g.getPassengers().forEach(g::removePassenger);
            g.getWorld().spawnParticle(Particle.POOF, g.getLocation(), 20, 1, 1, 1, 0.05);
            g.getWorld().playSound(g.getLocation(), Sound.ENTITY_GHAST_DEATH, 0.8f, 1.5f);
            g.remove();
        }
        Player p = Bukkit.getPlayer(ownerUUID);
        if (p != null && p.isOnline()) {
            p.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§7[Ghastly Whistle] §fGhast dismissed."));
        }
    }

    // ── passiveTick: action bar ───────────────────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;
        boolean onCd = plugin.getCooldownManager().isOnCooldown(player, getName());
        boolean riding = activeGhasts.containsKey(player.getUniqueId());
        String status = riding ? "§f👻 §aRiding ghast!"
                : onCd ? "§cCD: §f" + String.format("%.0f",
                    plugin.getCooldownManager().getCooldown(player, getName()) / 1000.0) + "s"
                : "§aReady";
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize("§f👻 §7Ghast: " + status));
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    @Override
    protected void performQuit(Player player, PlayerQuitEvent event) {
        dismissGhast(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, PlayerDeathEvent event) {
        dismissGhast(player.getUniqueId());
    }

    @Override
    public void cleanup() {
        for (UUID id : new java.util.HashSet<>(activeGhasts.keySet())) dismissGhast(id);
        activeGhasts.clear();
    }
}
