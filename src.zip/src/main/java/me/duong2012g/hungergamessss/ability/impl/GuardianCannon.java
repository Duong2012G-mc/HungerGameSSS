package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class GuardianCannon extends BaseAbility {

    public GuardianCannon(Main plugin) {
        super(plugin);
        // FIX BUG-GC-01: removed standalone startPassiveTask() BukkitRunnable.
        // Same root cause as BUG-AB-01 — each reload spawned a new parallel task.
        // Migrated to passiveTick() — driven by UnifiedPassiveTicker in AbilityManager.
    }

    @Override
    public String getName() { return "Guardian Cannon"; }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 18000);
    }

    // Replaces the old startPassiveTask() BukkitRunnable
    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, "guardian_cannon")) return;
        if (!player.isInWater()) return;

        int duration = getConfigInt("passive_effect_duration", 40);
        int amp = getConfigInt("passive_effect_amplifier", 1);
        player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, duration, amp, true, false, true));
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);
        // Guardian Stasis Beam
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GUARDIAN_ATTACK, 1.0f, 1.0f);
        player.sendMessage("§3[Guardian] §7Charging laser...");

        double range = getConfigDouble("beam_range", 40.0);
        double beamDamage = getConfigDouble("beam_damage", 2.0);
        int slownessDuration = getConfigInt("slowness_duration", 40);
        int slownessAmp = getConfigInt("slowness_amplifier", 2);

        new BukkitRunnable() {
            private int steps = 0;
            private Location current = player.getEyeLocation().clone();
            private final Vector direction = player.getEyeLocation().getDirection().normalize();
            private final double maxSteps = range * 2.5;

            @Override
            public void run() {
                for (int i = 0; i < 5; i++) {
                    current.add(direction.clone().multiply(0.4));
                    steps++;

                    if (steps > maxSteps || current.getBlock().getType().isSolid()) {
                        cancel();
                        return;
                    }

                    current.getWorld().spawnParticle(Particle.GLOW, current, 5, 0.1, 0.1, 0.1, 0.05);
                    current.getWorld().spawnParticle(Particle.BUBBLE, current, 2, 0.05, 0.05, 0.05, 0.01);

                    for (Entity entity : current.getWorld().getNearbyEntities(current, 1.5, 1.5, 1.5)) {
                        if (entity instanceof LivingEntity target && !target.equals(player)) {
                            if (target instanceof Player targetPlayer) {
                                if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                            }
                            target.damage(beamDamage, player);
                            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, slownessDuration, slownessAmp));
                            target.getWorld().spawnParticle(Particle.GLOW, target.getLocation().add(0, 1, 0), 10, 0.3, 0.3, 0.3, 0.1);
                        }
                    }
                }

                if (steps % 10 == 0) {
                    player.getWorld().playSound(current, Sound.BLOCK_BEACON_AMBIENT, 0.5f, 2.0f);
                }
            }
        }.runTaskTimer(plugin, 10L, 1L);
    }
}
