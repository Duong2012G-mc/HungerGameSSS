package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Beehive Blaster — Crossbow that launches a swarm of angry bees.
 *
 * RIGHT-CLICK (Shoot):
 *   Fires 4 angry bees that auto-target the nearest enemy within ~16 blocks.
 *   Each bee: 1 heart/sting + Poison I (8s), stackable across multiple bees.
 *   Bee lifetime: ~30 seconds.
 *   Cooldown: 22 seconds.
 *
 * DPS: ~12 hearts/shot (4 bees x 3 stings) + Poison DoT
 */
public class BeehiveBlaster extends BaseAbility {

    private static final int    DEFAULT_BEE_COUNT        = 4;
    private static final long   DEFAULT_COOLDOWN_MS      = 22_000L;
    private static final int    DEFAULT_SEARCH_RADIUS    = 16;
    private static final int    DEFAULT_BEE_LIFETIME_S   = 30;     // seconds
    private static final int    DEFAULT_POISON_TICKS     = 160;    // 8 seconds (20t * 8)
    private static final int    DEFAULT_POISON_AMPLIFIER = 0;      // Poison I
    private static final double DEFAULT_SPREAD_RADIUS    = 1.5;    // spawn spread

    // per-player list of active bees for cleanup
    private final Map<UUID, List<Bee>> activeBees = new ConcurrentHashMap<>();
    private final Map<UUID, Long> shootCooldowns   = new ConcurrentHashMap<>();

    public BeehiveBlaster(Main plugin) {
        super(plugin);
    }

    @Override public String getName()     { return "Beehive Blaster"; }
    @Override public long   getCooldown() { return 0; }

    private int    beeCount()        { return getConfigInt   ("bee_count",        DEFAULT_BEE_COUNT);       }
    private long   shootCdMs()       { return getConfigLong  ("shoot_cooldown",    DEFAULT_COOLDOWN_MS);     }
    private int    searchRadius()    { return getConfigInt   ("search_radius",     DEFAULT_SEARCH_RADIUS);   }
    private int    beeLifetimeTicks(){ return getConfigInt   ("bee_lifetime_s",    DEFAULT_BEE_LIFETIME_S) * 20; }
    private int    poisonTicks()     { return getConfigInt   ("poison_ticks",      DEFAULT_POISON_TICKS);    }
    private int    poisonAmplifier() { return getConfigInt   ("poison_amplifier",  DEFAULT_POISON_AMPLIFIER);}
    private double spreadRadius()    { return getConfigDouble("spawn_spread",      DEFAULT_SPREAD_RADIUS);   }

    // ── RIGHT-CLICK: Shoot swarm ──────────────────────────────────────────────

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);

        // Cooldown check
        Long last = shootCooldowns.get(player.getUniqueId());
        if (last != null && System.currentTimeMillis() - last < shootCdMs()) {
            long remaining = (shootCdMs() - (System.currentTimeMillis() - last)) / 1000L;
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize(
                    "§6[Beehive Blaster] §7Shoot §cCD: §f" + remaining + "s"));
            return;
        }
        shootCooldowns.put(player.getUniqueId(), System.currentTimeMillis());

        // Find nearest enemy target within search radius
        LivingEntity target = findNearestTarget(player);
        Location spawnLoc = player.getEyeLocation().clone().add(
                player.getLocation().getDirection().normalize().multiply(2.0));

        List<Bee> beeList = activeBees.computeIfAbsent(
                player.getUniqueId(), k -> Collections.synchronizedList(new ArrayList<>()));
        beeList.removeIf(b -> b == null || !b.isValid() || b.isDead());

        Random rand = new Random();
        int count = beeCount();

        for (int i = 0; i < count; i++) {
            // Slight spread so bees don't all stack on same block
            double ox = (rand.nextDouble() - 0.5) * spreadRadius();
            double oz = (rand.nextDouble() - 0.5) * spreadRadius();
            Location beeLoc = spawnLoc.clone().add(ox, 0, oz);

            Bee bee = (Bee) player.getWorld().spawnEntity(beeLoc, EntityType.BEE);
            bee.setAnger(Integer.MAX_VALUE); // permanently angry until cleaned up
            bee.setInvulnerable(false);      // can be killed (allows counterplay)
            bee.setSilent(false);

            if (target != null) {
                bee.setTarget(target);
            }

            beeList.add(bee);

            // Override default bee sting to apply Poison I on hit
            attachStingEffect(bee, player);

            // Auto-remove after lifetime
            UUID ownerUUID = player.getUniqueId();
            final Bee finalBee = bee;
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (finalBee.isValid()) {
                    finalBee.getWorld().spawnParticle(Particle.POOF,
                            finalBee.getLocation(), 5, 0.2, 0.2, 0.2, 0.05);
                    finalBee.remove();
                }
                List<Bee> bl = activeBees.get(ownerUUID);
                if (bl != null) bl.remove(finalBee);
            }, beeLifetimeTicks());
        }

        // Sound + visual
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEEHIVE_EXIT, 1.5f, 0.6f);
        player.getWorld().spawnParticle(Particle.DUST, spawnLoc,
                30, 0.5, 0.5, 0.5, new Particle.DustOptions(Color.YELLOW, 1.2f));

        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§6[Beehive Blaster] §e§l" + count + " §7bees launched! §cCD: §f"
                + (shootCdMs() / 1000) + "s"));
    }

    /**
     * Attaches a per-tick monitor to the bee that applies Poison I to its target
     * when the bee successfully stings. We use EntityDamageByEntityEvent indirectly
     * by watching the bee's target HP change — simpler and reliable on Paper 1.21.
     *
     * Implementation: poll every 4 ticks; if the bee has a valid target that is
     * within sting range (~1.5 blocks), apply Poison I refresh.
     */
    private void attachStingEffect(Bee bee, Player owner) {
        int pticks  = poisonTicks();
        int pamp    = poisonAmplifier();

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!bee.isValid() || bee.isDead()) {
                    cancel();
                    return;
                }
                LivingEntity t = bee.getTarget();
                if (t == null || !t.isValid()) return;
                if (t instanceof Player tp && plugin.getTeamManager().isFriendlyFire(owner, tp)) return;

                // Within sting range
                if (bee.getLocation().distanceSquared(t.getLocation()) < 4.0) {
                    t.addPotionEffect(new PotionEffect(
                            PotionEffectType.POISON, pticks, pamp, false, true, true));
                }
            }
        }.runTaskTimer(plugin, 5L, 4L);
    }

    /**
     * Find the nearest non-teammate LivingEntity within searchRadius of the player,
     * ignoring the player themselves.
     */
    private LivingEntity findNearestTarget(Player player) {
        int r = searchRadius();
        LivingEntity nearest = null;
        double minDist = Double.MAX_VALUE;

        for (Entity e : player.getNearbyEntities(r, r, r)) {
            if (!(e instanceof LivingEntity living)) continue;
            if (e.equals(player)) continue;
            if (living instanceof Player tp && plugin.getTeamManager().isFriendlyFire(player, tp)) continue;
            double d = e.getLocation().distanceSquared(player.getLocation());
            if (d < minDist) { minDist = d; nearest = living; }
        }
        return nearest;
    }

    // ── passiveTick: action bar status ───────────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;

        List<Bee> bees = activeBees.getOrDefault(player.getUniqueId(), Collections.emptyList());
        bees.removeIf(b -> b == null || !b.isValid() || b.isDead());
        int alive = bees.size();

        Long last = shootCooldowns.get(player.getUniqueId());
        boolean onCd = last != null && System.currentTimeMillis() - last < shootCdMs();
        String cdStr = onCd
                ? "§cCD: §f" + ((shootCdMs() - (System.currentTimeMillis() - last)) / 1000L) + "s"
                : "§aReady";

        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§6🐝 §7Shoot: " + cdStr
                + "  §8| §7Bees active: §e" + alive
                + "§8/§e" + beeCount()));
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    private void cleanupPlayer(UUID id) {
        List<Bee> bees = activeBees.remove(id);
        if (bees != null) {
            bees.forEach(b -> { if (b != null && b.isValid()) b.remove(); });
        }
        shootCooldowns.remove(id);
    }

    @Override
    protected void performQuit(Player player, PlayerQuitEvent event) {
        cleanupPlayer(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, PlayerDeathEvent event) {
        cleanupPlayer(player.getUniqueId());
    }

    @Override
    public void cleanup() {
        for (UUID id : new HashSet<>(activeBees.keySet())) cleanupPlayer(id);
        activeBees.clear();
        shootCooldowns.clear();
    }
}
