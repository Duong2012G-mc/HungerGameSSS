package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Crimson Chainsword — Nether-forged motorized blade.
 *
 * BASE STATS (via aiglos.yml attributes block):
 *   Damage: 12 HP (Sharpness VIII equivalent)
 *   Attack Speed: 2.0/s  |  Fire Aspect: 2
 *
 * RIGHT-CLICK: Chainsaw Rampage (10s cooldown)
 *   3-second burst, ticks every 0.25s (12 ticks total).
 *   Per tick in radius 3.5:
 *     - 3 heart damage (50% armour bypass)
 *     - Armour shred: 15-25% of random piece durability
 *     - Fire: 2s burn
 *     - 0.5-block radial knockback
 *   Visuals: BLOCK crack particles, ZOMBIE_ATTACK_IRON_DOOR sound, red CRIT glow
 *
 * PASSIVE: Shred Stacks (max 5)
 *   Each melee hit on a player builds 1 stack (8s duration per stack).
 *   Each stack: +10% effective armour penetration on all damage.
 *   Stacks shown in action bar.
 */
public class CrimsonChainsword extends BaseAbility {

    // ── Constants ──────────────────────────────────────────────────────────────
    private static final long   DEFAULT_RAMPAGE_CD_MS    = 10_000L;
    private static final int    DEFAULT_RAMPAGE_TICKS    = 12;      // 12 × 5t = 3 s
    private static final long   DEFAULT_RAMPAGE_PERIOD   = 5L;      // every 0.25 s
    private static final double DEFAULT_RAMPAGE_RADIUS   = 3.5;
    private static final double DEFAULT_RAMPAGE_DAMAGE   = 6.0;     // 3 hearts raw
    private static final double DEFAULT_ARMOR_BYPASS     = 0.50;    // 50%
    private static final double DEFAULT_KNOCKBACK        = 0.5;
    private static final int    DEFAULT_FIRE_TICKS       = 40;      // 2 s
    private static final int    DEFAULT_SHRED_MIN_PCT    = 15;
    private static final int    DEFAULT_SHRED_MAX_PCT    = 25;
    private static final int    DEFAULT_MAX_STACKS       = 5;
    private static final int    DEFAULT_STACK_DURATION_S = 8;

    // ── State ──────────────────────────────────────────────────────────────────
    // shredStacks: playerUUID → AtomicInteger (stack count)
    private final Map<UUID, AtomicInteger> shredStacks     = new ConcurrentHashMap<>();
    // stackExpiry: playerUUID → list of expiry timestamps (one per active stack)
    private final Map<UUID, Deque<Long>>   stackExpiries   = new ConcurrentHashMap<>();
    // rampageCooldowns: playerUUID → last-use timestamp
    private final Map<UUID, Long>          rampageCooldowns = new ConcurrentHashMap<>();
    // rampageActive: tracks whether rampage is running per player
    private final Set<UUID>                rampageActive   = ConcurrentHashMap.newKeySet();

    private final Random random = new Random();

    public CrimsonChainsword(Main plugin) {
        super(plugin);
    }

    @Override public String getName()     { return "Crimson Chainsword"; }
    @Override public long   getCooldown() { return 0; }

    // ── Config shortcuts ──────────────────────────────────────────────────────
    private long   rampageCdMs()   { return getConfigLong  ("rampage_cooldown",    DEFAULT_RAMPAGE_CD_MS);  }
    private int    rampageTicks()  { return getConfigInt   ("rampage_ticks",       DEFAULT_RAMPAGE_TICKS);  }
    private long   rampagePeriod() { return getConfigLong  ("rampage_period_ticks",DEFAULT_RAMPAGE_PERIOD); }
    private double rampageRadius() { return getConfigDouble("rampage_radius",      DEFAULT_RAMPAGE_RADIUS); }
    private double rampageDamage() { return getConfigDouble("rampage_damage",      DEFAULT_RAMPAGE_DAMAGE); }
    private double armorBypass()   { return getConfigDouble("armor_bypass",        DEFAULT_ARMOR_BYPASS);   }
    private double knockback()     { return getConfigDouble("rampage_knockback",   DEFAULT_KNOCKBACK);      }
    private int    fireTicks()     { return getConfigInt   ("fire_ticks",          DEFAULT_FIRE_TICKS);     }
    private int    shredMinPct()   { return getConfigInt   ("shred_min_pct",       DEFAULT_SHRED_MIN_PCT);  }
    private int    shredMaxPct()   { return getConfigInt   ("shred_max_pct",       DEFAULT_SHRED_MAX_PCT);  }
    private int    maxStacks()     { return getConfigInt   ("max_stacks",          DEFAULT_MAX_STACKS);     }
    private int    stackDurS()     { return getConfigInt   ("stack_duration_s",    DEFAULT_STACK_DURATION_S);}

    // ── PASSIVE: Melee hit → build shred stack ────────────────────────────────

    @Override
    protected void performHit(Player attacker, LivingEntity victim, ItemStack item,
                               EntityDamageByEntityEvent event) {
        if (!(victim instanceof Player target)) return;
        if (plugin.getTeamManager().isFriendlyFire(attacker, target)) return;

        // Apply current shred-stack penetration to this hit
        int stacks = liveStacks(attacker.getUniqueId());
        if (stacks > 0) {
            double pen = stacks * 0.10; // +10% penetration per stack
            double finalDmg = calcBypassDamage(victim, event.getDamage(), pen);
            event.setDamage(finalDmg);
        }

        // Add one shred stack (cap at maxStacks)
        if (stacks < maxStacks()) {
            addStack(attacker.getUniqueId());
            attacker.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize(buildStackBar(attacker.getUniqueId())));
        }
    }

    // ── RIGHT-CLICK: Chainsaw Rampage ─────────────────────────────────────────

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);

        // Cooldown check
        Long last = rampageCooldowns.get(player.getUniqueId());
        if (last != null && System.currentTimeMillis() - last < rampageCdMs()) {
            long rem = (rampageCdMs() - (System.currentTimeMillis() - last)) / 1000L;
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§4[Chainsword] §7Rampage §cCD: §f" + rem + "s"));
            return;
        }
        if (rampageActive.contains(player.getUniqueId())) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§4[Chainsword] §cRampage already active!"));
            return;
        }

        rampageCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
        rampageActive.add(player.getUniqueId());
        UUID uuid = player.getUniqueId();

        // CRIT + glow start sound
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ZOMBIE_ATTACK_IRON_DOOR, 1.2f, 0.8f);
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_GRINDSTONE_USE, 1.0f, 0.5f);
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize("§4§k|§r §c§lCHAINSAW RAMPAGE! §4§k|§r"));

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                Player p = Bukkit.getPlayer(uuid);
                if (p == null || !p.isOnline() || tick >= rampageTicks()) {
                    rampageActive.remove(uuid);
                    if (p != null) {
                        p.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                            .legacySection().deserialize("§4[Chainsword] §7Rampage ended. §cCD: §f" + (rampageCdMs() / 1000) + "s"));
                    }
                    cancel();
                    return;
                }

                double r = rampageRadius();
                Location center = p.getLocation();
                World world = center.getWorld();
                if (world == null) { cancel(); return; }

                // ── Per-tick visuals ──────────────────────────────────────────
                world.spawnParticle(Particle.BLOCK, center.clone().add(0, 1, 0),
                        60, r, 1.0, r, 0.05, Material.IRON_BLOCK.createBlockData());
                world.spawnParticle(Particle.CRIT, center.clone().add(0, 1, 0),
                        20, r * 0.8, 0.8, r * 0.8, 0.3);
                world.playSound(center, Sound.ENTITY_ZOMBIE_ATTACK_IRON_DOOR, 0.7f, 1.2f + (tick * 0.03f));

                // ── Per-tick effect on all enemies in radius ──────────────────
                for (Entity e : world.getNearbyEntities(center, r, r, r)) {
                    if (!(e instanceof LivingEntity target)) continue;
                    if (target.equals(p)) continue;
                    if (target instanceof Player tp && plugin.getTeamManager().isFriendlyFire(p, tp)) continue;

                    // Damage with 50% armour bypass
                    double dmg = calcBypassDamage(target, rampageDamage(), armorBypass());
                    target.setNoDamageTicks(0);
                    target.damage(dmg, p);

                    // Armour shred: random %, random piece
                    shredArmor(target);

                    // Fire
                    target.setFireTicks(Math.max(target.getFireTicks(), fireTicks()));

                    // Knockback (radial, outward)
                    if (target.getLocation().distanceSquared(center) > 0.01) {
                        org.bukkit.util.Vector kb = target.getLocation().toVector()
                                .subtract(center.toVector()).normalize().multiply(knockback()).setY(0.2);
                        target.setVelocity(target.getVelocity().add(kb));
                    }
                }

                tick++;
            }
        }.runTaskTimer(plugin, 0L, rampagePeriod());
    }

    // ── Armour shred ──────────────────────────────────────────────────────────

    private void shredArmor(LivingEntity target) {
        if (!(target instanceof Player tp)) return;
        ItemStack[] armor = tp.getInventory().getArmorContents();

        // Collect non-null pieces
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < armor.length; i++) {
            if (armor[i] != null && armor[i].getType() != Material.AIR) slots.add(i);
        }
        if (slots.isEmpty()) return;

        int slot = slots.get(random.nextInt(slots.size()));
        ItemStack piece = armor[slot];
        if (!(piece.getItemMeta() instanceof Damageable dmg)) return;

        int maxDur = piece.getType().getMaxDurability();
        if (maxDur <= 0) return;

        int pct = shredMinPct() + random.nextInt(Math.max(1, shredMaxPct() - shredMinPct() + 1));
        int dmgAmount = (int) (maxDur * (pct / 100.0));
        int newDmg = dmg.getDamage() + Math.max(1, dmgAmount);

        if (newDmg >= maxDur) {
            armor[slot] = null;
            tp.getInventory().setArmorContents(armor);
            tp.getWorld().playSound(tp.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
            tp.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§4§lARMOUR DESTROYED! §r§c(Chainsaw Rampage)"));
        } else {
            dmg.setDamage(newDmg);
            piece.setItemMeta((ItemMeta) dmg);
            armor[slot] = piece;
            tp.getInventory().setArmorContents(armor);
        }
    }

    // ── Shred stack helpers ───────────────────────────────────────────────────

    private void addStack(UUID uuid) {
        shredStacks.computeIfAbsent(uuid, k -> new AtomicInteger(0)).incrementAndGet();
        stackExpiries.computeIfAbsent(uuid, k -> new ArrayDeque<>())
                .addLast(System.currentTimeMillis() + stackDurS() * 1000L);
    }

    /** Returns live stack count, pruning expired ones. */
    private int liveStacks(UUID uuid) {
        Deque<Long> expiries = stackExpiries.get(uuid);
        if (expiries == null) return 0;
        long now = System.currentTimeMillis();
        int expired = 0;
        while (!expiries.isEmpty() && expiries.peekFirst() <= now) {
            expiries.pollFirst();
            expired++;
        }
        if (expired > 0) {
            AtomicInteger ai = shredStacks.get(uuid);
            if (ai != null) ai.set(Math.max(0, ai.get() - expired));
        }
        AtomicInteger ai = shredStacks.get(uuid);
        return ai != null ? ai.get() : 0;
    }

    private String buildStackBar(UUID uuid) {
        int stacks = liveStacks(uuid);
        int max = maxStacks();
        StringBuilder sb = new StringBuilder("§4⚙ §7Shred: §c");
        for (int i = 0; i < max; i++) sb.append(i < stacks ? "▐" : "░");
        sb.append(" §8(").append(stacks).append("/").append(max)
          .append(" | +").append(stacks * 10).append("% pen)");
        return sb.toString();
    }

    // ── Armour bypass calculation ─────────────────────────────────────────────

    private double calcBypassDamage(LivingEntity target, double raw, double bypass) {
        if (!(target instanceof Player)) return raw;
        try {
            double armour    = target.getAttribute(Attribute.GENERIC_ARMOR).getValue();
            double effective = armour * (1.0 - bypass);
            double reduction = effective / (effective + 25.0);
            return raw * (1.0 - reduction);
        } catch (Exception ignored) {
            return raw;
        }
    }

    // ── passiveTick: action bar ───────────────────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;

        Long last = rampageCooldowns.get(player.getUniqueId());
        boolean onCd = last != null && System.currentTimeMillis() - last < rampageCdMs();
        boolean active = rampageActive.contains(player.getUniqueId());
        String rampageStr = active ? "§c§l▶ ACTIVE"
                : onCd ? "§cCD: §f" + ((rampageCdMs() - (System.currentTimeMillis() - last)) / 1000L) + "s"
                : "§aReady";

        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(buildStackBar(player.getUniqueId())
                + "  §8| §7Rampage: " + rampageStr));
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    private void cleanupPlayer(UUID id) {
        shredStacks.remove(id);
        stackExpiries.remove(id);
        rampageCooldowns.remove(id);
        rampageActive.remove(id);
    }

    @Override
    protected void performQuit(Player player, PlayerQuitEvent event)   { cleanupPlayer(player.getUniqueId()); }
    @Override
    protected void performDeath(Player player, PlayerDeathEvent event) { cleanupPlayer(player.getUniqueId()); }
    @Override
    public void cleanup() {
        shredStacks.clear(); stackExpiries.clear();
        rampageCooldowns.clear(); rampageActive.clear();
    }
}
