package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class RibbitReel extends BaseAbility {

    public RibbitReel(Main plugin) {
        super(plugin);
    }

    @Override
    public String getName() {
        return "Ribbit Reel";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 17000); // 17s (Standardized to ms)
    }

    @Override
    protected void performProjectileLaunch(Player player, org.bukkit.entity.Projectile projectile, ItemStack item) {
        // Cancel vanilla projectile
        projectile.remove();

        // Sticky Tongue
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_FISHING_BOBBER_THROW, 1.0f, 0.5f);
        player.sendMessage("§a[Ribbit Reel] §7Shooting tongue...");

        Location start = player.getEyeLocation();
        org.bukkit.util.Vector dir = start.getDirection().normalize();

        new BukkitRunnable() {
            private final Location current = start.clone();
            private int steps = 0;

            @Override
            public void run() {
                for (int i = 0; i < 4; i++) {
                    current.add(dir.clone().multiply(0.5));
                    steps++;

                    if (steps > 50 || current.getBlock().getType().isSolid()) {
                        spawnTongue(player.getEyeLocation(), current);
                        pullPlayer(player, current);
                        cancel();
                        return;
                    }

                    // Green slime particles for tongue
                    current.getWorld().spawnParticle(Particle.ITEM_SLIME, current, 2, 0.02, 0.02, 0.02, 0.01);

                    for (Entity entity : current.getWorld().getNearbyEntities(current, 1.2, 1.2, 1.2)) {
                        if (entity instanceof LivingEntity target && !target.equals(player)) {
                             // Team Check
                             if (target instanceof Player targetPlayer) {
                                  if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                             }
                             
                            spawnTongue(player.getEyeLocation(), target.getLocation());
                            pullTarget(player, target);
                            double damage = getConfigDouble("tongue_damage", 2.0);
                            target.damage(damage, player);
                            cancel();
                            return;
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void spawnTongue(Location from, Location to) {
        double dist = from.distance(to);
        org.bukkit.util.Vector dir = to.toVector().subtract(from.toVector()).normalize();
        for (double d = 0; d < dist; d += 0.4) {
            from.getWorld().spawnParticle(Particle.ITEM_SLIME, from.clone().add(dir.clone().multiply(d)), 1, 0, 0, 0, 0);
        }
        from.getWorld().playSound(from, Sound.ENTITY_FROG_AMBIENT, 1f, 1.2f);
    }

    private void pullPlayer(Player player, Location target) {
        org.bukkit.util.Vector vec = target.toVector().subtract(player.getLocation().toVector());
        if (vec.length() > 1) {
            double multiplier = getConfigDouble("pull_player_multiplier", 1.8);
            double upward = getConfigDouble("pull_player_upward", 0.5);
            player.setVelocity(vec.normalize().multiply(multiplier).setY(upward));
        }
    }

    private void pullTarget(Player player, LivingEntity target) {
        org.bukkit.util.Vector vec = player.getLocation().toVector().subtract(target.getLocation().toVector());
        if (vec.length() > 1) {
            double multiplier = getConfigDouble("pull_target_multiplier", 1.5);
            double upward = getConfigDouble("pull_target_upward", 0.3);
            target.setVelocity(vec.normalize().multiply(multiplier).setY(upward));
        }
    }
}
