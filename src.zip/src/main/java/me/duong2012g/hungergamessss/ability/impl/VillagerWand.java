package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class VillagerWand extends BaseAbility implements Listener {

    // BUG-VW-01 FIX: taggedForReward leaked entries for entities that never died.
    // Now stores expiry timestamp. A cleanup task removes stale entries every 20s.
    private final Map<UUID, Long> taggedForReward = new ConcurrentHashMap<>();

    public VillagerWand(Main plugin) {
        super(plugin);
        // FIX: registerEvents moved to AbilityRegistry.register() — prevents double-registration on reload
        startCleanupTask();
    }

    private void startCleanupTask() {
        new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                taggedForReward.entrySet().removeIf(e -> now > e.getValue());
            }
        }.runTaskTimer(plugin, 400L, 400L); // Every 20s
    }

    @Override
    public String getName() {
        return "Villager Wand";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 20000); // 20s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        Location target = getTargetLocation(player);
        if (target != null) {
            spawnExplosive(player, target);
        }
    }

    private Location getTargetLocation(Player player) {
        RayTraceResult result = player.getWorld().rayTraceBlocks(player.getEyeLocation(), player.getEyeLocation().getDirection(), 40.0, FluidCollisionMode.NEVER, true);
        if (result != null && result.getHitPosition() != null) {
            return result.getHitPosition().toLocation(player.getWorld());
        }
        return player.getEyeLocation().add(player.getEyeLocation().getDirection().multiply(10));
    }

    private void spawnExplosive(Player player, Location location) {
        Location spawnLoc = location.clone().add(0, 1.5, 0);
        ItemDisplay display = (ItemDisplay) location.getWorld().spawnEntity(spawnLoc, EntityType.ITEM_DISPLAY);
        
        ItemStack slime = new ItemStack(Material.SLIME_BALL);
        ItemMeta meta = slime.getItemMeta();
        if (meta != null) {
            meta.setCustomModelData(12);
            slime.setItemMeta(meta);
        }
        display.setItemStack(slime);
        display.setBrightness(new Display.Brightness(15, 15));
        
        new BukkitRunnable() {
            int ticksElapsed = 0;
            boolean exploded = false;
            float rotation = 0;
            final int growTicks = getConfigInt("grow_ticks", 15);
            final int shrinkTicks = getConfigInt("shrink_ticks", 10);

            @Override
            public void run() {
                if (display.isDead() || !display.isValid()) {
                    cancel();
                    return;
                }

                rotation += 15.0f;
                if (!exploded) {
                    float t = Math.min(1.0f, (float) ticksElapsed / growTicks);
                    float scale = 1.0f + (3.0f * t);
                    applyTransform(display, rotation, scale, scale * 50.0f, scale);
                    
                    if (t >= 1.0f) {
                        explode(player, display.getLocation());
                        exploded = true;
                        ticksElapsed = 0;
                    }
                } else {
                    float t = Math.min(1.0f, (float) ticksElapsed / shrinkTicks);
                    float scale = 4.0f - (3.0f * t);
                    applyTransform(display, rotation, scale, scale * 50.0f, scale);
                    
                    if (t >= 1.0f) {
                        display.remove();
                        cancel();
                    }
                }
                ticksElapsed++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        
        player.getWorld().playSound(location, Sound.ENTITY_VILLAGER_YES, 1.0f, 1.0f);
    }

    private void applyTransform(ItemDisplay display, float rotation, float x, float y, float z) {
        Transformation trans = display.getTransformation();
        trans.getLeftRotation().rotationY((float) Math.toRadians(rotation));
        trans.getScale().set(x, y, z);
        display.setTransformation(trans);
    }

    private void explode(Player shooter, Location location) {
        float power = (float) getConfigDouble("explosion_power", 3.5);
        location.getWorld().createExplosion(location, power, false, false);
        location.getWorld().spawnParticle(Particle.EXPLOSION, location, 10, power, power, power, 0.1);
        location.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, location, 30, power, power, power, 0.05);
        location.getWorld().playSound(location, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.0f);
        location.getWorld().playSound(location, Sound.ENTITY_VILLAGER_CELEBRATE, 1.0f, 1.2f);

        for (Entity entity : location.getWorld().getNearbyEntities(location, power + 1, power + 1, power + 1)) {
            if (entity instanceof LivingEntity living && !entity.equals(shooter)) {
                long rewardWindow = getConfigLong("reward_window_ms", 5000);
                // BUG-VW-01 FIX: store expiry = now + window (not activation time).
                // onEntityDeath just checks now < expiry, no subtraction needed.
                taggedForReward.put(living.getUniqueId(), System.currentTimeMillis() + rewardWindow);
            }
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        UUID uuid = event.getEntity().getUniqueId();
        if (taggedForReward.containsKey(uuid)) {
            Long expiry = taggedForReward.remove(uuid);
            // BUG-VW-01: value is now an expiry timestamp, not an activation time
            if (expiry != null && System.currentTimeMillis() <= expiry) {
                int baseReward = getConfigInt("emerald_reward_base", 1);
                int monsterReward = getConfigInt("emerald_reward_monster", 2);
                event.getDrops().add(new ItemStack(Material.EMERALD, baseReward));
                if (event.getEntity() instanceof Monster) {
                    event.getDrops().add(new ItemStack(Material.EMERALD, monsterReward));
                }
            }
        }
    }
}
