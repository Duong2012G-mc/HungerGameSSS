package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.List;

public class CloudSword extends BaseAbility implements org.bukkit.event.Listener {

    private final NamespacedKey CLOUD_WALK_KEY;
    private final java.util.Map<Block, Long> activeClouds = new java.util.concurrent.ConcurrentHashMap<>();

    public CloudSword(Main plugin) {
        super(plugin);
        this.CLOUD_WALK_KEY = new NamespacedKey(plugin, "cloud_walk_active");
        startCleanupTask();
        // FIX: registerEvents moved to AbilityRegistry.register() — prevents double-registration on reload
    }

    private void startCleanupTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                activeClouds.entrySet().removeIf(entry -> {
                    if (now >= entry.getValue()) {
                        Block block = entry.getKey();
                        if (block.getType() == Material.WHITE_STAINED_GLASS) {
                            block.setType(Material.AIR);
                            block.getWorld().spawnParticle(Particle.CLOUD, block.getLocation().add(0.5, 0.5, 0.5), 1, 0.1, 0.1, 0.1, 0.01);
                        }
                        return true;
                    }
                    return false;
                });
            }
        }.runTaskTimer(plugin, 20L, 10L);
    }

    @org.bukkit.event.EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            org.bukkit.entity.Entity entity = event.getEntity();
            // Check if the block below is a cloud block created by this ability
            Block blockBelow = entity.getLocation().getBlock().getRelative(BlockFace.DOWN);
            if (activeClouds.containsKey(blockBelow)) {
                 event.setCancelled(true);
            }
        }
    }

    @Override
    public String getName() {
        return "Cloud Sword";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 5000); // 5s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        boolean active = meta.getPersistentDataContainer().getOrDefault(CLOUD_WALK_KEY, PersistentDataType.BOOLEAN, false);
        active = !active;

        meta.getPersistentDataContainer().set(CLOUD_WALK_KEY, PersistentDataType.BOOLEAN, active);

        // Rebuild lore as Component list to prevent italic (FIX L-FONT-01)
        // Read existing lore as plain strings, filter, then re-wrap as Components
        List<net.kyori.adventure.text.Component> existingLore = meta.hasLore() ? meta.lore() : new ArrayList<>();
        if (existingLore == null) existingLore = new ArrayList<>();

        // Strip the old Cloud Walk line (compare plain text)
        net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer plain =
                net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText();
        List<net.kyori.adventure.text.Component> newLore = new ArrayList<>();
        for (net.kyori.adventure.text.Component c : existingLore) {
            if (!plain.serialize(c).contains("Cloud Walk:")) newLore.add(c);
        }
        String statusStr = ChatColor.GRAY + "Cloud Walk: "
                + (active ? ChatColor.LIGHT_PURPLE + "ENABLED" : ChatColor.RED + "DISABLED");
        newLore.add(me.duong2012g.hungergamessss.util.ColorUtil.component(statusStr));
        meta.lore(newLore);

        item.setItemMeta(meta);

        if (active) {
            player.playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1f, 1.2f);
            // BUG-CS-02: cloud_walk_enabled/disabled missing from language files → "Message not found" spam.
            // Use sendActionBar directly so no language key needed.
            player.sendActionBar(net.kyori.adventure.text.Component.text(
                    "\u00a7b\u00a7l☁ Cloud Walk: \u00a7aENABLED"));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 1));
            // Initial particles
            player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 20, 0.5, 0.1, 0.5, 0.05);
        } else {
            player.playSound(player.getLocation(), Sound.ENTITY_BAT_AMBIENT, 1f, 0.8f);
            player.sendActionBar(net.kyori.adventure.text.Component.text(
                    "\u00a7b\u00a7l☁ Cloud Walk: \u00a7cDISABLED"));
        }
    }

    @Override
    protected void performMove(Player player, ItemStack item, PlayerMoveEvent event) {
        if (!isCloudWalkActive(item)) return;

        // Passive speed check
        if (!player.hasPotionEffect(PotionEffectType.SPEED)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 1));
        }

        Location to = event.getTo();
        if (to == null) return;

        // Only place blocks if horizontal position changed
        if (event.getFrom().getBlockX() == to.getBlockX()
                && event.getFrom().getBlockZ() == to.getBlockZ()) {
            return;
        }

        // BUG-CS-01: Placing blocks synchronously inside PlayerMoveEvent causes the
        // server physics to snap the player up by ~0.1 block on the same tick,
        // creating a constant stutter/jitter effect while walking.
        // Fix: defer ALL block placements to the next server tick so the movement
        // event completes cleanly before any world modification occurs.
        final Location center = to.clone().subtract(0, 1, 0);

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;
                // Only place clouds when player is actually in the air (not on solid ground)
                // This prevents unnecessary glass floors appearing on flat terrain.
                Block groundCheck = player.getLocation().getBlock().getRelative(BlockFace.DOWN);
                boolean isAirborne = groundCheck.getType() == Material.AIR
                        || activeClouds.containsKey(groundCheck);

                if (!isAirborne) return;

                // 3x3 platform beneath player
                for (int x = -1; x <= 1; x++) {
                    for (int z = -1; z <= 1; z++) {
                        placeCloudBlock(center.clone().add(x, 0, z));
                    }
                }
            }
        }.runTask(plugin);
    }

    private void placeCloudBlock(Location loc) {
        Block block = loc.getBlock();
        if (block.getType() != Material.AIR) return;

        block.setType(Material.WHITE_STAINED_GLASS);
        activeClouds.put(block, System.currentTimeMillis() + 2000L);
        loc.getWorld().spawnParticle(Particle.CLOUD, loc.clone().add(0.5, 1.1, 0.5), 2, 0.2, 0.1, 0.2, 0.01);
    }

    @Override
    protected void performHit(Player attacker, LivingEntity victim, ItemStack item, EntityDamageByEntityEvent event) {
        double multiplier = getConfigDouble("damage_multiplier", 1.2);
        event.setDamage(event.getDamage() * multiplier);

        // 2. Slow Logic
        Block below = victim.getLocation().getBlock().getRelative(BlockFace.DOWN);
        if (below.getType() == Material.AIR) {
            // Mid-air: Stronger slow
            int duration = getConfigInt("midair_slow_duration", 60);
            victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, duration, 2));
        } else {
            // Ground: Weaker slow
            int duration = getConfigInt("ground_slow_duration", 40);
            victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, duration, 1));
        }

        if (victim instanceof Player targetPlayer) {
            updateArmor(targetPlayer, 0.2);
        }
    }

    private void updateArmor(Player player, double shredPercent) {
        ItemStack[] armor = player.getInventory().getArmorContents();
        boolean changed = false;
        for (int i = 0; i < armor.length; i++) {
            ItemStack piece = armor[i];
            if (piece == null || piece.getType() == Material.AIR) continue;
            ItemMeta meta = piece.getItemMeta();
            if (meta instanceof Damageable damageable) {
                short max = piece.getType().getMaxDurability();
                int damageToAdd = (int) (max * shredPercent);
                if (damageToAdd > 0) {
                    damageable.setDamage(damageable.getDamage() + damageToAdd);
                    piece.setItemMeta(meta);
                    // Check break
                    if (damageable.getDamage() >= max) {
                        armor[i] = null;
                        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
                    }
                    changed = true;
                }
            }
        }
        if (changed) {
            player.getInventory().setArmorContents(armor);
        }
    }

    @Override
    protected void performDamaged(Player victim, ItemStack item, EntityDamageEvent event) {
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            event.setCancelled(true);
        }
    }
    
    private boolean isCloudWalkActive(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().getOrDefault(CLOUD_WALK_KEY, PersistentDataType.BOOLEAN, false);
    }
}
