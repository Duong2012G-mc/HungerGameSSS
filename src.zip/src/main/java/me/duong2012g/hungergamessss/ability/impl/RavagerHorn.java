package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Ravager;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

public class RavagerHorn extends BaseAbility {

    public RavagerHorn(Main plugin) {
        super(plugin);
    }

    // BUG-RH-01 FIX: track active ravagers for cleanup on quit/death
    private final java.util.Map<java.util.UUID, Ravager> activeRavagers = new java.util.concurrent.ConcurrentHashMap<>();

    @Override
    public String getName() {
        return "Ravager Horn";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 35000); // 35s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);
        if (player.isSneaking()) {
            // Stampede Roar
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1.5f, 0.8f);
            player.sendMessage("§6[Ravager Horn] §7STAMPEDE!");

            // BUG-RH-02 FIX: capture cast location eagerly BEFORE lambda.
            // Old code called player.getLocation() inside the lambda — if player moved during the
            // 16-tick wave animation, later waves started from the player's new position.
            final org.bukkit.Location castLoc = player.getLocation().clone();
            org.bukkit.util.Vector dir = castLoc.getDirection().setY(0).normalize();
            for (int i = 1; i <= 8; i++) {
                final int dist = i;
                plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                    org.bukkit.Location waveLoc = castLoc.clone().add(dir.clone().multiply(dist));
                    waveLoc.getWorld().spawnParticle(org.bukkit.Particle.BLOCK, waveLoc, 40, 1.0, 0.2, 1.0, 0.1, org.bukkit.Material.DIRT.createBlockData());
                    waveLoc.getWorld().playSound(waveLoc, Sound.BLOCK_GRASS_BREAK, 1f, 0.5f);
                    
                    for (org.bukkit.entity.Entity e : waveLoc.getWorld().getNearbyEntities(waveLoc, 2, 2, 2)) {
                        if (e instanceof LivingEntity target && e != player) {
                            if (target instanceof Player p) {
                                if (plugin.getTeamManager().isFriendlyFire(player, p)) continue;
                            }
                            double damage = getConfigDouble("stampede_damage", 6.0);
                            double multiplier = getConfigDouble("stampede_knockback", 1.8);
                            target.damage(damage, player);
                            target.setVelocity(dir.clone().multiply(multiplier).setY(0.4));
                        }
                    }
                }, i * 2L);
            }
            return;
        }

        if (player.getVehicle() instanceof Ravager ravager) {
            // Dash
            Vector direction = player.getLocation().getDirection().setY(0.1).normalize();
            double multiplier = getConfigDouble("dash_multiplier", 2.2);
            ravager.setVelocity(direction.multiply(multiplier));
            ravager.getWorld().playSound(ravager.getLocation(), Sound.ENTITY_RAVAGER_ATTACK, 1.0f, 1.0f);
            ravager.getWorld().spawnParticle(org.bukkit.Particle.CAMPFIRE_COSY_SMOKE, ravager.getLocation(), 20, 0.5, 0.2, 0.5, 0.05);
        } else {
            // Spawn Ravager
            Ravager ravager = (Ravager) player.getWorld().spawnEntity(player.getLocation(), EntityType.RAVAGER);
            ravager.setRemoveWhenFarAway(true); // A1-26
            ravager.setAI(false);
            ravager.addPassenger(player);
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_RAVAGER_CELEBRATE, 1.0f, 1.0f);
            activeRavagers.put(player.getUniqueId(), ravager);
            
            long duration = getConfigLong("ravager_duration_ticks", 600L);
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (ravager.isValid()) ravager.remove();
                activeRavagers.remove(player.getUniqueId());
            }, duration);
        }
    }

    private void dismountAndRemove(Player player) {
        Ravager r = activeRavagers.remove(player.getUniqueId());
        if (r != null && r.isValid()) {
            r.eject();
            r.remove();
        }
    }

    @Override
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        dismountAndRemove(player);
    }

    @Override
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        dismountAndRemove(player);
    }

    /**
     * FIX BUG-RH-03: remove all active ravagers on full shutdown.
     * Without this, any ravager that is alive at the time of /reload or server stop
     * continues roaming the arena world as a permanent entity until the server restarts.
     */
    @Override
    public void cleanup() {
        for (java.util.UUID id : new java.util.HashSet<>(activeRavagers.keySet())) {
            Ravager r = activeRavagers.remove(id);
            if (r != null && r.isValid()) {
                r.eject();
                r.remove();
            }
        }
    }
}
