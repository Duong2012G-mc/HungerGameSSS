package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Dragon Katana — Speed Run / Dragon Dash combat sword.
 *
 * PASSIVE · Speed Run
 *   While the Dragon Katana is in main hand the wielder permanently has Speed I.
 *   Applied every 20 ticks via passiveTick(). ambient=true / particles=false so
 *   the HUD icon shows but no swirling particles spam the screen.
 *   Does NOT override existing Speed II+ potions.
 *
 * ACTIVE · Dragon Dash (right-click, CD 12 s)
 *   Precise teleport toward the aimed block/player (up to 32 blocks).
 *   - No item consumed, no fall damage on landing.
 *   - Destination snapped to a safe standing position above the target block.
 *   - Dragon-breath particle trail along the path + arrival burst.
 *   - Aimed at a player: appear 1.5 blocks behind them (flank position).
 */
public class DragonKatana extends BaseAbility {

    private final Map<UUID, Long> teleportCooldowns = new ConcurrentHashMap<>();

    private static final long DEFAULT_TELEPORT_CD   = 12_000L;
    private static final int  DEFAULT_RANGE          = 32;
    private static final int  SPEED_REFRESH_TICKS    = 45;   // longer than UnifiedPassiveTicker period (20t)

    public DragonKatana(Main plugin) {
        super(plugin);
        // Passive driven by UnifiedPassiveTicker — no standalone BukkitRunnable needed.
    }

    @Override
    public String getName() { return "Dragon Katana"; }

    @Override
    public long getCooldown() { return 0; } // Teleport CD managed via teleportCooldowns map

    // ── helpers ──────────────────────────────────────────────────────────────

    private long tpCdMs() { return getConfigLong("teleport_cooldown", DEFAULT_TELEPORT_CD); }

    private boolean isOnTpCd(Player p) {
        Long t = teleportCooldowns.get(p.getUniqueId());
        return t != null && System.currentTimeMillis() - t < tpCdMs();
    }

    private long tpRemaining(Player p) {
        Long t = teleportCooldowns.get(p.getUniqueId());
        if (t == null) return 0;
        return Math.max(0, (tpCdMs() - (System.currentTimeMillis() - t)) / 1000L);
    }

    // ── PASSIVE: Speed Run ────────────────────────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;

        // Only apply if player has no stronger speed buff (respects potions)
        int configAmp = getConfigInt("passive_speed_amplifier", 0);
        PotionEffect existing = player.getPotionEffect(PotionEffectType.SPEED);
        if (existing == null || existing.getAmplifier() < configAmp) {
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.SPEED,
                    SPEED_REFRESH_TICKS,
                    configAmp, // 0 = Speed I, 1 = Speed II
                    true,  // ambient — no AoE particles
                    false, // no swirl particles
                    true));// show HUD icon
        }
    }

    // ── ACTIVE: Dragon Dash (right-click) ─────────────────────────────────────

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);

        if (isOnTpCd(player)) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize(
                    "§5[Dragon Katana] §7Dragon Dash §cCD: §f" + tpRemaining(player) + "s"));
            return;
        }

        int range = getConfigInt("teleport_range", DEFAULT_RANGE);

        // Precise rayTrace: hits blocks AND entities
        RayTraceResult result = player.getWorld().rayTrace(
                player.getEyeLocation(),
                player.getEyeLocation().getDirection(),
                range,
                org.bukkit.FluidCollisionMode.NEVER,
                true,
                0.25,
                e -> e != player);

        Location destination;

        if (result != null && result.getHitBlock() != null) {
            destination = getSafeDestination(result.getHitBlock(), result.getHitBlockFace());
        } else if (result != null && result.getHitEntity() instanceof Player targetPlayer) {
            // Flank: appear 1.5 blocks behind the aimed player
            destination = targetPlayer.getLocation()
                    .subtract(targetPlayer.getLocation().getDirection().normalize().multiply(1.5));
        } else {
            // Nothing in range — short dash toward look direction (max range)
            destination = player.getLocation().add(
                    player.getLocation().getDirection().normalize().multiply(range));
        }

        // Find the nearest safe standing spot
        destination = findSafeLanding(destination);
        if (destination == null) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§c[Dragon Katana] §7No safe landing spot!"));
            return;
        }

        // Dragon-breath trail along dash path
        spawnDashTrail(player.getLocation().clone(), destination);

        // Teleport — preserve look direction
        destination.setYaw(player.getLocation().getYaw());
        destination.setPitch(player.getLocation().getPitch());
        player.teleport(destination);

        // Arrival burst
        World w = destination.getWorld();
        w.spawnParticle(Particle.DRAGON_BREATH,
                destination.clone().add(0, 1, 0), 50, 0.5, 0.7, 0.5, 0.1);
        w.spawnParticle(Particle.PORTAL,
                destination.clone().add(0, 0.5, 0), 25, 0.3, 0.5, 0.3, 0.3);
        w.spawnParticle(Particle.FLASH, destination.clone().add(0, 0.5, 0), 1);
        w.playSound(destination, Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.6f);
        w.playSound(destination, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.9f);

        teleportCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§5[Dragon Katana] §d§lDragon Dash! §cCD: §f" + (tpCdMs() / 1000) + "s"));
    }

    // ── Teleport helpers ──────────────────────────────────────────────────────

    /**
     * Returns the landing location on top of the hit block face.
     */
    private Location getSafeDestination(Block hitBlock, BlockFace face) {
        if (face == null || face == BlockFace.UP) {
            return hitBlock.getLocation().clone().add(0.5, 1.0, 0.5);
        } else if (face == BlockFace.DOWN) {
            return hitBlock.getLocation().clone().add(0.5, -1.0, 0.5);
        } else {
            // Side face — step onto the adjacent air block
            return hitBlock.getRelative(face).getLocation().clone().add(0.5, 0.0, 0.5);
        }
    }

    /**
     * Searches up/down from the candidate location for a 2-block-tall air gap
     * with a solid floor. Returns null if no safe spot is found within ±5 blocks.
     */
    private Location findSafeLanding(Location candidate) {
        World world = candidate.getWorld();
        if (world == null) return null;

        // Upward pass first (most common case — landing on top of blocks)
        for (int dy = 0; dy <= 5; dy++) {
            Location check = candidate.clone().add(0, dy, 0);
            if (isSafeStand(check)) return check;
        }
        // Downward pass
        for (int dy = 1; dy <= 5; dy++) {
            Location check = candidate.clone().subtract(0, dy, 0);
            if (isSafeStand(check)) return check;
        }
        return null;
    }

    private boolean isSafeStand(Location loc) {
        Block feet  = loc.getBlock();
        Block head  = loc.clone().add(0, 1, 0).getBlock();
        Block floor = loc.clone().subtract(0, 1, 0).getBlock();
        return feet.isPassable() && head.isPassable() && floor.getType().isSolid();
    }

    /**
     * Spawns DRAGON_BREATH particles evenly spaced along the dash path.
     */
    private void spawnDashTrail(Location from, Location to) {
        org.bukkit.util.Vector dir = to.toVector().subtract(from.toVector());
        double dist = dir.length();
        if (dist < 0.1) return;
        dir.normalize();

        int steps = (int) Math.ceil(dist / 0.5);
        for (int i = 0; i < steps; i++) {
            Location pt = from.clone().add(dir.clone().multiply(i * 0.5));
            pt.getWorld().spawnParticle(Particle.DRAGON_BREATH, pt, 2, 0.05, 0.05, 0.05, 0.02);
        }
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    @Override
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        teleportCooldowns.remove(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        teleportCooldowns.remove(player.getUniqueId());
    }

    @Override
    public void cleanup() {
        teleportCooldowns.clear();
    }
}
