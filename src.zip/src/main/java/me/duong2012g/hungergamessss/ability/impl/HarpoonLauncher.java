package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class HarpoonLauncher extends BaseAbility {

    public HarpoonLauncher(Main plugin) {
        super(plugin);
    }

    @Override
    public String getName() {
        return "Harpoon Launcher";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 16000); // 16s (Standardized to ms)
    }

    @Override
    protected void performProjectileLaunch(Player player, Projectile projectile, ItemStack item) {
        // Cancel vanilla arrow
        projectile.remove();

        // Harpoon launch
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ARROW_SHOOT, 0.8f, 0.5f);
        player.sendMessage("§8[Harpoon] §7Launching hook...");

        Location start = player.getEyeLocation();
        org.bukkit.util.Vector dir = start.getDirection().normalize();

        int maxSteps = getConfigInt("hook_range_steps", 60);
        double damage = getConfigDouble("hook_damage", 6.0);
        double collisionRadius = getConfigDouble("collision_radius", 1.2);

        new BukkitRunnable() {
            private final Location current = start.clone();
            private int steps = 0;

            @Override
            public void run() {
                for (int i = 0; i < 4; i++) {
                    current.add(dir.clone().multiply(0.5));
                    steps++;

                    if (steps > maxSteps || current.getBlock().getType().isSolid()) {
                        spawnRope(player.getLocation(), current);
                        pull(player, current);
                        cancel();
                        return;
                    }

                    current.getWorld().spawnParticle(Particle.CRIT, current, 1, 0, 0, 0, 0);

                    for (Entity entity : current.getWorld().getNearbyEntities(current, collisionRadius, collisionRadius, collisionRadius)) {
                        if (entity instanceof LivingEntity target && !target.equals(player)) {
                             // Team Check
                             if (target instanceof Player targetPlayer) {
                                  if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                             }
                             
                            spawnRope(player.getLocation(), target.getLocation());
                            pull(player, target.getLocation());
                            target.damage(damage, player);
                            cancel();
                            return;
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void spawnRope(Location from, Location to) {
        double dist = from.distance(to);
        org.bukkit.util.Vector dir = to.toVector().subtract(from.toVector()).normalize();
        for (double d = 0; d < dist; d += 0.5) {
            from.getWorld().spawnParticle(Particle.CLOUD, from.clone().add(dir.clone().multiply(d)), 1, 0, 0, 0, 0);
        }
        from.getWorld().playSound(from, Sound.ENTITY_FISHING_BOBBER_RETRIEVE, 1f, 0.8f);
    }

    private void pull(Player player, Location target) {
        org.bukkit.util.Vector vec = target.toVector().subtract(player.getLocation().toVector());
        double dist = vec.length();
        if (dist > 1) {
            double pullMult = getConfigDouble("pull_multiplier", 0.2);
            double maxPull = getConfigDouble("max_pull_velocity", 2.8);
            vec.normalize().multiply(Math.min(dist * pullMult, maxPull)).setY(0.6);
            player.setVelocity(vec);
        }
    }
}
