package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class HermesBoots extends BaseAbility {

    private static final int EFFECT_DURATION = 40;
    private static final int EFFECT_AMPLIFIER = 1;
    private static final long TASK_PERIOD = 20L;

    // FIX BUG-HB-02: store task reference so cleanup() can cancel it
    private org.bukkit.scheduler.BukkitTask passiveTask;

    public HermesBoots(Main plugin) {
        super(plugin);
        startPassive();
    }

    @Override
    public String getName() {
        return "Hermes Boots";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 6000); // 6s (Standardized to ms)
    }

    // FIX M-02: was HashMap — passive task and sneak event can access concurrently
    private final java.util.Map<java.util.UUID, Long> lastShift = new java.util.concurrent.ConcurrentHashMap<>();

    @Override
    protected void performRightClick(Player player, ItemStack item, org.bukkit.event.player.PlayerInteractEvent event) {
        // Hermes Dash
        double multiplier = getConfigDouble("dash_multiplier", 1.5);
        double yBoost = getConfigDouble("dash_y_boost", 0.4);
        org.bukkit.util.Vector dir = player.getLocation().getDirection().normalize().multiply(multiplier).setY(yBoost);
        player.setVelocity(dir);
        player.getWorld().spawnParticle(org.bukkit.Particle.CLOUD, player.getLocation(), 30, 0.3, 0.1, 0.3, 0.1);
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_HORSE_GALLOP, 1.0f, 1.5f);
        player.sendMessage("§e[Hermes] §7Wings triggered!");
    }

    private void startPassive() {
        // FIX BUG-HB-02: save return value so cleanup() can cancel
        passiveTask = new BukkitRunnable() {
            @Override
            public void run() {
                for (me.duong2012g.hungergamessss.model.Arena arena : plugin.getArenaManager().getArenas().values()) {
                    if (arena.getState() != me.duong2012g.hungergamessss.model.MatchState.PLAYING &&
                        arena.getState() != me.duong2012g.hungergamessss.model.MatchState.DEATHMATCH) continue;

                    for (java.util.UUID uuid : arena.getPlayers()) {
                        Player player = Bukkit.getPlayer(uuid);
                        if (player == null || !validateCanUse(player)) continue;

                        ItemStack boots = player.getInventory().getBoots();
                        if (AbilityManager.isAbilityItem(boots, "hermes_boots")) {
                            int duration = getConfigInt("passive_effect_duration", 40);
                            int speedAmp = getConfigInt("speed_amplifier", 1);
                            int jumpAmp = getConfigInt("jump_amplifier", 1);
                            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, duration, speedAmp, false, false, true));
                            player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, duration, jumpAmp, false, false, true));
                            if (player.isSprinting()) {
                                 player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 1, 0.1, 0, 0.1, 0.02);
                            }
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }
    
    @Override
    protected void performDamaged(Player player, ItemStack item, EntityDamageEvent event) {
        // Bug-HB-01 fix: only cancel fall damage when player is actually wearing the boots
        if (!AbilityManager.isAbilityItem(player.getInventory().getBoots(), "hermes_boots")) return;

        if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            event.setCancelled(true);
            player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 15, 0.3, 0.1, 0.3, 0.1);
            player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_SMALL_FALL, 1f, 1.5f);
        }
    }

    // ── Lifecycle cleanup ────────────────────────────────────────────────────

    /**
     * FIX BUG-HB-02: cancel the passive task and clear per-player state.
     * Called by AbilityRegistry.shutdownAll() on plugin disable/reload.
     */
    @Override
    public void cleanup() {
        if (passiveTask != null && !passiveTask.isCancelled()) {
            passiveTask.cancel();
        }
        lastShift.clear();
    }

    @Override
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        lastShift.remove(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        lastShift.remove(player.getUniqueId());
    }
}
