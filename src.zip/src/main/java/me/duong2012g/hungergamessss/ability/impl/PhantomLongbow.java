package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class PhantomLongbow extends BaseAbility {

    public PhantomLongbow(Main plugin) {
        super(plugin);
    }

    @Override
    public String getName() {
        return "Phantom Longbow";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 13000); // 13s (Standardized to ms)
    }

    @Override
    protected void performProjectileLaunch(Player player, Projectile projectile, ItemStack item) {
        if (!(projectile instanceof Arrow arrow)) return;

        // BUG-PL-01 FIX: Do NOT remove() the arrow before the tracking runnable starts.
        // The old code called arrow.remove() immediately, then scheduled a runnable with
        // delay 1L. When the runnable ran, projectile.isValid() was already false → instant
        // cancel → ability did nothing except grant invisibility.
        // Fix: make the arrow invisible and non-pickable so it flies silently.
        arrow.setPickupStatus(org.bukkit.entity.AbstractArrow.PickupStatus.DISALLOWED);
        arrow.setGravity(false); // Ethereal arrows fly straight
        // Hide the arrow visually by giving it near-zero damage (cosmetic)
        arrow.setDamage(0.0);

        // Ethereal Arrow
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SKELETON_SHOOT, 1.0f, 1.5f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PHANTOM_AMBIENT, 0.8f, 1.2f);
        
        int invisDuration = getConfigInt("invisibility_duration_ticks", 100);
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, invisDuration, 0, false, false));
        player.sendMessage("§7[Phantom] §8You slip into the ethereal plane...");

        double damage = getConfigDouble("arrow_damage", 10.0);
        int darknessDuration = getConfigInt("darkness_duration_ticks", 60);

        new BukkitRunnable() {
            @Override
            public void run() {
                // Now isValid() will be true because arrow is still flying
                if (!arrow.isValid() || arrow.isOnGround() || arrow.isDead()) {
                    arrow.remove();
                    cancel();
                    return;
                }
                arrow.getWorld().spawnParticle(Particle.SOUL, arrow.getLocation(), 2, 0.1, 0.1, 0.1, 0.02);
                
                for (Entity e : arrow.getNearbyEntities(1.2, 1.2, 1.2)) {
                    if (e instanceof LivingEntity target && !target.equals(player)) {
                        // Team Check
                        if (target instanceof Player targetPlayer) {
                            if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                        }
                        
                        target.damage(damage, player);
                        target.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, darknessDuration, 0));
                        target.getWorld().spawnParticle(Particle.SOUL, target.getLocation().add(0, 1, 0), 10);
                        player.playSound(player.getLocation(), Sound.ENTITY_PHANTOM_BITE, 1f, 1f);
                        arrow.remove();
                        cancel();
                        return;
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }
}
