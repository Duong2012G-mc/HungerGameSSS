package me.duong2012g.hungergamessss.ability;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.manager.*;

/**
 * A1-S1: Lightweight dependency-injection context for abilities.
 *
 * <h3>Problem</h3>
 * Every ability previously received only {@code Main plugin} and then called
 * {@code plugin.getTeamManager()}, {@code plugin.getArenaManager()}, etc. —
 * effectively using {@code Main} as a service locator. This made abilities
 * hard to unit-test (required a full {@code Main} mock) and obscured which
 * dependencies each ability actually needed.
 *
 * <h3>Solution</h3>
 * {@code AbilityServices} is a value-class (thin wrapper, no logic) constructed
 * once in {@link AbilityRegistry} and passed to every {@code BaseAbility}
 * constructor. Abilities declare their real dependencies via the typed accessors.
 *
 * <h3>Migration</h3>
 * <pre>{@code
 * // Old — ability constructor
 * public MyAbility(Main plugin) {
 *     super(plugin);
 *     plugin.getTeamManager().isFriendlyFire(a, b);
 * }
 *
 * // New — ability constructor
 * public MyAbility(AbilityServices svc) {
 *     super(svc);
 *     svc.teams().isFriendlyFire(a, b);
 * }
 * }</pre>
 *
 * <p>Abilities that still receive {@code Main} directly continue to work because
 * {@code BaseAbility} retains its {@code protected final Main plugin} field and
 * exposes it via {@link #plugin()}.
 */
public final class AbilityServices {

    private final Main plugin;

    public AbilityServices(Main plugin) {
        this.plugin = java.util.Objects.requireNonNull(plugin, "plugin");
    }

    // ── Core plugin ───────────────────────────────────────────────────────────

    /** The underlying {@code JavaPlugin} instance. Use sparingly — prefer typed accessors. */
    public Main plugin()         { return plugin; }

    // ── Manager accessors (typed, no cast required) ───────────────────────────

    public me.duong2012g.hungergamessss.manager.ArenaManager    arenas()   { return plugin.getArenaManager(); }
    public me.duong2012g.hungergamessss.manager.AbilityManager  abilities(){ return plugin.getAbilityManager(); }
    public me.duong2012g.hungergamessss.manager.CooldownManager cooldowns(){ return plugin.getCooldownManager(); }
    public me.duong2012g.hungergamessss.manager.TeamManager      teams()    { return plugin.getTeamManager(); }
    public me.duong2012g.hungergamessss.manager.ArenaEntityTracker tracker(){ return plugin.getEntityTracker(); }
    public me.duong2012g.hungergamessss.manager.LootTableManager loot()    { return plugin.getLootTableManager(); }
    public me.duong2012g.hungergamessss.manager.HologramManager  holograms(){ return plugin.getHologramManager(); }
    public me.duong2012g.hungergamessss.manager.MessageManager   messages() { return plugin.getMessageManager(); }

    /** Convenience: {@code config().getDouble("abilities.xxx.damage", 10.0)} */
    public org.bukkit.configuration.file.FileConfiguration config() { return plugin.getConfig(); }

    /** Convenience: Bukkit server scheduler. */
    public org.bukkit.scheduler.BukkitScheduler scheduler() { return plugin.getServer().getScheduler(); }

    /** Convenience: Bukkit plugin manager (for firing custom events). */
    public org.bukkit.plugin.PluginManager events() { return plugin.getServer().getPluginManager(); }

    /**
     * Creates a new {@code AbilityServices} that delegates to the same {@code Main}.
     * Useful in unit tests when you want to provide a partial mock.
     */
    public static AbilityServices of(Main plugin) { return new AbilityServices(plugin); }
}
