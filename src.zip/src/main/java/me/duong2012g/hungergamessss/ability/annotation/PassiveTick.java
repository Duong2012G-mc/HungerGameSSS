package me.duong2012g.hungergamessss.ability.annotation;

import java.lang.annotation.*;

/**
 * A1-S2: Marks a method as the passive-tick handler for an ability.
 *
 * <p>When the {@code UnifiedPassiveTicker} fires every 20 ticks, it calls
 * {@code passiveTick(Player, ItemStack)} on every ability held by a player
 * in an active arena. This annotation documents which method provides that
 * behaviour and carries tuning metadata for a future APT pass.
 *
 * <h3>Usage</h3>
 * <pre>{@code
 * public class HermesBoots extends BaseAbility implements Ability.PassiveAbility {
 *
 *     @PassiveTick(intervalTicks = 20)
 *     public void passiveTick(Player player, ItemStack item) {
 *         // apply speed effect …
 *     }
 * }
 * }</pre>
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface PassiveTick {

    /**
     * How often this tick handler should fire, in server ticks.
     * The UnifiedPassiveTicker runs every 20 ticks by default; abilities
     * that want a coarser interval (e.g. every 40 ticks) can declare it here
     * so a future scheduler can subdivide accordingly.
     */
    int intervalTicks() default 20;

    /**
     * If {@code true}, the passive tick runs even when the player is sneaking.
     * Defaults to {@code true} — set to {@code false} for abilities that
     * explicitly pause their passive while sneaking (e.g. aim-mode toggles).
     */
    boolean runWhenSneaking() default true;
}
