package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class GolemHammer extends BaseAbility {

    // FIX M-02: was HashMap — passive task and onDamaged event can race; ConcurrentHashMap is safe
    private final Map<UUID, Boolean> inAir = new ConcurrentHashMap<>();
    private org.bukkit.scheduler.BukkitTask passiveTask;
    private static final String KB_MODIFIER_NAME = "golem_hammer_kb";
    private final org.bukkit.NamespacedKey KB_MODIFIER_KEY;

    public GolemHammer(Main plugin) {
        super(plugin);
        this.KB_MODIFIER_KEY = new org.bukkit.NamespacedKey(plugin, KB_MODIFIER_NAME);
        // FIX: passiveTask now stored as field and cancelled via cleanup() on shutdown
        startPassiveTicker();
    }

    /** FIX BUG-GH-01: renamed disable() → cleanup() to match the Ability.cleanup() contract
     *  so AbilityManager.shutdown() → AbilityRegistry.shutdownAll() can call it automatically. */
    @Override
    public void cleanup() {
        if (passiveTask != null && !passiveTask.isCancelled()) {
            passiveTask.cancel();
            passiveTask = null;
        }
        for (Player p : Bukkit.getOnlinePlayers()) {
            removeKBResist(p);
        }
    }

    /** @deprecated Use {@link #cleanup()} — kept for compatibility only. */
    @Deprecated
    public void disable() {
        cleanup();
    }

    private void startPassiveTicker() {
        passiveTask = new BukkitRunnable() {
            @Override
            public void run() {
                for (me.duong2012g.hungergamessss.model.Arena arena : plugin.getArenaManager().getArenas().values()) {
                    if (arena.getState() != me.duong2012g.hungergamessss.model.MatchState.PLAYING && 
                        arena.getState() != me.duong2012g.hungergamessss.model.MatchState.DEATHMATCH) continue;

                    for (UUID uuid : arena.getPlayers()) {
                        Player p = Bukkit.getPlayer(uuid);
                        if (p == null) continue;

                        if (!validateCanUse(p)) {
                            removeKBResist(p);
                            continue;
                        }
                        
                        ItemStack item = p.getInventory().getItemInMainHand();
                        if (me.duong2012g.hungergamessss.manager.AbilityManager.isAbilityItem(item, getName())) {
                            applyKBResist(p);
                        } else {
                            removeKBResist(p);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    private void applyKBResist(Player p) {
        org.bukkit.attribute.AttributeInstance attr = p.getAttribute(org.bukkit.attribute.Attribute.GENERIC_KNOCKBACK_RESISTANCE);
        if (attr != null) {
            // Check if already has it via NamespacedKey (Bug-GH-01 fix: use non-deprecated AttributeModifier API)
            boolean has = attr.getModifiers().stream().anyMatch(mod -> mod.getKey().equals(KB_MODIFIER_KEY));
            if (!has) {
                attr.addModifier(new org.bukkit.attribute.AttributeModifier(
                    KB_MODIFIER_KEY, 0.5, org.bukkit.attribute.AttributeModifier.Operation.ADD_NUMBER,
                    org.bukkit.inventory.EquipmentSlotGroup.ANY));
            }
        }
    }

    private void removeKBResist(Player p) {
        org.bukkit.attribute.AttributeInstance attr = p.getAttribute(org.bukkit.attribute.Attribute.GENERIC_KNOCKBACK_RESISTANCE);
        if (attr != null) {
            attr.removeModifier(KB_MODIFIER_KEY);
        }
    }

    @Override
    public String getName() {
        return "Golem Hammer";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 40000); // 40s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        double launchHeight = getConfigDouble("launch_height", 5.0);
        Vector velocity = new Vector(0, launchHeight / 2.5, 0);
        player.setVelocity(velocity);
        
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_IRON_GOLEM_ATTACK, 1.5f, 0.8f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1.0f, 0.5f);
        player.getWorld().spawnParticle(Particle.EXPLOSION, player.getLocation(), 5, 0.5, 0.5, 0.5, 0);
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 20, 0.5, 0.2, 0.5, 0.1);
        
        inAir.put(player.getUniqueId(), true);

        new BukkitRunnable() {
            private int ticks = 0;
            @Override
            public void run() {
                if (!player.isOnline() || ticks >= 200) {
                    inAir.remove(player.getUniqueId());
                    cancel();
                    return;
                }
                
                if (inAir.getOrDefault(player.getUniqueId(), false) && player.isOnGround()) {
                    createShockwave(player);
                    Bukkit.getScheduler().runTaskLater(plugin, () -> inAir.remove(player.getUniqueId()), 20L);
                    cancel();
                    return;
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 5L, 2L);
    }

    private void createShockwave(Player player) {
        Location loc = player.getLocation();
        double radius = getConfigDouble("shockwave_radius", 6.0);
        double damage = getConfigDouble("shockwave_damage", 10.0);
        double knockback = getConfigDouble("shockwave_knockback", 2.0);
        int slownessDuration = getConfigInt("slowness_duration", 100);

        player.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.7f);
        player.getWorld().playSound(loc, Sound.ENTITY_IRON_GOLEM_DEATH, 1.5f, 0.8f);
        player.getWorld().playSound(loc, Sound.BLOCK_ANVIL_LAND, 2.0f, 0.5f);

        new BukkitRunnable() {
            private double currentRadius = 0.0;
            @Override
            public void run() {
                if (currentRadius >= radius) {
                    for (LivingEntity entity : loc.getWorld().getNearbyLivingEntities(loc, radius, e -> !e.equals(player))) {
                        if (entity instanceof Player targetPlayer) {
                            if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                        }
                        
                        entity.damage(damage, player);
                        Vector direction = entity.getLocation().toVector().subtract(loc.toVector()).normalize();
                        direction.setY(0.5);
                        direction.multiply(knockback);
                        entity.setVelocity(direction);
                        if (entity instanceof Player) {
                            ((Player) entity).addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, slownessDuration, 1, false, false));
                        }
                    }
                    cancel();
                    return;
                }
                
                int particles = (int) (currentRadius * 15);
                for (int i = 0; i < particles; i++) {
                    double angle = (2 * Math.PI * i) / particles;
                    double x = Math.cos(angle) * currentRadius;
                    double z = Math.sin(angle) * currentRadius;
                    Location particleLoc = loc.clone().add(x, 0.1, z);
                    player.getWorld().spawnParticle(Particle.CLOUD, particleLoc, 2, 0.1, 0.1, 0.1, 0.02);
                }
                currentRadius += 1.5;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    @Override
    protected void performDamaged(Player victim, ItemStack item, EntityDamageEvent event) {
        // Bug-GH-02 fix: renamed from onDamaged → performDamaged so BaseAbility.validateCanUse() runs
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL && inAir.getOrDefault(victim.getUniqueId(), false)) {
            event.setCancelled(true);
        }
    }
}
