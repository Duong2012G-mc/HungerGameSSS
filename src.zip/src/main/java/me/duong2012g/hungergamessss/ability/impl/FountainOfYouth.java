package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Fountain of Youth — Healing support item.
 *
 * PASSIVE: Hold in main hand → auto-regen 1 HP every second (no food dependency).
 *   Applied via passiveTick() every 20 ticks.
 *
 * RIGHT-CLICK: Spawn healing water zone (CD 60s)
 *   Creates an 8×8 water-theme healing area at player's feet for 30 seconds.
 *   All teammates (+ self) inside the zone: +1 HP every second.
 *   Visual: blue DRIPPING_WATER + GLOW + water splash particles.
 *   Sound: AMBIENT_UNDERWATER_ENTER + ENTITY_VILLAGER_YES on spawn.
 */
public class FountainOfYouth extends BaseAbility {

    private static final long   DEFAULT_CD_MS           = 60_000L;
    private static final double DEFAULT_ZONE_RADIUS     = 4.0;   // 8×8 = radius 4
    private static final int    DEFAULT_ZONE_DURATION_S = 30;
    private static final double DEFAULT_PASSIVE_REGEN   = 1.0;   // HP/s while holding
    private static final double DEFAULT_ZONE_REGEN      = 1.0;   // HP/s inside zone

    private final Map<UUID, Long> shootCooldowns = new ConcurrentHashMap<>();

    public FountainOfYouth(Main plugin) {
        super(plugin);
    }

    @Override public String getName()     { return "Fountain of Youth"; }
    @Override public long   getCooldown() { return 0; }

    private long   cdMs()          { return getConfigLong  ("cooldown",       DEFAULT_CD_MS);          }
    private double zoneRadius()    { return getConfigDouble("zone_radius",    DEFAULT_ZONE_RADIUS);    }
    private int    zoneDurationS() { return getConfigInt   ("zone_duration_s",DEFAULT_ZONE_DURATION_S);}
    private double passiveRegen()  { return getConfigDouble("passive_regen",  DEFAULT_PASSIVE_REGEN);  }
    private double zoneRegen()     { return getConfigDouble("zone_regen",     DEFAULT_ZONE_REGEN);     }

    // ── PASSIVE: auto-regen 1 HP/s while holding ─────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;

        double maxHp = player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue();
        if (player.getHealth() < maxHp) {
            player.setHealth(Math.min(player.getHealth() + passiveRegen(), maxHp));
        }

        // CD hint
        Long last = shootCooldowns.get(player.getUniqueId());
        boolean onCd = last != null && System.currentTimeMillis() - last < cdMs();
        String cdStr = onCd
                ? "§cCD: §f" + ((cdMs() - (System.currentTimeMillis() - last)) / 1000L) + "s"
                : "§aReady";
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§b💧 §7Passive: §a+1 HP/s  §8| §7Fountain: " + cdStr));
    }

    // ── RIGHT-CLICK: Healing zone ─────────────────────────────────────────────

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);

        Long last = shootCooldowns.get(player.getUniqueId());
        if (last != null && System.currentTimeMillis() - last < cdMs()) {
            long rem = (cdMs() - (System.currentTimeMillis() - last)) / 1000L;
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§b[Fountain] §7CD: §c" + rem + "s"));
            return;
        }
        shootCooldowns.put(player.getUniqueId(), System.currentTimeMillis());

        final Location center = player.getLocation().clone();
        final World world = center.getWorld();
        final UUID ownerUUID = player.getUniqueId();
        final double r = zoneRadius();
        final int durationTicks = zoneDurationS() * 20;

        // Spawn sound + announcement
        world.playSound(center, Sound.AMBIENT_UNDERWATER_ENTER, 1.0f, 1.2f);
        world.playSound(center, Sound.ENTITY_VILLAGER_YES, 0.8f, 1.0f);
        world.spawnParticle(Particle.SPLASH, center.clone().add(0, 0.5, 0),
                80, r, 0.3, r, 0.2);
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize("§b💧 §7Healing fountain spawned! §8(§f8×8§8, §f30s§8)"));

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= durationTicks) {
                    // Fade-out
                    world.spawnParticle(Particle.GLOW, center.clone().add(0, 0.5, 0),
                            30, r, 0.3, r, 0.05);
                    cancel();
                    return;
                }

                // ── Tick visuals (every 2 ticks) ──────────────────────────────
                double progress = ticks / (double) durationTicks;
                // Rotating ring of water drops
                double ring = r * 0.9;
                int dots = 16;
                for (int i = 0; i < dots; i++) {
                    double angle = (Math.PI * 2 * i / dots) + (ticks * 0.05);
                    double x = Math.cos(angle) * ring;
                    double z = Math.sin(angle) * ring;
                    world.spawnParticle(Particle.DRIPPING_WATER,
                            center.clone().add(x, 0.5, z), 1, 0, 0.3, 0, 0.01);
                }
                // Blue GLOW scattered inside zone
                world.spawnParticle(Particle.GLOW, center.clone().add(0, 0.3, 0),
                        6, r * 0.7, 0.2, r * 0.7, 0.01);

                // ── Heal logic (every 20 ticks = 1s) ──────────────────────────
                if (ticks % 20 == 0) {
                    Player owner = Bukkit.getPlayer(ownerUUID);
                    if (owner == null) { cancel(); return; }

                    Arena arena = plugin.getArenaManager().getArenaByPlayer(owner);
                    if (arena == null) { cancel(); return; }

                    for (UUID uuid : arena.getPlayers()) {
                        Player target = Bukkit.getPlayer(uuid);
                        if (target == null) continue;
                        // Only heal teammates and self
                        if (!target.equals(owner)
                                && !plugin.getTeamManager().isFriendlyFire(owner, target)) continue;
                        if (target.getLocation().distanceSquared(center) > r * r) continue;

                        double maxHp = target.getAttribute(
                                org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue();
                        if (target.getHealth() < maxHp) {
                            target.setHealth(Math.min(target.getHealth() + zoneRegen(), maxHp));
                            // Water splash on healed player
                            target.getWorld().spawnParticle(Particle.SPLASH,
                                    target.getLocation().add(0, 1, 0), 5, 0.2, 0.2, 0.2, 0.05);
                        }
                    }
                    // Brief whoosh sound every 5s
                    if ((ticks / 20) % 5 == 0) {
                        world.playSound(center, Sound.BLOCK_WATER_AMBIENT, 0.5f, 1.2f);
                    }
                }
                ticks += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    @Override
    protected void performQuit(Player player, PlayerQuitEvent event)   { shootCooldowns.remove(player.getUniqueId()); }
    @Override
    protected void performDeath(Player player, PlayerDeathEvent event) { shootCooldowns.remove(player.getUniqueId()); }
    @Override
    public void cleanup() { shootCooldowns.clear(); }
}
