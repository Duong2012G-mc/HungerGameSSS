package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.model.TeamData;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class Mjolnir extends BaseAbility {

    private final Map<UUID, ItemDisplay> activeMjolnirDisplays = new ConcurrentHashMap<>();
    private final Map<UUID, ItemStack> thrownMjolnirs = new ConcurrentHashMap<>();

    public Mjolnir(Main plugin) {
        super(plugin);
    }

    @Override
    public String getName() {
        return "Mjolnir";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 10000); // 10s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);
        throwMjolnir(player, item);
    }

    @Override
    protected void performHit(Player attacker, LivingEntity victim, ItemStack item, EntityDamageByEntityEvent event) {
        if (victim instanceof Player target) {
            if (plugin.getTeamManager().isFriendlyFire(attacker, target)) return;

            new BukkitRunnable() {
                @Override
                public void run() {
                    Location lightningLoc = target.getLocation().add(0, 1, 0);
                    target.getWorld().strikeLightningEffect(lightningLoc);
                    target.getWorld().playSound(target.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.0f);
                    target.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, lightningLoc, 15, 0.3, 0.3, 0.3, 0.05);
                }
            }.runTaskLater(plugin, 1L);
        }
    }

    @Override
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        cleanup(player);
    }

    private void throwMjolnir(Player player, ItemStack item) {
        // Self-Correction: Check if the thrown hammer actually exists before blocking
        if (thrownMjolnirs.containsKey(player.getUniqueId())) {
            ItemDisplay display = activeMjolnirDisplays.get(player.getUniqueId());
            if (display != null && display.isValid() && !display.isDead()) {
                player.sendMessage("§cYou can only throw one Mjolnir at a time!");
                return;
            } else {
                // State desync detected (hammer entity is gone but map entry remains)
                // Clean up and allow throw
                cleanup(player);
            }
        }

        thrownMjolnirs.put(player.getUniqueId(), item.clone());
        
        Location loc = player.getEyeLocation();
        World world = loc.getWorld();
        ItemDisplay mjolnirDisplay = (ItemDisplay) world.spawnEntity(loc, EntityType.ITEM_DISPLAY);
        mjolnirDisplay.setMetadata("hg_mjolnir", new org.bukkit.metadata.FixedMetadataValue(plugin, player.getUniqueId().toString()));
        activeMjolnirDisplays.put(player.getUniqueId(), mjolnirDisplay);
        
        mjolnirDisplay.setItemStack(item.clone());
        
        // Initial orientation
        Transformation transformation = mjolnirDisplay.getTransformation();
        transformation.getLeftRotation().rotationX((float) Math.toRadians(90));
        mjolnirDisplay.setTransformation(transformation);
        mjolnirDisplay.setRotation(loc.getYaw(), loc.getPitch());
        
        player.getInventory().setItemInMainHand(null);
        
        Vector direction = loc.getDirection().normalize();
        world.playSound(loc, Sound.ENTITY_ENDER_DRAGON_SHOOT, 1.0f, 1.0f);
        
        double flightSpeed = getConfigDouble("flight_speed", 1.8);
        double returnSpeed = getConfigDouble("return_speed", 1.6);
        float rotationSpeed = (float) getConfigDouble("rotation_speed", 25.0);
        
        new BukkitRunnable() {
            private Location currentLoc = loc.clone();
            private boolean isReturning = false;
            private int ticks = 0;
            private float rotationAngle = 0;
            private final Vector velocity = direction.clone().multiply(flightSpeed);
            
            @Override
            public void run() {
                if (!player.isOnline() || mjolnirDisplay.isDead() || !mjolnirDisplay.isValid()) {
                    cleanup();
                    this.cancel();
                    return;
                }

                if (!isReturning) {
                    currentLoc.add(velocity);
                    
                    double wobble = Math.sin(ticks * 0.3) * 0.05;
                    Location displayLoc = currentLoc.clone().add(0, wobble, 0);
                    mjolnirDisplay.teleport(displayLoc);
                    
                    // FIX M-05: modulo keeps angle in [0,360) — prevents float precision loss after ~18h runtime
                    rotationAngle = (rotationAngle + rotationSpeed) % 360f;
                    Transformation trans = mjolnirDisplay.getTransformation();
                    Quaternionf rotation = new Quaternionf();
                    rotation.rotateX((float) Math.toRadians(90));
                    rotation.rotateY((float) Math.toRadians(rotationAngle));
                    trans.getLeftRotation().set(rotation);
                    mjolnirDisplay.setTransformation(trans);
                    
                    Block targetBlock = currentLoc.getBlock();
                    if (!targetBlock.isPassable() || ticks >= 80) {
                        impact();
                        return;
                    }
                    
                    for (Entity entity : currentLoc.getWorld().getNearbyEntities(currentLoc, 1, 1, 1)) {
                        if (entity instanceof LivingEntity && entity != player) {
                            impact();
                            return;
                        }
                    }
                } else {
                    Location playerTarget = player.getLocation().add(0, 1, 0);
                    Vector returnVector = playerTarget.subtract(currentLoc).toVector().normalize().multiply(returnSpeed);
                    currentLoc.add(returnVector);
                    mjolnirDisplay.teleport(currentLoc);
                    
                    rotationAngle = (rotationAngle + rotationSpeed * 1.5f) % 360f; // FIX M-05
                    Transformation trans = mjolnirDisplay.getTransformation();
                    Quaternionf rotation = new Quaternionf();
                    rotation.rotateX((float) Math.toRadians(90));
                    rotation.rotateY((float) Math.toRadians(rotationAngle));
                    trans.getLeftRotation().set(rotation);
                    mjolnirDisplay.setTransformation(trans);
                    
                    if (currentLoc.distance(player.getLocation()) < 1.5) {
                        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_SHOOT, 1.0f, 0.5f);
                        returnItem();
                        mjolnirDisplay.remove();
                        this.cancel();
                        return;
                    }
                }
                
                currentLoc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, currentLoc, 5, 0.1, 0.1, 0.1, 0.05);
                if (ticks % 3 == 0) {
                    currentLoc.getWorld().spawnParticle(Particle.CLOUD, currentLoc, 2, 0.2, 0.2, 0.2, 0.01);
                }
                ticks++;
            }

            private void impact() {
                currentLoc.getWorld().strikeLightningEffect(currentLoc);
                double areaDamage = getConfigDouble("impact_damage", 12.0);
                double radius = getConfigDouble("impact_radius", 2.0);
                me.duong2012g.hungergamessss.ability.AbilityUtils.applyAreaDamage(plugin, player, currentLoc, radius, areaDamage, getName());
                isReturning = true;
            }

            private void returnItem() {
                ItemStack saved = thrownMjolnirs.remove(player.getUniqueId());
                activeMjolnirDisplays.remove(player.getUniqueId());
                if (saved != null) {
                    if (player.getInventory().firstEmpty() != -1) {
                        player.getInventory().addItem(saved);
                    } else {
                        player.getWorld().dropItemNaturally(player.getLocation(), saved);
                    }
                }
            }

            private void cleanup() {
                Mjolnir.this.cleanup(player);
                this.cancel();
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void cleanup(Player player) {
        ItemStack saved = thrownMjolnirs.remove(player.getUniqueId());
        ItemDisplay display = activeMjolnirDisplays.remove(player.getUniqueId());
        
        if (saved != null && player.isOnline()) {
             // If inventory is full, drop naturally
            if (player.getInventory().firstEmpty() != -1) {
                player.getInventory().addItem(saved);
            } else {
                player.getWorld().dropItemNaturally(player.getLocation(), saved);
            }
        }
        
        if (display != null && !display.isDead()) {
            display.remove();
        }
    }
}
