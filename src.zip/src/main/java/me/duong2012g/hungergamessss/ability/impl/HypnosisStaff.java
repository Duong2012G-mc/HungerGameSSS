package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class HypnosisStaff extends BaseAbility implements Listener {

    private final Map<UUID, Set<UUID>> controlledMobs = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> mobOwners = new ConcurrentHashMap<>();
    // FIX BUG-HS-01: store task reference so cleanup() can cancel it on shutdown
    private org.bukkit.scheduler.BukkitTask minionTask;

    public HypnosisStaff(Main plugin) {
        super(plugin);
        // FIX: registerEvents moved to AbilityRegistry.register() to prevent double-registration on reload
        startMinionTask();
    }

    /** FIX BUG-HS-01: cancel minionTask and remove all controlled mobs on shutdown. */
    @Override
    public void cleanup() {
        if (minionTask != null && !minionTask.isCancelled()) {
            minionTask.cancel();
        }
        for (UUID owner : new java.util.ArrayList<>(controlledMobs.keySet())) {
            cleanupMobs(owner);
        }
        controlledMobs.clear();
        mobOwners.clear();
    }

    @Override
    public String getName() {
        return "Hypnosis Staff";
    }

    @Override
    public long getCooldown() {
        return 10000; // 10s (Standardized to ms)
    }

    @Override
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        cleanupMobs(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        cleanupMobs(player.getUniqueId());
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        fireHypnosisRay(player);
    }

    @EventHandler
    public void onOwnerAttack(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player owner && event.getEntity() instanceof LivingEntity target) {
            Set<UUID> mobs = controlledMobs.get(owner.getUniqueId());
            if (mobs != null) {
                for (UUID mobId : mobs) {
                    Entity entity = Bukkit.getEntity(mobId);
                    if (entity instanceof Mob mob && !entity.isDead()) {
                        mob.setTarget(target);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onFriendlyFire(EntityDamageByEntityEvent event) {
        UUID victimId = event.getEntity().getUniqueId();
        UUID damagerId = event.getDamager().getUniqueId();

        // 1. Owner hitting Minion
        if (mobOwners.containsKey(victimId)) {
             if (mobOwners.get(victimId).equals(damagerId)) {
                 event.setCancelled(true);
                 return;
             }
        }

        // 2. Minion hitting Owner
        if (mobOwners.containsKey(damagerId)) {
             if (mobOwners.get(damagerId).equals(victimId)) {
                 event.setCancelled(true);
                 return;
             }
        }

        // 3. Minion hitting another Minion of the same owner
        if (mobOwners.containsKey(victimId) && mobOwners.containsKey(damagerId)) {
            if (mobOwners.get(victimId).equals(mobOwners.get(damagerId))) {
                event.setCancelled(true);
            }
        }
    }

    private void fireHypnosisRay(Player player) {
        Location start = player.getEyeLocation();
        Vector direction = start.getDirection();
        player.playSound(player.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 1.0f, 1.5f);

        new BukkitRunnable() {
            double distance = 0;
            final double maxDist = 40.0;

            @Override
            public void run() {
                if (distance >= maxDist) {
                    cancel();
                    return;
                }
                Location current = start.clone().add(direction.clone().multiply(distance));
                current.getWorld().spawnParticle(Particle.DUST, current, 3, 0.1, 0.1, 0.1, 0, new Particle.DustOptions(Color.YELLOW, 1.0f));

                RayTraceResult result = current.getWorld().rayTraceEntities(current, direction, 1.0, entity -> entity instanceof LivingEntity && entity != player);
                if (result != null && result.getHitEntity() instanceof LivingEntity target) {
                    if (!(target instanceof Player)) {
                        hypnotize(player, target);
                    }
                    cancel();
                    return;
                }
                
                if (current.getBlock().getType().isSolid()) {
                    cancel();
                    return;
                }
                distance += 1.0;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void hypnotize(Player player, LivingEntity mob) {
        Set<UUID> playerMobs = controlledMobs.computeIfAbsent(player.getUniqueId(), k -> Collections.newSetFromMap(new ConcurrentHashMap<>()));
        int minionLimit = getConfigInt("minion_limit", 5);
        if (playerMobs.size() >= minionLimit) {
            player.sendMessage("§cYou cannot control more than " + minionLimit + " minions!");
            return;
        }

        if (mobOwners.containsKey(mob.getUniqueId())) return;

        playerMobs.add(mob.getUniqueId());
        mobOwners.put(mob.getUniqueId(), player.getUniqueId());
        
        if (mob.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            mob.setHealth(mob.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue());
        }
        mob.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, Integer.MAX_VALUE, 0, false, false));
        mob.setCustomName("§e" + player.getName() + "'s Minion");
        mob.setCustomNameVisible(true);
        
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.5f);
        mob.getWorld().spawnParticle(Particle.HEART, mob.getLocation().add(0, 1, 0), 10, 0.5, 0.5, 0.5, 0);
    }

    private void startMinionTask() {
        minionTask = new BukkitRunnable() {
            @Override
            public void run() {
                double teleportDist = getConfigDouble("minion_teleport_dist", 30.0);
                double followDist = getConfigDouble("minion_follow_dist", 3.0);
                double moveSpeed = getConfigDouble("minion_move_speed", 1.2);

                for (Map.Entry<UUID, Set<UUID>> entry : controlledMobs.entrySet()) {
                    Player owner = Bukkit.getPlayer(entry.getKey());
                    if (owner == null || !owner.isOnline() || !validateCanUse(owner)) {
                        cleanupMobs(entry.getKey());
                        continue;
                    }

                    for (UUID mobId : new HashSet<>(entry.getValue())) {
                        Entity entity = Bukkit.getEntity(mobId);
                        if (!(entity instanceof LivingEntity mob) || mob.isDead() || !mob.isValid()) {
                            entry.getValue().remove(mobId);
                            mobOwners.remove(mobId);
                            continue;
                        }

                        double dist = mob.getLocation().distance(owner.getLocation());
                        if (dist > teleportDist) {
                            mob.teleport(owner.getLocation());
                            mob.getWorld().spawnParticle(Particle.PORTAL, mob.getLocation(), 20, 0.5, 0.5, 0.5, 0);
                        } else if (dist > followDist && mob instanceof Mob m) {
                            m.getPathfinder().moveTo(owner, moveSpeed);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 10L);
    }

    private void cleanupMobs(UUID ownerId) {
        Set<UUID> mobs = controlledMobs.remove(ownerId);
        if (mobs != null) {
            for (UUID id : mobs) {
                Entity e = Bukkit.getEntity(id);
                if (e != null) {
                    e.remove();
                }
                mobOwners.remove(id);
            }
        }
    }
}
