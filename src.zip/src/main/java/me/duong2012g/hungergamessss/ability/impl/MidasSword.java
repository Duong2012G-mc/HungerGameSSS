package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import me.duong2012g.hungergamessss.manager.AbilityManager;
import java.util.UUID;

public class MidasSword extends BaseAbility implements Listener {

    private final NamespacedKey DAMAGE_KEY;
    private final NamespacedKey MIDAS_MODIFIER_KEY;

    public MidasSword(Main plugin) {
        super(plugin);
        this.DAMAGE_KEY = new NamespacedKey(plugin, "midas_damage");
        this.MIDAS_MODIFIER_KEY = new NamespacedKey(plugin, "midas_attack_damage");
        // FIX: registerEvents moved to AbilityRegistry.register() — prevents double-registration on reload
    }

    @Override
    public String getName() {
        return "Midas Sword";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 0);
    }

    @EventHandler
    public void onKill(EntityDeathEvent event) {
        if (event.getEntity().getKiller() instanceof Player killer) {
            ItemStack item = killer.getInventory().getItemInMainHand();
            if (AbilityManager.isAbilityItem(item, "Midas Sword")) {
                upgradeSword(item);
                playMidasEffect(event.getEntity().getLocation());
            }
        }
    }

    private void upgradeSword(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        int currentDamage = meta.getPersistentDataContainer().getOrDefault(DAMAGE_KEY, PersistentDataType.INTEGER, 0);
        int maxCap = getConfigInt("max_damage_cap", 20);
        if (currentDamage >= maxCap) return; // Cap at config value

        int nextDamage = currentDamage + 1;
        meta.getPersistentDataContainer().set(DAMAGE_KEY, PersistentDataType.INTEGER, nextDamage);

        // Remove old midas modifiers using NamespacedKey
        if (meta.hasAttributeModifiers()) {
            java.util.Collection<AttributeModifier> modifiers = meta.getAttributeModifiers(Attribute.GENERIC_ATTACK_DAMAGE);
            if (modifiers != null) {
                for (AttributeModifier mod : new java.util.ArrayList<>(modifiers)) {
                    if (mod.getKey().equals(MIDAS_MODIFIER_KEY)) {
                        meta.removeAttributeModifier(Attribute.GENERIC_ATTACK_DAMAGE, mod);
                    }
                }
            }
        }

        double baseBonus = getConfigDouble("base_bonus_damage", 7.0);
        // Bug-MS-01 fix: use non-deprecated AttributeModifier(NamespacedKey, double, Operation, EquipmentSlotGroup)
        AttributeModifier modifier = new AttributeModifier(MIDAS_MODIFIER_KEY, baseBonus + nextDamage, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND);
        meta.addAttributeModifier(Attribute.GENERIC_ATTACK_DAMAGE, modifier);

        // Update Lore — Component API prevents italic (FIX L-FONT-01)
        meta.lore(java.util.Arrays.asList(
                me.duong2012g.hungergamessss.util.ColorUtil.component("§6§lMidas Touch"),
                me.duong2012g.hungergamessss.util.ColorUtil.component("§eKills: §f" + nextDamage),
                me.duong2012g.hungergamessss.util.ColorUtil.component("§eBonus Damage: §6+" + nextDamage)));
        
        item.setItemMeta(meta);
    }

    private void playMidasEffect(Location loc) {
        loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
        loc.getWorld().playSound(loc, Sound.BLOCK_METAL_PLACE, 1.0f, 1.5f);
        loc.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc.add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.1);
        loc.getWorld().spawnParticle(Particle.GLOW, loc, 20, 0.3, 0.3, 0.3, 0);
    }
}
