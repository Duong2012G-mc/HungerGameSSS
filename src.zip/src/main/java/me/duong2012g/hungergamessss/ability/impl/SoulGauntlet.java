package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class SoulGauntlet extends BaseAbility {

    // FIX M-02: was HashMap — performHit and performRightClick are called from concurrent event contexts
    private final Map<UUID, Integer> soulCharges = new ConcurrentHashMap<>();

    public SoulGauntlet(Main plugin) {
        super(plugin);
    }

    @Override
    public String getName() {
        return "Soul Gauntlet";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 14000); // 14s (Standardized to ms)
    }

    @Override
    protected void performHit(Player attacker, LivingEntity victim, ItemStack item, EntityDamageByEntityEvent event) {
        // Collect soul on hit
        int charges = soulCharges.getOrDefault(attacker.getUniqueId(), 0);
        if (charges < 5) {
            soulCharges.put(attacker.getUniqueId(), charges + 1);
            attacker.getWorld().playSound(attacker.getLocation(), Sound.PARTICLE_SOUL_ESCAPE, 1.0f, 1.2f);
            attacker.getWorld().spawnParticle(Particle.WAX_OFF, victim.getLocation().add(0, 1, 0), 5, 0.3, 0.3, 0.3, 0.05);
            attacker.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize("§d✦ Souls: " + (charges + 1) + "/5 ✦"));
        }
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        int charges = soulCharges.getOrDefault(player.getUniqueId(), 0);
        
        if (player.isSneaking()) {
            // Ground Slam
            int slamCost = getConfigInt("ground_slam_souls", 5);
            if (charges < slamCost) {
                player.sendMessage("§c[Soul Gauntlet] §7Need full souls for Ground Slam! (" + slamCost + "/" + slamCost + ")");
                return;
            }
            performGroundSlam(player);
            soulCharges.put(player.getUniqueId(), 0);
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize("§d✦ Souls: 0/5 ✦"));
            return;
        }

        int blastCost = getConfigInt("soul_blast_souls", 3);
        if (charges < blastCost) {
            player.sendMessage("§c[Soul Gauntlet] §7Not enough souls for Soul Blast! (" + charges + "/" + blastCost + ")");
            return;
        }

        soulCharges.put(player.getUniqueId(), charges - blastCost);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 1.0f, 1.2f);
        // Soul Blast
        Vector dir = player.getEyeLocation().getDirection().normalize();

        new BukkitRunnable() {
            private int steps = 0;
            private Location current = player.getEyeLocation().clone();

            @Override
            public void run() {
                for (int i = 0; i < 3; i++) {
                    current.add(dir.clone().multiply(0.6));
                    steps++;

                    if (steps > 40 || current.getBlock().getType().isSolid()) {
                        cancel();
                        return;
                    }

                    current.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, current, 5, 0.1, 0.1, 0.1, 0.05);

                    for (Entity e : current.getWorld().getNearbyEntities(current, 1.8, 1.8, 1.8)) {
                        if (e instanceof LivingEntity target && !target.equals(player)) {
                            if (target instanceof Player targetPlayer) {
                                if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                            }
                            
                            double damage = getConfigDouble("soul_blast_damage", 12.0);
                            target.damage(damage, player);
                            target.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1));
                            target.getWorld().spawnParticle(Particle.FLASH, target.getLocation().add(0, 1, 0), 1);
                            cancel();
                            return;
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        // BUG-SG-01 FIX: was hardcoded (charges - 3) — if config changes soul_blast_souls the bar was wrong
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize("§d✦ Souls: " + (charges - blastCost) + "/5 ✦"));
    }

    private void performGroundSlam(Player player) {
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WARDEN_ROAR, 1.2f, 1.5f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, 1.0f, 0.5f);
        
        Location loc = player.getLocation();
        double radius = getConfigDouble("slam_radius", 6.0);
        double damage = getConfigDouble("slam_damage", 10.0);
        double knockback = getConfigDouble("slam_knockback", 1.5);

        for (org.bukkit.entity.Entity e : player.getNearbyEntities(radius, radius, radius)) {
            if (e instanceof LivingEntity target && e != player) {
                if (target instanceof Player targetPlayer) {
                    if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                }

                target.damage(damage, player);
                Vector kbDir = target.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(knockback).setY(0.8);
                target.setVelocity(kbDir);
                target.getWorld().spawnParticle(Particle.SOUL, target.getLocation(), 20, 0.5, 0.5, 0.5, 0.1);
            }
        }
        
        // Visual Crack
        for (int i = 0; i < 360; i += 10) {
            double angle = Math.toRadians(i);
            double x = Math.cos(angle) * 4;
            double z = Math.sin(angle) * 4;
            player.getWorld().spawnParticle(Particle.SCULK_SOUL, loc.clone().add(x, 0.1, z), 5, 0.1, 0.1, 0.1, 0.05);
        }
    }

    @Override
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        soulCharges.remove(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        soulCharges.remove(player.getUniqueId());
    }
}
