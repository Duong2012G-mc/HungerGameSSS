package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;

public class PufferfishCannon extends BaseAbility {

    private static final int COOLDOWN = 5;
    private static final double VELOCITY_MULTIPLIER = 1.5;
    private static final float EXPLOSION_POWER = 2.0f;
    private static final double EXPLOSION_RADIUS = 3.0;
    private static final int POISON_DURATION = 100;
    private static final int POISON_AMPLIFIER = 1;
    private static final int NAUSEA_DURATION = 140;

    public PufferfishCannon(Main plugin) {
        super(plugin);
    }

    @Override
    public String getName() {
        return "Pufferfish Cannon";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 4000); // 4s (Standardized to ms)
    }

    @Override
    protected void performProjectileLaunch(Player player, org.bukkit.entity.Projectile projectile, ItemStack item) {
        // Cancel vanilla projectile
        projectile.remove();

        org.bukkit.entity.PufferFish fish = (org.bukkit.entity.PufferFish) player.getWorld().spawnEntity(player.getEyeLocation(), org.bukkit.entity.EntityType.PUFFERFISH);
        double launchVel = getConfigDouble("launch_velocity", VELOCITY_MULTIPLIER);
        fish.setVelocity(player.getEyeLocation().getDirection().multiply(launchVel));
        
        // Track projectile manually since PufferFish isn't a Projectile
        int maxBounces = getConfigInt("max_bounces", 3);
        double collisionRadius = getConfigDouble("collision_radius", 1.0);

        new org.bukkit.scheduler.BukkitRunnable() {
            private int bounces = 0;
            @Override
            public void run() {
                if (fish.isDead() || !fish.isValid() || bounces > maxBounces) {
                    explodeFish(fish, player);
                    cancel();
                    return;
                }

                if (fish.isOnGround()) {
                    bounces++;
                    fish.setVelocity(fish.getVelocity().multiply(0.8).setY(0.4));
                    fish.getWorld().playSound(fish.getLocation(), Sound.ENTITY_PUFFER_FISH_BLOW_UP, 1f, 1.2f);
                }

                for (org.bukkit.entity.Entity e : fish.getNearbyEntities(collisionRadius, collisionRadius, collisionRadius)) {
                    if (e instanceof org.bukkit.entity.LivingEntity living && e != player) {
                        explodeFish(fish, player);
                        cancel();
                        return;
                    }
                }
            }
        }.runTaskTimer(plugin, 1, 1);
        
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PUFFER_FISH_BLOW_OUT, 1f, 1f);
    }

    private void explodeFish(org.bukkit.entity.PufferFish fish, Player player) {
        Location loc = fish.getLocation();
        loc.getWorld().spawnParticle(Particle.SNEEZE, loc, 50, 1, 1, 1, 0.1);
        loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.5f);
        
        double explosionRadius = getConfigDouble("explosion_radius", 4.0);
        double explosionDamage = getConfigDouble("explosion_damage", 8.0);
        int poisonDuration = getConfigInt("poison_duration_ticks", 100);
        int poisonAmp = getConfigInt("poison_amplifier", 1);
        int nauseaDuration = getConfigInt("nausea_duration_ticks", 140);

        for (org.bukkit.entity.Entity e : fish.getNearbyEntities(explosionRadius, explosionRadius, explosionRadius)) {
            if (e instanceof LivingEntity target && e != player) {
                // Team Check
                if (target instanceof Player targetPlayer) {
                    if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                }
                
                target.damage(explosionDamage, player);
                target.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.POISON, poisonDuration, poisonAmp));
                target.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.NAUSEA, nauseaDuration, 0));
            }
        }
        fish.remove();
    }
}
