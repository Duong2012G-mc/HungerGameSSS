package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class SculkweaversLantern extends BaseAbility {

    public SculkweaversLantern(Main plugin) {
        super(plugin);
    }

    @Override
    public String getName() {
        return "Sculkweavers Lantern";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 28000); // 28s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);
        // Throw sculk lantern bomb
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_FISHING_BOBBER_THROW, 1.0f, 0.5f);

        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection().multiply(1.2);

        // Projectile simulation
        new BukkitRunnable() {
            private Location current = eye.clone();
            private int ticks = 0;
            private Vector velocity = dir.clone();

            @Override
            public void run() {
                velocity.setY(velocity.getY() - 0.05); // Gravity
                current.add(velocity);
                ticks++;

                if (ticks > 60 || current.getBlock().getType().isSolid()) {
                    // Sculk explosion on impact
                    sculptExplosion(current, player);
                    cancel();
                    return;
                }

                current.getWorld().spawnParticle(Particle.SCULK_CHARGE, current, 3, 0.1, 0.1, 0.1, 0.01);

                for (Entity entity : current.getWorld().getNearbyEntities(current, 1.5, 1.5, 1.5)) {
                    if (entity instanceof LivingEntity target && !target.equals(player)) {
                        sculptExplosion(current, player);
                        cancel();
                        return;
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void sculptExplosion(Location loc, Player player) {
        loc.getWorld().playSound(loc, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.8f, 1.5f);
        loc.getWorld().playSound(loc, Sound.BLOCK_SCULK_SHRIEKER_SHRIEK, 1.0f, 0.5f);
        
        double radius = getConfigDouble("explosion_radius", 5.0);
        double damage = getConfigDouble("explosion_damage", 2.0);
        int darknessDuration = getConfigInt("darkness_duration", 60);
        int slownessDuration = getConfigInt("slowness_duration", 40);
        int persistTicks = getConfigInt("persist_ticks", 100);

        new BukkitRunnable() {
            private int t = 0;
            @Override
            public void run() {
                if (t >= persistTicks) {
                    cancel();
                    return;
                }
                
                // Persistence visuals
                loc.getWorld().spawnParticle(Particle.SCULK_CHARGE, loc, 5, 2.0, 1.0, 2.0, 0.02);
                if (t % 20 == 0) {
                    loc.getWorld().playSound(loc, Sound.BLOCK_SCULK_CATALYST_BLOOM, 0.5f, 0.8f);
                    
                    for (Entity entity : loc.getWorld().getNearbyEntities(loc, radius, 3, radius)) {
                        if (entity instanceof LivingEntity target && !target.equals(player)) {
                            if (target instanceof Player targetPlayer) {
                                if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                            }
                            target.damage(damage, player);
                            target.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, darknessDuration, 0));
                            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, slownessDuration, 1));
                        }
                    }
                }
                t++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}
