package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;
import org.bukkit.scheduler.BukkitRunnable;

public class MagmaClub extends BaseAbility {

    public MagmaClub(Main plugin) {
        super(plugin);
    }

    @Override
    public String getName() {
        return "Magma Club";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 15000); // 15s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        Location loc = player.getLocation();
        
        if (player.isSneaking()) {
            // Volcanic Eruption
            player.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.5f);
            player.getWorld().playSound(loc, Sound.BLOCK_LAVA_AMBIENT, 1.5f, 1.0f);
            player.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, loc, 1);
            player.getWorld().spawnParticle(Particle.LAVA, loc, 50, 2.0, 0.5, 2.0, 0.1);
            
            double eruptionRadius = getConfigDouble("eruption_radius", 6.0);
            double eruptionDamage = getConfigDouble("eruption_damage", 12.0);
            int fireTicks = getConfigInt("eruption_fire_ticks", 160);

            for (org.bukkit.entity.Entity e : player.getNearbyEntities(eruptionRadius, 3, eruptionRadius)) {
                if (e instanceof LivingEntity target && e != player) {
                    if (target instanceof Player pTarget) {
                        if (plugin.getTeamManager().isFriendlyFire(player, pTarget)) continue;
                    }
                    target.damage(eruptionDamage, player);
                    target.setFireTicks(fireTicks);
                    target.setVelocity(new Vector(0, 1.2, 0).add(target.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(0.5)));
                }
            }
            player.sendMessage("§c[Magma Club] §7VOLCANIC ERUPTION!");
            return;
        }

        // Lava Pillars
        player.getWorld().playSound(loc, Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 1.0f, 0.8f);
        player.getWorld().spawnParticle(Particle.FLAME, loc, 50, 1.0, 0.5, 1.0, 0.1);

        double pillarRadius = getConfigDouble("pillar_radius", 5.0);
        double pillarDamage = getConfigDouble("pillar_damage", 6.0);
        int pillarFireTicks = getConfigInt("pillar_fire_ticks", 80);

        for (org.bukkit.entity.Entity entity : player.getWorld().getNearbyEntities(loc, pillarRadius, 2.0, pillarRadius)) {
            if (entity instanceof LivingEntity target && entity != player) {
                if (target instanceof Player pTarget) {
                    if (plugin.getTeamManager().isFriendlyFire(player, pTarget)) continue;
                }
                target.damage(pillarDamage, player);
                target.setFireTicks(pillarFireTicks);
            }
        }

        // Visual Magma blocks (Packet based would be better but this is fine for now)
        java.util.Map<Block, Material> originalBlocks = new java.util.HashMap<>();
        for (int i = 1; i <= 5; i++) {
             Block b = loc.clone().add(player.getLocation().getDirection().multiply(i)).getBlock();
             if (b.getType() == Material.AIR || b.getType() == Material.GRASS_BLOCK) {
                 originalBlocks.put(b, b.getType());
                 b.setType(Material.MAGMA_BLOCK);
             }
        }
        
        new BukkitRunnable() {
            @Override
            public void run() {
                originalBlocks.forEach(Block::setType);
            }
        }.runTaskLater(plugin, 60L);
    }
}
