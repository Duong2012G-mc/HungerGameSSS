package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import java.util.UUID;

public class LichStaff extends BaseAbility {

    public LichStaff(Main plugin) {
        super(plugin);
        // FIX BUG-LS-01: removed standalone startPassiveTask() BukkitRunnable.
        // Same root cause as BUG-AB-01 — each reload spawned a new parallel task.
        // Frost Walker passive migrated to passiveTick() — driven by UnifiedPassiveTicker.
    }

    // Replaces the old startPassiveTask() BukkitRunnable (frost walker only)
    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, "lich_staff")) return;
        // Passive: Frost Walker (freeze nearby water blocks)
        org.bukkit.Location feet = player.getLocation();
        int range = getConfigInt("frost_walker_range", 2);
        for (int x = -range; x <= range; x++) {
            for (int z = -range; z <= range; z++) {
                org.bukkit.block.Block block = feet.clone().add(x, -1, z).getBlock();
                if (block.getType() == Material.WATER) {
                    block.setType(Material.FROSTED_ICE);
                    final org.bukkit.block.Block finalBlock = block;
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        if (finalBlock.getType() == Material.FROSTED_ICE) {
                            finalBlock.setType(Material.WATER);
                        }
                    }, 100L);
                }
            }
        }
    }

    @Override
    public String getName() {
        return "Lich Staff";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 800); // 0.8s between shots (prevents spam without limiting ammo)
    }

    // FIX M-02: was HashMap — onCooldownEnd and performRightClick access from concurrent scheduler/event contexts
    private final java.util.Map<UUID, Integer> ammoCount = new java.util.concurrent.ConcurrentHashMap<>();

    private int getAmmo(Player player) {
        int maxAmmo = getConfigInt("max_souls", 4);
        return ammoCount.getOrDefault(player.getUniqueId(), maxAmmo);
    }

    @Override
    public void onCooldownEnd(Player player, ItemStack item) {
        int maxAmmo = getConfigInt("max_souls", 4);
        ammoCount.put(player.getUniqueId(), maxAmmo);
        updateActionBar(player);
        player.sendMessage("§b[Lich] §7Souls recharged!");
        player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.0f);
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);
        int ammo = getAmmo(player);
        
        if (ammo > 0) {
            // Shoot mode
            ammoCount.put(player.getUniqueId(), ammo - 1);
            updateActionBar(player);

            player.getWorld().playSound(player.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.0f, 1.5f);
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SNOW_GOLEM_AMBIENT, 1.0f, 0.5f);
            shootIceball(player);

            // If it was the last bullet, start reload cooldown automatically
            if (ammo - 1 <= 0) {
                long reloadTime = getConfigLong("reload_time", 30000); // 30s reload (aligned with Demo)
                plugin.getCooldownManager().setCooldown(player, getName(), "Lich Staff", reloadTime);
                player.sendMessage("§b[Lich] §cOut of souls! §7Recharging in §f" + (reloadTime / 1000) + "s...");
                player.playSound(player.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.6f, 1.8f);
            }
        }
    }

    private void shootIceball(Player player) {
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection().multiply(1.5);
        new BukkitRunnable() {
            private Location current = eye.clone();
            private int steps = 0;
            @Override
            public void run() {
                for (int i = 0; i < 3; i++) {
                    current.add(dir.clone().multiply(0.3));
                    steps++;
                    if (steps > 50 || current.getBlock().getType().isSolid()) {
                        iceExplosion(current, player);
                        cancel();
                        return;
                    }
                    current.getWorld().spawnParticle(Particle.WHITE_ASH, current, 3, 0.05, 0.05, 0.05, 0);
                    current.getWorld().spawnParticle(Particle.ENCHANTED_HIT, current, 1, 0, 0, 0, 0);
                    for (Entity entity : current.getWorld().getNearbyEntities(current, 1.0, 1.0, 1.0)) {
                        if (entity instanceof LivingEntity target && !target.equals(player)) {
                            iceExplosion(current, player);
                            cancel();
                            return;
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void updateActionBar(Player player) {
        int ammo = getAmmo(player);
        int maxAmmo = getConfigInt("max_souls", 4);
        StringBuilder sb = new StringBuilder("§bSouls: ");
        for (int i = 0; i < maxAmmo; i++) {
            sb.append(i < ammo ? "§b●" : "§7○");
        }
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(sb.toString()));
    }

    private void iceExplosion(Location loc, Player player) {
        loc.getWorld().playSound(loc, Sound.BLOCK_GLASS_BREAK, 1.5f, 0.8f);
        loc.getWorld().spawnParticle(Particle.SNOWFLAKE, loc, 40, 1.5, 1.5, 1.5, 0.1);
        loc.getWorld().spawnParticle(Particle.ITEM_SNOWBALL, loc, 20, 1.0, 1.0, 1.0, 0.1);

        double radius = getConfigDouble("iceball_radius", 3.0);
        double damage = getConfigDouble("iceball_damage", 6.0);
        int freezeTicks = getConfigInt("freeze_ticks", 140);
        
        me.duong2012g.hungergamessss.ability.AbilityUtils.applyAreaDamage(plugin, player, loc, radius, damage, getName());
        
        // Custom effect for Lich
        for (Entity entity : loc.getWorld().getNearbyEntities(loc, radius, radius, radius)) {
            if (entity instanceof LivingEntity target && !target.equals(player)) {
                if (target instanceof Player tp && plugin.getTeamManager().isFriendlyFire(player, tp)) continue;
                target.setFreezeTicks(freezeTicks);
                target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 2, true, true));
            }
        }
    }

    @Override
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        ammoCount.remove(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        ammoCount.remove(player.getUniqueId());
    }

    /**
     * FIX BUG-LS-02: clear ammo state on full shutdown so stale entries from
     * the previous match cannot interfere with a freshly started one.
     */
    @Override
    public void cleanup() {
        ammoCount.clear();
    }
}
