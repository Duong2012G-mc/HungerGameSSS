package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ToxicCrossbow extends BaseAbility {


    public ToxicCrossbow(Main plugin) {
        super(plugin);
    }

    @Override
    public String getName() {
        return "Toxic Crossbow";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 10000); // 10s (Standardized to ms)
    }

    @Override
    protected void performProjectileLaunch(Player player, Projectile projectile, ItemStack item) {
        if (!(projectile instanceof Arrow arrow)) return;
        
        // Cancel vanilla arrow (we launch our own high-velocity one or modify this one)
        // Let's modify the existing one to be high velocity
        
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_CROSSBOW_SHOOT, 1.0f, 0.7f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 1.0f, 0.7f);

        double velocityMul = getConfigDouble("arrow_velocity", 3.0);
        double damage = getConfigDouble("arrow_damage", 8.0);
        Vector direction = player.getEyeLocation().getDirection().multiply(velocityMul);
        arrow.setVelocity(direction);
        arrow.setDamage(damage);
        arrow.setColor(Color.fromRGB(0, 255, 0));
        arrow.setMetadata("toxic_owner", new org.bukkit.metadata.FixedMetadataValue(plugin, player.getUniqueId()));

        // Trail effects
        new BukkitRunnable() {
            @Override
            public void run() {
                if (arrow.isDead() || arrow.isOnGround()) {
                    cancel();
                    return;
                }
                Location loc = arrow.getLocation();
                loc.getWorld().spawnParticle(Particle.DUST, loc, 3, 0.1, 0.1, 0.1, 0.0, new Particle.DustOptions(Color.fromRGB(0, 255, 0), 1.0f));
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    @Override
    protected void performProjectileHit(Projectile projectile, ProjectileHitEvent event) {
        if (!projectile.hasMetadata("toxic_owner")) return;
        
        UUID shooterId = (UUID) projectile.getMetadata("toxic_owner").get(0).value();
        Player shooter = Bukkit.getPlayer(shooterId);
        if (shooter == null) return;

        createToxicCloud(projectile.getLocation(), shooter);
    }

    private void createToxicCloud(Location location, Player shooter) {
        double radius = getConfigDouble("cloud_radius", 4.0);
        int durationTicks = getConfigInt("cloud_duration", 100);
        double damagePerPulse = getConfigDouble("cloud_damage", 0.5);

        location.getWorld().playSound(location, Sound.BLOCK_BREWING_STAND_BREW, 1.5f, 0.8f);
        location.getWorld().playSound(location, Sound.ENTITY_ZOMBIE_VILLAGER_CONVERTED, 1.0f, 1.5f);

        new BukkitRunnable() {
            private int ticksElapsed = 0;

            @Override
            public void run() {
                if (ticksElapsed >= durationTicks) {
                    cancel();
                    return;
                }

                // Cloud Particles
                for (int i = 0; i < 15; i++) {
                    double angle = Math.random() * 2 * Math.PI;
                    double distance = Math.random() * radius;
                    double height = (Math.random() - 0.5) * 2.0;
                    Location pLoc = location.clone().add(Math.cos(angle) * distance, height, Math.sin(angle) * distance);
                    location.getWorld().spawnParticle(Particle.DUST, pLoc, 1, 0, 0, 0, 0, new Particle.DustOptions(Color.fromRGB(0, 255, 0), 1.0f));
                }

                // Damage logic every 10 ticks (pulse)
                if (ticksElapsed % 10 == 0) {
                    for (Entity entity : location.getWorld().getNearbyEntities(location, radius, radius, radius)) {
                        if (entity instanceof LivingEntity target && !entity.equals(shooter)) {
                            if (target instanceof Player targetPlayer) {
                                if (plugin.getTeamManager().isFriendlyFire(shooter, targetPlayer)) continue;
                            }
                            target.damage(damagePerPulse, shooter);
                            target.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 60, 1));
                        }
                    }
                }
                ticksElapsed++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    @Override
    protected void performHit(Player attacker, LivingEntity victim, ItemStack item, EntityDamageByEntityEvent event) {
        // Base ability handles standard hit logic if needed, but primary is projectile
    }
}
