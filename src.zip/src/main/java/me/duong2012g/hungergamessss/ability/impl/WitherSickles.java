package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class WitherSickles extends BaseAbility implements Listener {

    // ──────────────────────────────────────────────────────────────
    //  Dual-wield system (ported from DemoRaHoplite)
    //  Auto-equip offhand sickle when main-hand sickle equipped
    // ──────────────────────────────────────────────────────────────
    private final NamespacedKey offhandKey;
    private final Set<UUID>     dualWieldActive = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Long> throwCooldowns = new ConcurrentHashMap<>();

    // Legacy constants kept for fallback defaults
    private static final double AOE_RADIUS     = 7.0;
    private static final int    WITHER_DURATION = 60;
    private static final int    WITHER_AMPLIFIER = 1;

    public WitherSickles(Main plugin) {
        super(plugin);
        this.offhandKey = new NamespacedKey(plugin, "wither_sickle_offhand");
        // FIX: registerEvents moved to AbilityRegistry.register() — prevents double-registration on reload
    }

    @Override
    public String getName() { return "Wither Sickles"; }

    @Override
    public long getCooldown() { return 0; } // Managed per-ability (throw CD)

    // ── offhand helpers ───────────────────────────────────────────
    private boolean isAdditionalSickle(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer()
                   .has(offhandKey, PersistentDataType.BYTE);
    }

    private ItemStack makeOffhandCopy(ItemStack main) {
        ItemStack copy = main.clone();
        ItemMeta meta = copy.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(offhandKey, PersistentDataType.BYTE, (byte) 1);
            copy.setItemMeta(meta);
        }
        return copy;
    }

    private void equipOffhand(Player player) {
        if (dualWieldActive.contains(player.getUniqueId())) return;
        ItemStack main = player.getInventory().getItemInMainHand();
        if (!AbilityManager.isAbilityItem(main, getName())) return;
        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (offhand != null && offhand.getType() != Material.AIR) return; // Don't overwrite
        player.getInventory().setItemInOffHand(makeOffhandCopy(main));
        dualWieldActive.add(player.getUniqueId());
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize("§8[Wither Sickles] §7Dual-wield §aactivated!"));
        player.playSound(player.getLocation(), Sound.ITEM_ARMOR_EQUIP_GENERIC, 1.0f, 1.2f);
    }

    private void removeOffhand(Player player) {
        if (!dualWieldActive.contains(player.getUniqueId())) return;
        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (isAdditionalSickle(offhand)) {
            player.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
        }
        dualWieldActive.remove(player.getUniqueId());
    }

    // ── item-hold events ──────────────────────────────────────────
    @EventHandler
    public void onItemHeld(PlayerItemHeldEvent event) {
        Player player  = event.getPlayer();
        ItemStack prev = player.getInventory().getItem(event.getPreviousSlot());
        ItemStack next = player.getInventory().getItem(event.getNewSlot());
        boolean prevSickle = AbilityManager.isAbilityItem(prev, getName());
        boolean nextSickle = AbilityManager.isAbilityItem(next, getName());

        if (prevSickle && !nextSickle) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> removeOffhand(player), 1L);
        } else if (!prevSickle && nextSickle) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> equipOffhand(player), 1L);
        }
    }

    // ── prevent moving / dropping the offhand copy ───────────────
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player p)) return;
        ItemStack cursor  = event.getCursor();
        ItemStack current = event.getCurrentItem();
        // BUG-WS-01 FIX: detect when player overwrites the offhand slot with a non-sickle item.
        // Previously dualWieldActive stayed true even though the copy was gone, blocking re-equip.
        if (isAdditionalSickle(current) || isAdditionalSickle(cursor)) {
            event.setCancelled(true);
            return;
        }
        // If the offhand slot is being replaced by something else while dual-wield is active,
        // clear the active flag so equipOffhand can re-run properly next time.
        if (dualWieldActive.contains(p.getUniqueId())) {
            ItemStack offhand = p.getInventory().getItemInOffHand();
            if (offhand != null && offhand.getType() != Material.AIR && !isAdditionalSickle(offhand)) {
                dualWieldActive.remove(p.getUniqueId());
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (isAdditionalSickle(event.getOldCursor())) event.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (isAdditionalSickle(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        if (isAdditionalSickle(event.getOffHandItem()) ||
            isAdditionalSickle(event.getMainHandItem())) {
            event.setCancelled(true);
        }
    }

    // ── throw mechanic ────────────────────────────────────────────
    private boolean isThrowOnCooldown(Player player) {
        Long last = throwCooldowns.get(player.getUniqueId());
        return last != null && System.currentTimeMillis() - last < getConfigLong("throw_cooldown", 7000L);
    }

    private long throwRemaining(Player player) {
        Long last = throwCooldowns.get(player.getUniqueId());
        if (last == null) return 0;
        return Math.max(0, (getConfigLong("throw_cooldown", 7000L) - (System.currentTimeMillis() - last)) / 1000L);
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        if (isAdditionalSickle(item)) return; // Ignore right-click from offhand copy
        if (isThrowOnCooldown(player)) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize("§8[Wither Sickles] §7Throw §cCD: §f" + throwRemaining(player) + "s"));
            return;
        }
        throwCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
        throwSickle(player);
    }

    private void throwSickle(Player player) {
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WITHER_SHOOT, 0.8f, 1.5f);
        double throwDmg  = getConfigDouble("throw_damage",   12.0);
        double throwRadius = 1.2;
        double throwSpeed = getConfigDouble("throw_speed", 1.6);
        int    witherDur = getConfigInt("wither_duration", WITHER_DURATION);
        int    witherAmp = getConfigInt("wither_amplifier", WITHER_AMPLIFIER);
        int    maxTicks  = 60;

        new BukkitRunnable() {
            private Location pos = player.getEyeLocation();
            private final org.bukkit.util.Vector dir = pos.getDirection().normalize().multiply(throwSpeed);
            private int t = 0;
            @Override
            public void run() {
                if (t++ > maxTicks) { cancel(); return; }
                pos.add(dir);

                // Trail particles
                pos.getWorld().spawnParticle(Particle.SOUL, pos, 2, 0.05, 0.05, 0.05, 0.02);
                pos.getWorld().spawnParticle(Particle.WITCH, pos, 1, 0, 0, 0, 0);

                // Hit detection
                for (Entity e : pos.getWorld().getNearbyEntities(pos, throwRadius, throwRadius, throwRadius)) {
                    if (!(e instanceof LivingEntity target) || e.equals(player)) continue;
                    if (target instanceof Player tp && plugin.getTeamManager().isFriendlyFire(player, tp)) continue;

                    target.damage(throwDmg, player);
                    target.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, witherDur * 2, witherAmp));
                    target.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, target.getLocation().add(0, 1, 0), 20, 0.3, 0.3, 0.3, 0.05);
                    target.getWorld().playSound(target.getLocation(), Sound.ENTITY_WITHER_SHOOT, 0.6f, 0.7f);
                    cancel();
                    return;
                }
                // Block collision
                if (pos.getBlock().getType().isSolid()) { cancel(); }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize("§8[Wither Sickles] §7Sickle thrown!"));
    }

    // ── on-hit AOE wither + lifesteal ────────────────────────────
    @Override
    protected void performHit(Player player, LivingEntity victim, ItemStack item, EntityDamageByEntityEvent event) {
        if (isAdditionalSickle(item)) return; // Offhand copy doesn't trigger ability
        double radius      = getConfigDouble("aoe_radius",     AOE_RADIUS);
        double damage      = getConfigDouble("aoe_damage",     4.0);
        int    witherDur   = getConfigInt("wither_duration",   WITHER_DURATION);
        int    witherAmp   = getConfigInt("wither_amplifier",  WITHER_AMPLIFIER);

        int count = 0;
        for (Entity e : player.getNearbyEntities(radius, radius, radius)) {
            if (!(e instanceof LivingEntity living) || e.equals(player) || e.equals(victim)) continue;
            if (living instanceof Player tp && plugin.getTeamManager().isFriendlyFire(player, tp)) continue;
            living.damage(damage, player);
            living.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, witherDur, witherAmp));
            spawnSoulBridge(living.getLocation(), player.getLocation());
            count++;
        }
        if (count > 0) {
            double heal = Math.min(count * 1.0, 6.0);
            player.setHealth(Math.min(player.getHealth() + heal,
                    player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue()));
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WITHER_SHOOT, 0.8f, 1.2f);
            player.sendMessage(ChatColor.DARK_PURPLE + "[Wither Sickles] " + ChatColor.LIGHT_PURPLE + "Soul Siphon: "
                    + ChatColor.GRAY + "Healed " + (heal / 2) + " hearts!");
        }
    }

    // ── passive tick: action bar when holding ─────────────────────
    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (isAdditionalSickle(item)) return;
        if (isThrowOnCooldown(player)) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize("§8[Wither Sickles] §7Throw §cCD: §f" + throwRemaining(player) + "s  §8| §7Dual-wield §aON"));
        } else {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize("§8[Wither Sickles] §aRight-click to throw §8| §7Dual-wield §aON"));
        }
    }

    private void spawnSoulBridge(Location from, Location to) {
        org.bukkit.util.Vector dir = to.toVector().subtract(from.toVector()).normalize();
        double dist = from.distance(to);
        for (double d = 0; d < dist; d += 0.5) {
            from.getWorld().spawnParticle(Particle.SOUL, from.clone().add(dir.clone().multiply(d)), 1, 0, 0, 0, 0.02);
        }
    }

    // ── cleanup ───────────────────────────────────────────────────
    @Override
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        removeOffhand(player);
        throwCooldowns.remove(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        removeOffhand(player);
        throwCooldowns.remove(player.getUniqueId());
    }

    /**
     * FIX BUG-WS-02: remove all offhand copies and clear cooldown state on
     * shutdown so maps don't hold stale UUID references between matches.
     */
    @Override
    public void cleanup() {
        for (java.util.UUID id : new java.util.HashSet<>(dualWieldActive)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) removeOffhand(p);
        }
        dualWieldActive.clear();
        throwCooldowns.clear();
    }
}
