package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Excalibur — King Arthur's legendary sword.
 *
 * PASSIVE · 3-Hit Immunity Charges
 *   Each charge blocks 100% of an incoming damage instance
 *   (melee, arrow, explosion — any EntityDamageEvent).
 *   Visual: golden ENCHANTED_HIT burst + ANVIL_LAND sound on each block.
 *   Max 3 charges. Recharges +1 every 45 seconds automatically.
 *   Charges stored in-memory per player (reset on quit/death → fairness).
 *
 * STATS:
 *   Damage: 8 HP base (ADD_NUMBER +7 on netherite sword base 1)
 *   Unbreakable via item meta, Sharpness-enchantable via anvil.
 */
public class Excalibur extends BaseAbility implements Listener {

    private static final int    DEFAULT_MAX_CHARGES    = 3;
    private static final long   DEFAULT_RECHARGE_MS    = 45_000L; // 45 seconds

    // per-player: current charge count
    private final Map<UUID, AtomicInteger> charges       = new ConcurrentHashMap<>();
    // per-player: last charge was gained timestamp (for recharge ticker)
    private final Map<UUID, Long>          lastChargeMsMap = new ConcurrentHashMap<>();
    // recharge task
    private org.bukkit.scheduler.BukkitTask rechargeTask;

    public Excalibur(Main plugin) {
        super(plugin);
        // registerEvents handled by AbilityRegistry.register()
        startRechargeTask();
    }

    @Override public String getName()     { return "Excalibur"; }
    @Override public long   getCooldown() { return 0; }

    private int  maxCharges()    { return getConfigInt ("max_charges",    DEFAULT_MAX_CHARGES); }
    private long rechargeCdMs()  { return getConfigLong("recharge_ms",    DEFAULT_RECHARGE_MS);}

    // ── Recharge ticker — runs every second ──────────────────────────────────

    private void startRechargeTask() {
        rechargeTask = new BukkitRunnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                for (me.duong2012g.hungergamessss.model.Arena arena :
                        plugin.getArenaManager().getArenas().values()) {
                    if (arena.getState() != me.duong2012g.hungergamessss.model.MatchState.PLAYING
                            && arena.getState() != me.duong2012g.hungergamessss.model.MatchState.DEATHMATCH) continue;

                    for (UUID uuid : arena.getPlayers()) {
                        AtomicInteger ai = charges.get(uuid);
                        if (ai == null) continue;
                        int cur = ai.get();
                        if (cur >= maxCharges()) continue;

                        Long lastGain = lastChargeMsMap.get(uuid);
                        if (lastGain == null || now - lastGain >= rechargeCdMs()) {
                            ai.incrementAndGet();
                            lastChargeMsMap.put(uuid, now);
                            Player p = Bukkit.getPlayer(uuid);
                            if (p != null) {
                                p.playSound(p.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.8f, 1.4f);
                                p.sendActionBar(
                                    net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                                        .legacySection().deserialize(buildChargeBar(uuid)));
                            }
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    // ── PASSIVE: Block incoming damage with a charge ──────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        ItemStack held = player.getInventory().getItemInMainHand();
        if (!AbilityManager.isAbilityItem(held, getName())) return;
        if (!validateCanUse(player)) return;

        AtomicInteger ai = charges.computeIfAbsent(player.getUniqueId(), k -> new AtomicInteger(maxCharges()));
        int cur = ai.get();
        if (cur <= 0) return;

        // Consume one charge — block 100% damage
        if (ai.compareAndSet(cur, cur - 1)) {
            event.setCancelled(true);
            lastChargeMsMap.put(player.getUniqueId(), System.currentTimeMillis());

            // Visual + sound
            Location loc = player.getLocation().add(0, 1, 0);
            player.getWorld().spawnParticle(Particle.ENCHANTED_HIT, loc, 25, 0.4, 0.5, 0.4, 0.15);
            player.getWorld().spawnParticle(Particle.END_ROD, loc, 10, 0.3, 0.4, 0.3, 0.05);
            player.getWorld().playSound(loc, Sound.BLOCK_ANVIL_LAND, 0.9f, 1.8f);
            player.getWorld().playSound(loc, Sound.ITEM_SHIELD_BLOCK, 1.0f, 1.4f);

            // Attacker feedback
            if (event instanceof EntityDamageByEntityEvent edee) {
                Entity damager = edee.getDamager();
                if (damager instanceof Player attacker) {
                    attacker.playSound(attacker.getLocation(), Sound.ENTITY_IRON_GOLEM_HURT, 1.0f, 3.0f);
                    attacker.sendActionBar(
                        net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                            .legacySection().deserialize("§e§lEXCALIBUR §7blocked that hit! §8(" + (cur - 1) + " charges left)"));
                }
            }

            // Owner feedback
            int remaining = cur - 1;
            String chargeStr = remaining == 0 ? "§c0 charges! Recharging in §f45s..." : buildChargeBar(player.getUniqueId());
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize(chargeStr));
        }
    }

    // ── passiveTick: show shield bar ─────────────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;

        UUID id = player.getUniqueId();
        int cur = charges.computeIfAbsent(id, k -> new AtomicInteger(maxCharges())).get();
        int max = maxCharges();

        String bar = buildChargeBar(id);
        Long lastGain = lastChargeMsMap.get(id);
        String rechargeStr = "";
        if (cur < max && lastGain != null) {
            long rem = (rechargeCdMs() - (System.currentTimeMillis() - lastGain)) / 1000L;
            if (rem > 0) rechargeStr = "  §8(+1 in §f" + rem + "s§8)";
        }

        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(bar + rechargeStr));
    }

    private String buildChargeBar(UUID id) {
        int cur = charges.computeIfAbsent(id, k -> new AtomicInteger(maxCharges())).get();
        int max = maxCharges();
        StringBuilder sb = new StringBuilder("§e✦ §7Shield: ");
        for (int i = 0; i < max; i++) {
            sb.append(i < cur ? "§6◈" : "§8◈");
        }
        sb.append(" §8(").append(cur).append("/").append(max).append(")");
        return sb.toString();
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    @Override
    public void cleanup() {
        if (rechargeTask != null && !rechargeTask.isCancelled()) rechargeTask.cancel();
        charges.clear();
        lastChargeMsMap.clear();
    }

    @Override
    protected void performQuit(Player player, PlayerQuitEvent event) {
        charges.remove(player.getUniqueId());
        lastChargeMsMap.remove(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, PlayerDeathEvent event) {
        // Reset charges on death — fair, no free permanent shield
        charges.put(player.getUniqueId(), new AtomicInteger(0));
        lastChargeMsMap.put(player.getUniqueId(), System.currentTimeMillis());
    }
}
