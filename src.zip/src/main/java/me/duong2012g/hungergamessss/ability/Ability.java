package me.duong2012g.hungergamessss.ability;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public interface Ability {
    String getName();
    long getCooldown(); // in milliseconds
    
    /**
     * Called when this ability's cooldown finishes.
     */
    default void onCooldownEnd(org.bukkit.entity.Player player, org.bukkit.inventory.ItemStack item) {}
    
    default void onRightClick(org.bukkit.entity.Player player, org.bukkit.inventory.ItemStack item, org.bukkit.event.player.PlayerInteractEvent event) {}
    default void onLeftClick(org.bukkit.entity.Player player, org.bukkit.inventory.ItemStack item, org.bukkit.event.player.PlayerInteractEvent event) {}
    default void onHit(org.bukkit.entity.Player attacker, org.bukkit.entity.LivingEntity victim, org.bukkit.inventory.ItemStack item, org.bukkit.event.entity.EntityDamageByEntityEvent event) {}
    default void onProjectileLaunch(org.bukkit.entity.Player shooter, org.bukkit.entity.Projectile projectile, org.bukkit.inventory.ItemStack item) {}
    default void onProjectileHit(org.bukkit.entity.Projectile projectile, org.bukkit.event.entity.ProjectileHitEvent event) {}
    default void onDamaged(org.bukkit.entity.Player victim, org.bukkit.inventory.ItemStack item, org.bukkit.event.entity.EntityDamageEvent event) {}
    default void onRiptide(org.bukkit.entity.Player player, org.bukkit.inventory.ItemStack item, org.bukkit.event.player.PlayerRiptideEvent event) {}
    default void onSneak(org.bukkit.entity.Player player, org.bukkit.inventory.ItemStack item, org.bukkit.event.player.PlayerToggleSneakEvent event) {}
    default void onDeath(org.bukkit.entity.Player player, org.bukkit.event.entity.PlayerDeathEvent event) {}
    default void onQuit(org.bukkit.entity.Player player, org.bukkit.event.player.PlayerQuitEvent event) {}
    default void onEntityChangeBlock(org.bukkit.entity.Entity entity, org.bukkit.event.entity.EntityChangeBlockEvent event) {}
    default void onEntityTarget(org.bukkit.entity.Entity entity, org.bukkit.event.entity.EntityTargetEvent event) {}
    default void onEntityDamage(org.bukkit.entity.Entity entity, org.bukkit.event.entity.EntityDamageEvent event) {}
    default void onMove(org.bukkit.entity.Player player, org.bukkit.inventory.ItemStack item, org.bukkit.event.player.PlayerMoveEvent event) {}

    default void execute(AbilityContext ctx) {}

    /**
     * Called by AbilityManager.shutdown() for every registered ability.
     * Override to cancel any standalone BukkitTasks, clear maps, or remove
     * world entities owned by this ability.
     * The default implementation is a no-op.
     */
    default void cleanup() {}
}
