package me.duong2012g.hungergamessss.ability;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Root contract for every HungerGamesSSS legendary ability.
 *
 * <h3>Lifecycle</h3>
 * <ol>
 *   <li>Abilities are instantiated once in {@link AbilityRegistry#registerDefaults()}.</li>
 *   <li>Events are registered via {@code registerEvents()} called from
 *       {@link AbilityRegistry#register(Ability)} — <em>never</em> inside the constructor.</li>
 *   <li>{@link #execute(AbilityContext)} is the single dispatch entry-point called by
 *       {@code BaseAbility}'s {@code EnumMap} dispatcher.</li>
 *   <li>{@link #cleanup()} is called by {@link AbilityRegistry#shutdownAll()} on plugin
 *       disable/reload. It must cancel all owned {@code BukkitTask}s, clear all
 *       per-player maps, and remove any world entities owned by this ability.</li>
 * </ol>
 *
 * <h3>Sub-interfaces (ISP — A1-1)</h3>
 * Implement the narrowest interface that covers your ability's triggers:
 * <ul>
 *   <li>{@link ActiveAbility}  — abilities with a primary right-click or left-click action.</li>
 *   <li>{@link PassiveAbility} — abilities with a continuous per-tick effect.</li>
 *   <li>{@link ProjectileAbility} — abilities that fire custom projectiles.</li>
 *   <li>{@link ListenerAbility}  — abilities that react to entity events (damage, target…).</li>
 * </ul>
 * An ability may implement multiple sub-interfaces (e.g. a bow that is both
 * {@link ActiveAbility} and {@link ProjectileAbility}).
 *
 * <h3>Implementing a new ability</h3>
 * <pre>{@code
 * public class MyAbility extends BaseAbility implements ActiveAbility {
 *     public MyAbility(Main plugin) { super(plugin); }
 *
 *     @Override public String getName() { return "My Ability"; }
 *     @Override public long getCooldown() { return 5_000L; }
 *
 *     @Override
 *     protected void performRightClick(Player p, ItemStack item, PlayerInteractEvent e) {
 *         // your logic here
 *     }
 * }
 * }</pre>
 */
public interface Ability {

    /** Display name as it appears on the item's PDC tag and lore. */
    String getName();

    /** Cooldown in <em>milliseconds</em> between activations. */
    long getCooldown();

    // ── Trigger hooks (all optional via default no-op) ───────────────────────

    /**
     * Called when the cooldown for this ability expires for {@code player}.
     * Override to restore visual state (e.g. action bar message).
     */
    default void onCooldownEnd(Player player, ItemStack item) {}

    /**
     * Called when the player right-clicks while holding this ability item.
     * @param player the caster
     * @param item   the exact item that was clicked (defensive clone from {@link AbilityContext})
     * @param event  the underlying interact event — may be cancelled if needed
     */
    default void onRightClick(Player player, ItemStack item, PlayerInteractEvent event) {}

    /**
     * Called on left-click (attack swing) while holding this ability item.
     * @see #onRightClick
     */
    default void onLeftClick(Player player, ItemStack item, PlayerInteractEvent event) {}

    /**
     * Called when the player lands a melee hit on a living entity with this item.
     * @param attacker the ability wielder
     * @param victim   the entity being hit
     * @param item     held item (defensive clone)
     * @param event    the damage event — modify damage here if needed
     */
    default void onHit(Player attacker, LivingEntity victim, ItemStack item,
                       EntityDamageByEntityEvent event) {}

    /**
     * Called when the player launches a projectile while this item is held.
     * The projectile is tagged with a {@code hg_ability} metadata key before
     * this method is called, so {@link #onProjectileHit} can route back to this ability.
     */
    default void onProjectileLaunch(Player shooter, Projectile projectile, ItemStack item) {}

    /**
     * Called when a projectile previously tagged by this ability hits a block or entity.
     * @param projectile the projectile that was fired
     * @param event      the hit event; call {@code event.getHitEntity()} for entity hits
     */
    default void onProjectileHit(Projectile projectile, ProjectileHitEvent event) {}

    /**
     * Called when the ability-item holder receives damage.
     * Use to implement damage-reduction, immunity, or fall-cancel effects.
     * Note: {@code onDeath} is NOT guarded by {@code validateCanUse()} — cleanup
     * must always run even when the arena is in ENDING state.
     */
    default void onDamaged(Player victim, ItemStack item,
                           org.bukkit.event.entity.EntityDamageEvent event) {}

    /** Called when the player activates Riptide while holding this item. */
    default void onRiptide(Player player, ItemStack item,
                           org.bukkit.event.player.PlayerRiptideEvent event) {}

    /**
     * Called when the player toggles sneak (shift) while holding this item.
     * Useful for dual-mode abilities (e.g. toggle cloud-walk, aim-mode).
     */
    default void onSneak(Player player, ItemStack item,
                         org.bukkit.event.player.PlayerToggleSneakEvent event) {}

    /**
     * Called when the caster dies.
     * <strong>Must</strong> clean up all per-player state for {@code player}.
     * This hook is called even when the arena is in ENDING state.
     */
    default void onDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {}

    /**
     * Called when the caster disconnects mid-game.
     * Implementations should mirror {@link #onDeath} cleanup logic.
     */
    default void onQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {}

    /** Called when an entity changes a block (e.g. Enderman pickup, Ravager stomp). */
    default void onEntityChangeBlock(org.bukkit.entity.Entity entity,
                                     org.bukkit.event.entity.EntityChangeBlockEvent event) {}

    /** Called when an entity selects a new target — used by summoned-entity abilities. */
    default void onEntityTarget(org.bukkit.entity.Entity entity,
                                org.bukkit.event.entity.EntityTargetEvent event) {}

    /** Called when an entity (possibly a summoned one) takes damage. */
    default void onEntityDamage(org.bukkit.entity.Entity entity,
                                org.bukkit.event.entity.EntityDamageEvent event) {}

    /**
     * Called each tick a player moves a full block while holding this item.
     * Only fires when block-position actually changes (filtered in {@code AbilityListener}).
     */
    default void onMove(Player player, ItemStack item,
                        org.bukkit.event.player.PlayerMoveEvent event) {}

    // ── Core dispatch & lifecycle ─────────────────────────────────────────────

    /**
     * Central dispatch entry-point called by {@code BaseAbility}'s {@code EnumMap}
     * dispatcher. Concrete abilities do not normally override this — override the
     * specific {@code onXxx} hooks instead.
     */
    default void execute(AbilityContext ctx) {}

    /**
     * Called by {@link AbilityRegistry#shutdownAll()} when the plugin is disabled
     * or reloaded. Implementations <strong>must</strong>:
     * <ul>
     *   <li>Cancel every owned {@code BukkitTask}.</li>
     *   <li>Clear all per-player state maps.</li>
     *   <li>Remove any world entities (bees, armadillos, display entities…) spawned
     *       by this ability that are still alive.</li>
     * </ul>
     * The default implementation is a no-op; concrete abilities should override it.
     */
    default void cleanup() {}

    // ── Sub-interfaces (ISP — A1-1) ───────────────────────────────────────────

    /**
     * Marker interface for abilities that have a primary <em>active</em> activation
     * (right-click or left-click). Implement this alongside {@link Ability} to
     * communicate intent clearly to readers and future annotation processors.
     *
     * <p>Example: {@code CloudSword}, {@code Mjolnir}, {@code ArmadilloDetonator}.
     */
    interface ActiveAbility extends Ability {}

    /**
     * Marker interface for abilities whose effect is continuous and driven by the
     * {@code UnifiedPassiveTicker} (every 20 ticks).
     *
     * <p>Example: {@code HermesBoots}, {@code ReinforcedElytra}.
     */
    interface PassiveAbility extends Ability {}

    /**
     * Marker interface for abilities that fire or interact with projectiles.
     * Implementing this signals that the ability needs {@link #onProjectileLaunch}
     * and/or {@link #onProjectileHit} hooks to function correctly.
     *
     * <p>Example: {@code ArtemisBow}, {@code CorruptedCrossbow}, {@code GhastlyWhistle}.
     */
    interface ProjectileAbility extends Ability {}

    /**
     * Marker interface for abilities that register a Bukkit {@code Listener} to
     * intercept entity events. These abilities implement both {@code Ability}
     * and {@code org.bukkit.event.Listener}; {@link AbilityRegistry#register}
     * calls {@code registerEvents} automatically.
     *
     * <p>Example: {@code BeehiveBlaster}, {@code CloudSword}, {@code VillagerWand}.
     */
    interface ListenerAbility extends Ability {}
}

