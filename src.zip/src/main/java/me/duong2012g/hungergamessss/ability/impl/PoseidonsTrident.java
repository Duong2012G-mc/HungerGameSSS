package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.entity.Player;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Trident;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerRiptideEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PoseidonsTrident extends BaseAbility {

    public PoseidonsTrident(Main plugin) {
        super(plugin);
        // BUG-PT-01: Removed startPassive() BukkitRunnable — migrated to passiveTick()
        // driven by UnifiedPassiveTicker in AbilityManager (avoids task leak on reload).
    }

    @Override
    public String getName() {
        return "Poseidon's Trident";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 10000);
    }

    // ── Passive: Conduit Power + Dolphins Grace in water/rain ────────────────
    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (player.isInWater() || isInRain(player)) {
            int duration = getConfigInt("effect_duration_ticks", 40);
            player.addPotionEffect(new PotionEffect(PotionEffectType.CONDUIT_POWER, duration, 0, true, false, true));
            player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, duration, 0, true, false, true));
        }
    }

    private boolean isInRain(Player player) {
        return player.getWorld().hasStorm()
                && player.getLocation().getBlock().getY()
                >= player.getWorld().getHighestBlockYAt(player.getLocation());
    }

    // ── Melee hit: bonus lightning damage in water ────────────────────────────
    @Override
    protected void performHit(Player attacker, LivingEntity victim, ItemStack item,
                              org.bukkit.event.entity.EntityDamageByEntityEvent event) {
        applyWaterBonusIfApplicable(attacker, victim, event);
    }

    // ── Thrown trident hits entity/block: also check water bonus ─────────────
    // BUG-PT-02: When the trident is thrown, getDamager() in EntityDamageByEntityEvent
    // is the Trident entity, not the Player — so performHit was never invoked.
    // Fix: override performProjectileHit which IS invoked for thrown tridents that
    // land via ProjectileHitEvent tagged with the ability metadata.
    @Override
    protected void performProjectileHit(org.bukkit.entity.Projectile projectile,
                                        ProjectileHitEvent event) {
        if (!(projectile instanceof Trident trident)) return;
        if (!(projectile.getShooter() instanceof Player shooter)) return;

        if (event.getHitEntity() instanceof LivingEntity target) {
            // Reuse the water-bonus logic; create a synthetic DamageEvent proxy isn't
            // possible easily, so we apply the bonus effects manually here.
            if (shooter.isInWater() || target.isInWater()) {
                if (target instanceof Player tp
                        && plugin.getTeamManager().isFriendlyFire(shooter, tp)) return;

                double bonusDamage = getConfigDouble("water_bonus_damage", 6.0);
                target.damage(bonusDamage, shooter);
                target.getWorld().strikeLightningEffect(target.getLocation());
                shooter.playSound(shooter.getLocation(),
                        org.bukkit.Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.2f);
            }
        }
    }

    private void applyWaterBonusIfApplicable(Player attacker, LivingEntity victim,
                                              org.bukkit.event.entity.EntityDamageByEntityEvent event) {
        if (attacker.isInWater() || victim.isInWater()) {
            if (victim instanceof Player tp
                    && plugin.getTeamManager().isFriendlyFire(attacker, tp)) return;
            victim.getWorld().strikeLightningEffect(victim.getLocation());
            double bonusDamage = getConfigDouble("water_bonus_damage", 6.0);
            event.setDamage(event.getDamage() + bonusDamage);
            attacker.playSound(attacker.getLocation(),
                    org.bukkit.Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.2f);
        }
    }

    // ── Riptide boost ─────────────────────────────────────────────────────────
    @Override
    protected void performRiptide(Player player, ItemStack item, PlayerRiptideEvent event) {
        me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArena(player);
        if (arena == null
                || arena.getState() != me.duong2012g.hungergamessss.model.MatchState.PLAYING) return;

        double multiplier = getConfigDouble("riptide_multiplier", 1.5);
        player.setVelocity(player.getVelocity().multiply(multiplier));
        player.getWorld().spawnParticle(org.bukkit.Particle.GLOW,
                player.getLocation(), 20, 0.5, 0.5, 0.5, 0.1);
    }
}
