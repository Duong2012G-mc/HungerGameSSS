package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Warpick — combat pickaxe with two abilities:
 *
 * ABILITY 1 · Mine Explosion (BlockBreak trigger)
 *   Breaking any block while holding the Warpick triggers a 3×3×3 area-clear
 *   explosion centred on the broken block. Cooldown 5 s. Acts like a focused TNT
 *   blast useful for clearing terrain or creating space in PvP.
 *
 * ABILITY 2 · Critical Hit (Hit trigger)
 *   Landing a vanilla critical hit (player falling + hit) on an enemy player has
 *   a configurable chance to also apply light knockback AND degrade a random piece
 *   of the target's armour by a configurable durability amount. Cooldown 20 s.
 *   Designed to combo with the Sharpness X enchantment to shred armour over time.
 *
 * Base stats applied via warpick.yml: Sharpness X, Efficiency I.
 */
public class Warpick extends BaseAbility implements Listener {

    // Per-player cooldown maps — two abilities, two independent timers
    private final Map<UUID, Long> mineCooldowns   = new ConcurrentHashMap<>();
    private final Map<UUID, Long> critCooldowns    = new ConcurrentHashMap<>();
    private final Random random = new Random();

    // Configurable cooldowns in ms
    private static final long DEFAULT_MINE_CD  = 5_000L;   // 5 s
    private static final long DEFAULT_CRIT_CD  = 20_000L;  // 20 s

    public Warpick(Main plugin) {
        super(plugin);
        // FIX: registerEvents() handled by AbilityRegistry.register() — not called here
    }

    @Override
    public String getName() { return "Warpick"; }

    @Override
    public long getCooldown() { return 0; } // Per-ability CDs replace the global CD

    // ── helpers ──────────────────────────────────────────────────────────────

    private long mineCdMs()   { return getConfigLong("mine_cooldown",  DEFAULT_MINE_CD);  }
    private long critCdMs()   { return getConfigLong("crit_cooldown",  DEFAULT_CRIT_CD);  }

    private boolean isOnCd(Map<UUID, Long> map, long cdMs, Player p) {
        Long t = map.get(p.getUniqueId());
        return t != null && System.currentTimeMillis() - t < cdMs;
    }

    private long remaining(Map<UUID, Long> map, long cdMs, Player p) {
        Long t = map.get(p.getUniqueId());
        if (t == null) return 0;
        return Math.max(0, (cdMs - (System.currentTimeMillis() - t)) / 1000L);
    }

    // ── ABILITY 1: Mine Explosion ─────────────────────────────────────────────

    /**
     * Triggered when the player breaks any block while holding the Warpick.
     * Uses EventPriority.HIGH so it runs after BlockBreakListener's arena-state guard.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (!AbilityManager.isAbilityItem(item, getName())) return;
        if (!validateCanUse(player)) return;

        if (isOnCd(mineCooldowns, mineCdMs(), player)) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize(
                    "§6[Warpick] §7Mine Explosion §cCD: §f" + remaining(mineCooldowns, mineCdMs(), player) + "s"));
            return;
        }

        mineCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
        triggerMineExplosion(player, event.getBlock());
    }

    private void triggerMineExplosion(Player player, Block origin) {
        int radius    = getConfigInt("mine_radius", 1);          // half-size → 3×3×3 when radius=1
        boolean dropBlocks = getConfigBoolean("mine_drop_blocks", false);

        Location center = origin.getLocation();
        World world = center.getWorld();

        // FIX BUG-WP-03: store owner UUID so closure is safe even if player goes offline
        UUID ownerUUID = player.getUniqueId();

        // Delay 1 tick so the original broken block is fully removed first
        new BukkitRunnable() {
            @Override
            public void run() {
                int cleared = 0;
                for (int x = -radius; x <= radius; x++) {
                    for (int y = -radius; y <= radius; y++) {
                        for (int z = -radius; z <= radius; z++) {
                            Block b = world.getBlockAt(
                                    center.getBlockX() + x,
                                    center.getBlockY() + y,
                                    center.getBlockZ() + z);

                            if (b.getType() == Material.AIR
                                    || b.getType() == Material.BEDROCK
                                    || b.getType() == Material.BARRIER) continue;

                            if (dropBlocks) {
                                b.breakNaturally();
                            } else {
                                b.setType(Material.AIR, false);
                            }
                            cleared++;
                        }
                    }
                }

                // Visual + sound
                world.spawnParticle(Particle.EXPLOSION_EMITTER, center.clone().add(0.5, 0.5, 0.5), 3, 0.3, 0.3, 0.3, 0);
                world.spawnParticle(Particle.BLOCK, center.clone().add(0.5, 0.5, 0.5),
                        50, 0.8, 0.8, 0.8, 0.1, Material.STONE.createBlockData());
                world.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.9f);
                world.playSound(center, Sound.BLOCK_STONE_BREAK, 1.5f, 0.6f);

                // Damage players/mobs in blast zone (not teammates)
                double blastDamage = getConfigDouble("mine_blast_damage", 6.0);
                double blastRadius = radius + 0.5;
                Player owner = Bukkit.getPlayer(ownerUUID);

                for (Entity e : world.getNearbyEntities(center.clone().add(0.5, 0.5, 0.5),
                        blastRadius, blastRadius, blastRadius)) {
                    if (!(e instanceof LivingEntity target)) continue;
                    if (owner != null && target.equals(owner)) continue;
                    if (target instanceof Player tp && owner != null
                            && plugin.getTeamManager().isFriendlyFire(owner, tp)) continue;

                    target.damage(blastDamage, owner);
                }

                // Notify player
                Player p = Bukkit.getPlayer(ownerUUID);
                if (p != null) {
                    p.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                        .legacySection().deserialize("§6[Warpick] §lMINE EXPLOSION! §7Cleared §f" + cleared + " §7blocks"));
                }
            }
        }.runTaskLater(plugin, 1L);
    }

    // ── ABILITY 2: Critical Hit ───────────────────────────────────────────────

    /**
     * On hit: if the strike is a vanilla critical hit (player falling) against an
     * enemy Player, apply light knockback and degrade one random armour piece.
     * Gated by a 20 s cooldown — only triggers once per cooldown window.
     */
    @Override
    protected void performHit(Player attacker, LivingEntity victim, ItemStack item,
                              EntityDamageByEntityEvent event) {

        // Only trigger on vanilla critical hits against players
        if (!event.isCritical()) return;
        if (!(victim instanceof Player targetPlayer)) return;
        if (plugin.getTeamManager().isFriendlyFire(attacker, targetPlayer)) return;

        if (isOnCd(critCooldowns, critCdMs(), attacker)) return; // Silent — no spam message
        critCooldowns.put(attacker.getUniqueId(), System.currentTimeMillis());

        // 1. Light knockback
        double kbMultiplier = getConfigDouble("crit_knockback_multiplier", 0.5);
        org.bukkit.util.Vector kb = attacker.getLocation().getDirection()
                .setY(0).normalize().multiply(kbMultiplier).setY(0.3);
        targetPlayer.setVelocity(targetPlayer.getVelocity().add(kb));

        // 2. Armour shred — pick one random worn piece and reduce durability
        degradeRandomArmour(targetPlayer);

        // 3. Feedback
        attacker.playSound(attacker.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.6f, 1.8f);
        attacker.getWorld().spawnParticle(Particle.CRIT,
                targetPlayer.getLocation().add(0, 1, 0), 15, 0.3, 0.5, 0.3, 0.05);
        attacker.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§c[Warpick] §lCRITICAL HIT! §7Armour degraded → §cCD: §f"
                + (critCdMs() / 1000) + "s"));
        targetPlayer.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize("§c§lYour armour was damaged by a Critical Hit!"));
    }

    /**
     * Reduces durability of one random worn armour piece by a configurable amount.
     * Breaks the piece if durability reaches maximum.
     */
    private void degradeRandomArmour(Player target) {
        ItemStack[] armour = target.getInventory().getArmorContents();

        // Build list of indices with a non-null, non-AIR piece
        java.util.List<Integer> wornSlots = new java.util.ArrayList<>();
        for (int i = 0; i < armour.length; i++) {
            if (armour[i] != null && armour[i].getType() != Material.AIR) {
                wornSlots.add(i);
            }
        }
        if (wornSlots.isEmpty()) return;

        int slot = wornSlots.get(random.nextInt(wornSlots.size()));
        ItemStack piece = armour[slot];
        ItemMeta meta = piece.getItemMeta();
        if (!(meta instanceof Damageable damageable)) return;

        short maxDurability = piece.getType().getMaxDurability();
        if (maxDurability <= 0) return;

        int degradeAmount = getConfigInt("crit_armour_degrade", 15); // % of max durability
        int damageToApply = (int) (maxDurability * (degradeAmount / 100.0));
        int newDamage = damageable.getDamage() + Math.max(1, damageToApply);

        if (newDamage >= maxDurability) {
            // Break the piece
            armour[slot] = null;
            target.getInventory().setArmorContents(armour);
            target.getWorld().playSound(target.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
            target.sendMessage("§c[Warpick] §7Your " + formatSlot(slot) + " was destroyed!");
        } else {
            damageable.setDamage(newDamage);
            piece.setItemMeta(meta);
            armour[slot] = piece;
            target.getInventory().setArmorContents(armour);
        }
    }

    private String formatSlot(int slot) {
        return switch (slot) {
            case 0 -> "boots";
            case 1 -> "leggings";
            case 2 -> "chestplate";
            case 3 -> "helmet";
            default -> "armour";
        };
    }

    // ── passiveTick: action bar hint while holding ────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;

        String mineStatus = isOnCd(mineCooldowns, mineCdMs(), player)
                ? "§cCD: §f" + remaining(mineCooldowns, mineCdMs(), player) + "s"
                : "§aReady";
        String critStatus = isOnCd(critCooldowns, critCdMs(), player)
                ? "§cCD: §f" + remaining(critCooldowns, critCdMs(), player) + "s"
                : "§aReady";

        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§6⛏ §7Mine: " + mineStatus + " §8| §7CritHit: " + critStatus));
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    @Override
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        UUID id = player.getUniqueId();
        mineCooldowns.remove(id);
        critCooldowns.remove(id);
    }

    @Override
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        UUID id = player.getUniqueId();
        mineCooldowns.remove(id);
        critCooldowns.remove(id);
    }

    @Override
    public void cleanup() {
        mineCooldowns.clear();
        critCooldowns.clear();
    }
}
