package me.duong2012g.hungergamessss.ability;

public enum TriggerType {
    RIGHT_CLICK,
    LEFT_CLICK,
    HIT,
    PROJECTILE_LAUNCH,
    PROJECTILE_HIT,
    DAMAGED,
    RIPTIDE,
    SNEAK,
    DEATH,
    QUIT,
    ENTITY_CHANGE_BLOCK,
    ENTITY_TARGET,
    ENTITY_DAMAGE,
    MOVE
}
