package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.ShulkerBullet;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class VoidStaff extends BaseAbility implements Listener {

    // ──────────────────────────────────────────────────────────────
    //  Mode system (ported from DemoRaHoplite)
    // ──────────────────────────────────────────────────────────────
    public enum StaffMode {
        PORTAL  ("§dPortal Mode",   "§7Sneak+Click: place portal  §8|  §7Click again to connect"),
        SHULKER ("§5Shulker Mode",  "§7Click: fire tracking shulker bullet");

        private final String label;
        private final String hint;
        StaffMode(String label, String hint) { this.label = label; this.hint = hint; }
        public String getLabel() { return label; }
        public String getHint()  { return hint;  }
    }

    private final Map<UUID, StaffMode> playerModes    = new ConcurrentHashMap<>();
    private final Map<UUID, Long>      portalCDs       = new ConcurrentHashMap<>();
    private final Map<UUID, Long>      shulkerCDs      = new ConcurrentHashMap<>();

    public VoidStaff(Main plugin) {
        super(plugin);
        // FIX: registerEvents moved to AbilityRegistry.register() — prevents double-registration on reload
    }

    @Override
    public String getName() { return "Void Staff"; }

    @Override
    public long getCooldown() { return 0; }  // Per-mode CDs replace single CD

    // ── helpers ──────────────────────────────────────────────────
    private long portalCdMs()   { return getConfigLong("portal_cooldown",  40_000L); }
    private long shulkerCdMs()  { return getConfigLong("shulker_cooldown", 30_000L); }

    private StaffMode mode(Player p) {
        return playerModes.getOrDefault(p.getUniqueId(), StaffMode.PORTAL);
    }

    private boolean onCd(Map<UUID, Long> map, long cdMs, Player p) {
        Long t = map.get(p.getUniqueId());
        return t != null && System.currentTimeMillis() - t < cdMs;
    }

    private long remaining(Map<UUID, Long> map, long cdMs, Player p) {
        Long t = map.get(p.getUniqueId());
        if (t == null) return 0;
        return Math.max(0, (cdMs - (System.currentTimeMillis() - t)) / 1000L);
    }

    // ── left-click → switch mode ──────────────────────────────────
    @Override
    protected void performLeftClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);
        StaffMode next = mode(player) == StaffMode.PORTAL ? StaffMode.SHULKER : StaffMode.PORTAL;
        playerModes.put(player.getUniqueId(), next);
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f,
                         next == StaffMode.PORTAL ? 1.5f : 0.8f);
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(next.getLabel() + " §8| " + next.getHint()));
    }

    // ── right-click → use current mode ───────────────────────────
    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        switch (mode(player)) {
            case PORTAL  -> handlePortalUse(player, event);
            case SHULKER -> handleShulkerUse(player, event);
        }
    }

    private void handlePortalUse(Player player, PlayerInteractEvent event) {
        if (onCd(portalCDs, portalCdMs(), player)) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize("§dPortal Mode §8| §cCooldown: §f" + remaining(portalCDs, portalCdMs(), player) + "s"));
            return;
        }
        me.duong2012g.hungergamessss.manager.PortalManager pm = plugin.getPortalManager();
        if (pm == null) { player.sendMessage("§cPortal system unavailable."); return; }

        event.setCancelled(true);
        boolean connected = pm.createPortal(player, player.getLocation());

        if (connected) {
            // BUG-VS-01 FIX: Only start CD after both portals are placed and connected.
            // Old code set CD after ANY portal placement, blocking the second portal click.
            portalCDs.put(player.getUniqueId(), System.currentTimeMillis());
            player.sendMessage("§d[Void] §7Portal connection established!");
            player.playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_SET_SPAWN, 1.0f, 1.2f);
        } else {
            player.sendMessage("§d[Void] §7First portal placed. Right-click again to connect.");
            player.playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 1.0f, 1.5f);
        }
    }

    private void handleShulkerUse(Player player, PlayerInteractEvent event) {
        if (onCd(shulkerCDs, shulkerCdMs(), player)) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize("§5Shulker Mode §8| §cCooldown: §f" + remaining(shulkerCDs, shulkerCdMs(), player) + "s"));
            return;
        }
        event.setCancelled(true);
        shulkerCDs.put(player.getUniqueId(), System.currentTimeMillis());
        ShulkerBullet bullet = player.launchProjectile(ShulkerBullet.class);
        bullet.setShooter(player);
        bullet.setCustomName("VoidBullet");
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SHULKER_SHOOT, 1.0f, 1.2f);
        player.getWorld().spawnParticle(Particle.PORTAL, player.getLocation().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0.1);
    }

    // ── action bar update (on move + on item-hold) ────────────────
    private void refreshActionBar(Player player) {
        StaffMode m = mode(player);
        String cdPart = switch (m) {
            case PORTAL  -> onCd(portalCDs,  portalCdMs(),  player)
                            ? "§cCD: §f" + remaining(portalCDs,  portalCdMs(),  player) + "s"
                            : "§aReady";
            case SHULKER -> onCd(shulkerCDs, shulkerCdMs(), player)
                            ? "§cCD: §f" + remaining(shulkerCDs, shulkerCdMs(), player) + "s"
                            : "§aReady";
        };
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(m.getLabel() + " §8| " + cdPart + "  §8[§7Left-click to switch§8]"));
    }

    @EventHandler
    public void onItemHeld(PlayerItemHeldEvent event) {
        Player p = event.getPlayer();
        ItemStack next = p.getInventory().getItem(event.getNewSlot());
        if (next != null && AbilityManager.isAbilityItem(next, getName())) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> refreshActionBar(p), 2L);
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (!AbilityManager.isAbilityItem(hand, getName())) return;

        // Throttle action bar to once per second
        Location to = event.getTo();
        if (to != null && event.getFrom().getBlock().equals(to.getBlock())) return;

        refreshActionBar(player);

        me.duong2012g.hungergamessss.manager.PortalManager pm = plugin.getPortalManager();
        if (pm != null && to != null && pm.isPortalBlock(to.getBlock().getLocation())) {
            pm.handlePortalTouch(player, to.getBlock().getLocation());
        }
    }

    // ── projectile hit ────────────────────────────────────────────
    @Override
    protected void performProjectileHit(Projectile projectile, ProjectileHitEvent event) {
        if (!(projectile instanceof ShulkerBullet) || !"VoidBullet".equals(projectile.getCustomName())) return;
        Location loc = projectile.getLocation();
        loc.getWorld().spawnParticle(Particle.EXPLOSION, loc, 1);
        loc.getWorld().playSound(loc, Sound.ENTITY_SHULKER_BULLET_HIT, 1.0f, 1.0f);
        if (event.getHitEntity() instanceof LivingEntity target) {
            if (!(projectile.getShooter() instanceof Player shooter)) return;
            if (target instanceof Player tp && plugin.getTeamManager().isFriendlyFire(shooter, tp)) return;
            double damage = getConfigDouble("projectile_damage", 6.0);
            int levitation = getConfigInt("levitation_duration", 60);
            target.damage(damage, shooter);
            target.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, levitation, 1));
        }
    }

    @Override
    protected void performHit(Player attacker, LivingEntity victim, ItemStack item, EntityDamageByEntityEvent event) {}

    // ── cleanup ───────────────────────────────────────────────────
    @Override
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        UUID id = player.getUniqueId();
        playerModes.remove(id); portalCDs.remove(id); shulkerCDs.remove(id);
    }

    @Override
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        UUID id = player.getUniqueId();
        playerModes.remove(id); portalCDs.remove(id); shulkerCDs.remove(id);
    }

    /** FIX BUG-VS-02: clear all per-player state on full shutdown. */
    @Override
    public void cleanup() {
        playerModes.clear();
        portalCDs.clear();
        shulkerCDs.clear();
    }
}
