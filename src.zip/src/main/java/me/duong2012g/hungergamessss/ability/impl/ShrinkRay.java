package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

public class ShrinkRay extends BaseAbility {

    private final UUID SHRINK_UUID = UUID.fromString("69696969-6969-6969-6969-696969696969");
    private final UUID ENLARGE_UUID = UUID.fromString("70707070-7070-7070-7070-707070707070");
    private final org.bukkit.NamespacedKey SHRINK_KEY;
    private final org.bukkit.NamespacedKey ENLARGE_KEY;

    public ShrinkRay(Main plugin) {
        super(plugin);
        this.SHRINK_KEY = new org.bukkit.NamespacedKey(plugin, "shrink_ray_" + SHRINK_UUID.toString().substring(0, 8));
        this.ENLARGE_KEY = new org.bukkit.NamespacedKey(plugin, "shrink_ray_" + ENLARGE_UUID.toString().substring(0, 8));
    }

    @Override
    public String getName() {
        return "Shrink Ray";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 40000); // 40s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        shootRay(player, false); // Enlarge
    }

    @Override
    protected void performLeftClick(Player player, ItemStack item, PlayerInteractEvent event) {
        shootRay(player, true); // Shrink
    }

    private void shootRay(Player player, boolean shrink) {
        double range = getConfigDouble("ray_range", 20.0);
        double raySpeed = getConfigDouble("ray_speed", 0.8);
        int maxTicks = (int) (range / raySpeed);

        new BukkitRunnable() {
            private int ticks = 0;
            private final org.bukkit.Location loc = player.getEyeLocation();
            private final org.bukkit.util.Vector dir = loc.getDirection().multiply(raySpeed);

            @Override
            public void run() {
                if (ticks >= maxTicks) {
                    cancel();
                    return;
                }
                loc.add(dir);
                player.getWorld().spawnParticle(Particle.DUST, loc, 3, 0.05, 0.05, 0.05, 0.0, new Particle.DustOptions(shrink ? Color.BLUE : Color.RED, 0.8f));
                player.getWorld().spawnParticle(Particle.GLOW, loc, 1, 0, 0, 0, 0);
                
                for (org.bukkit.entity.Entity entity : loc.getWorld().getNearbyEntities(loc, 0.5, 0.5, 0.5)) {
                    if (entity instanceof LivingEntity target && entity != player) {
                        // Team Check
                        if (target instanceof Player targetPlayer) {
                            if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                        }
                        
                        applyScale(target, shrink);
                        cancel();
                        return;
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1.0f, shrink ? 1.5f : 0.5f);
    }

    private void applyScale(LivingEntity target, boolean shrink) {
        AttributeInstance scaleAttr = target.getAttribute(Attribute.GENERIC_SCALE);
        if (scaleAttr == null) return;

        // Clear existing modifiers
        scaleAttr.removeModifier(SHRINK_KEY);
        scaleAttr.removeModifier(ENLARGE_KEY);

        double amount = shrink ? -getConfigDouble("shrink_amount", 0.5) : getConfigDouble("enlarge_amount", 0.5);
        org.bukkit.NamespacedKey key = shrink ? SHRINK_KEY : ENLARGE_KEY;
        
        AttributeModifier modifier = new AttributeModifier(key, amount, AttributeModifier.Operation.ADD_NUMBER);
        scaleAttr.addModifier(modifier);

        target.getWorld().spawnParticle(Particle.EXPLOSION, target.getLocation(), 1);
        target.getWorld().playSound(target.getLocation(), Sound.ENTITY_ZOMBIE_VILLAGER_CONVERTED, 1.0f, shrink ? 1.8f : 0.6f);

        long duration = getConfigLong("effect_duration_ticks", 240L);
        new BukkitRunnable() {
            @Override
            public void run() {
                if (target.isValid()) {
                    scaleAttr.removeModifier(modifier.getKey());
                    target.getWorld().spawnParticle(Particle.CLOUD, target.getLocation(), 10);
                }
            }
        }.runTaskLater(plugin, duration);
    }
}
