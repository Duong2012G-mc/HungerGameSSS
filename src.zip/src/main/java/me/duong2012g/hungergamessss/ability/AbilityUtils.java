package me.duong2012g.hungergamessss.ability;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.TeamData;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Vector;

import java.util.Collection;
import java.util.Random;

public class AbilityUtils {

    private static final Random RANDOM = new Random();

    /**
     * Applies damage to all living entities within a radius, respecting team boundaries.
     *
     * @param plugin   The plugin instance
     * @param attacker The player who triggered the ability
     * @param center   The location of the effect
     * @param radius   The radius to check
     * @param damage   The amount of damage to apply
     * @param source   The name of the ability for cooldown/logging
     */
    public static void applyAreaDamage(Main plugin, Player attacker, Location center, double radius, double damage, String source) {
        if (center.getWorld() == null) return;

        TeamData attackerTeam = plugin.getTeamManager().getTeamOf(attacker);
        // A1-14: Use radiusSq for cheaper distance checks; note getNearbyEntities uses an
        // AABB bounding box so some returned entities may be outside the true sphere —
        // the distanceSquared guard below filters to the exact sphere.
        double radiusSq = radius * radius;

        for (org.bukkit.entity.Entity entity : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(entity instanceof LivingEntity target) || entity.equals(attacker)) continue;
            // A1-14: cheaper sphere check BEFORE team/damage logic
            if (target.getLocation().distanceSquared(center) > radiusSq) continue;

            if (target instanceof Player targetPlayer) {
                TeamData targetTeam = plugin.getTeamManager().getTeamOf(targetPlayer);
                if (attackerTeam != null && targetTeam != null && attackerTeam.equals(targetTeam)) continue;
            }
            target.damage(damage, attacker);
        }
    }

    /**
     * Spawns a line of particles between two locations.
     */
    public static void spawnParticleLine(Location start, Location end, Particle particle, int count, double offset) {
        if (start.getWorld() == null || end.getWorld() == null) return;
        
        Vector direction = end.toVector().subtract(start.toVector());
        double distance = direction.length();
        direction.normalize();

        for (double d = 0; d <= distance; d += offset) {
            Location pLoc = start.clone().add(direction.clone().multiply(d));
            start.getWorld().spawnParticle(particle, pLoc, count, 0, 0, 0, 0);
        }
    }

    /**
     * Knocks back an entity from a specific location.
     */
    public static void applyKnockback(Entity target, Location source, double multiplier, double upward) {
        Vector velocity = target.getLocation().toVector().subtract(source.toVector());
        if (velocity.lengthSquared() < 0.0001) return;
        
        velocity.normalize().multiply(multiplier);
        velocity.setY(upward);
        target.setVelocity(velocity);
    }

    /**
     * Finds a safe 2-block-tall landing location near the given origin.
     * Searches ±{@code searchRange} blocks vertically for a solid floor with
     * two air blocks above it. Returns {@code null} if none is found.
     *
     * @param origin      starting location to search from
     * @param searchRange vertical blocks to scan above and below
     */
    public static Location findSafeLanding(Location origin, int searchRange) {
        if (origin.getWorld() == null) return null;
        for (int dy = 0; dy <= searchRange; dy++) {
            for (int sign : new int[]{1, -1}) {
                Location candidate = origin.clone().add(0, dy * sign, 0);
                if (!candidate.getBlock().getType().isSolid()) continue;
                Location feet  = candidate.clone().add(0, 1, 0);
                Location head  = candidate.clone().add(0, 2, 0);
                if (!feet.getBlock().getType().isSolid() && !head.getBlock().getType().isSolid()) {
                    return feet;
                }
            }
        }
        return null;
    }

    /**
     * Degrades a random worn armour piece by {@code percentDurability}% of its max durability.
     * Safely ignores unbreakable items and slots that are empty.
     *
     * @param player           the target player
     * @param percentDurability fraction of max durability to remove (0.0 – 1.0)
     */
    public static void degradeRandomArmorPiece(Player player, double percentDurability) {
        ItemStack[] armor = player.getInventory().getArmorContents();
        // collect non-null, non-unbreakable pieces
        java.util.List<Integer> slots = new java.util.ArrayList<>();
        for (int i = 0; i < armor.length; i++) {
            ItemStack piece = armor[i];
            if (piece == null || piece.getType().getMaxDurability() <= 0) continue;
            ItemMeta meta = piece.getItemMeta();
            if (meta != null && meta.isUnbreakable()) continue;
            slots.add(i);
        }
        if (slots.isEmpty()) return;

        int idx = slots.get(RANDOM.nextInt(slots.size()));
        ItemStack piece = armor[idx];
        if (piece == null) return;
        ItemMeta meta = piece.getItemMeta();
        if (!(meta instanceof Damageable dmg)) return;

        int maxDur = piece.getType().getMaxDurability();
        int degradeAmount = (int) Math.max(1, maxDur * percentDurability);
        dmg.setDamage(Math.min(maxDur - 1, dmg.getDamage() + degradeAmount));
        piece.setItemMeta(dmg);
        armor[idx] = piece;
        player.getInventory().setArmorContents(armor);
    }

    // ── A1-27: Generic projectile tick helper ─────────────────────────────────

    /**
     * Describes one tick of a custom (non-entity) projectile simulation.
     * Used by {@link #tickProjectile}.
     */
    @FunctionalInterface
    public interface ProjectileTickHandler {
        /**
         * @param loc     current position of the projectile this tick
         * @param vel     current velocity (mutable — the handler may modify it)
         * @param tickNum tick counter starting at 0
         * @return {@code true} to continue flight, {@code false} to stop
         */
        boolean onTick(org.bukkit.Location loc, org.bukkit.util.Vector vel, int tickNum);
    }

    /**
     * A1-27: Starts a per-tick projectile simulation task, avoiding copy-paste of
     * gravity/drag/tick-limit boilerplate across CorruptedCrossbow, ArtemisBow, etc.
     *
     * <p>The task cancels itself when:
     * <ul>
     *   <li>{@code maxTicks} is exceeded</li>
     *   <li>the projectile's block is solid (collision)</li>
     *   <li>{@code handler.onTick()} returns {@code false}</li>
     * </ul>
     *
     * @param plugin    plugin for task scheduling
     * @param start     initial spawn location (cloned internally)
     * @param velocity  initial velocity vector (cloned internally)
     * @param maxTicks  maximum flight ticks before auto-cancel
     * @param gravity   downward acceleration per tick (use 0.05 for Minecraft arrow physics)
     * @param drag      horizontal drag factor per tick (use 0.01 for Minecraft arrow physics)
     * @param handler   callback invoked each tick; return false to cancel early
     * @return the {@code BukkitTask} for manual cancellation if needed
     */
    public static org.bukkit.scheduler.BukkitTask tickProjectile(
            org.bukkit.plugin.Plugin plugin,
            org.bukkit.Location start,
            org.bukkit.util.Vector velocity,
            int maxTicks,
            double gravity,
            double drag,
            ProjectileTickHandler handler) {

        final org.bukkit.Location pos = start.clone();
        final org.bukkit.util.Vector vel = velocity.clone();

        return new org.bukkit.scheduler.BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (tick++ >= maxTicks) { cancel(); return; }

                pos.add(vel);
                vel.setX(vel.getX() * (1.0 - drag));
                vel.setY(vel.getY() - gravity);
                vel.setZ(vel.getZ() * (1.0 - drag));

                // Block collision check
                if (pos.getBlock().getType().isSolid()) { cancel(); return; }

                if (!handler.onTick(pos.clone(), vel.clone(), tick)) cancel();
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    /**
     * A1-27: Removes an entity from the world after {@code delayTicks} if it is still
     * valid and alive. Useful for summoned entities (ghasts, bees) that should auto-expire
     * rather than persisting until a player manually re-enters the arena.
     *
     * @param plugin     scheduling plugin
     * @param entity     entity to remove
     * @param delayTicks ticks before removal
     */
    public static void removeAfter(org.bukkit.plugin.Plugin plugin,
                                   org.bukkit.entity.Entity entity,
                                   long delayTicks) {
        if (entity == null) return;
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (entity.isValid()) entity.remove();
        }, delayTicks);
    }

    public static boolean areTeammates(Main plugin, org.bukkit.entity.Player attacker, org.bukkit.entity.Player target) {
        if (attacker == null || target == null) return false;
        TeamData at = plugin.getTeamManager().getTeamOf(attacker);
        TeamData tt = plugin.getTeamManager().getTeamOf(target);
        return at != null && tt != null && at.equals(tt);
    }
}
