package me.duong2012g.hungergamessss.ability;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.TeamData;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.Collection;

public class AbilityUtils {

    /**
     * Applies damage to all living entities within a radius, respecting team boundaries.
     *
     * @param plugin   The plugin instance
     * @param attacker The player who triggered the ability
     * @param center   The location of the effect
     * @param radius   The radius to check
     * @param damage   The amount of damage to apply
     * @param source   The name of the ability for cooldown/logging
     */
    public static void applyAreaDamage(Main plugin, Player attacker, Location center, double radius, double damage, String source) {
        if (center.getWorld() == null) return;

        TeamData attackerTeam = plugin.getTeamManager().getTeamOf(attacker);

        Collection<Entity> targets = center.getWorld().getNearbyEntities(center, radius, radius, radius);
        double radiusSq = radius * radius;
        for (Entity entity : targets) {
            if (!(entity instanceof LivingEntity target) || entity.equals(attacker)) continue;

            if (target.getLocation().distanceSquared(center) > radiusSq) continue;

            if (target instanceof Player targetPlayer) {
                TeamData targetTeam = plugin.getTeamManager().getTeamOf(targetPlayer);
                if (attackerTeam != null && targetTeam != null && attackerTeam.equals(targetTeam)) {
                    continue;
                }
            }

            target.damage(damage, attacker);
        }
    }

    /**
     * Spawns a line of particles between two locations.
     */
    public static void spawnParticleLine(Location start, Location end, Particle particle, int count, double offset) {
        if (start.getWorld() == null || end.getWorld() == null) return;
        
        Vector direction = end.toVector().subtract(start.toVector());
        double distance = direction.length();
        direction.normalize();

        for (double d = 0; d <= distance; d += offset) {
            Location pLoc = start.clone().add(direction.clone().multiply(d));
            start.getWorld().spawnParticle(particle, pLoc, count, 0, 0, 0, 0);
        }
    }

    /**
     * Knocks back an entity from a specific location.
     */
    public static void applyKnockback(Entity target, Location source, double multiplier, double upward) {
        Vector velocity = target.getLocation().toVector().subtract(source.toVector());
        if (velocity.lengthSquared() < 0.0001) return;
        
        velocity.normalize().multiply(multiplier);
        velocity.setY(upward);
        target.setVelocity(velocity);
    }
}
