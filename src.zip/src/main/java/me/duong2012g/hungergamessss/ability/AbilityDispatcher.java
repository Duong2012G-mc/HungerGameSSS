package me.duong2012g.hungergamessss.ability;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class AbilityDispatcher {
    // FIX L-06: was a static field initialised at class-load time via Main.getInstance().
    // If the class was loaded before Main.onEnable() completed, getInstance() returned null
    // and the field was null, causing NPE on every ability dispatch.
    // Now lazily initialised on first use, guaranteed to run after onEnable().
    private static NamespacedKey legendKey;

    private static NamespacedKey getLegendKey() {
        if (legendKey == null) {
            legendKey = new NamespacedKey(Main.getInstance(), "hg_ability");
        }
        return legendKey;
    }

    public static void handle(TriggerType trigger, AbilityContext ctx) {
        Main plugin = Main.getInstance();
        if (plugin == null) return;

        String id = ctx.getAbilityId();
        if (id == null) {
            ItemStack item = ctx.getItem();
            if (item == null || !item.hasItemMeta()) return;
            id = getItemId(item);
        }

        if (id == null) return;

        Ability ability = plugin.getAbilityManager().getRegistry().getAbility(id);
        if (ability == null) return;

        ability.execute(ctx);
    }

    public static String getItemId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        NamespacedKey key = getLegendKey();
        if (key != null && meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)) {
            return meta.getPersistentDataContainer().get(key, PersistentDataType.STRING).replace("_", " ");
        }
        Main plugin = Main.getInstance();
        if (plugin == null) return null;
        return plugin.getAbilityManager().getAbilityName(item);
    }
}
