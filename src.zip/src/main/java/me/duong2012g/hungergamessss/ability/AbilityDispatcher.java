package me.duong2012g.hungergamessss.ability;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class AbilityDispatcher {

    public static void handle(TriggerType trigger, AbilityContext ctx) {
        Main plugin = Main.getInstance();
        if (plugin == null) return;

        String id = ctx.getAbilityId();
        if (id == null) {
            ItemStack item = ctx.getItem();
            if (item == null || !item.hasItemMeta()) return;
            id = getItemId(item);
        }

        if (id == null) return;

        Ability ability = plugin.getAbilityManager().getRegistry().getAbility(id);
        if (ability == null) {
            // OPT-DISP-01: log dispatch miss when debug=true so ability authors can
            // catch typos in PDC tags or unregistered abilities quickly
            if (plugin.getConfig().getBoolean("debug", false)) {
                plugin.getLogger().warning("[AbilityDispatcher] No ability found for id='"
                        + id + "' trigger=" + trigger
                        + " player=" + (ctx.getCaster() != null ? ctx.getCaster() : "none"));
            }
            return;
        }

        ability.execute(ctx);
    }

    public static String getItemId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        Main plugin = Main.getInstance();
        if (plugin == null) return null;

        // OPT-DISP-02: delegate entirely to AbilityManager which holds the cached
        // NamespacedKey. AbilityDispatcher no longer needs its own lazy-init key copy.
        return plugin.getAbilityManager().getAbilityName(item);
    }
}
