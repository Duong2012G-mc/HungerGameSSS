package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class ReinforcedElytra extends BaseAbility {

    private static final int GROUND_CHECK_DISTANCE = 2;
    // FIX M-02: was HashMap — passive task (2-tick) and sneak event access concurrently
    private final java.util.Map<java.util.UUID, Long> explosionCooldowns = new java.util.concurrent.ConcurrentHashMap<>();

    public ReinforcedElytra(Main plugin) {
        super(plugin);
        startPassiveTask();
    }

    @Override
    public String getName() {
        return "Reinforced Elytra";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 20000); // 20s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        // Boost handled in Sneak event
    }

    @Override
    protected void performSneak(Player player, ItemStack item, PlayerToggleSneakEvent event) {
        if (!event.isSneaking() || !player.isGliding()) return;
        
        ItemStack chest = player.getInventory().getChestplate();
        if (chest == null || !AbilityManager.isAbilityItem(chest, "reinforced_elytra")) return;

        if (checkCooldown(player)) return;

        // Sonic Boom Takeoff
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.5f, 0.8f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.5f);
        player.getWorld().spawnParticle(Particle.EXPLOSION, player.getLocation(), 1);
        player.getWorld().spawnParticle(Particle.FLASH, player.getLocation(), 5);

        double takeoffKnockback = getConfigDouble("takeoff_knockback", 1.5);
        double takeoffY = getConfigDouble("takeoff_y", 0.4);
        double takeoffVelocity = getConfigDouble("takeoff_velocity", 2.8);

        for (Entity e : player.getNearbyEntities(5, 3, 5)) {
            if (e instanceof LivingEntity target && e != player) {
                if (target instanceof Player targetPlayer) {
                    if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                }
                target.setVelocity(target.getLocation().toVector().subtract(player.getLocation().toVector()).normalize().multiply(takeoffKnockback).setY(takeoffY));
            }
        }

        Vector direction = player.getLocation().getDirection();
        player.setVelocity(direction.multiply(takeoffVelocity));
    }

    private void startPassiveTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (me.duong2012g.hungergamessss.model.Arena arena : plugin.getArenaManager().getArenas().values()) {
                    if (arena.getState() != me.duong2012g.hungergamessss.model.MatchState.PLAYING &&
                        arena.getState() != me.duong2012g.hungergamessss.model.MatchState.DEATHMATCH) continue;

                    for (java.util.UUID uuid : arena.getPlayers()) {
                        Player player = Bukkit.getPlayer(uuid);
                        if (player == null || !player.isGliding() || !validateCanUse(player)) continue;
                        
                        ItemStack chest = player.getInventory().getChestplate();
                        if (!AbilityManager.isAbilityItem(chest, "reinforced_elytra")) continue;

                        player.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, player.getLocation(), 2, 0.1, 0.1, 0.1, 0.02);
                        player.getWorld().spawnParticle(Particle.END_ROD, player.getLocation(), 1, 0.1, 0.1, 0.1, 0.02);

                        double checkDist = getConfigDouble("ground_check_distance", 2.0);
                        Block targetBlock = player.getTargetBlockExact((int) checkDist);
                        if (targetBlock != null && targetBlock.getType().isSolid()) {
                            triggerExplosion(player);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 2L, 2L);
    }

    private void triggerExplosion(Player player) {
        long now = System.currentTimeMillis();
        if (explosionCooldowns.getOrDefault(player.getUniqueId(), 0L) > now) return;
        explosionCooldowns.put(player.getUniqueId(), now + 1000); // 1s internal cooldown

        player.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.RESISTANCE, 20, 255));

        locExplosion(player.getLocation(), player);
        
        player.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, player.getLocation(), 1);
        player.getWorld().spawnParticle(Particle.FLASH, player.getLocation(), 20, 2, 2, 2, 0);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 2f, 0.8f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 2f, 1.2f);
    }

    private void locExplosion(org.bukkit.Location loc, Player owner) {
        double radius = getConfigDouble("explosion_radius", 8.0);
        double damage = getConfigDouble("explosion_damage", 14.0);
        double knockback = getConfigDouble("explosion_knockback", 2.0);

        for (Entity e : loc.getWorld().getNearbyEntities(loc, radius, radius, radius)) {
            if (e instanceof LivingEntity living && e != owner) {
                if (living instanceof Player targetPlayer) {
                    if (plugin.getTeamManager().isFriendlyFire(owner, targetPlayer)) continue;
                }
                living.damage(damage, owner);
                living.setVelocity(living.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(knockback).setY(0.5));
            }
        }
    }
}
