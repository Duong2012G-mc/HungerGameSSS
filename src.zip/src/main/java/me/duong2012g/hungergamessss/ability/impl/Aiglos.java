package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Aiglos — Spear of the Ice King
 *
 * PASSIVE · Melee stats (applied via item AttributeModifiers in aiglos.yml):
 *   - Attack Damage  : 7 HP  (ADD_NUMBER +6 on base 1 = 7 total)
 *   - Attack Speed   : 1.6/s (ADD_NUMBER -2.4 on base 4 = 1.6 total)
 *   - Reach          : 3.5 b (ADD_NUMBER +0.5 on default 3.0 = 3.5)
 *   - Sharpness enchant on item adds melee damage as normal.
 *
 * ACTIVE · Explosive Throw (trident mechanic):
 *   Right-click to throw. On impact:
 *   - Visual-only explosion (power 3, no block damage).
 *   - AOE damage in 3x3x3 zone (base damage + Sharpness bonus per level).
 *   - Loyalty 3 enchant auto-returns the trident (vanilla mechanic).
 *   No explicit ability cooldown — vanilla trident 1.6 s throw cooldown applies.
 */
public class Aiglos extends BaseAbility {

    private static final String TAG = "aiglos_thrower";

    // Track in-flight trident per player
    private final Map<UUID, UUID> inFlight = new ConcurrentHashMap<>();

    private static final double DEFAULT_EXPLOSION_DAMAGE         = 12.0;
    private static final double DEFAULT_SHARPNESS_BONUS_PER_LVL = 1.5;
    private static final double DEFAULT_EXPLOSION_RADIUS         = 1.5;
    private static final float  DEFAULT_EXPLOSION_POWER          = 3.0f;

    public Aiglos(Main plugin) {
        super(plugin);
    }

    @Override public String getName()     { return "Aiglos"; }
    @Override public long   getCooldown() { return 0; }

    private double explosionDamage()  { return getConfigDouble("explosion_damage",          DEFAULT_EXPLOSION_DAMAGE);         }
    private double sharpnessBonus()   { return getConfigDouble("sharpness_damage_per_level", DEFAULT_SHARPNESS_BONUS_PER_LVL); }
    private double explosionRadius()  { return getConfigDouble("explosion_radius",            DEFAULT_EXPLOSION_RADIUS);        }
    private float  explosionPower()   { return (float) getConfigDouble("explosion_power",     DEFAULT_EXPLOSION_POWER);         }

    // ── Tag trident on launch ─────────────────────────────────────────────────

    @Override
    protected void performProjectileLaunch(Player shooter, org.bukkit.entity.Projectile projectile, ItemStack item) {
        if (!(projectile instanceof Trident trident)) return;

        trident.setMetadata(TAG, new FixedMetadataValue(plugin, shooter.getUniqueId().toString()));
        inFlight.put(shooter.getUniqueId(), trident.getUniqueId());

        shooter.getWorld().spawnParticle(Particle.DRAGON_BREATH,
                shooter.getLocation().clone().add(0, 1, 0), 12, 0.15, 0.15, 0.15, 0.06);
        shooter.getWorld().playSound(shooter.getLocation(), Sound.ITEM_TRIDENT_THROW, 1.0f, 0.9f);
    }

    // ── Explosion + AOE damage on impact ──────────────────────────────────────

    @Override
    protected void performProjectileHit(org.bukkit.entity.Projectile projectile, ProjectileHitEvent event) {
        if (!(projectile instanceof Trident trident)) return;
        if (!trident.hasMetadata(TAG)) return;

        String shooterUUIDStr = trident.getMetadata(TAG).get(0).asString();
        UUID shooterUUID;
        try {
            shooterUUID = UUID.fromString(shooterUUIDStr);
        } catch (IllegalArgumentException e) {
            return;
        }
        Player shooter = Bukkit.getPlayer(shooterUUID);
        inFlight.remove(shooterUUID);

        Location impact = trident.getLocation();
        World world = impact.getWorld();
        if (world == null) return;

        // Read Sharpness level from the trident ItemStack
        int sharpnessLevel = 0;
        try {
            sharpnessLevel = trident.getItem().getEnchantmentLevel(Enchantment.SHARPNESS);
        } catch (Exception ignored) {}

        double totalDamage = explosionDamage() + (sharpnessLevel * sharpnessBonus());
        double r = explosionRadius();

        // Visual explosion — setFire=false, breakBlocks=false = no terrain damage
        world.createExplosion(impact, explosionPower(), false, false, shooter);
        world.spawnParticle(Particle.SNOWFLAKE, impact, 80, r, r, r, 0.25);
        world.spawnParticle(Particle.FLASH, impact, 2, r * 0.5, r * 0.5, r * 0.5, 0);
        world.playSound(impact, Sound.BLOCK_GLASS_BREAK, 1.2f, 0.5f);

        // A1-19: configurable AOE shape — "sphere" (default) or "cylinder"
        // sphere  = standard 3D sphere check (r × r × r bounding box, then distanceSq)
        // cylinder = full vertical column, radius only on X/Z plane (good for tight corridors)
        String shape = getConfigString("aoe_shape", "sphere").toLowerCase();
        double rSq   = r * r;

        for (Entity e : world.getNearbyEntities(impact, r, "cylinder".equals(shape) ? 256 : r, r)) {
            if (!(e instanceof LivingEntity target)) continue;
            if (shooter != null && target.equals(shooter)) continue;
            if (target instanceof Player tp && shooter != null
                    && plugin.getTeamManager().isFriendlyFire(shooter, tp)) continue;

            if ("sphere".equals(shape)) {
                // Extra sphere precision check (bounding box above is over-inclusive)
                if (target.getLocation().distanceSquared(impact) > rSq) continue;
            } else {
                // Cylinder: only check horizontal distance
                Location tl = target.getLocation();
                double dx = tl.getX() - impact.getX(), dz = tl.getZ() - impact.getZ();
                if (dx * dx + dz * dz > rSq) continue;
            }

            target.damage(totalDamage, shooter);

            // Ice spike visual
            for (int i = 0; i < 4; i++) {
                Location spike = target.getLocation().clone().add(0, i * 0.4, 0);
                spike.getWorld().spawnParticle(Particle.BLOCK,
                        spike, 4, 0.1, 0.1, 0.1, 0, Material.ICE.createBlockData());
            }
        }

        // Loyalty 3 enchant handles auto-return — no manual return needed.
    }

    // ── Action bar hint ───────────────────────────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;
        int sharpLevel = item.getEnchantmentLevel(Enchantment.SHARPNESS);
        double explosionTotal = explosionDamage() + (sharpLevel * sharpnessBonus());
        boolean flying = inFlight.containsKey(player.getUniqueId());

        player.sendActionBar(
            net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection()
                .deserialize(flying
                    ? "§b[Aiglos] §7Thrown... §8(Loyalty returning)"
                    : "§b[Aiglos] §7Throw: §f" + String.format("%.1f", explosionTotal / 2.0)
                        + "\u2665 §8AoE §8| §7Sharpness §fX" + sharpLevel));
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    @Override
    protected void performQuit(Player player, PlayerQuitEvent event) {
        inFlight.remove(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, PlayerDeathEvent event) {
        inFlight.remove(player.getUniqueId());
    }

    @Override
    public void cleanup() {
        inFlight.clear();
    }
}
