package me.duong2012g.hungergamessss.ability;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.impl.*;

import java.util.HashMap;
import java.util.Map;

public class AbilityRegistry {
    private final Main plugin;
    private final Map<String, Ability> abilities = new HashMap<>();

    public AbilityRegistry(Main plugin) {
        this.plugin = plugin;
        registerDefaults();
    }

    /**
     * FIX: registerEvents() was previously called inside each ability constructor,
     * which caused double-registration on plugin reload (old instance's handlers
     * kept firing alongside the new instance's handlers).
     * Now every ability that implements Listener is registered exactly once here,
     * after the ability object is fully constructed.
     */
    public void register(Ability ability) {
        abilities.put(ability.getName().toLowerCase(), ability);
        if (ability instanceof org.bukkit.event.Listener listener) {
            org.bukkit.Bukkit.getPluginManager().registerEvents(listener, plugin);
        }
    }

    /** Cancel all standalone tasks and clean up world state for every ability. */
    public void shutdownAll() {
        for (Ability ability : abilities.values()) {
            try {
                ability.cleanup();
            } catch (Exception e) {
                plugin.getLogger().warning("[AbilityRegistry] cleanup() failed for "
                        + ability.getName() + ": " + e.getMessage());
            }
        }
    }

    private void registerDefaults() {
        register(new CloudSword(plugin));
        register(new DragonKatana(plugin));
        register(new Excalibur(plugin));
        register(new ShadowBlade(plugin));
        register(new MidasSword(plugin));
        register(new WitherSickles(plugin));
        register(new VillagerWand(plugin));
        register(new HypnosisStaff(plugin));
        
        // New additions from DemoraHopliteWeapons
        register(new Mjolnir(plugin));
        register(new GolemHammer(plugin));
        register(new ReaperScythe(plugin));
        register(new ShrinkRay(plugin));
        register(new MagmaClub(plugin));
        register(new VoidStaff(plugin));
        // ChainsawSword removed
        
        // Original additions
        register(new Aiglos(plugin));
        register(new ArtemisBow(plugin));
        register(new DeathNote(plugin));
        register(new EmeraldBlade(plugin));
        register(new EnderBow(plugin));
        register(new ObsidianDagger(plugin));
        register(new PufferfishCannon(plugin));
        register(new WardenCrossbow(plugin));
        register(new BeehiveBlaster(plugin));
        register(new ReinforcedElytra(plugin));
        
        // New Additions (Batch 2)
        register(new HermesBoots(plugin));
        register(new PoseidonsTrident(plugin));
        register(new HadesHelm(plugin));


        // ==========================================
        // Vred's Hoplite Weapons Datapack (v8.3.1)
        // ==========================================
        register(new GuardianCannon(plugin));
        register(new HarpoonLauncher(plugin));
        register(new HornOfWinter(plugin));
        register(new FountainOfYouth(plugin));
        register(new GhastlyWhistle(plugin));
        register(new PhantomLongbow(plugin));
        register(new SculkweaversLantern(plugin));
        register(new SoulGauntlet(plugin));
        register(new ToxicCrossbow(plugin));
        register(new Warpick(plugin));
        register(new LichStaff(plugin));
        register(new ArmadilloDetonator(plugin));
        register(new RibbitReel(plugin));
        register(new RavagerHorn(plugin));
        register(new CrimsonChainsword(plugin));
        register(new CorruptedCrossbow(plugin));
    }



    public Ability getAbility(String name) {
        if (name == null) return null;
        // Normalize: lowercase, replace underscores with spaces
        String key = name.toLowerCase().replace("_", " ").trim();
        
        // Exact match (space-normalized)
        if (abilities.containsKey(key)) return abilities.get(key);
        
        // Try underscore-normalized key
        String keyUnderscore = key.replace(" ", "_");
        if (abilities.containsKey(keyUnderscore)) return abilities.get(keyUnderscore);
        
        // Try matching both ways for each registered ability
        for (Map.Entry<String, Ability> entry : abilities.entrySet()) {
            String regKey = entry.getKey();
            if (regKey.replace(" ", "_").equals(keyUnderscore) || regKey.replace("_", " ").equals(key)) {
                return entry.getValue();
            }
        }
        return null;
    }
    
    public java.util.Collection<Ability> getAbilities() {
        return abilities.values();
    }
}
