package me.duong2012g.hungergamessss.ability;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.impl.*;

import java.util.HashMap;
import java.util.Map;
import java.util.ServiceLoader;

public class AbilityRegistry {
    private final Main plugin;
    private final Map<String, Ability> abilities = new HashMap<>();

    public AbilityRegistry(Main plugin) {
        this.plugin = plugin;
        registerDefaults();
        // A1-10: load any third-party abilities from the Java ServiceLoader SPI
        discoverSpiAbilities();
        // A1-11: apply config-driven overrides (disable/replace built-in abilities)
        applyConfigOverrides();
    }

    // ── A1-10: ServiceLoader (SPI) discovery ──────────────────────────────────

    /**
     * A1-10: Discovers and registers abilities declared in
     * {@code META-INF/services/me.duong2012g.hungergamessss.ability.Ability}
     * by any plugin JAR on the class-path.
     *
     * <p>Third-party plugin authors only need to:
     * <ol>
     *   <li>Implement {@link Ability} (or extend {@link me.duong2012g.hungergamessss.ability.BaseAbility}).</li>
     *   <li>Add a no-arg constructor or a constructor that accepts {@link AbilityServices}.</li>
     *   <li>Create {@code META-INF/services/me.duong2012g.hungergamessss.ability.Ability}
     *       with the fully-qualified class name.</li>
     * </ol>
     * Built-in abilities are not affected — their keys take priority unless
     * {@code abilities.override-allow: true} is set in config.
     */
    private void discoverSpiAbilities() {
        boolean overrideAllowed = plugin.getConfig().getBoolean("abilities.spi-override-allow", false);
        ServiceLoader<Ability> loader;
        try {
            loader = ServiceLoader.load(Ability.class, plugin.getClass().getClassLoader());
        } catch (Exception e) {
            plugin.getLogger().warning("[AbilityRegistry] SPI discovery failed: " + e.getMessage());
            return;
        }
        int loaded = 0;
        for (Ability ability : loader) {
            String key = normalizeKey(ability.getName());
            if (abilities.containsKey(key) && !overrideAllowed) {
                plugin.getLogger().info("[AbilityRegistry] SPI ability '" + ability.getName()
                        + "' skipped (built-in exists; set abilities.spi-override-allow: true to override).");
                continue;
            }
            register(ability);
            loaded++;
            plugin.getLogger().info("[AbilityRegistry] SPI: loaded external ability '" + ability.getName() + "'.");
        }
        if (loaded > 0)
            plugin.getLogger().info("[AbilityRegistry] Loaded " + loaded + " external ability/abilities via SPI.");
    }

    // ── A1-11: Config-driven overrides ───────────────────────────────────────

    /**
     * A1-11: Reads the {@code abilities.disabled} list from config.yml and
     * unregisters each named ability. This lets server admins disable any
     * built-in ability without editing plugin source code.
     *
     * <p>Also reads {@code abilities.enabled-only} — if non-empty, every ability
     * <em>not</em> in that list is unregistered (whitelist mode).
     *
     * <p>Example config:
     * <pre>{@code
     * abilities:
     *   disabled:
     *     - "Armadillo Detonator"
     *     - "Shrink Ray"
     *   enabled-only: []   # empty = no whitelist; list names to use whitelist mode
     * }</pre>
     */
    private void applyConfigOverrides() {
        // Blacklist — remove explicitly disabled abilities
        java.util.List<String> disabled = plugin.getConfig().getStringList("abilities.disabled");
        for (String name : disabled) {
            String key = normalizeKey(name);
            if (abilities.containsKey(key)) {
                unregister(name);
                plugin.getLogger().info("[AbilityRegistry] Disabled by config: '" + name + "'.");
            }
        }

        // Whitelist — keep only explicitly listed abilities
        java.util.List<String> enabledOnly = plugin.getConfig().getStringList("abilities.enabled-only");
        if (!enabledOnly.isEmpty()) {
            java.util.Set<String> allowed = new java.util.HashSet<>();
            for (String name : enabledOnly) allowed.add(normalizeKey(name));

            java.util.List<String> toRemove = abilities.keySet().stream()
                    .filter(k -> !allowed.contains(k))
                    .toList();
            toRemove.forEach(k -> {
                Ability a = abilities.get(k);
                if (a != null) {
                    try { a.cleanup(); } catch (Exception ignored) {}
                    abilities.remove(k);
                    plugin.getLogger().info("[AbilityRegistry] Whitelist: removed '" + k + "'.");
                }
            });
        }
    }

    // OPT-REG-01: Normalize keys at registration time (lowercase + spaces only).
    // Previously the key was stored as-is and getAbility() did three fallback passes
    // (exact → underscore → full loop) on every dispatch call. Now lookup is O(1).
    private static String normalizeKey(String name) {
        return name.toLowerCase().replace("_", " ").trim();
    }

    /**
     * FIX: registerEvents() was previously called inside each ability constructor,
     * which caused double-registration on plugin reload (old instance's handlers
     * kept firing alongside the new instance's handlers).
     * Now every ability that implements Listener is registered exactly once here,
     * after the ability object is fully constructed.
     */
    public void register(Ability ability) {
        abilities.put(normalizeKey(ability.getName()), ability);
        if (ability instanceof org.bukkit.event.Listener listener) {
            org.bukkit.Bukkit.getPluginManager().registerEvents(listener, plugin);
        }
    }

    /**
     * Unregisters an ability by name and calls its cleanup().
     * Useful for hot-reload of a single ability without a full shutdown.
     */
    public void unregister(String name) {
        Ability ability = abilities.remove(normalizeKey(name));
        if (ability != null) {
            try { ability.cleanup(); } catch (Exception e) {
                plugin.getLogger().warning("[AbilityRegistry] cleanup() failed on unregister for "
                        + ability.getName() + ": " + e.getMessage());
            }
        }
    }

    /** Cancel all standalone tasks and clean up world state for every ability. */
    public void shutdownAll() {
        for (Ability ability : abilities.values()) {
            try {
                ability.cleanup();
            } catch (Exception e) {
                plugin.getLogger().warning("[AbilityRegistry] cleanup() failed for "
                        + ability.getName() + ": " + e.getMessage());
            }
        }
    }

    private void registerDefaults() {
        register(new CloudSword(plugin));
        register(new DragonKatana(plugin));
        register(new Excalibur(plugin));
        register(new ShadowBlade(plugin));
        register(new MidasSword(plugin));
        register(new WitherSickles(plugin));
        register(new VillagerWand(plugin));
        register(new HypnosisStaff(plugin));
        
        // New additions from DemoraHopliteWeapons
        register(new Mjolnir(plugin));
        register(new GolemHammer(plugin));
        register(new ReaperScythe(plugin));
        register(new ShrinkRay(plugin));
        register(new MagmaClub(plugin));
        register(new VoidStaff(plugin));
        // ChainsawSword removed
        
        // Original additions
        register(new Aiglos(plugin));
        register(new ArtemisBow(plugin));
        register(new DeathNote(plugin));
        register(new EmeraldBlade(plugin));
        register(new EnderBow(plugin));
        register(new ObsidianDagger(plugin));
        register(new PufferfishCannon(plugin));
        register(new WardenCrossbow(plugin));
        register(new BeehiveBlaster(plugin));
        register(new ReinforcedElytra(plugin));
        
        // New Additions (Batch 2)
        register(new HermesBoots(plugin));
        register(new PoseidonsTrident(plugin));
        register(new HadesHelm(plugin));


        // ==========================================
        // Vred's Hoplite Weapons Datapack (v8.3.1)
        // ==========================================
        register(new GuardianCannon(plugin));
        register(new HarpoonLauncher(plugin));
        register(new HornOfWinter(plugin));
        register(new FountainOfYouth(plugin));
        register(new GhastlyWhistle(plugin));
        register(new PhantomLongbow(plugin));
        register(new SculkweaversLantern(plugin));
        register(new SoulGauntlet(plugin));
        register(new ToxicCrossbow(plugin));
        register(new Warpick(plugin));
        register(new LichStaff(plugin));
        register(new ArmadilloDetonator(plugin));
        register(new RibbitReel(plugin));
        register(new RavagerHorn(plugin));
        register(new CrimsonChainsword(plugin));
        register(new CorruptedCrossbow(plugin));
    }



    public Ability getAbility(String name) {
        if (name == null) return null;
        return abilities.get(normalizeKey(name));
    }

    /** Returns an unmodifiable list of all registered ability display names. */
    public java.util.List<String> getAllAbilityNames() {
        return abilities.values().stream()
                .map(Ability::getName)
                .sorted()
                .toList();
    }
    
    public java.util.Collection<Ability> getAbilities() {
        return abilities.values();
    }
}
