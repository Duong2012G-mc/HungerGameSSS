package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Armadillo Detonator — Explosive crossbow with remote detonation.
 *
 * RIGHT-CLICK (Shoot):
 *   Launches up to 3 armadillo projectiles (max 3 active at once).
 *   Each bounces lightly on terrain and travels ~30 blocks.
 *   Shoot cooldown: 20 s after each volley.
 *
 * LEFT-CLICK (Detonate):
 *   Instantly explodes ALL active armadillos for this player.
 *   Each blast: ~15-20 hearts, radius ~2 blocks (4x4x4 zone), no terrain damage.
 *   40% armour bypass on direct blast damage.
 *   No cooldown on detonate — only limited by how many are active.
 */
public class ArmadilloDetonator extends BaseAbility {

    private static final int    DEFAULT_MAX_ACTIVE       = 3;
    private static final long   DEFAULT_SHOOT_CD_MS      = 20_000L;
    private static final double DEFAULT_LAUNCH_VELOCITY  = 1.5;
    private static final int    DEFAULT_MAX_FLIGHT_TICKS = 400;   // ~20 s max flight
    private static final double DEFAULT_EXPL_RADIUS      = 2.0;   // half of 4x4x4
    private static final double DEFAULT_EXPL_DAMAGE      = 30.0;  // 15 hearts base
    private static final double DEFAULT_ARMOR_BYPASS     = 0.40;
    private static final int    DEFAULT_BOUNCE_MAX       = 3;

    // per-player: list of active armadillo entities
    private final Map<UUID, List<Armadillo>> activeArmadillos = new ConcurrentHashMap<>();
    // per-player: shoot cooldown timestamp
    private final Map<UUID, Long> shootCooldowns = new ConcurrentHashMap<>();

    private final Random random = new Random();

    public ArmadilloDetonator(Main plugin) {
        super(plugin);
    }

    @Override public String getName()     { return "Armadillo Detonator"; }
    @Override public long   getCooldown() { return 0; } // Per-action CDs below

    // ── Config shortcuts ──────────────────────────────────────────────────────
    private int    maxActive()      { return getConfigInt   ("max_active",        DEFAULT_MAX_ACTIVE);       }
    private long   shootCdMs()      { return getConfigLong  ("shoot_cooldown",     DEFAULT_SHOOT_CD_MS);      }
    private double launchVel()      { return getConfigDouble("launch_velocity",    DEFAULT_LAUNCH_VELOCITY);  }
    private int    maxFlightTicks() { return getConfigInt   ("max_flight_ticks",   DEFAULT_MAX_FLIGHT_TICKS); }
    private double explRadius()     { return getConfigDouble("explosion_radius",   DEFAULT_EXPL_RADIUS);      }
    private double explDamage()     { return getConfigDouble("explosion_damage",   DEFAULT_EXPL_DAMAGE);      }
    private double armorBypass()    { return getConfigDouble("armor_bypass",       DEFAULT_ARMOR_BYPASS);     }
    private int    bounceMax()      { return getConfigInt   ("bounce_max",         DEFAULT_BOUNCE_MAX);       }

    // ── RIGHT-CLICK: Shoot ────────────────────────────────────────────────────

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);

        // Shoot cooldown check
        Long last = shootCooldowns.get(player.getUniqueId());
        if (last != null && System.currentTimeMillis() - last < shootCdMs()) {
            long remaining = (shootCdMs() - (System.currentTimeMillis() - last)) / 1000L;
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize(
                    "§c[Armadillo Detonator] §7Shoot §cCD: §f" + remaining + "s"));
            return;
        }

        List<Armadillo> active = activeArmadillos.computeIfAbsent(
                player.getUniqueId(), k -> Collections.synchronizedList(new ArrayList<>()));

        // Remove expired/dead entities from tracking list
        active.removeIf(a -> a == null || !a.isValid() || a.isDead());

        if (active.size() >= maxActive()) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize(
                    "§c[Armadillo Detonator] §7Max §f" + maxActive()
                    + " §7armadillos active! §8Left-click to detonate."));
            return;
        }

        shootCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
        launchArmadillo(player, active);

        player.getWorld().playSound(player.getLocation(), Sound.ITEM_CROSSBOW_SHOOT, 1.0f, 0.6f);
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§c[Armadillo Detonator] §7Launched! §8(" + (active.size()) + "/" + maxActive()
                + " active) §8| §7Left-click to detonate"));
    }

    private void launchArmadillo(Player player, List<Armadillo> active) {
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection().normalize().multiply(launchVel());

        Armadillo arma = (Armadillo) player.getWorld().spawnEntity(eye.clone().add(dir), EntityType.ARMADILLO);
        arma.setAI(false);
        arma.setInvulnerable(true);
        arma.setSilent(true);
        arma.setGravity(true);

        active.add(arma);
        UUID ownerUUID = player.getUniqueId();

        new BukkitRunnable() {
            int ticks = 0;
            int bounces = 0;
            Vector velocity = dir.clone();

            @Override
            public void run() {
                if (!arma.isValid() || arma.isDead() || ticks++ > maxFlightTicks()) {
                    active.remove(arma);
                    if (arma.isValid()) arma.remove();
                    cancel();
                    return;
                }

                // Trail particles
                arma.getWorld().spawnParticle(Particle.CRIT,
                        arma.getLocation(), 3, 0.1, 0.1, 0.1, 0.05);
                arma.getWorld().spawnParticle(Particle.SMOKE,
                        arma.getLocation(), 1, 0.05, 0.05, 0.05, 0.01);

                // Apply velocity
                arma.setVelocity(velocity);

                // Block collision — bounce
                if (arma.getLocation().getBlock().getType().isSolid() && bounces < bounceMax()) {
                    velocity.setY(Math.abs(velocity.getY()) * 0.6);
                    velocity.setX(velocity.getX() * 0.8);
                    velocity.setZ(velocity.getZ() * 0.8);
                    bounces++;
                    arma.getWorld().playSound(arma.getLocation(),
                            Sound.ENTITY_ARMADILLO_ROLL, 0.8f, 1.2f);
                } else if (arma.getLocation().getBlock().getType().isSolid() && bounces >= bounceMax()) {
                    // Stop bouncing — sit on ground
                    velocity.setY(0);
                    velocity.setX(velocity.getX() * 0.4);
                    velocity.setZ(velocity.getZ() * 0.4);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    // ── LEFT-CLICK: Detonate all ──────────────────────────────────────────────

    @Override
    protected void performLeftClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);

        List<Armadillo> active = activeArmadillos.remove(player.getUniqueId());
        if (active == null || active.isEmpty()) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§c[Armadillo Detonator] §7No active armadillos!"));
            return;
        }

        // Remove dead ones silently
        active.removeIf(a -> a == null || !a.isValid() || a.isDead());
        if (active.isEmpty()) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§c[Armadillo Detonator] §7All armadillos already gone!"));
            return;
        }

        int count = active.size();
        for (Armadillo arma : active) {
            if (arma.isValid()) {
                detonateAt(arma.getLocation(), player);
                arma.remove();
            }
        }
        active.clear();

        player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.7f);
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§c[Armadillo Detonator] §l§cDETONATED §r§7(" + count + " armadillos)"));
    }

    private void detonateAt(Location loc, Player owner) {
        World world = loc.getWorld();
        if (world == null) return;

        // Visual explosion — no block break
        world.createExplosion(loc, (float) explRadius(), false, false, owner);
        world.spawnParticle(Particle.EXPLOSION_EMITTER, loc, 2, 0.3, 0.3, 0.3, 0);
        world.spawnParticle(Particle.CRIT, loc, 30, 0.6, 0.6, 0.6, 0.3);
        world.spawnParticle(Particle.SMOKE, loc, 25, 0.5, 0.5, 0.5, 0.1);
        world.playSound(loc, Sound.ENTITY_ARMADILLO_PEEK, 1.5f, 0.5f);
        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.9f);

        double r = explRadius();
        for (Entity e : world.getNearbyEntities(loc, r, r, r)) {
            if (!(e instanceof LivingEntity target)) continue;
            if (target.equals(owner)) continue;
            if (target instanceof Player tp && plugin.getTeamManager().isFriendlyFire(owner, tp)) continue;

            // Armour bypass: reduce effective armour before calculating damage
            double finalDamage = calcBypassDamage(target, explDamage(), armorBypass());
            target.setNoDamageTicks(0);
            target.damage(finalDamage, owner);

            // Radial knockback
            Vector kb = target.getLocation().toVector().subtract(loc.toVector());
            if (kb.lengthSquared() > 0) kb.normalize().multiply(1.8).setY(0.5);
            target.setVelocity(target.getVelocity().add(kb));
        }
    }

    private double calcBypassDamage(LivingEntity target, double raw, double bypass) {
        if (!(target instanceof Player)) return raw;
        try {
            double armour   = target.getAttribute(Attribute.GENERIC_ARMOR).getValue();
            double effective = armour * (1.0 - bypass);
            double reduction = effective / (effective + 25.0);
            return raw * (1.0 - reduction);
        } catch (Exception ignored) {
            return raw;
        }
    }

    // ── passiveTick: action bar status ───────────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;

        List<Armadillo> active = activeArmadillos.getOrDefault(
                player.getUniqueId(), Collections.emptyList());
        active.removeIf(a -> a == null || !a.isValid() || a.isDead());
        int count = active.size();

        Long last = shootCooldowns.get(player.getUniqueId());
        boolean onCd = last != null && System.currentTimeMillis() - last < shootCdMs();
        String cdStr = onCd
                ? "§cCD: §f" + ((shootCdMs() - (System.currentTimeMillis() - last)) / 1000L) + "s"
                : "§aReady";

        String status = count > 0
                ? "§c" + count + " §7active §8| §7Left-click §c§lDETONATE"
                : "§7None active";

        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§6⬡ §7Shoot: " + cdStr + "  §8| §7Armadillos: " + status));
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    private void cleanupPlayer(UUID id) {
        List<Armadillo> active = activeArmadillos.remove(id);
        if (active != null) {
            active.forEach(a -> { if (a != null && a.isValid()) a.remove(); });
        }
        shootCooldowns.remove(id);
    }

    @Override
    protected void performQuit(Player player, PlayerQuitEvent event) {
        cleanupPlayer(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, PlayerDeathEvent event) {
        cleanupPlayer(player.getUniqueId());
    }

    @Override
    public void cleanup() {
        for (UUID id : new HashSet<>(activeArmadillos.keySet())) cleanupPlayer(id);
        activeArmadillos.clear();
        shootCooldowns.clear();
    }
}
