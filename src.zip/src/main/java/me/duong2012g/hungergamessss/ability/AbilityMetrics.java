package me.duong2012g.hungergamessss.ability;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * A1-S5: Lightweight internal metrics for the ability system.
 *
 * <p>Tracks per-ability activation counts, blocked counts (cooldown/validate), and
 * cumulative totals. Exposed via {@code /hg debug metrics} and the bStats integration.
 *
 * <h3>Usage inside an ability</h3>
 * <pre>{@code
 * AbilityMetrics.recordActivation(getName());
 * AbilityMetrics.recordBlocked(getName());
 * }</pre>
 *
 * <h3>Reading metrics</h3>
 * <pre>{@code
 * AbilityMetrics.Snapshot snap = AbilityMetrics.snapshot();
 * snap.activations().forEach((name, count) -> …);
 * }</pre>
 */
public final class AbilityMetrics {

    private static final Map<String, AtomicLong> activations = new ConcurrentHashMap<>();
    private static final Map<String, AtomicLong> blocked      = new ConcurrentHashMap<>();
    private static final AtomicLong totalActivations = new AtomicLong();
    private static final AtomicLong totalBlocked     = new AtomicLong();
    /** Monotonic server-start timestamp for uptime calculation. */
    private static final long startedAt = System.currentTimeMillis();

    private AbilityMetrics() {}

    /** Records one successful ability activation (all guards passed). */
    public static void recordActivation(String abilityName) {
        activations.computeIfAbsent(abilityName, k -> new AtomicLong()).incrementAndGet();
        totalActivations.incrementAndGet();
    }

    /** Records one blocked attempt (cooldown active or validateCanUse failed). */
    public static void recordBlocked(String abilityName) {
        blocked.computeIfAbsent(abilityName, k -> new AtomicLong()).incrementAndGet();
        totalBlocked.incrementAndGet();
    }

    /** Resets all counters. Called on arena reset or via debug command. */
    public static void reset() {
        activations.clear();
        blocked.clear();
        totalActivations.set(0);
        totalBlocked.set(0);
    }

    /** Returns an immutable snapshot of current counters. */
    public static Snapshot snapshot() {
        Map<String, Long> actSnap  = new java.util.LinkedHashMap<>();
        Map<String, Long> blkSnap  = new java.util.LinkedHashMap<>();
        activations.forEach((k, v) -> actSnap.put(k, v.get()));
        blocked.forEach((k, v)     -> blkSnap.put(k, v.get()));
        return new Snapshot(
                java.util.Collections.unmodifiableMap(actSnap),
                java.util.Collections.unmodifiableMap(blkSnap),
                totalActivations.get(),
                totalBlocked.get(),
                System.currentTimeMillis() - startedAt
        );
    }

    /**
     * Immutable snapshot of ability metrics at a point in time.
     *
     * @param activations    per-ability activation count map
     * @param blocked        per-ability blocked count map
     * @param totalActivations total activations across all abilities
     * @param totalBlocked     total blocked attempts
     * @param uptimeMillis   milliseconds since metrics were last reset
     */
    public record Snapshot(
            Map<String, Long> activations,
            Map<String, Long> blocked,
            long totalActivations,
            long totalBlocked,
            long uptimeMillis
    ) {
        /** Returns the most-used ability name, or {@code "(none)"} if no data. */
        public String topAbility() {
            return activations.entrySet().stream()
                    .max(Map.Entry.comparingByValue())
                    .map(Map.Entry::getKey)
                    .orElse("(none)");
        }

        /** Formats a compact one-line summary for console/chat display. */
        public String summary() {
            long upSec = uptimeMillis / 1000;
            return String.format(
                    "§eAbilityMetrics §7— activations: §a%d §7blocked: §c%d §7uptime: §e%ds §7top: §6%s",
                    totalActivations, totalBlocked, upSec, topAbility());
        }
    }
}
