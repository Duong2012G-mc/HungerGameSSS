package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;


public class EmeraldBlade extends BaseAbility implements Listener {

    private final NamespacedKey emeraldBladeKey;
    private final NamespacedKey upgradeCountKey;
    private final NamespacedKey emeraldCountKey;
    private final NamespacedKey emeraldDamageModKey;
    
    private final String GUI_TITLE = ChatColor.GREEN + "Emerald Blade Upgrades";

    public EmeraldBlade(Main plugin) {
        super(plugin);
        this.emeraldBladeKey = new NamespacedKey(plugin, "emerald_blade");
        this.upgradeCountKey = new NamespacedKey(plugin, "emerald_blade_upgrades");
        this.emeraldCountKey = new NamespacedKey(plugin, "emerald_blade_emeralds");
        this.emeraldDamageModKey = new NamespacedKey(plugin, "emerald_blade_damage");
        // FIX: registerEvents moved to AbilityRegistry.register() — prevents double-registration on reload
    }

    @Override
    public String getName() {
        return "Emerald Blade";
    }

    @Override
    public long getCooldown() {
        return 0; // No active cooldown for passive scaling
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        if (player.isSneaking()) {
            openUpgradeMenu(player, item);
        }
    }

    private void openUpgradeMenu(Player player, ItemStack item) {
        Inventory menu = Bukkit.createInventory(null, 18, GUI_TITLE);
        int storedEmeralds = getEmeraldCount(item);
        
        int remaining = storedEmeralds;
        while (remaining > 0) {
            int stackSize = Math.min(64, remaining);
            menu.addItem(new ItemStack(Material.EMERALD, stackSize));
            remaining -= stackSize;
        }
        
        player.openInventory(menu);
        player.playSound(player.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 1.0f, 1.0f);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTitle().equals(GUI_TITLE)) {
            ItemStack clicked = event.getCurrentItem();
            ItemStack cursor = event.getCursor();
            
            // Only allow emeralds
            if (event.getClickedInventory() == event.getView().getTopInventory()) {
                if (cursor != null && cursor.getType() != Material.AIR && cursor.getType() != Material.EMERALD) {
                    event.setCancelled(true);
                }
            }
            
            if (event.isShiftClick() && clicked != null && clicked.getType() != Material.EMERALD) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getView().getTitle().equals(GUI_TITLE)) {
            if (event.getOldCursor() != null && event.getOldCursor().getType() != Material.EMERALD) {
                for (int slot : event.getRawSlots()) {
                    if (slot < event.getView().getTopInventory().getSize()) {
                        event.setCancelled(true);
                        return;
                    }
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getView().getTitle().equals(GUI_TITLE)) {
            Player player = (Player) event.getPlayer();
            ItemStack item = player.getInventory().getItemInMainHand();
            
            if (!isEmeraldBlade(item)) {
                // Return items if blade was swapped
                for (ItemStack content : event.getInventory().getContents()) {
                    if (content != null && content.getType() != Material.AIR) {
                        player.getInventory().addItem(content).values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));
                    }
                }
                return;
            }
            
            int emeraldsInMenu = 0;
            for (ItemStack content : event.getInventory().getContents()) {
                if (content != null && content.getType() == Material.EMERALD) {
                    emeraldsInMenu += content.getAmount();
                }
            }
            
            int previousEmeralds = getEmeraldCount(item);
            updateItemData(item, emeraldsInMenu);
            
            if (emeraldsInMenu > previousEmeralds) {
                player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_USE, 1.0f, 1.5f);
                player.sendMessage(ChatColor.GREEN + "Emerald Blade updated! Total emeralds: " + emeraldsInMenu);
            }
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        if (event.getEntity().getKiller() != null) {
            Player killer = event.getEntity().getKiller();
            ItemStack weapon = killer.getInventory().getItemInMainHand();
            
            if (isEmeraldBlade(weapon)) {
                int playerDrop = getConfigInt("drop_on_player_kill", 20);
                int mobDrop = getConfigInt("drop_on_mob_kill", 1);
                int amount = (event.getEntity() instanceof Player) ? playerDrop : mobDrop;
                event.getDrops().add(new ItemStack(Material.EMERALD, amount));
            }
        }
    }

    private boolean isEmeraldBlade(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        // Check for standard legend key
        NamespacedKey key = new NamespacedKey(plugin, "hg_ability");
        if (item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.STRING)) {
            String val = item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
            if (val.equalsIgnoreCase("emerald_blade") || val.equalsIgnoreCase("emerald_sword")) return true;
        }
        return item.getItemMeta().getPersistentDataContainer().has(emeraldBladeKey, PersistentDataType.BYTE);
    }

    private int getEmeraldCount(ItemStack item) {
        if (!isEmeraldBlade(item)) return 0;
        return item.getItemMeta().getPersistentDataContainer().getOrDefault(emeraldCountKey, PersistentDataType.INTEGER, 0);
    }

    private void updateItemData(ItemStack item, int emeraldCount) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        
        int emeraldsPerUpgrade = getConfigInt("emeralds_per_upgrade", 64);
        int upgradeCount = emeraldCount / emeraldsPerUpgrade;
        
        double baseDamage = getConfigDouble("base_damage", 7.0);
        double damagePerUpgrade = getConfigDouble("damage_per_upgrade", 2.0);
        double totalDamage = baseDamage + (upgradeCount * damagePerUpgrade);
        
        // Clear old modifiers
        meta.removeAttributeModifier(Attribute.GENERIC_ATTACK_DAMAGE);
        
        // Add new modifier
        // Bug-EB-01 fix: use non-deprecated AttributeModifier(NamespacedKey, double, Operation, EquipmentSlotGroup)
        AttributeModifier modifier = new AttributeModifier(emeraldDamageModKey, totalDamage, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND);
        meta.addAttributeModifier(Attribute.GENERIC_ATTACK_DAMAGE, modifier);
        
        meta.getPersistentDataContainer().set(emeraldBladeKey, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(emeraldCountKey, PersistentDataType.INTEGER, emeraldCount);
        meta.getPersistentDataContainer().set(upgradeCountKey, PersistentDataType.INTEGER, upgradeCount);
        
        // Update Lore — use Component API to prevent italic (FIX L-FONT-01)
        java.util.List<net.kyori.adventure.text.Component> lore = new java.util.ArrayList<>();
        lore.add(me.duong2012g.hungergamessss.util.ColorUtil.component(
                ChatColor.GRAY + "Deposited Emeralds: " + ChatColor.GREEN + emeraldCount));
        lore.add(me.duong2012g.hungergamessss.util.ColorUtil.component(
                ChatColor.GRAY + "Current Level: " + ChatColor.YELLOW + upgradeCount));
        lore.add(me.duong2012g.hungergamessss.util.ColorUtil.component(""));
        lore.add(me.duong2012g.hungergamessss.util.ColorUtil.component(
                ChatColor.DARK_GRAY + "Shift-Right-Click to deposit emeralds."));
        meta.lore(lore);
        
        item.setItemMeta(meta);
    }

    @Override
    protected void performHit(Player attacker, LivingEntity victim, ItemStack item, EntityDamageByEntityEvent event) {
        // The attribute modifier handles the damage automatically
    }
}
