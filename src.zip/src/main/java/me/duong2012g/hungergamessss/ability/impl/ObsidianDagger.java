package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class ObsidianDagger extends BaseAbility {

    private static final int COOLDOWN = 30;
    private static final int TARGET_DISTANCE = 50;
    private static final int SPAWN_HEIGHT = 15;
    private static final double METEOR_SPEED = -1.5;
    private static final float EXPLOSION_POWER = 4.0f;
    private static final double LOW_HEALTH_THRESHOLD = 10.0;
    private static final int RESISTANCE_DURATION = 40;
    private static final int RESISTANCE_AMPLIFIER = 1;

    public ObsidianDagger(Main plugin) {
        super(plugin);
        // FIX BUG-OD-01: removed startPassiveTask() BukkitRunnable.
        // Same root cause as BUG-AB-01 — each reload spawned a new parallel task.
        // Low-health resistance passive migrated to passiveTick() — driven by UnifiedPassiveTicker.
    }

    /**
     * Passive: grant brief Resistance when health is critically low.
     * Replaces the old startPassiveTask() BukkitRunnable (runs every 40 ticks via UnifiedPassiveTicker).
     */
    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;
        double threshold = getConfigDouble("low_health_threshold", LOW_HEALTH_THRESHOLD);
        if (player.getHealth() < threshold) {
            int duration = getConfigInt("resistance_duration", RESISTANCE_DURATION);
            int amplifier = getConfigInt("resistance_amplifier", RESISTANCE_AMPLIFIER);
            player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, duration, amplifier, true, false, true));
        }
    }

    @Override
    public String getName() {
        return "Obsidian Dagger";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 30000); // 30s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        if (player.isSneaking()) {
            // Obsidian Shield
            player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 60, 4));
            player.getWorld().playSound(player.getLocation(), Sound.BLOCK_ANVIL_PLACE, 1f, 0.5f);
            player.getWorld().spawnParticle(Particle.BLOCK, player.getLocation().add(0, 1, 0), 40, 0.5, 0.5, 0.5, Material.OBSIDIAN.createBlockData());
            // BUG-OD-03 Fix: replaced hardcoded sendMessage with sendActionBar (no i18n key required, consistent with other abilities)
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§5[Obsidian Dagger] §7Obsidian Shield active!"));
            return;
        }

        // Summon Meteor
        // BUG-OD-02 Fix: replaced deprecated getTargetBlock(null, range) with FluidCollisionMode-based rayTrace.
        // Passing null for the transparent-block set is deprecated in Paper 1.21 and causes a compile warning.
        org.bukkit.block.Block targetBlock = player.rayTraceBlocks(TARGET_DISTANCE,
                org.bukkit.FluidCollisionMode.NEVER) != null
                ? player.rayTraceBlocks(TARGET_DISTANCE, org.bukkit.FluidCollisionMode.NEVER).getHitBlock()
                : null;
        if (targetBlock == null) {
            // Fallback: no block in sight
            targetBlock = player.getTargetBlockExact(TARGET_DISTANCE, org.bukkit.FluidCollisionMode.NEVER);
        }
        if (targetBlock == null) return;
        Location targetLoc = targetBlock.getLocation();
        
        me.duong2012g.hungergamessss.model.Arena currentArena = plugin.getArenaManager().getArena(player);
        if (currentArena != null) {
            me.duong2012g.hungergamessss.model.Arena targetArena = plugin.getArenaManager().getArenaAt(targetLoc);
            if (targetArena == null || !targetArena.getName().equals(currentArena.getName())) {
                // BUG-OD-03 Fix: replaced hardcoded sendMessage with sendActionBar
                player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                    .legacySection().deserialize("§cYou cannot summon a meteor outside the arena!"));
                return;
            }
        }

        Location spawnLoc = targetLoc.clone().add(0, SPAWN_HEIGHT, 0);

        FallingBlock meteor = player.getWorld().spawnFallingBlock(spawnLoc, Bukkit.createBlockData(Material.OBSIDIAN));
        meteor.setDropItem(false);
        meteor.setHurtEntities(true);
        meteor.setMetadata("obsidian_meteor", new FixedMetadataValue(plugin, player.getUniqueId().toString()));
        meteor.setMetadata("hg_ability", new FixedMetadataValue(plugin, "Obsidian Dagger"));
        meteor.setVelocity(new org.bukkit.util.Vector(0, METEOR_SPEED, 0));
        
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_SHOOT, 1f, 0.5f);
        
        // BUG-OD-02 Fix: changed period from 1L to 2L — reduces server-side task frequency
        // by 50% with no visible difference for a slow-falling meteor particle trail.
        new BukkitRunnable() {
            @Override
            public void run() {
                if (meteor.isDead() || !meteor.isValid()) {
                    this.cancel();
                    return;
                }
                meteor.getWorld().spawnParticle(Particle.FLAME, meteor.getLocation(), 15, 0.2, 0.2, 0.2, 0.05);
                meteor.getWorld().spawnParticle(Particle.LAVA, meteor.getLocation(), 5, 0.1, 0.1, 0.1, 0.02);
                meteor.getWorld().spawnParticle(Particle.LARGE_SMOKE, meteor.getLocation(), 10, 0.3, 0.3, 0.3, 0.05);
            }
        }.runTaskTimer(plugin, 1L, 2L);
    }

    @Override
    protected void performEntityChangeBlock(Entity entity, org.bukkit.event.entity.EntityChangeBlockEvent event) {
        if (entity instanceof FallingBlock fb && fb.hasMetadata("obsidian_meteor")) {
            event.setCancelled(true); // Don't place block
            
            String ownerIdStr = fb.getMetadata("obsidian_meteor").get(0).asString();
            Player owner = Bukkit.getPlayer(java.util.UUID.fromString(ownerIdStr));
            
            // Explosion
            boolean mobGriefing = fb.getWorld().getGameRuleValue(org.bukkit.GameRule.MOB_GRIEFING);
            float power = (float) getConfigDouble("meteor_explosion_power", 4.0);
            fb.getWorld().createExplosion(fb.getLocation(), power, true, mobGriefing, owner); 
            
            fb.remove();
        }
    }

}
