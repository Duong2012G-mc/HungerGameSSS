package me.duong2012g.hungergamessss.ability.impl;

import org.bukkit.Location;
import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.model.Arena;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Sound;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class ShadowBlade extends BaseAbility {

    private final Map<UUID, ItemStack[]> armorMap = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> vanishedPlayers = new ConcurrentHashMap<>();

    private static final long COOLDOWN = 30;
    private static final int EFFECT_DURATION = 200; // 10 seconds
    private static final int SPEED_AMPLIFIER = 2; // Speed III
    private static final long RESTORE_DELAY = 200L;

    public ShadowBlade(Main plugin) {
        super(plugin);
    }

    @Override
    public String getName() {
        return "Shadow Blade";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 30000); // 30s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        if (player.isSneaking()) {
            // Shadow Step
            org.bukkit.entity.LivingEntity target = null;
            // BUG-SB-01 FIX: Shadow Step had no team check — could teleport behind teammates.
            int range = getConfigInt("shadow_step_range", 15);
            for (org.bukkit.entity.Entity e : player.getNearbyEntities(range, range, range)) {
                if (e instanceof LivingEntity lt && e != player) {
                    if (e instanceof Player tp && plugin.getTeamManager().isFriendlyFire(player, tp)) continue;
                    target = lt;
                    break;
                }
            }

            if (target != null) {
                Location behind = target.getLocation().subtract(target.getLocation().getDirection().normalize().multiply(1.5));
                player.teleport(behind);
                player.getWorld().spawnParticle(Particle.SMOKE, player.getLocation(), 20, 0.2, 0.2, 0.2, 0.05);
                player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
                player.sendMessage("§8[Shadow Blade] §7Shadow Stepped behind target!");
                return;
            }
        }

        // True invisibility
        // True invisibility (Optimized: only hide from players in the same arena)
        armorMap.put(player.getUniqueId(), player.getInventory().getArmorContents());
        player.getInventory().setArmorContents(null);
        
        me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        if (arena != null) {
            for (UUID uuid : arena.getPlayers()) {
                Player onlinePlayer = plugin.getServer().getPlayer(uuid);
                if (onlinePlayer != null && !onlinePlayer.equals(player)) {
                    onlinePlayer.hidePlayer(plugin, player);
                }
            }
        }
        vanishedPlayers.put(player.getUniqueId(), true);
        
        int effectDuration = getConfigInt("stealth_duration", EFFECT_DURATION);
        int speedAmplifier = getConfigInt("speed_amplifier", SPEED_AMPLIFIER);
        
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, effectDuration, 0));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, effectDuration, speedAmplifier));
        
        player.sendMessage("§8[Shadow] §7You have vanished into the shadows!");
        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.5f);
        player.getWorld().spawnParticle(Particle.SMOKE, player.getLocation().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0.05);

        new BukkitRunnable() {
            @Override
            public void run() {
                revealPlayer(player);
            }
        }.runTaskLater(plugin, (long) effectDuration);
    }

    private void revealPlayer(Player player) {
        if (vanishedPlayers.containsKey(player.getUniqueId())) {
            vanishedPlayers.remove(player.getUniqueId());
            // FIX H-02: Only reveal to players in the same arena, not the entire server
            Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
            if (arena != null) {
                for (UUID uid : arena.getPlayers()) {
                    Player viewer = plugin.getServer().getPlayer(uid);
                    if (viewer != null) viewer.showPlayer(plugin, player);
                }
            } else {
                // Fallback: player already left the arena (quit/death), reveal to everyone online
                for (Player onlinePlayer : plugin.getServer().getOnlinePlayers()) {
                    onlinePlayer.showPlayer(plugin, player);
                }
            }
            restoreArmor(player);
            player.sendMessage("§c[Shadow] §7You have returned from the shadows.");
            player.getWorld().spawnParticle(Particle.LARGE_SMOKE, player.getLocation().add(0, 1, 0), 50, 0.3, 0.3, 0.3, 0.02);
            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_AMBIENT, 1.0f, 1.2f);
        }
    }

    private void restoreArmor(Player player) {
        if (armorMap.containsKey(player.getUniqueId())) {
            ItemStack[] armor = armorMap.remove(player.getUniqueId());
            if (player.isOnline()) {
                if (player.isDead()) {
                    // If dead, drop items
                    for (ItemStack item : armor) {
                        if (item != null && item.getType() != org.bukkit.Material.AIR) {
                            player.getWorld().dropItemNaturally(player.getLocation(), item);
                        }
                    }
                } else {
                    player.getInventory().setArmorContents(armor);
                    player.getWorld().playSound(player.getLocation(), Sound.ITEM_TRIDENT_RETURN, 1f, 1f);
                }
            }
        }
    }

    @Override
    public void onDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        if (vanishedPlayers.containsKey(player.getUniqueId())) {
            revealPlayer(player);
        }
    }

    @Override
    public void onQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        if (vanishedPlayers.containsKey(player.getUniqueId())) {
            revealPlayer(player);
        }
    }

    /**
     * FIX BUG-SB-02: reveal all vanished players and clear both maps on
     * full shutdown. Without this, players who were invisible at the time of
     * /reload would remain hidden to all other players permanently.
     */
    @Override
    public void cleanup() {
        for (java.util.UUID id : new java.util.HashSet<>(vanishedPlayers.keySet())) {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null) revealPlayer(p);
        }
        vanishedPlayers.clear();
        armorMap.clear();
    }

    @Override
    protected void performHit(Player attacker, LivingEntity victim, ItemStack item, EntityDamageByEntityEvent event) {
        victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1));
        
        if (event.isCritical()) {
            victim.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0));
        }

        // Breaking stealth on hit
        if (vanishedPlayers.containsKey(attacker.getUniqueId())) {
            revealPlayer(attacker);
        }
    }
}
