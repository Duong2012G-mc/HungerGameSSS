package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class WardenCrossbow extends BaseAbility {

    private static final double DEFAULT_VELOCITY_MULTIPLIER = 1.5;
    private static final double DEFAULT_DAMAGE = 8.0;
    private static final double DEFAULT_AOE_RADIUS = 3.0;

    private final java.util.Random random = new java.util.Random();
    private final java.util.Set<org.bukkit.Material> nonReplaceableBlocks = new java.util.HashSet<>();

    public WardenCrossbow(Main plugin) {
        super(plugin);
        initNonReplaceableBlocks();
    }
    
    private void initNonReplaceableBlocks() {
        nonReplaceableBlocks.addAll(java.util.Arrays.asList(
            org.bukkit.Material.BEDROCK, org.bukkit.Material.BARRIER, org.bukkit.Material.COMMAND_BLOCK,
            org.bukkit.Material.CHAIN_COMMAND_BLOCK, org.bukkit.Material.REPEATING_COMMAND_BLOCK,
            org.bukkit.Material.STRUCTURE_BLOCK, org.bukkit.Material.JIGSAW, org.bukkit.Material.END_PORTAL,
            org.bukkit.Material.END_PORTAL_FRAME, org.bukkit.Material.END_GATEWAY, org.bukkit.Material.NETHER_PORTAL,
            org.bukkit.Material.RESPAWN_ANCHOR, org.bukkit.Material.LIGHT, org.bukkit.Material.STRUCTURE_VOID,
            org.bukkit.Material.OBSIDIAN, org.bukkit.Material.CRYING_OBSIDIAN,
            // Protection for containers/spawners
            org.bukkit.Material.CHEST, org.bukkit.Material.TRAPPED_CHEST, org.bukkit.Material.ENDER_CHEST,
            org.bukkit.Material.BARREL, org.bukkit.Material.SHULKER_BOX, org.bukkit.Material.SPAWNER,
            org.bukkit.Material.BEACON, org.bukkit.Material.ENCHANTING_TABLE
        ));
    }

    @Override
    public String getName() {
        return "Warden Crossbow";
    }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 15000); // 15s (Standardized to ms)
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        // Not used
    }

    @Override
    protected void performProjectileLaunch(Player player, org.bukkit.entity.Projectile projectile, ItemStack item) {
        if (projectile instanceof Arrow) {
            // Cancel vanilla arrow
            projectile.remove();
            
            // Trigger Sonic Boom logic
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 1.0f, 0.8f);
            launchSculkProjectile(player);
        }
    }

    @Override
    protected void performProjectileHit(org.bukkit.entity.Projectile projectile, ProjectileHitEvent event) {
        // Not used as we cancel the projectile
    }

    private void launchSculkProjectile(Player shooter) {
        org.bukkit.Location eyeLoc = shooter.getEyeLocation();
        Vector direction = eyeLoc.getDirection().normalize();
        
        new BukkitRunnable() {
            private org.bukkit.Location currentLoc = eyeLoc.clone();
            private int ticks = 0;
            private final int maxTicks = 100;
            private final double speed = 1.5;

            @Override
            public void run() {
                if (ticks >= maxTicks) {
                    cancel();
                    return;
                }
                currentLoc.add(direction.clone().multiply(speed));
                org.bukkit.World world = currentLoc.getWorld();
                if (world == null) {
                    cancel();
                    return;
                }
                
                // Particles (Optimized: every 2 ticks)
                if (ticks % 2 == 0) {
                    world.spawnParticle(Particle.SONIC_BOOM, currentLoc, 1, 0, 0, 0, 0);
                    world.spawnParticle(Particle.SCULK_SOUL, currentLoc, 5, 0.2, 0.2, 0.2, 0.02);
                    world.spawnParticle(Particle.SCULK_CHARGE_POP, currentLoc, 2, 0.1, 0.1, 0.1, 0);
                }

                // Entity Collision
                for (LivingEntity entity : world.getNearbyLivingEntities(currentLoc, 0.8, e -> !e.equals(shooter))) {
                    handleExplosionAndSpread(currentLoc, shooter);
                    cancel();
                    return;
                }
                
                // Block Collision
                org.bukkit.block.Block block = currentLoc.getBlock();
                if (block.getType() != org.bukkit.Material.AIR && block.getType().isSolid()) {
                    handleExplosionAndSpread(currentLoc, shooter);
                    cancel();
                    return;
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void handleExplosionAndSpread(org.bukkit.Location location, Player shooter) {
        createExplosion(location, shooter);
        new BukkitRunnable() {
            @Override
            public void run() {
                startSculkSpread(location);
            }
        }.runTaskLater(plugin, 20L);
    }

    private void createExplosion(org.bukkit.Location location, Player shooter) {
        org.bukkit.World world = location.getWorld();
        if (world == null) return;
        
        world.spawnParticle(Particle.SONIC_BOOM, location, 3, 1, 1, 1, 0);
        world.spawnParticle(Particle.SCULK_SOUL, location, 30, 1.5, 1.5, 1.5, 0.05);
        world.playSound(location, Sound.ENTITY_WARDEN_SONIC_BOOM, 2.0f, 0.8f);
        world.playSound(location, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 0.5f);

        double radius = getConfigDouble("aoe_radius", DEFAULT_AOE_RADIUS) + 2.0;
        double damage = getConfigDouble("damage", DEFAULT_DAMAGE);
        
        me.duong2012g.hungergamessss.ability.AbilityUtils.applyAreaDamage(plugin, shooter, location, radius, damage, getName());
        
        // Custom knockback for Warden feeling
        for (Entity entity : world.getNearbyEntities(location, radius, radius, radius)) {
            if (entity instanceof LivingEntity && !entity.equals(shooter)) {
                me.duong2012g.hungergamessss.ability.AbilityUtils.applyKnockback(entity, location, 1.5, 0.4);
            }
        }
    }

    private void startSculkSpread(org.bukkit.Location centerLocation) {
        int radius = getConfigInt("spread_radius", 5);
        int blocksPerTick = getConfigInt("spread_blocks_per_tick", 8);
        int tickDelay = getConfigInt("spread_tick_delay", 4);
        double replaceChance = getConfigDouble("spread_replace_chance", 0.8);
        
        java.util.List<org.bukkit.block.Block> blocksToProcess = getBlocksInRadius(centerLocation, radius);
        java.util.Collections.shuffle(blocksToProcess);
        
        new BukkitRunnable() {
            private int processedBlocks = 0;
            @Override
            public void run() {
                int processed = 0;
                while (processed < blocksPerTick && processedBlocks < blocksToProcess.size()) {
                    org.bukkit.block.Block block = blocksToProcess.get(processedBlocks);
                    processedBlocks++;
                    if (shouldReplaceBlock(block, replaceChance)) {
                        replaceBlockWithSculk(block);
                        processed++;
                    }
                }
                if (processedBlocks >= blocksToProcess.size()) {
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, tickDelay);
    }

    private java.util.List<org.bukkit.block.Block> getBlocksInRadius(org.bukkit.Location center, int radius) {
        java.util.List<org.bukkit.block.Block> blocks = new java.util.ArrayList<>();
        org.bukkit.World world = center.getWorld();
        if (world == null) return blocks;
        int centerX = center.getBlockX();
        int centerY = center.getBlockY();
        int centerZ = center.getBlockZ();
        
        int radiusSquared = radius * radius;
        
        for (int x = centerX - radius; x <= centerX + radius; x++) {
            int xSquared = (x - centerX) * (x - centerX);
            for (int z = centerZ - radius; z <= centerZ + radius; z++) {
                int zSquared = (z - centerZ) * (z - centerZ);
                int xzSquared = xSquared + zSquared;
                if (xzSquared > radiusSquared) continue; // Early exit for cylinder check
                
                for (int y = Math.max(world.getMinHeight(), centerY - radius); 
                     y <= Math.min(world.getMaxHeight() - 1, centerY + radius); y++) {
                    int ySquared = (y - centerY) * (y - centerY);
                    if (xzSquared + ySquared <= radiusSquared) {
                        blocks.add(world.getBlockAt(x, y, z));
                    }
                }
            }
        }
        return blocks;
    }

    private boolean shouldReplaceBlock(org.bukkit.block.Block block, double chance) {
        org.bukkit.Material type = block.getType();
        if (type.isAir() || nonReplaceableBlocks.contains(type)) {
            return false;
        }
        return random.nextDouble() < chance;
    }

    private void replaceBlockWithSculk(org.bukkit.block.Block block) {
        // Fix: Save to Arena
        me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaAt(block.getLocation());
        if (arena != null) {
            if (!arena.getOriginalBlocks().containsKey(block.getLocation())) {
                arena.getOriginalBlocks().put(block.getLocation(), block.getType());
            }
        }

        org.bukkit.Material sculkType = getRandomSculkBlock(block);
        block.setType(sculkType);
        org.bukkit.Location loc = block.getLocation().add(0.5, 0.5, 0.5);
        org.bukkit.World world = loc.getWorld();
        if (world != null) {
            world.spawnParticle(Particle.SCULK_CHARGE_POP, loc, 5, 0.3, 0.3, 0.3, 0);
            world.playSound(loc, Sound.BLOCK_SCULK_PLACE, 0.5f, 1.0f + (random.nextFloat() * 0.4f - 0.2f));
        }
    }

    private org.bukkit.Material getRandomSculkBlock(org.bukkit.block.Block block) {
        boolean isSurface = block.getRelative(0, 1, 0).getType() == org.bukkit.Material.AIR;
        int rand = random.nextInt(100);
        if (isSurface) {
            return rand < 70 ? org.bukkit.Material.SCULK : org.bukkit.Material.SCULK_VEIN;
        } else {
            return org.bukkit.Material.SCULK;
        }
    }
}
