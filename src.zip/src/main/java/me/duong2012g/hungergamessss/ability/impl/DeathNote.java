package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Death Note — S-Tier legendary book.
 *
 * USAGE: Hold Death Note in main hand, then type "/dn <username>" in chat.
 *
 * MECHANICS:
 *   - Instantly kills the named player (bypass armor, potions, totem of undying).
 *   - Cooldown: 25 seconds per target (cannot write the same name twice quickly).
 *   - Uses: 3 total. After 3 kills, the book is destroyed (removed from inventory).
 *   - Range: Global — target can be anywhere on the map.
 *   - Team-safe: cannot write a teammate's name.
 *   - Target must be alive, in the same arena, and currently playing.
 *
 * Uses are stored in the item's PersistentDataContainer so they survive
 * plugin reloads and are not reset by item stacking.
 */
public class DeathNote extends BaseAbility {

    // PDC key storing remaining uses on the book item
    public final NamespacedKey USES_KEY;

    private static final int DEFAULT_MAX_USES      = 3;
    private static final long DEFAULT_TARGET_CD_MS = 25_000L;

    // Per-writer: map of targetUUID → last-write timestamp (25s cooldown per target)
    private final Map<UUID, Map<UUID, Long>> targetCooldowns = new ConcurrentHashMap<>();

    public DeathNote(Main plugin) {
        super(plugin);
        this.USES_KEY = new NamespacedKey(plugin, "death_note_uses");
    }

    @Override public String getName()     { return "Death Note"; }
    @Override public long   getCooldown() { return 0; }

    private int  maxUses()     { return getConfigInt ("max_uses",    DEFAULT_MAX_USES);      }
    private long targetCdMs()  { return getConfigLong("target_cooldown_ms", DEFAULT_TARGET_CD_MS); }

    // ── Called by DeathNoteCommand when player types /dn <name> ──────────────

    /**
     * Attempts to execute a Death Note kill.
     * Returns true if the kill was executed; false otherwise (with feedback sent to writer).
     */
    public boolean executeKill(Player writer, String targetName) {
        // 1. Writer must be in an active arena holding the Death Note
        Arena arena = plugin.getArenaManager().getArenaByPlayer(writer);
        if (arena == null || (arena.getState() != MatchState.PLAYING
                && arena.getState() != MatchState.DEATHMATCH)) {
            writer.sendMessage("§8[§0☠ §8Death Note§8] §cYou must be in an active match.");
            return false;
        }

        ItemStack note = getHeldNote(writer);
        if (note == null) {
            writer.sendMessage("§8[§0☠ §8Death Note§8] §cYou must hold the Death Note in your main hand.");
            return false;
        }

        // 2. Check remaining uses
        int uses = getRemainingUses(note);
        if (uses <= 0) {
            writer.sendMessage("§8[§0☠ §8Death Note§8] §cThis Death Note has no uses remaining.");
            return false;
        }

        // 3. Find target in same arena
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null || !target.isOnline()) {
            writer.sendMessage("§8[§0☠ §8Death Note§8] §c'" + targetName + "' is not online.");
            return false;
        }
        if (target.equals(writer)) {
            writer.sendMessage("§8[§0☠ §8Death Note§8] §cYou cannot write your own name.");
            return false;
        }
        if (plugin.getTeamManager().isFriendlyFire(writer, target)) {
            writer.sendMessage("§8[§0☠ §8Death Note§8] §cYou cannot write a teammate's name.");
            return false;
        }
        Arena targetArena = plugin.getArenaManager().getArenaByPlayer(target);
        if (targetArena == null || !targetArena.getName().equals(arena.getName())) {
            writer.sendMessage("§8[§0☠ §8Death Note§8] §c'" + targetName + "' is not in your arena.");
            return false;
        }
        if (!arena.getGamePlayer(target.getUniqueId()).isAlive()) {
            writer.sendMessage("§8[§0☠ §8Death Note§8] §c'" + targetName + "' is already dead.");
            return false;
        }

        // 4. Per-target cooldown check
        Map<UUID, Long> myCDs = targetCooldowns.computeIfAbsent(writer.getUniqueId(), k -> new ConcurrentHashMap<>());
        Long lastWrite = myCDs.get(target.getUniqueId());
        if (lastWrite != null && System.currentTimeMillis() - lastWrite < targetCdMs()) {
            long rem = (targetCdMs() - (System.currentTimeMillis() - lastWrite)) / 1000L;
            writer.sendMessage("§8[§0☠ §8Death Note§8] §cMust wait §f" + rem + "s §cbefore writing "
                    + target.getName() + " again.");
            return false;
        }

        // 5. Execute kill
        myCDs.put(target.getUniqueId(), System.currentTimeMillis());
        consumeUse(writer, note, uses);
        killTarget(writer, target);
        return true;
    }

    private void killTarget(Player writer, Player target) {
        // Broadcast dramatic message to arena
        Arena arena = plugin.getArenaManager().getArenaByPlayer(writer);
        String broadcastMsg = "§8[§0☠§8] §f" + target.getName()
                + "'s §7name was written in the Death Note by §f" + writer.getName() + "§7.";
        if (arena != null) {
            for (UUID uuid : arena.getPlayers()) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null) {
                    p.sendMessage(broadcastMsg);
                    p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.6f, 0.5f);
                }
            }
        }

        // Target warning
        target.sendMessage("§4§l§k||§r §0§l☠ YOUR NAME WAS WRITTEN §4§l§k||");
        target.sendMessage("§8[§0☠§8] §cYou have been condemned by the Death Note.");
        target.playSound(target.getLocation(), Sound.ENTITY_WARDEN_DEATH, 1.0f, 0.5f);
        target.getWorld().spawnParticle(Particle.LARGE_SMOKE,
                target.getLocation().add(0, 1, 0), 50, 0.5, 1.0, 0.5, 0.05);
        target.getWorld().spawnParticle(Particle.SOUL,
                target.getLocation().add(0, 1, 0), 30, 0.5, 1.0, 0.5, 0.08);

        // Brief delay (2 ticks) for the dramatic effect, then instant kill
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!target.isOnline() || target.isDead()) return;
                // Bypass totem of undying: set to 0 health directly with noDamageTicks=0
                target.setNoDamageTicks(0);
                target.setAbsorptionAmount(0);
                target.setHealth(0); // Instant kill — bypasses armor calculation entirely
            }
        }.runTaskLater(plugin, 2L);
    }

    // ── Uses tracking via item PDC ────────────────────────────────────────────

    public int getRemainingUses(ItemStack note) {
        if (!note.hasItemMeta()) return maxUses();
        ItemMeta meta = note.getItemMeta();
        if (!meta.getPersistentDataContainer().has(USES_KEY, PersistentDataType.INTEGER)) {
            return maxUses(); // freshly crafted note
        }
        return meta.getPersistentDataContainer().get(USES_KEY, PersistentDataType.INTEGER);
    }

    private void consumeUse(Player writer, ItemStack note, int currentUses) {
        int remaining = currentUses - 1;
        ItemMeta meta = note.getItemMeta();

        if (remaining <= 0) {
            // Destroy the book — dramatic animation then remove
            writer.sendMessage("§8[§0☠§8] §7The Death Note crumbles to ash... §8(0 uses remaining)");
            writer.getWorld().spawnParticle(Particle.ASH, writer.getLocation().add(0, 1, 0),
                    60, 0.4, 0.5, 0.4, 0.05);
            writer.getWorld().playSound(writer.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1.0f, 0.4f);
            // Remove from inventory
            note.setAmount(0);
        } else {
            // Update uses in PDC
            meta.getPersistentDataContainer().set(USES_KEY, PersistentDataType.INTEGER, remaining);
            // Update lore to show remaining uses
            updateUsesLore(meta, remaining);
            note.setItemMeta(meta);
            writer.sendMessage("§8[§0☠§8] §7Death Note: §c" + remaining + " §7use"
                    + (remaining == 1 ? "" : "s") + " remaining.");
        }
    }

    private void updateUsesLore(ItemMeta meta, int remaining) {
        java.util.List<net.kyori.adventure.text.Component> lore =
                meta.hasLore() ? meta.lore() : new java.util.ArrayList<>();
        if (lore == null) lore = new java.util.ArrayList<>();

        // Remove old uses line
        net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer plain =
                net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText();
        lore.removeIf(c -> plain.serialize(c).contains("Uses remaining:"));

        // Add updated line
        String usesStr = remaining == 1
                ? "§c§lLAST USE remaining: §f" + remaining + "/3"
                : "§7Uses remaining: §c" + remaining + "§7/3";
        lore.add(me.duong2012g.hungergamessss.util.ColorUtil.component(usesStr));
        meta.lore(lore);
    }

    // ── Passive tick: show uses in action bar ─────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;
        int uses = getRemainingUses(item);
        String usesColor = uses == 1 ? "§c" : uses == 2 ? "§e" : "§a";
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§0☠ §7Death Note — " + usesColor + uses + " §7use"
                + (uses == 1 ? "" : "s") + " §8| §7Type §f/dn <name> §7to kill"));
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private ItemStack getHeldNote(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();
        if (AbilityManager.isAbilityItem(item, getName())) return item;
        return null;
    }

    /**
     * FIX BUG-DN-01: replaced direct onQuit() / onDeath() overrides with
     * performQuit() / performDeath(). The former bypassed BaseAbility entirely;
     * the latter integrate with the validated lifecycle chain and ensure
     * cleanup always runs through the same code path as every other ability.
     */
    @Override
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        targetCooldowns.remove(player.getUniqueId());
    }

    @Override
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        targetCooldowns.remove(player.getUniqueId());
    }

    @Override
    public void cleanup() {
        targetCooldowns.clear();
    }
}
