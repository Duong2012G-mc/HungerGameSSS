package me.duong2012g.hungergamessss.ability.annotation;

import me.duong2012g.hungergamessss.ability.TriggerType;

import java.lang.annotation.*;

/**
 * A1-S2: Marks a method as a trigger handler for a specific {@link TriggerType}.
 *
 * <p>In the current implementation this annotation is <em>documentation-only</em>
 * — it does not replace the {@link me.duong2012g.hungergamessss.ability.BaseAbility}
 * dispatch map at runtime. A future APT (Annotation Processing Tool) pass can
 * generate the registry boilerplate automatically using this annotation.
 *
 * <h3>Usage</h3>
 * <pre>{@code
 * public class MyAbility extends BaseAbility implements Ability.ActiveAbility {
 *
 *     @AbilityTrigger(TriggerType.RIGHT_CLICK)
 *     protected void performRightClick(Player p, ItemStack item, PlayerInteractEvent e) {
 *         // …
 *     }
 *
 *     @AbilityTrigger(TriggerType.HIT)
 *     protected void performHit(Player attacker, LivingEntity victim,
 *                               ItemStack item, EntityDamageByEntityEvent e) {
 *         // …
 *     }
 * }
 * }</pre>
 *
 * <h3>Future APT integration</h3>
 * An annotation processor can read {@code @AbilityTrigger} and generate:
 * <ol>
 *   <li>A {@code META-INF/services/…Ability} SPI entry for each annotated class.</li>
 *   <li>A compile-time check that the method signature matches the expected parameters
 *       for the declared {@link TriggerType}.</li>
 *   <li>Automatic {@code dispatchMap} entries so abilities don't need to override
 *       the {@code performXxx} methods at all.</li>
 * </ol>
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface AbilityTrigger {

    /** The trigger type this method handles. */
    TriggerType value();

    /**
     * If {@code true}, this method runs even when the ability is on cooldown.
     * Useful for methods that only display feedback (e.g. action bar) without
     * consuming a charge.
     */
    boolean ignoreCooldown() default false;

    /**
     * Priority within the same trigger type when multiple methods could handle it.
     * Lower values run first. Matches Bukkit's {@code EventPriority} convention.
     */
    int priority() default 50;
}
