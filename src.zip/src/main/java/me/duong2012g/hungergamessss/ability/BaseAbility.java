package me.duong2012g.hungergamessss.ability;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.event.player.PlayerInteractEvent;

public abstract class BaseAbility implements Ability {
    protected final Main plugin;

    public BaseAbility(Main plugin) {
        this.plugin = plugin;
    }

    /**
     * Gets a configuration value for this specific ability.
     * Path: abilities.[ability_name].[key]
     */
    protected String getConfigString(String key, String defaultValue) {
        return plugin.getConfig().getString("abilities." + getName().toLowerCase().replace(" ", "_") + "." + key, defaultValue);
    }

    protected int getConfigInt(String key, int defaultValue) {
        return plugin.getConfig().getInt("abilities." + getName().toLowerCase().replace(" ", "_") + "." + key, defaultValue);
    }

    protected double getConfigDouble(String key, double defaultValue) {
        return plugin.getConfig().getDouble("abilities." + getName().toLowerCase().replace(" ", "_") + "." + key, defaultValue);
    }

    protected long getConfigLong(String key, long defaultValue) {
        return plugin.getConfig().getLong("abilities." + getName().toLowerCase().replace(" ", "_") + "." + key, defaultValue);
    }

    protected boolean getConfigBoolean(String key, boolean defaultValue) {
        return plugin.getConfig().getBoolean("abilities." + getName().toLowerCase().replace(" ", "_") + "." + key, defaultValue);
    }

    // --- Template Methods (Framework) ---

    @Override
    public void execute(AbilityContext ctx) {
        org.bukkit.entity.Player caster = ctx.getCaster() != null ? org.bukkit.Bukkit.getPlayer(ctx.getCaster()) : null;
        if (caster == null && ctx.getTrigger() != TriggerType.ENTITY_CHANGE_BLOCK && ctx.getTrigger() != TriggerType.ENTITY_TARGET && ctx.getTrigger() != TriggerType.ENTITY_DAMAGE) {
            return;
        }

        try {
            switch (ctx.getTrigger()) {
                case RIGHT_CLICK:
                    if (ctx.getEvent() instanceof org.bukkit.event.player.PlayerInteractEvent e) {
                        onRightClick(caster, ctx.getItem(), e);
                    }
                    break;
                case LEFT_CLICK:
                    if (ctx.getEvent() instanceof org.bukkit.event.player.PlayerInteractEvent e) {
                        onLeftClick(caster, ctx.getItem(), e);
                    }
                    break;
                case HIT:
                    if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityDamageByEntityEvent e && ctx.getTarget() != null) {
                        org.bukkit.entity.Entity target = org.bukkit.Bukkit.getEntity(ctx.getTarget());
                        if (target instanceof org.bukkit.entity.LivingEntity le) {
                            onHit(caster, le, ctx.getItem(), e);
                        }
                    }
                    break;
                case PROJECTILE_LAUNCH:
                    if (ctx.getEvent() instanceof org.bukkit.event.entity.ProjectileLaunchEvent e && e.getEntity() instanceof org.bukkit.entity.Projectile p) {
                        onProjectileLaunch(caster, p, ctx.getItem());
                    } else if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityShootBowEvent e && e.getProjectile() instanceof org.bukkit.entity.Projectile p) {
                        onProjectileLaunch(caster, p, ctx.getItem());
                    }
                    break;
                case PROJECTILE_HIT:
                    if (ctx.getEvent() instanceof org.bukkit.event.entity.ProjectileHitEvent e) {
                        onProjectileHit(e.getEntity(), e);
                    }
                    break;
                case SNEAK:
                    if (ctx.getEvent() instanceof org.bukkit.event.player.PlayerToggleSneakEvent e) {
                        onSneak(caster, ctx.getItem(), e);
                    }
                    break;
                case DAMAGED:
                    if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityDamageEvent e) {
                        onDamaged(caster, ctx.getItem(), e);
                    }
                    break;
                case DEATH:
                    if (ctx.getEvent() instanceof org.bukkit.event.entity.PlayerDeathEvent e) {
                        onDeath(caster, e);
                    }
                    break;
                case QUIT:
                    if (ctx.getEvent() instanceof org.bukkit.event.player.PlayerQuitEvent e) {
                        onQuit(caster, e);
                    }
                    break;
                case ENTITY_CHANGE_BLOCK:
                    if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityChangeBlockEvent e) {
                        onEntityChangeBlock(e.getEntity(), e);
                    }
                    break;
                case ENTITY_TARGET:
                    if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityTargetEvent e) {
                        onEntityTarget(e.getEntity(), e);
                    }
                    break;
                case ENTITY_DAMAGE:
                    if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityDamageEvent e) {
                        onEntityDamage(e.getEntity(), e);
                    }
                    break;
                case MOVE:
                    if (ctx.getEvent() instanceof org.bukkit.event.player.PlayerMoveEvent e) {
                        onMove(caster, ctx.getItem(), e);
                    }
                    break;
            }
        } catch (Exception e) {
            plugin.getLogger().severe("Error executing ability " + getName() + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void onRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        boolean debug = plugin.getConfig().getBoolean("debug", false);
        if (debug) plugin.getLogger().info("[Ability] onRightClick called for " + getName() + " by " + player.getName());
        
        // 1. Validate Permission/State
        if (!validateCanUse(player)) {
            return;
        }

        // 2. XP Cost Check (B-03)
        int xpCost = getConfigInt("xp-cost", 0);
        if (xpCost > 0 && player.getLevel() < xpCost && !player.isOp()) {
            player.sendMessage(plugin.getMessageManager().getMessage("not_enough_xp", 
                java.util.Map.of("cost", String.valueOf(xpCost))));
            return;
        }

        // 3. Enforce Cooldown (Priority: config.yml -> hardcoded getCooldown())
        long cooldown = getConfigLong("cooldown", getCooldown());
        if (cooldown > 0) {
            if (checkCooldown(player, item, cooldown)) {
                if (debug) plugin.getLogger().info("[Ability] Cooldown BLOCKED for " + player.getName() + " on " + getName());
                return;
            }
        }

        // 4. Deduct XP
        if (xpCost > 0 && !player.isOp()) {
            player.setLevel(player.getLevel() - xpCost);
        }

        // 5. Delegate to Logic
        if (debug) plugin.getLogger().info("[Ability] Executing performRightClick for " + getName());
        performRightClick(player, item, event);
    }

    /**
     * Override this method to implement right-click logic.
     * Permission and Cooldown are already checked.
     */
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {}

    @Override
    public void onLeftClick(Player player, ItemStack item, PlayerInteractEvent event) {
        if (!validateCanUse(player)) return;
        // Left click should NOT trigger cooldown by default
        performLeftClick(player, item, event);
    }
    protected void performLeftClick(Player player, ItemStack item, PlayerInteractEvent event) {}

    @Override
    public void onHit(Player attacker, org.bukkit.entity.LivingEntity victim, ItemStack item, org.bukkit.event.entity.EntityDamageByEntityEvent event) {
        if (!validateCanUse(attacker)) return;
        // Hit should NOT trigger cooldown by default (usually a passive or special effect)
        performHit(attacker, victim, item, event);
    }
    protected void performHit(Player attacker, org.bukkit.entity.LivingEntity victim, ItemStack item, org.bukkit.event.entity.EntityDamageByEntityEvent event) {}

    @Override
    public void onProjectileLaunch(Player shooter, org.bukkit.entity.Projectile projectile, ItemStack item) {
        if (!validateCanUse(shooter)) return;
        // Projectile launch often has its own logic, don't block by default unless needed
        performProjectileLaunch(shooter, projectile, item);
    }
    protected void performProjectileLaunch(Player shooter, org.bukkit.entity.Projectile projectile, ItemStack item) {}

    @Override
    public void onProjectileHit(org.bukkit.entity.Projectile projectile, org.bukkit.event.entity.ProjectileHitEvent event) {
        if (projectile.getShooter() instanceof Player player) {
            if (!validateCanUse(player)) return;
            performProjectileHit(projectile, event);
        }
    }
    protected void performProjectileHit(org.bukkit.entity.Projectile projectile, org.bukkit.event.entity.ProjectileHitEvent event) {}

    @Override
    public void onRiptide(Player player, ItemStack item, org.bukkit.event.player.PlayerRiptideEvent event) {
        if (!validateCanUse(player)) return;
        performRiptide(player, item, event);
    }
    protected void performRiptide(Player player, ItemStack item, org.bukkit.event.player.PlayerRiptideEvent event) {}

    @Override
    public void onSneak(Player player, ItemStack item, org.bukkit.event.player.PlayerToggleSneakEvent event) {
        if (!validateCanUse(player)) return;
        performSneak(player, item, event);
    }
    protected void performSneak(Player player, ItemStack item, org.bukkit.event.player.PlayerToggleSneakEvent event) {}

    @Override
    public void onDamaged(Player victim, ItemStack item, org.bukkit.event.entity.EntityDamageEvent event) {
        if (!validateCanUse(victim)) return;
        performDamaged(victim, item, event);
    }
    protected void performDamaged(Player victim, ItemStack item, org.bukkit.event.entity.EntityDamageEvent event) {}

    @Override
    public void onDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        // Validation?
        if (!validateCanUse(player)) return;
        performDeath(player, event);
    }
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {}

    @Override
    public void onQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        // No validation needed for quit cleanup
        performQuit(player, event);
    }
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {}

    @Override
    public void onEntityChangeBlock(org.bukkit.entity.Entity entity, org.bukkit.event.entity.EntityChangeBlockEvent event) {
        // No player to validate easily
        performEntityChangeBlock(entity, event);
    }
    protected void performEntityChangeBlock(org.bukkit.entity.Entity entity, org.bukkit.event.entity.EntityChangeBlockEvent event) {}

    @Override
    public void onEntityTarget(org.bukkit.entity.Entity entity, org.bukkit.event.entity.EntityTargetEvent event) {
        performEntityTarget(entity, event);
    }
    protected void performEntityTarget(org.bukkit.entity.Entity entity, org.bukkit.event.entity.EntityTargetEvent event) {}

    @Override
    public void onMove(Player player, ItemStack item, org.bukkit.event.player.PlayerMoveEvent event) {
        if (!validateCanUse(player)) return;
        performMove(player, item, event);
    }
    protected void performMove(Player player, ItemStack item, org.bukkit.event.player.PlayerMoveEvent event) {}

    // ... (Other hooks like onLeftClick, onHit can be added similarly later) ...

    /**
     * Checks if the player can use the ability (Arena, GameState, Spectator).
     * This enforces the game logic protection (Fix II.3, I.1).
     */
    protected boolean validateCanUse(Player player) {
        boolean debug = plugin.getConfig().getBoolean("debug", false);

        // 0. Admin Bypass for Testing
        if (player.hasPermission("hoplitebr.admin") || player.isOp()) {
            if (debug) plugin.getLogger().info("[Ability] validateCanUse: " + player.getName() + " has admin permission → BYPASSING CHECKS");
            return true;
        }

        // 1. Check Arena
        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        if (arena == null) {
            if (debug) plugin.getLogger().info("[Ability] validateCanUse: " + player.getName() + " is NOT in any arena → BLOCKED");
            return false; // Not in arena, can't use
        }
        
        // 2. Check Game State
        if (arena.getState() != MatchState.PLAYING && arena.getState() != MatchState.DEATHMATCH) {
            if (debug) plugin.getLogger().info("[Ability] validateCanUse: " + player.getName() + " arena state is " + arena.getState() + " → BLOCKED");
            return false;
        }
        
        // 3. Check Spectator
        if (arena.getSpectators().contains(player.getUniqueId())) {
            if (debug) plugin.getLogger().info("[Ability] validateCanUse: " + player.getName() + " is a spectator → BLOCKED");
            return false;
        }
        
        if (debug) plugin.getLogger().info("[Ability] validateCanUse: " + player.getName() + " PASSED all checks");
        return true;
    }

    /**
     * Checks cooldown and permissions. Returns true if BLOCKED (on cooldown or invalid).
     * Usage: if (checkCooldown(player, item)) return;
     */
    protected boolean checkCooldown(Player player, ItemStack item) {
        return checkCooldown(player, item, getCooldown());
    }

    protected boolean checkCooldown(Player player, ItemStack item, long cooldownValue) {
        String displayName = (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) 
                ? item.getItemMeta().getDisplayName() 
                : getName();

        if (plugin.getCooldownManager().isOnCooldown(player, getName())) {
            // Optional: Send cooldown message here if manager doesn't
            long timeLeft = plugin.getCooldownManager().getCooldown(player, getName());
            player.sendMessage(plugin.getMessageManager().getMessage("cooldown_msg",
                java.util.Map.of("ability", getName(), "time", String.format("%.1f", timeLeft / 1000.0))));
            return true;
        }
        
        // Set new cooldown
        plugin.getCooldownManager().setCooldown(player, getName(), displayName, cooldownValue);
        return false;
    }

    @Deprecated
    protected boolean checkCooldown(Player player) {
        return checkCooldown(player, null);
    }

    // -----------------------------------------------------------------------
    // M-01: Unified passive tick hook
    // -----------------------------------------------------------------------

    /**
     * Called by the single global passive ticker in AbilityManager every 20 ticks
     * for each player that is holding or wearing this ability item in an active arena.
     *
     * Abilities that previously spawned their own BukkitRunnable for passive effects
     * should override this method instead. The override should NOT schedule another
     * BukkitRunnable — just perform the per-player passive logic directly.
     *
     * The default implementation is a no-op so existing abilities that have not yet
     * been migrated continue to work via their own task (they will be removed in a
     * future cleanup pass).
     *
     * @param player the arena player currently holding / wearing this ability
     * @param item   the ability ItemStack (main-hand or armour slot)
     */
    public void passiveTick(Player player, ItemStack item) {
        // Default: no-op. Override in passive abilities.
    }
}
