package me.duong2012g.hungergamessss.ability;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.Consumer;

public abstract class BaseAbility implements Ability {
    protected final Main plugin;
    private final String configKeyPrefix;
    /** A1-S1: optional typed DI context — null when constructed via legacy Main constructor. */
    protected final AbilityServices svc;

    /** Legacy constructor — kept for backwards compatibility with all existing abilities. */
    public BaseAbility(Main plugin) {
        this.plugin = plugin;
        this.svc    = AbilityServices.of(plugin);
        this.configKeyPrefix = "abilities." + getName().toLowerCase().replace(" ", "_") + ".";
        buildDispatchMap();
    }

    /**
     * A1-S1: Preferred constructor for new abilities — accepts the typed DI context.
     * Existing abilities can migrate at their own pace.
     */
    public BaseAbility(AbilityServices svc) {
        this.svc    = svc;
        this.plugin = svc.plugin();
        this.configKeyPrefix = "abilities." + getName().toLowerCase().replace(" ", "_") + ".";
        buildDispatchMap();
    }

    // OPT-BASE-02: Map-based dispatch — EnumMap O(1), built once in constructor.
    private final EnumMap<TriggerType, Consumer<AbilityContext>> dispatchMap = new EnumMap<>(TriggerType.class);

    private void buildDispatchMap() {
        dispatchMap.put(TriggerType.RIGHT_CLICK, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.player.PlayerInteractEvent e)
                onRightClick(ctx.getCasterPlayer(), ctx.getItem(), e);
        });
        dispatchMap.put(TriggerType.LEFT_CLICK, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.player.PlayerInteractEvent e)
                onLeftClick(ctx.getCasterPlayer(), ctx.getItem(), e);
        });
        dispatchMap.put(TriggerType.HIT, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityDamageByEntityEvent e
                    && ctx.getTarget() != null) {
                org.bukkit.entity.Entity target = org.bukkit.Bukkit.getEntity(ctx.getTarget());
                if (target instanceof org.bukkit.entity.LivingEntity le)
                    onHit(ctx.getCasterPlayer(), le, ctx.getItem(), e);
            }
        });
        dispatchMap.put(TriggerType.PROJECTILE_LAUNCH, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.entity.ProjectileLaunchEvent e
                    && e.getEntity() instanceof org.bukkit.entity.Projectile p)
                onProjectileLaunch(ctx.getCasterPlayer(), p, ctx.getItem());
            else if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityShootBowEvent e
                    && e.getProjectile() instanceof org.bukkit.entity.Projectile p)
                onProjectileLaunch(ctx.getCasterPlayer(), p, ctx.getItem());
        });
        dispatchMap.put(TriggerType.PROJECTILE_HIT, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.entity.ProjectileHitEvent e)
                onProjectileHit(e.getEntity(), e);
        });
        dispatchMap.put(TriggerType.SNEAK, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.player.PlayerToggleSneakEvent e)
                onSneak(ctx.getCasterPlayer(), ctx.getItem(), e);
        });
        dispatchMap.put(TriggerType.DAMAGED, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityDamageEvent e)
                onDamaged(ctx.getCasterPlayer(), ctx.getItem(), e);
        });
        dispatchMap.put(TriggerType.DEATH, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.entity.PlayerDeathEvent e)
                onDeath(ctx.getCasterPlayer(), e);
        });
        dispatchMap.put(TriggerType.QUIT, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.player.PlayerQuitEvent e)
                onQuit(ctx.getCasterPlayer(), e);
        });
        dispatchMap.put(TriggerType.ENTITY_CHANGE_BLOCK, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityChangeBlockEvent e)
                onEntityChangeBlock(e.getEntity(), e);
        });
        dispatchMap.put(TriggerType.ENTITY_TARGET, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityTargetEvent e)
                onEntityTarget(e.getEntity(), e);
        });
        dispatchMap.put(TriggerType.ENTITY_DAMAGE, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.entity.EntityDamageEvent e)
                onEntityDamage(e.getEntity(), e);
        });
        dispatchMap.put(TriggerType.MOVE, ctx -> {
            if (ctx.getEvent() instanceof org.bukkit.event.player.PlayerMoveEvent e)
                onMove(ctx.getCasterPlayer(), ctx.getItem(), e);
        });
    }

    /**
     * Gets a configuration value for this specific ability.
     * Path: abilities.[ability_name].[key]
     */
    protected String getConfigString(String key, String defaultValue) {
        return plugin.getConfig().getString(configKeyPrefix + key, defaultValue);
    }

    protected int getConfigInt(String key, int defaultValue) {
        return plugin.getConfig().getInt(configKeyPrefix + key, defaultValue);
    }

    protected double getConfigDouble(String key, double defaultValue) {
        return plugin.getConfig().getDouble(configKeyPrefix + key, defaultValue);
    }

    protected long getConfigLong(String key, long defaultValue) {
        return plugin.getConfig().getLong(configKeyPrefix + key, defaultValue);
    }

    protected boolean getConfigBoolean(String key, boolean defaultValue) {
        return plugin.getConfig().getBoolean(configKeyPrefix + key, defaultValue);
    }

    /**
     * A1-18: Returns a {@code List<String>} config value for this ability.
     * Falls back to {@code defaultValue} if the key is absent or not a list.
     *
     * <pre>{@code
     * List<String> biomes = getConfigList("allowed_biomes", List.of("PLAINS", "FOREST"));
     * }</pre>
     */
    @SuppressWarnings("unchecked")
    protected java.util.List<String> getConfigStringList(String key, java.util.List<String> defaultValue) {
        String path = configKeyPrefix + key;
        if (!plugin.getConfig().contains(path)) return defaultValue;
        java.util.List<?> raw = plugin.getConfig().getList(path);
        if (raw == null) return defaultValue;
        java.util.List<String> result = new java.util.ArrayList<>();
        for (Object o : raw) result.add(String.valueOf(o));
        return result;
    }

    /**
     * A1-18: Returns a {@code Map<String, Object>} config section for this ability.
     * Useful for abilities that accept variable-length key-value parameters
     * (e.g. per-mode damage values, named-phase timers).
     * Returns an empty map if the section is absent.
     *
     * <pre>{@code
     * Map<String, Object> phases = getConfigSection("phases");
     * int phase1Damage = (int) phases.getOrDefault("phase1_damage", 10);
     * }</pre>
     */
    protected java.util.Map<String, Object> getConfigSection(String key) {
        String path = configKeyPrefix + key;
        org.bukkit.configuration.ConfigurationSection section = plugin.getConfig().getConfigurationSection(path);
        return section != null ? section.getValues(false) : java.util.Collections.emptyMap();
    }

    // --- Template Methods (Framework) ---

    @Override
    public void execute(AbilityContext ctx) {
        // OPT-BASE-02: single EnumMap lookup replaces 14-arm switch-case
        org.bukkit.entity.Player caster = ctx.getCasterPlayer();
        boolean needsCaster = ctx.getTrigger() != TriggerType.ENTITY_CHANGE_BLOCK
                && ctx.getTrigger() != TriggerType.ENTITY_TARGET
                && ctx.getTrigger() != TriggerType.ENTITY_DAMAGE;
        if (caster == null && needsCaster) return;

        Consumer<AbilityContext> handler = dispatchMap.get(ctx.getTrigger());
        if (handler == null) {
            if (plugin.getConfig().getBoolean("debug", false)) {
                plugin.getLogger().warning("[AbilityDispatch] No handler for trigger "
                        + ctx.getTrigger() + " in ability " + getName());
            }
            return;
        }
        try {
            handler.accept(ctx);
        } catch (Exception e) {
            plugin.getLogger().severe("[Ability] Error in " + getName()
                    + " trigger=" + ctx.getTrigger() + ": " + e.getMessage());
            if (plugin.getConfig().getBoolean("debug", false)) e.printStackTrace();
        }
    }

    // ── A1-17: Chain-of-Responsibility for pre-execution guards ──────────────
    //
    // Each "guard" is a Predicate<Player> that returns true to ALLOW execution.
    // They run in order; the first one returning false short-circuits the chain.
    //
    // Default chain (applied to all active triggers): arena → state → spectator → cooldown.
    // Abilities can append custom guards via addGuard() in their constructor.
    // Individual hooks can also call executeWithGuards() to inherit the full chain.

    @FunctionalInterface
    public interface AbilityGuard {
        /**
         * @param player the player trying to use the ability
         * @param item   the item being used (may be null for non-item triggers)
         * @return {@code true} to allow execution, {@code false} to block it
         */
        boolean allows(Player player, ItemStack item);
    }

    private final java.util.List<AbilityGuard> guards = new java.util.ArrayList<>();

    /**
     * Appends a custom guard to the chain.
     * Guards run after the built-in arena/state/spectator/cooldown checks.
     * Call from the ability's constructor.
     *
     * <pre>{@code
     * public MyAbility(Main plugin) {
     *     super(plugin);
     *     // Only allow use when the player is on the ground
     *     addGuard((p, item) -> p.isOnGround());
     * }
     * }</pre>
     */
    protected void addGuard(AbilityGuard guard) {
        guards.add(java.util.Objects.requireNonNull(guard));
    }

    /**
     * Runs the full guard chain for an active trigger (validate → xpCost → cooldown →
     * custom guards). Returns {@code true} if all guards pass (i.e. execution is allowed).
     * Handles messaging and cooldown registration when successful.
     *
     * <p>Replaces the duplicated validate/xp/cooldown boilerplate in onRightClick,
     * onLeftClick, onSneak, and onMove.
     */
    protected boolean passesGuards(Player player, ItemStack item) {
        // 1. Arena / state / spectator
        if (!validateCanUse(player)) {
            AbilityMetrics.recordBlocked(getName()); // A1-S5
            return false;
        }

        // 2. XP cost
        int xpCost = getConfigInt("xp-cost", 0);
        if (xpCost > 0 && !player.isOp()) {
            if (player.getLevel() < xpCost) {
                player.sendMessage(plugin.getMessageManager().getMessage("not_enough_xp",
                        java.util.Map.of("cost", String.valueOf(xpCost))));
                AbilityMetrics.recordBlocked(getName()); // A1-S5
                return false;
            }
            player.setLevel(player.getLevel() - xpCost);
        }

        // 3. Cooldown
        long cooldown = getConfigLong("cooldown", getCooldown());
        if (cooldown > 0 && checkCooldown(player, item, cooldown)) {
            AbilityMetrics.recordBlocked(getName()); // A1-S5
            return false;
        }

        // 4. Custom guards
        for (AbilityGuard g : guards) {
            if (!g.allows(player, item)) {
                AbilityMetrics.recordBlocked(getName()); // A1-S5
                return false;
            }
        }
        AbilityMetrics.recordActivation(getName()); // A1-S5
        return true;
    }


    @Override
    public void onRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        if (plugin.getConfig().getBoolean("debug", false))
            plugin.getLogger().info("[Ability] onRightClick: " + getName() + " → " + player.getName());
        // A1-17: single passesGuards() call replaces repeated validate/xp/cooldown blocks
        if (!passesGuards(player, item)) return;
        performRightClick(player, item, event);
    }

    /**
     * Override to implement right-click logic.
     * Arena state, spectator check, XP cost, and cooldown are already enforced.
     */
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {}

    @Override
    public void onLeftClick(Player player, ItemStack item, PlayerInteractEvent event) {
        if (!validateCanUse(player)) return;
        // Left click should NOT trigger cooldown by default
        performLeftClick(player, item, event);
    }
    protected void performLeftClick(Player player, ItemStack item, PlayerInteractEvent event) {}

    @Override
    public void onHit(Player attacker, org.bukkit.entity.LivingEntity victim, ItemStack item, org.bukkit.event.entity.EntityDamageByEntityEvent event) {
        if (!validateCanUse(attacker)) return;
        // Hit should NOT trigger cooldown by default (usually a passive or special effect)
        performHit(attacker, victim, item, event);
    }
    protected void performHit(Player attacker, org.bukkit.entity.LivingEntity victim, ItemStack item, org.bukkit.event.entity.EntityDamageByEntityEvent event) {}

    @Override
    public void onProjectileLaunch(Player shooter, org.bukkit.entity.Projectile projectile, ItemStack item) {
        if (!validateCanUse(shooter)) return;
        // Projectile launch often has its own logic, don't block by default unless needed
        performProjectileLaunch(shooter, projectile, item);
    }
    protected void performProjectileLaunch(Player shooter, org.bukkit.entity.Projectile projectile, ItemStack item) {}

    @Override
    public void onProjectileHit(org.bukkit.entity.Projectile projectile, org.bukkit.event.entity.ProjectileHitEvent event) {
        if (projectile.getShooter() instanceof Player player) {
            if (!validateCanUse(player)) return;
            performProjectileHit(projectile, event);
        }
    }
    protected void performProjectileHit(org.bukkit.entity.Projectile projectile, org.bukkit.event.entity.ProjectileHitEvent event) {}

    @Override
    public void onRiptide(Player player, ItemStack item, org.bukkit.event.player.PlayerRiptideEvent event) {
        if (!validateCanUse(player)) return;
        performRiptide(player, item, event);
    }
    protected void performRiptide(Player player, ItemStack item, org.bukkit.event.player.PlayerRiptideEvent event) {}

    @Override
    public void onSneak(Player player, ItemStack item, org.bukkit.event.player.PlayerToggleSneakEvent event) {
        if (!validateCanUse(player)) return;
        performSneak(player, item, event);
    }
    protected void performSneak(Player player, ItemStack item, org.bukkit.event.player.PlayerToggleSneakEvent event) {}

    @Override
    public void onDamaged(Player victim, ItemStack item, org.bukkit.event.entity.EntityDamageEvent event) {
        if (!validateCanUse(victim)) return;
        performDamaged(victim, item, event);
    }
    protected void performDamaged(Player victim, ItemStack item, org.bukkit.event.entity.EntityDamageEvent event) {}

    @Override
    public void onDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {
        // FIX BUG-BASE-02: do NOT call validateCanUse() here.
        // When a player dies the arena state may already be ENDING (last kill triggers
        // state transition before death event fires), which caused validateCanUse() to
        // return false and skip cleanup — leaving lingering entities and state maps.
        // Death cleanup must always run regardless of arena state.
        performDeath(player, event);
    }
    protected void performDeath(Player player, org.bukkit.event.entity.PlayerDeathEvent event) {}

    @Override
    public void onQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {
        // No validation needed for quit cleanup
        performQuit(player, event);
    }
    protected void performQuit(Player player, org.bukkit.event.player.PlayerQuitEvent event) {}

    @Override
    public void onEntityChangeBlock(org.bukkit.entity.Entity entity, org.bukkit.event.entity.EntityChangeBlockEvent event) {
        // No player to validate easily
        performEntityChangeBlock(entity, event);
    }
    protected void performEntityChangeBlock(org.bukkit.entity.Entity entity, org.bukkit.event.entity.EntityChangeBlockEvent event) {}

    @Override
    public void onEntityTarget(org.bukkit.entity.Entity entity, org.bukkit.event.entity.EntityTargetEvent event) {
        performEntityTarget(entity, event);
    }
    protected void performEntityTarget(org.bukkit.entity.Entity entity, org.bukkit.event.entity.EntityTargetEvent event) {}

    @Override
    public void onMove(Player player, ItemStack item, org.bukkit.event.player.PlayerMoveEvent event) {
        if (!validateCanUse(player)) return;
        performMove(player, item, event);
    }
    protected void performMove(Player player, ItemStack item, org.bukkit.event.player.PlayerMoveEvent event) {}

    // ... (Other hooks like onLeftClick, onHit can be added similarly later) ...

    /**
     * Checks if the player can use the ability (Arena, GameState, Spectator).
     * This enforces the game logic protection (Fix II.3, I.1).
     */
    protected boolean validateCanUse(Player player) {
        boolean debug = plugin.getConfig().getBoolean("debug", false);

        // 0. Admin Bypass for Testing
        if (player.hasPermission("hoplitebr.admin") || player.isOp()) {
            if (debug) plugin.getLogger().info("[Ability] validateCanUse: " + player.getName() + " has admin permission → BYPASSING CHECKS");
            return true;
        }

        // 1. Check Arena
        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        if (arena == null) {
            if (debug) plugin.getLogger().info("[Ability] validateCanUse: " + player.getName() + " is NOT in any arena → BLOCKED");
            return false; // Not in arena, can't use
        }
        
        // 2. Check Game State
        if (arena.getState() != MatchState.PLAYING && arena.getState() != MatchState.DEATHMATCH) {
            if (debug) plugin.getLogger().info("[Ability] validateCanUse: " + player.getName() + " arena state is " + arena.getState() + " → BLOCKED");
            return false;
        }
        
        // 3. Check Spectator
        if (arena.getSpectators().contains(player.getUniqueId())) {
            if (debug) plugin.getLogger().info("[Ability] validateCanUse: " + player.getName() + " is a spectator → BLOCKED");
            return false;
        }
        
        if (debug) plugin.getLogger().info("[Ability] validateCanUse: " + player.getName() + " PASSED all checks");
        return true;
    }

    /**
     * Checks cooldown and permissions. Returns true if BLOCKED (on cooldown or invalid).
     * Usage: if (checkCooldown(player, item)) return;
     */
    protected boolean checkCooldown(Player player, ItemStack item) {
        return checkCooldown(player, item, getCooldown());
    }

    protected boolean checkCooldown(Player player, ItemStack item, long cooldownValue) {
        String displayName = (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) 
                ? item.getItemMeta().getDisplayName() 
                : getName();

        if (plugin.getCooldownManager().isOnCooldown(player, getName())) {
            // Optional: Send cooldown message here if manager doesn't
            long timeLeft = plugin.getCooldownManager().getCooldown(player, getName());
            player.sendMessage(plugin.getMessageManager().getMessage("cooldown_msg",
                java.util.Map.of("ability", getName(), "time", String.format("%.1f", timeLeft / 1000.0))));
            return true;
        }
        
        // Set new cooldown
        plugin.getCooldownManager().setCooldown(player, getName(), displayName, cooldownValue);
        return false;
    }

    @Deprecated
    protected boolean checkCooldown(Player player) {
        return checkCooldown(player, null);
    }

    // -----------------------------------------------------------------------
    // M-01: Unified passive tick hook
    // -----------------------------------------------------------------------

    /**
     * Called by the single global passive ticker in AbilityManager every 20 ticks
     * for each player that is holding or wearing this ability item in an active arena.
     *
     * Abilities that previously spawned their own BukkitRunnable for passive effects
     * should override this method instead. The override should NOT schedule another
     * BukkitRunnable — just perform the per-player passive logic directly.
     *
     * The default implementation is a no-op so existing abilities that have not yet
     * been migrated continue to work via their own task (they will be removed in a
     * future cleanup pass).
     *
     * @param player the arena player currently holding / wearing this ability
     * @param item   the ability ItemStack (main-hand or armour slot)
     */
    public void passiveTick(Player player, ItemStack item) {
        // Default: no-op. Override in passive abilities.
    }
}
