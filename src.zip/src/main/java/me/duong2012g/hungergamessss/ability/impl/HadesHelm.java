package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class HadesHelm extends BaseAbility {

    private static final int NIGHT_VISION_DURATION  = 240;
    private static final int INVISIBILITY_DURATION  = 40;
    private static final int WITHER_DURATION        = 100;
    private static final int WITHER_AMPLIFIER       = 1;

    public HadesHelm(Main plugin) {
        super(plugin);
        // FIX BUG-HH-02: removed standalone startPassive() BukkitRunnable.
        // Same root cause as BUG-AB-01 — each reload spawned a new parallel task.
        // Migrated to passiveTick() — driven by UnifiedPassiveTicker in AbilityManager.
    }

    @Override
    public String getName() { return "Hades' Helm"; }

    @Override
    public long getCooldown() {
        return getConfigLong("cooldown", 15000);
    }

    // Replaces the old startPassive() BukkitRunnable
    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(player.getInventory().getHelmet(), "hades_helm")) return;

        int nvDuration = getConfigInt("night_vision_duration", NIGHT_VISION_DURATION);
        player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, nvDuration, 0, false, false));

        if (player.isSneaking()) {
            int invisDuration = getConfigInt("sneak_invisibility_duration", INVISIBILITY_DURATION);
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, invisDuration, 0, false, false));
        }

        // Fire Aura
        double auraRadius = getConfigDouble("fire_aura_radius", 3.0);
        int fireTicks = getConfigInt("fire_aura_ticks", 40);
        for (org.bukkit.entity.Entity entity : player.getNearbyEntities(auraRadius, auraRadius, auraRadius)) {
            if (entity instanceof org.bukkit.entity.LivingEntity living && entity != player) {
                if (entity instanceof Player pTarget) {
                    if (plugin.getTeamManager().isFriendlyFire(player, pTarget)) continue;
                }
                living.setFireTicks(fireTicks);
                living.getWorld().spawnParticle(org.bukkit.Particle.FLAME, living.getLocation().add(0, 1, 0), 3, 0.2, 0.2, 0.2, 0.02);
            }
        }
    }

    @Override
    protected void performRightClick(Player player, ItemStack item, org.bukkit.event.player.PlayerInteractEvent event) {
        if (player.isSneaking()) {
            // Underworld Blink
            double blinkRange = getConfigDouble("blink_range", 15.0);
            org.bukkit.entity.Entity target = null;
            for (org.bukkit.entity.Entity e : player.getNearbyEntities(blinkRange, 10, blinkRange)) {
                if (e instanceof org.bukkit.entity.LivingEntity && e != player) {
                    if (e instanceof Player targetPlayer) {
                        if (plugin.getTeamManager().isFriendlyFire(player, targetPlayer)) continue;
                    }
                    target = e;
                    break;
                }
            }

            if (target != null) {
                org.bukkit.Location loc = target.getLocation().subtract(target.getLocation().getDirection().multiply(1.5));
                player.teleport(loc);
                int resDuration = getConfigInt("blink_resistance_duration", 40);
                int resAmp = getConfigInt("blink_resistance_amplifier", 4);
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, resDuration, resAmp));
                player.getWorld().spawnParticle(org.bukkit.Particle.SOUL_FIRE_FLAME, player.getLocation(), 20, 0.3, 0.5, 0.3, 0.05);
                player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.5f);
                player.sendMessage("§b[Hades] §7Teleported through the underworld!");
            }
        }
    }

    @Override
    protected void performDamaged(Player player, ItemStack item, org.bukkit.event.entity.EntityDamageEvent event) {
        // Bug-HH-01 fix: only trigger when player is actually wearing the Hades' Helm
        if (!AbilityManager.isAbilityItem(player.getInventory().getHelmet(), "hades_helm")) return;

        if (event instanceof EntityDamageByEntityEvent damageEvent) {
            if (damageEvent.getDamager() instanceof org.bukkit.entity.LivingEntity attacker) {
                int duration = getConfigInt("wither_duration", WITHER_DURATION);
                int amp = getConfigInt("wither_amplifier", WITHER_AMPLIFIER);
                attacker.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, duration, amp));
            }
        }
    }
}
