package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

/**
 * Reaper Scythe — Soul-harvesting weapon.
 *
 * BASE STATS (via reaper_scythe.yml attributes):
 *   Damage: 7♥ base (ADD_NUMBER +6 on axe base 1)
 *   Attack Speed: 1.0/s (ADD_NUMBER -3.0 on base 4)
 *   Unbreakable: true
 *
 * RIGHT-CLICK · Soul Harvest (CD: 45s)
 *   360° AoE swing in radius 5 blocks.
 *   Per enemy hit:
 *     1. Steal ALL beneficial potion effects (full duration transferred, enemy loses them).
 *     2. Lifesteal: heal 25% of enemy's MAX HP.
 *   Visual: 50 SOUL particles + sweeping arc + ENTITY_WITHER_HURT sound.
 *
 * Stolen beneficial effects: Speed, Strength, Regeneration, Resistance, Haste,
 *   Jump Boost, Fire Resistance, Water Breathing.
 *   Debuffs (Poison, Slowness, Weakness…) are NEVER stolen.
 */
public class ReaperScythe extends BaseAbility {

    private static final long   DEFAULT_CD_MS         = 45_000L;
    private static final double DEFAULT_RADIUS        = 5.0;
    private static final double DEFAULT_LIFESTEAL_PCT = 0.25;    // 25% of enemy max HP

    // Strictly beneficial effects that can be stolen
    private static final Set<PotionEffectType> BENEFICIAL = Set.of(
            PotionEffectType.SPEED,
            PotionEffectType.STRENGTH,
            PotionEffectType.REGENERATION,
            PotionEffectType.RESISTANCE,
            PotionEffectType.HASTE,
            PotionEffectType.JUMP_BOOST,
            PotionEffectType.FIRE_RESISTANCE,
            PotionEffectType.WATER_BREATHING
    );

    public ReaperScythe(Main plugin) {
        super(plugin);
    }

    @Override public String getName()     { return "Reaper Scythe"; }
    @Override public long   getCooldown() { return getConfigLong("cooldown", DEFAULT_CD_MS); }

    private double radius()       { return getConfigDouble("swing_radius",    DEFAULT_RADIUS);       }
    private double lifestealPct() { return getConfigDouble("lifesteal_pct",   DEFAULT_LIFESTEAL_PCT);}

    // ── RIGHT-CLICK: Soul Harvest ─────────────────────────────────────────────

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);

        Location center = player.getLocation();
        World world = center.getWorld();
        double r = radius();

        // ── Visuals: scythe whoosh arc ────────────────────────────────────────
        world.playSound(center, Sound.ENTITY_WITHER_HURT, 1.2f, 0.7f);
        world.playSound(center, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.5f);

        // 50 SOUL particles in a sweeping ring
        for (double angle = 0; angle < Math.PI * 2; angle += Math.PI / 25.0) {
            double x = Math.cos(angle) * r;
            double z = Math.sin(angle) * r;
            world.spawnParticle(Particle.SOUL, center.clone().add(x, 1.0, z), 1, 0, 0, 0, 0.02);
        }
        // Dense burst at player position
        world.spawnParticle(Particle.SOUL_FIRE_FLAME, center.clone().add(0, 1, 0),
                30, 0.5, 0.7, 0.5, 0.08);

        // ── AoE: steal effects + lifesteal ────────────────────────────────────
        int targetsHit = 0;
        int totalEffectsStolen = 0;
        double totalHeal = 0;

        for (Entity e : player.getNearbyEntities(r, r, r)) {
            if (!(e instanceof LivingEntity target)) continue;
            if (target.equals(player)) continue;
            if (target instanceof Player tp && plugin.getTeamManager().isFriendlyFire(player, tp)) continue;

            // Collect beneficial effects to steal
            List<PotionEffect> toSteal = new ArrayList<>();
            for (PotionEffect fx : target.getActivePotionEffects()) {
                if (BENEFICIAL.contains(fx.getType())) toSteal.add(fx);
            }

            // Apply stolen effects to self (full duration), remove from enemy
            for (PotionEffect fx : toSteal) {
                target.removePotionEffect(fx.getType());
                // Override if we already have a weaker version
                PotionEffect existing = player.getPotionEffect(fx.getType());
                if (existing == null || existing.getAmplifier() < fx.getAmplifier()
                        || existing.getDuration() < fx.getDuration()) {
                    player.addPotionEffect(fx);
                }
                totalEffectsStolen++;
            }

            // Lifesteal: 25% of target's max HP
            double maxHp = target.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
            double heal  = maxHp * lifestealPct();
            totalHeal += heal;

            // Visual on target
            target.getWorld().spawnParticle(Particle.SOUL,
                    target.getLocation().add(0, 1.2, 0), 20, 0.3, 0.5, 0.3, 0.1);
            target.getWorld().spawnParticle(Particle.DRAGON_BREATH,
                    target.getLocation().add(0, 1.0, 0), 15, 0.2, 0.4, 0.2, 0.04);

            targetsHit++;
        }

        // Apply total heal
        if (totalHeal > 0 || totalEffectsStolen > 0) {
            double maxHp = player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
            double newHp = Math.min(player.getHealth() + totalHeal, maxHp);
            player.setHealth(newHp);

            // Glow on self
            world.spawnParticle(Particle.SOUL, center.clone().add(0, 1.5, 0),
                    25, 0.3, 0.5, 0.3, 0.05);
            world.playSound(center, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.5f);

            // Feedback
            double healHearts = totalHeal / 2.0;
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize(
                    "§5☠ §7Harvested §d" + totalEffectsStolen + " §7effect"
                    + (totalEffectsStolen != 1 ? "s" : "")
                    + " §8| §7Healed §c+" + String.format("%.1f", healHearts) + "♥"
                    + " §8(" + targetsHit + " target"
                    + (targetsHit != 1 ? "s" : "") + ")"));
        } else if (targetsHit == 0) {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§5☠ §7No enemies in range."));
        } else {
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§5☠ §7No beneficial effects to steal."));
        }
    }

    // ── passiveTick: action bar ───────────────────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;
        // Cooldown is managed by BaseAbility.checkCooldown — use CooldownManager
        boolean onCd = plugin.getCooldownManager().isOnCooldown(player, getName());
        String cdStr = onCd
                ? "§cCD: §f" + String.format("%.0f", plugin.getCooldownManager().getCooldown(player, getName()) / 1000.0) + "s"
                : "§aReady";
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§5☠ §7Soul Harvest: " + cdStr
                + "  §8| §7Radius §f5b §8| §725% lifesteal"));
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    @Override
    protected void performQuit(Player player, PlayerQuitEvent event)   {}
    @Override
    protected void performDeath(Player player, PlayerDeathEvent event) {}
    @Override
    public void cleanup() {}
}
