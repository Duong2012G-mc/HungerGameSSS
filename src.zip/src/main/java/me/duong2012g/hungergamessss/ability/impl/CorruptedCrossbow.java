package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Corrupted Crossbow — Plague-infused crossbow with splash Poison clouds.
 *
 * RIGHT-CLICK (Shoot):
 *   Fires a Poison Cloud Arrow.
 *   On impact: AoE Poison I (8s) splash in 4×4×4 radius.
 *   Direct hit: 6-8 heart damage + Poison.
 *   Visual: purple WITCH + DUST trail, wither skull smoke on impact.
 *   Cooldown: 4 seconds (spam-oriented).
 *
 *   Quick Charge III means the crossbow charges fast.
 *   Multishot enchant fires 3 poison clouds simultaneously.
 */
public class CorruptedCrossbow extends BaseAbility {

    private static final String POISON_BOLT_TAG = "corrupted_poison_bolt";

    private static final long   DEFAULT_SHOOT_CD_MS    = 4_000L;
    private static final double DEFAULT_DIRECT_DAMAGE  = 12.0;     // 6 hearts
    private static final double DEFAULT_SPLASH_RADIUS  = 2.0;      // half of 4×4×4
    private static final int    DEFAULT_POISON_TICKS   = 160;      // 8 seconds
    private static final int    DEFAULT_POISON_AMP     = 0;        // Poison I
    private static final double DEFAULT_BOLT_SPEED     = 1.8;      // blocks/tick

    private final Map<UUID, Long> shootCooldowns = new ConcurrentHashMap<>();

    public CorruptedCrossbow(Main plugin) {
        super(plugin);
    }

    @Override public String getName()     { return "Corrupted Crossbow"; }
    @Override public long   getCooldown() { return 0; }

    private long   shootCdMs()      { return getConfigLong  ("shoot_cooldown",   DEFAULT_SHOOT_CD_MS);   }
    private double directDamage()   { return getConfigDouble("direct_damage",    DEFAULT_DIRECT_DAMAGE); }
    private double splashRadius()   { return getConfigDouble("splash_radius",    DEFAULT_SPLASH_RADIUS); }
    private int    poisonTicks()    { return getConfigInt   ("poison_ticks",     DEFAULT_POISON_TICKS);  }
    private int    poisonAmp()      { return getConfigInt   ("poison_amplifier", DEFAULT_POISON_AMP);    }
    private double boltSpeed()      { return getConfigDouble("bolt_speed",       DEFAULT_BOLT_SPEED);    }

    // ── RIGHT-CLICK: Fire poison cloud arrow ─────────────────────────────────

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);

        Long last = shootCooldowns.get(player.getUniqueId());
        if (last != null && System.currentTimeMillis() - last < shootCdMs()) {
            long rem = (shootCdMs() - (System.currentTimeMillis() - last)) / 1000L;
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize(
                    "§5[Corrupted Crossbow] §7Shoot §cCD: §f" + rem + "s"));
            return;
        }
        shootCooldowns.put(player.getUniqueId(), System.currentTimeMillis());

        // Determine bolt count: 3 if Multishot, 1 otherwise
        int boltCount = item.getEnchantmentLevel(org.bukkit.enchantments.Enchantment.MULTISHOT) > 0 ? 3 : 1;

        Location eye = player.getEyeLocation();
        Vector baseDir = eye.getDirection().normalize();

        for (int i = 0; i < boltCount; i++) {
            Vector dir = spread(baseDir, i, boltCount);
            launchPoisonBolt(player, eye.clone(), dir);
        }

        player.getWorld().playSound(player.getLocation(), Sound.ITEM_CROSSBOW_SHOOT, 1.2f, 0.6f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WITCH_CELEBRATE, 0.7f, 0.5f);
        player.getWorld().spawnParticle(Particle.DUST, eye.clone().add(baseDir),
                20, 0.3, 0.3, 0.3, new Particle.DustOptions(Color.fromRGB(100, 0, 130), 1.2f));

        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§5[Corrupted] §d§l" + boltCount + " §7poison bolt"
                + (boltCount > 1 ? "s" : "") + " fired! §cCD: §f" + (shootCdMs() / 1000) + "s"));
    }

    /** Compute a spread direction: index 0 = centre, 1 = left, 2 = right. */
    private Vector spread(Vector base, int index, int total) {
        if (total <= 1) return base.clone();
        double[] offsets = {0.0, -0.18, 0.18};
        double angle = offsets[index % 3];
        double cos = Math.cos(angle), sin = Math.sin(angle);
        double x = base.getX() * cos - base.getZ() * sin;
        double z = base.getX() * sin + base.getZ() * cos;
        return new Vector(x, base.getY(), z).normalize().multiply(boltSpeed());
    }

    /** Launch a single poison bolt as a tick-based projectile. */
    private void launchPoisonBolt(Player owner, Location startLoc, Vector velocity) {
        UUID ownerUUID = owner.getUniqueId();

        new BukkitRunnable() {
            final Location pos  = startLoc.clone();
            int ticks = 0;
            final int maxTicks  = 50; // ~30 blocks at 1.8 b/t

            @Override
            public void run() {
                // Advance per tick in sub-steps for smoother collision
                for (int step = 0; step < 3; step++) {
                    pos.add(velocity.clone().multiply(1.0 / 3.0));

                    // Trail: WITCH purple dust
                    pos.getWorld().spawnParticle(Particle.WITCH, pos, 2, 0.05, 0.05, 0.05, 0.02);
                    pos.getWorld().spawnParticle(Particle.DUST, pos, 1, 0, 0, 0, 0,
                            new Particle.DustOptions(Color.fromRGB(80, 0, 110), 1.0f));

                    // Block collision
                    if (pos.getBlock().getType().isSolid()) {
                        detonate(pos, owner);
                        cancel();
                        return;
                    }

                    // Entity collision
                    for (Entity e : pos.getWorld().getNearbyEntities(pos, 0.8, 0.8, 0.8)) {
                        if (!(e instanceof LivingEntity target)) continue;
                        Player p = org.bukkit.Bukkit.getPlayer(ownerUUID);
                        if (p != null && target.equals(p)) continue;
                        if (target instanceof Player tp && p != null
                                && plugin.getTeamManager().isFriendlyFire(p, tp)) continue;

                        // Direct hit damage
                        target.setNoDamageTicks(0);
                        target.damage(directDamage(), p);
                        detonate(pos, owner);
                        cancel();
                        return;
                    }
                }

                // Apply light gravity
                velocity.setY(velocity.getY() - 0.04);
                ticks++;
                if (ticks > maxTicks) {
                    detonate(pos, owner);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    /** Detonates a poison cloud at the given location. */
    private void detonate(Location loc, Player owner) {
        World world = loc.getWorld();
        if (world == null) return;

        double r = splashRadius();

        // Visual — wither/witch smoke burst
        world.spawnParticle(Particle.WITCH, loc, 60, r, r, r, 0.15);
        world.spawnParticle(Particle.DUST, loc, 40, r, r, r, 0,
                new Particle.DustOptions(Color.fromRGB(90, 0, 120), 1.5f));
        world.spawnParticle(Particle.LARGE_SMOKE, loc, 20, r * 0.5, r * 0.5, r * 0.5, 0.05);
        world.playSound(loc, Sound.ENTITY_WITCH_AMBIENT, 1.2f, 0.7f);
        world.playSound(loc, Sound.ENTITY_GHAST_SHOOT, 0.6f, 1.8f);

        // AoE Poison splash
        for (Entity e : world.getNearbyEntities(loc, r, r, r)) {
            if (!(e instanceof LivingEntity target)) continue;
            if (target.equals(owner)) continue;
            if (target instanceof Player tp && plugin.getTeamManager().isFriendlyFire(owner, tp)) continue;

            target.addPotionEffect(new PotionEffect(
                    PotionEffectType.POISON, poisonTicks(), poisonAmp(), false, true, true));

            // Visual on hit
            target.getWorld().spawnParticle(Particle.WITCH,
                    target.getLocation().add(0, 1, 0), 15, 0.3, 0.5, 0.3, 0.1);
        }
    }

    // ── passiveTick: action bar ───────────────────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;

        Long last = shootCooldowns.get(player.getUniqueId());
        boolean onCd = last != null && System.currentTimeMillis() - last < shootCdMs();
        String cdStr = onCd
                ? "§cCD: §f" + ((shootCdMs() - (System.currentTimeMillis() - last)) / 1000L) + "s"
                : "§aReady";
        int bolts = item.getEnchantmentLevel(org.bukkit.enchantments.Enchantment.MULTISHOT) > 0 ? 3 : 1;

        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§5☠ §7Shoot: " + cdStr
                + "  §8| §7Bolts: §d" + bolts
                + (bolts > 1 ? " §8(Multishot)" : "")));
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    @Override
    protected void performQuit(Player player, PlayerQuitEvent event)   { shootCooldowns.remove(player.getUniqueId()); }
    @Override
    protected void performDeath(Player player, PlayerDeathEvent event) { shootCooldowns.remove(player.getUniqueId()); }
    @Override
    public void cleanup() { shootCooldowns.clear(); }
}
