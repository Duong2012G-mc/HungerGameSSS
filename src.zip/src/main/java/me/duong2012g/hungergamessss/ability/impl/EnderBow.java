package me.duong2012g.hungergamessss.ability.impl;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.BaseAbility;
import me.duong2012g.hungergamessss.manager.AbilityManager;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Ender Bow — Void-powered bow with three interconnected abilities.
 *
 * 1. PASSIVE: Infinite Ender Pearls (RIGHT-CLICK, CD 30s)
 *    Shoots a virtual ender pearl toward the look direction.
 *    On impact teleports player to a safe block above the hit point.
 *    Purple ender particles + ENDERMAN_TELEPORT sound.
 *
 * 2. ACTIVE: Arrow → Floating Pearl (BOW SHOT via EntityShootBow)
 *    Arrow hit on block → spawns a glowing ender pearl Item entity at impact.
 *    Max 3 pearls active per player at any time.
 *    Pearl lasts 60 seconds before despawning.
 *
 * 3. UTILITY: Pearl Pickup → Instant Teleport (NO cooldown)
 *    Walking over an active ender pearl Item instantly teleports to it.
 *    No cooldown — chaining pearls = unlimited mobility.
 *    Cancelled if EntityPickupItemEvent occurs (player walks into pearl).
 *
 * Stats: Power III bow, no Infinity (arrow management = part of the gameplay loop).
 */
public class EnderBow extends BaseAbility implements org.bukkit.event.Listener {

    private static final String PEARL_TAG    = "ender_bow_pearl";
    private static final String ARROW_TAG    = "ender_bow_arrow";

    private static final long   DEFAULT_PEARL_CD_MS   = 30_000L;
    private static final int    DEFAULT_MAX_PEARLS     = 3;
    private static final int    DEFAULT_PEARL_RANGE    = 40;     // blocks
    private static final long   DEFAULT_PEARL_LIFETIME = 60 * 20L; // ticks

    // per-player: cooldown for right-click pearl shot
    private final Map<UUID, Long> pearlCooldowns = new ConcurrentHashMap<>();
    // per-player: list of active pearl Item entities
    private final Map<UUID, List<Item>> activePearls = new ConcurrentHashMap<>();

    public EnderBow(Main plugin) {
        super(plugin);
        // FIX: registerEvents handled by AbilityRegistry.register()
    }

    @Override public String getName()     { return "Ender Bow"; }
    @Override public long   getCooldown() { return 0; }

    private long pearlCdMs()   { return getConfigLong  ("pearl_cooldown",   DEFAULT_PEARL_CD_MS);   }
    private int  maxPearls()   { return getConfigInt   ("max_pearls",        DEFAULT_MAX_PEARLS);    }
    private int  pearlRange()  { return getConfigInt   ("pearl_range",       DEFAULT_PEARL_RANGE);   }
    private long pearlLife()   { return getConfigLong  ("pearl_lifetime_ticks", DEFAULT_PEARL_LIFETIME); }

    // ── ABILITY 1: RIGHT-CLICK → Virtual Ender Pearl ─────────────────────────

    @Override
    protected void performRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        event.setCancelled(true);

        Long last = pearlCooldowns.get(player.getUniqueId());
        if (last != null && System.currentTimeMillis() - last < pearlCdMs()) {
            long rem = (pearlCdMs() - (System.currentTimeMillis() - last)) / 1000L;
            player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§5[Ender Bow] §7Pearl §cCD: §f" + rem + "s"));
            return;
        }
        pearlCooldowns.put(player.getUniqueId(), System.currentTimeMillis());

        // Tick-based pearl trajectory
        shootVirtualPearl(player);
    }

    private void shootVirtualPearl(Player player) {
        final UUID ownerUUID = player.getUniqueId();
        final Location pos = player.getEyeLocation().clone();
        final org.bukkit.util.Vector vel = pos.getDirection().normalize().multiply(1.5);
        final int maxTicks = (int) (pearlRange() / 1.5 * 1.5); // approx ticks to reach range

        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.5f, 1.4f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                Player p = Bukkit.getPlayer(ownerUUID);
                if (p == null || !p.isOnline() || ticks++ > maxTicks) { cancel(); return; }

                // Gravity
                vel.setY(vel.getY() - 0.04);
                pos.add(vel);

                // Trail
                pos.getWorld().spawnParticle(Particle.REVERSE_PORTAL, pos, 3, 0.05, 0.05, 0.05, 0.05);

                // Block collision
                if (pos.getBlock().getType().isSolid()) {
                    teleportSafe(p, pos.clone().subtract(vel).add(0, 1, 0));
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    // ── ABILITY 2: ARROW HIT → Spawn floating Pearl ──────────────────────────

    @Override
    protected void performProjectileLaunch(Player shooter, Projectile projectile, ItemStack item) {
        projectile.setMetadata(ARROW_TAG,
                new FixedMetadataValue(plugin, shooter.getUniqueId().toString()));
    }

    @Override
    protected void performProjectileHit(Projectile projectile, ProjectileHitEvent event) {
        if (!projectile.hasMetadata(ARROW_TAG)) return;

        String shooterUUIDStr = projectile.getMetadata(ARROW_TAG).get(0).asString();
        UUID shooterUUID;
        try { shooterUUID = UUID.fromString(shooterUUIDStr); } catch (Exception e) { return; }
        Player shooter = Bukkit.getPlayer(shooterUUID);
        if (shooter == null) return;

        // Only spawn pearl on block hit (not entity hit)
        if (event.getHitEntity() != null) return;

        // Check pearl cap
        List<Item> pearls = activePearls.computeIfAbsent(shooterUUID,
                k -> Collections.synchronizedList(new ArrayList<>()));
        pearls.removeIf(p -> p == null || !p.isValid() || p.isDead());

        if (pearls.size() >= maxPearls()) {
            shooter.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize("§5[Ender Bow] §7Max §f" + maxPearls()
                    + " §7pearls active! Walk into one to teleport."));
            return;
        }

        Location spawnLoc = projectile.getLocation().clone().add(0, 0.5, 0);
        spawnFloatingPearl(shooter, spawnLoc, pearls);
    }

    private void spawnFloatingPearl(Player owner, Location loc, List<Item> pearls) {
        // Drop an ender pearl item entity
        ItemStack pearlItem = new ItemStack(Material.ENDER_PEARL);
        Item pearl = loc.getWorld().dropItem(loc, pearlItem);
        pearl.setPickupDelay(0);
        pearl.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
        pearl.setGravity(false);
        pearl.setInvulnerable(true);
        pearl.setGlowing(true);
        pearl.setMetadata(PEARL_TAG, new FixedMetadataValue(plugin, owner.getUniqueId().toString()));

        pearls.add(pearl);
        UUID ownerUUID = owner.getUniqueId();

        // Spin + glow effect while active
        new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;

            @Override
            public void run() {
                if (!pearl.isValid() || pearl.isDead() || ticks++ > pearlLife()) {
                    if (pearl.isValid()) pearl.remove();
                    pearls.remove(pearl);
                    cancel();
                    return;
                }
                // Float orbit
                angle += 0.15;
                Location orbitLoc = pearl.getLocation();
                orbitLoc.getWorld().spawnParticle(Particle.REVERSE_PORTAL,
                        orbitLoc.clone().add(0, 0.3, 0), 2, 0.15, 0.15, 0.15, 0.02);
                pearl.setVelocity(new org.bukkit.util.Vector(0, Math.sin(angle) * 0.02, 0));
            }
        }.runTaskTimer(plugin, 1L, 1L);

        owner.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§5[Ender Bow] §7Pearl spawned! Walk into it to teleport. ("
                + (pearls.size()) + "/" + maxPearls() + ")"));

        // Particles at spawn
        loc.getWorld().spawnParticle(Particle.PORTAL, loc, 20, 0.3, 0.3, 0.3, 0.2);
        loc.getWorld().playSound(loc, Sound.BLOCK_PORTAL_TRIGGER, 0.5f, 1.8f);
    }

    // ── ABILITY 3: Walk into pearl → Instant teleport (Listener) ─────────────

    @org.bukkit.event.EventHandler
    public void onPearlPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        Item item = event.getItem();
        if (!item.hasMetadata(PEARL_TAG)) return;

        String ownerUUIDStr = item.getMetadata(PEARL_TAG).get(0).asString();
        UUID ownerUUID;
        try { ownerUUID = UUID.fromString(ownerUUIDStr); } catch (Exception e) { return; }

        // Any player (including enemies) can accidentally walk into the pearl — only owner teleports
        if (!player.getUniqueId().equals(ownerUUID)) {
            event.setCancelled(true); // nobody else picks it up
            return;
        }

        event.setCancelled(true); // don't add to inventory

        Location dest = item.getLocation().clone();
        item.remove();
        List<Item> pearls = activePearls.get(ownerUUID);
        if (pearls != null) pearls.remove(item);

        teleportSafe(player, dest.add(0, 1, 0));

        player.getWorld().spawnParticle(Particle.REVERSE_PORTAL,
                player.getLocation().add(0, 1, 0), 30, 0.4, 0.6, 0.4, 0.1);
        player.getWorld().playSound(player.getLocation(),
                Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize("§5[Ender Bow] §d§lTELEPORTED!"));
    }

    // ── Safe teleport ─────────────────────────────────────────────────────────

    private void teleportSafe(Player player, Location loc) {
        World world = loc.getWorld();
        if (world == null) return;
        // Search upward for a 2-block-tall air gap
        for (int dy = 0; dy <= 5; dy++) {
            Location check = loc.clone().add(0, dy, 0);
            if (check.getBlock().isPassable()
                    && check.clone().add(0, 1, 0).getBlock().isPassable()
                    && check.clone().subtract(0, 1, 0).getBlock().getType().isSolid()) {
                check.setYaw(player.getLocation().getYaw());
                check.setPitch(player.getLocation().getPitch());
                player.teleport(check);
                return;
            }
        }
        // Fallback — just go to loc+1
        loc.setYaw(player.getLocation().getYaw());
        loc.setPitch(player.getLocation().getPitch());
        player.teleport(loc);
    }

    // ── passiveTick: action bar ───────────────────────────────────────────────

    @Override
    public void passiveTick(Player player, ItemStack item) {
        if (!AbilityManager.isAbilityItem(item, getName())) return;

        Long last = pearlCooldowns.get(player.getUniqueId());
        boolean onCd = last != null && System.currentTimeMillis() - last < pearlCdMs();
        String cdStr = onCd
                ? "§cCD: §f" + ((pearlCdMs() - (System.currentTimeMillis() - last)) / 1000L) + "s"
                : "§aReady";

        List<Item> pearls = activePearls.getOrDefault(player.getUniqueId(), Collections.emptyList());
        pearls.removeIf(p -> p == null || !p.isValid() || p.isDead());
        int count = pearls.size();

        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(
                "§5◈ §7Pearl: " + cdStr
                + "  §8| §7Floating: §d" + count + "§8/§d" + maxPearls()
                + "  §8| §7LClick=Arrow→Pearl  RClick=PearlShot"));
    }

    // ── cleanup ───────────────────────────────────────────────────────────────

    private void cleanupPlayer(UUID id) {
        pearlCooldowns.remove(id);
        List<Item> pearls = activePearls.remove(id);
        if (pearls != null) pearls.forEach(p -> { if (p != null && p.isValid()) p.remove(); });
    }

    @Override
    protected void performQuit(Player player, PlayerQuitEvent event)   { cleanupPlayer(player.getUniqueId()); }
    @Override
    protected void performDeath(Player player, PlayerDeathEvent event) { cleanupPlayer(player.getUniqueId()); }
    @Override
    public void cleanup() {
        for (UUID id : new HashSet<>(activePearls.keySet())) cleanupPlayer(id);
        pearlCooldowns.clear();
    }
}
