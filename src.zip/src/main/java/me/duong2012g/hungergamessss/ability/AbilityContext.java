package me.duong2012g.hungergamessss.ability;

import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class AbilityContext {
    private final UUID caster;
    private final UUID target;
    private final Location location;
    private final Arena arena;
    private final TriggerType trigger;
    private final ItemStack item;
    private final Event event;
    private final String abilityId;
    /** Mutable cancellation flag — abilities can call setCancelled(true) to signal
     *  that further processing of this context should be skipped. */
    private boolean cancelled = false;

    public AbilityContext(UUID caster, UUID target, Location location, Arena arena, TriggerType trigger, ItemStack item, Event event) {
        this(caster, target, location, arena, trigger, item, event, null);
    }

    public AbilityContext(UUID caster, UUID target, Location location, Arena arena, TriggerType trigger, ItemStack item, Event event, String abilityId) {
        this.caster = caster;
        this.target = target;
        this.location = location;
        this.arena = arena;
        this.trigger = trigger;
        this.item = item;
        this.event = event;
        this.abilityId = abilityId;
    }

    public UUID getCaster() {
        return caster;
    }

    public UUID getTarget() {
        return target;
    }

    public Location getLocation() {
        return location;
    }

    public Arena getArena() {
        return arena;
    }

    public TriggerType getTrigger() {
        return trigger;
    }

    public ItemStack getItem() {
        return item;
    }

    public Event getEvent() {
        return event;
    }

    public String getAbilityId() {
        return abilityId;
    }

    /** Returns true if this context has been marked cancelled by an ability. */
    public boolean isCancelled() {
        return cancelled;
    }

    /**
     * Mark this context as cancelled. Abilities that share a trigger chain can
     * check {@link #isCancelled()} to skip redundant processing.
     */
    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }
}
