package me.duong2012g.hungergamessss.ability;

import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.Location;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/**
 * Immutable data-transfer object that carries all context a trigger needs.
 *
 * <h3>Design notes</h3>
 * <ul>
 *   <li>{@code item} is stored as a defensive clone (A1-4) so abilities that mutate
 *       the item inside a handler cannot corrupt the shared context object.</li>
 *   <li>{@code location} is stored as-is; use {@link #getLocationSafe()} when you
 *       need a mutable copy for offset math.</li>
 *   <li>Arena-requiring triggers ({@code RIGHT_CLICK}, {@code HIT}, etc.) log a
 *       warning when called without an arena, but do not throw — abilities already
 *       call {@code validateCanUse()} which gates on arena state (A1-6).</li>
 * </ul>
 */
public class AbilityContext {

    // A1-5 NOTE: this class cannot be a Java record because:
    //   (a) it carries a mutable `cancelled` flag that must survive across the
    //       dispatch chain, and
    //   (b) ItemStack is not immutable, so we need the defensive-copy constructor
    //       logic that records cannot express.
    // Once ItemStack gains value-type semantics (Project Valhalla), revisit.

    private final UUID caster;
    private final UUID target;
    private final Location location;
    private final Arena arena;
    private final TriggerType trigger;
    /** Defensive clone — mutations inside an ability handler stay local. */
    private final ItemStack item;
    private final Event event;
    private final String abilityId;
    /** Mutable cancellation flag — abilities can signal "skip further processing". */
    private boolean cancelled = false;

    // ── Constructors ─────────────────────────────────────────────────────────

    public AbilityContext(UUID caster, UUID target, Location location, Arena arena,
                          TriggerType trigger, ItemStack item, Event event) {
        this(caster, target, location, arena, trigger, item, event, null);
    }

    public AbilityContext(UUID caster, UUID target, Location location, Arena arena,
                          TriggerType trigger, ItemStack item, Event event, String abilityId) {
        // A1-6: validate arena for triggers that require one
        if (arena == null && requiresArena(trigger)) {
            // Warn but do not throw — abilities are individually guarded by validateCanUse()
            me.duong2012g.hungergamessss.Main main = me.duong2012g.hungergamessss.Main.getInstance();
            if (main != null && main.getConfig().getBoolean("debug", false)) {
                main.getLogger().warning("[AbilityContext] arena=null for trigger=" + trigger
                        + " caster=" + caster + ". Check the dispatch site.");
            }
        }
        this.caster    = caster;
        this.target    = target;
        this.location  = location;
        this.arena     = arena;
        this.trigger   = trigger;
        // A1-4: defensive clone — prevents ability handlers from corrupting the shared item ref
        this.item      = item != null ? item.clone() : null;
        this.event     = event;
        this.abilityId = abilityId;
    }

    /**
     * Returns {@code true} for triggers that are only meaningful inside an active arena.
     * DEATH/QUIT must work even when the arena is ENDING, so they are excluded.
     */
    private static boolean requiresArena(TriggerType t) {
        return switch (t) {
            case RIGHT_CLICK, LEFT_CLICK, HIT, PROJECTILE_LAUNCH,
                 PROJECTILE_HIT, SNEAK, DAMAGED, MOVE -> true;
            default -> false;
        };
    }

    // ── Accessors ─────────────────────────────────────────────────────────────

    public UUID getCaster()  { return caster; }
    public UUID getTarget()  { return target; }
    public Arena getArena()  { return arena; }
    public TriggerType getTrigger() { return trigger; }
    /** Returns the defensive-cloned item. Further mutation is safe. */
    public ItemStack getItem() { return item; }
    public Event getEvent()  { return event; }
    public String getAbilityId() { return abilityId; }

    /** Resolves the caster UUID to an online {@link org.bukkit.entity.Player}. */
    public org.bukkit.entity.Player getCasterPlayer() {
        return caster != null ? org.bukkit.Bukkit.getPlayer(caster) : null;
    }

    /** Returns the raw stored location (may be mutated by the caller). */
    public Location getLocation() { return location; }

    /**
     * Returns a defensive clone of the stored location.
     * Use this when you need to offset the position without altering the context.
     */
    public Location getLocationSafe() {
        return location != null ? location.clone() : null;
    }

    // ── Cancellation chain ────────────────────────────────────────────────────

    /** {@code true} if an earlier handler marked this context as cancelled. */
    public boolean isCancelled() { return cancelled; }

    /**
     * Mark this context cancelled so downstream handlers in the same trigger
     * chain can skip redundant processing.
     */
    public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }
}

