package me.duong2012g.hungergamessss.util;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.Collection;

/**
 * A2-S2: Particle emission throttle — reduces visual effects when many players
 * are online in an arena to cut down on packet volume and client-side lag.
 *
 * <h3>How it works</h3>
 * <ol>
 *   <li>Count living (non-spectator) players in the arena at the spawn location.</li>
 *   <li>If that count exceeds {@code performance.yml → effects-optimization.particle-reduction-threshold},
 *       reduce the particle {@code count} and suppress "expensive" particles entirely.</li>
 *   <li>The throttle only fires if {@code effects-optimization.reduce-particles-crowded: true}.</li>
 * </ol>
 *
 * <h3>Usage</h3>
 * <pre>{@code
 * // Replace direct spawnParticle calls with:
 * ParticleThrottle.spawn(plugin, location, Particle.CRIT, 10, 0.3, 0.3, 0.3, 0.1);
 *
 * // For effects that must always show (e.g. status application feedback):
 * location.getWorld().spawnParticle(Particle.CRIT, location, 1);  // bypass throttle
 * }</pre>
 */
public final class ParticleThrottle {

    // Particles that are expensive (many vertices / large billboard) and are
    // suppressed entirely when the arena is crowded.
    private static final java.util.Set<Particle> EXPENSIVE = java.util.Set.of(
            Particle.EXPLOSION_EMITTER,
            Particle.FLASH,
            Particle.SONIC_BOOM,
            Particle.DUST_PLUME
    );

    private ParticleThrottle() {}

    /**
     * Spawns particles with automatic throttling based on nearby player count.
     *
     * @param plugin    the plugin instance (used to read config)
     * @param location  where to spawn the effect
     * @param particle  the particle type
     * @param count     nominal count at low player-density; reduced automatically
     * @param offX/Y/Z  spread offsets
     * @param extra     speed / size / data (depends on particle type)
     */
    public static void spawn(Main plugin, Location location, Particle particle,
                             int count, double offX, double offY, double offZ, double extra) {
        if (location.getWorld() == null) return;

        if (!isThrottleEnabled(plugin)) {
            location.getWorld().spawnParticle(particle, location, count, offX, offY, offZ, extra);
            return;
        }

        int threshold = plugin.getConfig().getInt(
                "effects-optimization.particle-reduction-threshold", 10);
        int nearby = countNearbyPlayers(location, 64);

        if (nearby < threshold) {
            // Below threshold — full quality
            location.getWorld().spawnParticle(particle, location, count, offX, offY, offZ, extra);
            return;
        }

        boolean suppressExpensive = plugin.getConfig().getBoolean(
                "effects-optimization.disable-expensive-particles", true);
        if (suppressExpensive && EXPENSIVE.contains(particle)) return;

        // Above threshold — halve count (minimum 1)
        int reduced = Math.max(1, count / 2);
        location.getWorld().spawnParticle(particle, location, reduced, offX, offY, offZ, extra);
    }

    /** Overload without extra (defaults to 0). */
    public static void spawn(Main plugin, Location location, Particle particle,
                             int count, double offX, double offY, double offZ) {
        spawn(plugin, location, particle, count, offX, offY, offZ, 0);
    }

    /**
     * Spawns a particle line between two points with throttling.
     * Delegates to {@link me.duong2012g.hungergamessss.ability.AbilityUtils#spawnParticleLine}
     * but respects the crowded threshold.
     */
    public static void spawnLine(Main plugin, Location from, Location to,
                                 Particle particle, int countPerPoint, double step) {
        if (from.getWorld() == null) return;
        boolean enabled = isThrottleEnabled(plugin);
        int threshold   = enabled ? plugin.getConfig().getInt(
                "effects-optimization.particle-reduction-threshold", 10) : Integer.MAX_VALUE;
        int nearby = countNearbyPlayers(from, 64);

        if (enabled && nearby >= threshold) {
            // Double the step interval so fewer points are spawned along the line
            step = step * 2;
        }
        me.duong2012g.hungergamessss.ability.AbilityUtils.spawnParticleLine(from, to, particle, countPerPoint, step);
    }

    /**
     * A1-S4: Fire-and-forget particle spawn that offloads the Bukkit call to the
     * next server tick via a {@code runTask} (still main-thread — Paper requires
     * world-access on the main thread — but deferred, reducing same-tick spikes).
     *
     * <p>Use this for purely cosmetic effects that don't need to appear in the exact
     * same tick as a game event (e.g. ambient trails, idle sparkles).
     * Do NOT use for feedback effects tied to player actions (hit sparks, status
     * application) — those must be synchronous so the player sees them immediately.
     *
     * @param plugin    plugin for scheduling
     * @param location  where to spawn
     * @param particle  particle type
     * @param count     count
     * @param offX/Y/Z  spread
     */
    public static void spawnDeferred(Main plugin, Location location, Particle particle,
                                     int count, double offX, double offY, double offZ) {
        plugin.getServer().getScheduler().runTask(plugin,
                () -> spawn(plugin, location, particle, count, offX, offY, offZ));
    }

    private static boolean isThrottleEnabled(Main plugin) {
        return plugin.getConfig().getBoolean("effects-optimization.reduce-particles-crowded", true);
    }

    private static int countNearbyPlayers(Location loc, double radius) {
        if (loc.getWorld() == null) return 0;
        Collection<? extends Player> nearby = loc.getWorld()
                .getNearbyPlayers(loc, radius, radius, radius);
        return nearby.size();
    }
}
