package me.duong2012g.hungergamessss.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;

/**
 * Central colour-translation utility.
 *
 * FIX L-02: Migrated from deprecated ChatColor.translateAlternateColorCodes()
 * to Adventure's LegacyComponentSerializer (Paper-native).
 *
 * FIX L-FONT-01: Added component() / componentOf() helpers that wrap legacy
 * strings into Adventure Components with italic=false, preventing Minecraft
 * 1.20.5+ from rendering custom item names in italic by default.
 */
public class ColorUtil {

    private static final LegacyComponentSerializer AMP =
            LegacyComponentSerializer.legacyAmpersand();
    private static final LegacyComponentSerializer SEC =
            LegacyComponentSerializer.legacySection();

    /** Translates {@code &}-colour codes to §-codes. */
    public static String colorize(String s) {
        if (s == null) return "";
        return AMP.serialize(AMP.deserialize(s));
    }

    /** Strips all colour codes from a string. */
    public static String strip(String s) {
        if (s == null) return "";
        return PlainTextComponentSerializer.plainText().serialize(AMP.deserialize(s));
    }

    /**
     * Converts a §-coded legacy string to a Component with italic explicitly FALSE.
     * Minecraft 1.20.5+ renders custom item names in italic by default; this prevents it.
     */
    public static Component component(String legacySection) {
        if (legacySection == null) legacySection = "";
        return SEC.deserialize(legacySection)
                .decoration(TextDecoration.ITALIC, false);
    }

    /** Colorize (&-codes → §-codes) then wrap as a non-italic Component. */
    public static Component componentOf(String ampStr) {
        return component(colorize(ampStr));
    }
}
