package me.duong2012g.hungergamessss.util;

import org.bukkit.configuration.file.FileConfiguration;

import java.util.*;
import java.util.function.Predicate;
import java.util.logging.Logger;

/**
 * A1-S6: Lightweight YAML config schema validator.
 *
 * <p>Validates a {@link FileConfiguration} against a declarative schema without
 * requiring the Configurate library or JSON Schema. Designed to be used at plugin
 * startup (inside {@code Main.validateConfig()}) to catch misconfigured values
 * before they cause silent bugs mid-match.
 *
 * <h3>Usage</h3>
 * <pre>{@code
 * ConfigSchemaValidator v = new ConfigSchemaValidator(plugin.getConfig(), plugin.getLogger());
 * v.require("game.min-players-to-start",     int.class,    n -> n >= 2 && n <= 100)
 *  .require("game.border-initial-size",       double.class, d -> d >= 50 && d <= 10_000)
 *  .optional("abilities.spi-override-allow",  boolean.class, null)
 *  .validate();   // logs all violations; returns true if zero errors
 * }</pre>
 */
public class ConfigSchemaValidator {

    /** Severity of a schema violation. */
    public enum Severity { ERROR, WARNING }

    /** A single violation found during validation. */
    public record Violation(String path, String message, Severity severity) {
        @Override public String toString() {
            return "[" + severity + "] " + path + ": " + message;
        }
    }

    private final FileConfiguration config;
    private final Logger log;
    private final List<SchemaEntry<?>> entries = new ArrayList<>();
    private final List<Violation> violations = new ArrayList<>();

    public ConfigSchemaValidator(FileConfiguration config, Logger log) {
        this.config = Objects.requireNonNull(config);
        this.log    = Objects.requireNonNull(log);
    }

    // ── Builder API ───────────────────────────────────────────────────────────

    /**
     * Declares a required key. A missing key or a value that fails {@code constraint}
     * is logged as an ERROR.
     */
    public <T> ConfigSchemaValidator require(String path, Class<T> type,
                                             Predicate<T> constraint) {
        entries.add(new SchemaEntry<>(path, type, constraint, true, Severity.ERROR));
        return this;
    }

    /**
     * Declares an optional key. Present-but-invalid values are logged as WARNING;
     * absent keys are silently skipped.
     */
    public <T> ConfigSchemaValidator optional(String path, Class<T> type,
                                              Predicate<T> constraint) {
        entries.add(new SchemaEntry<>(path, type, constraint, false, Severity.WARNING));
        return this;
    }

    /**
     * Runs all declared validations.
     *
     * @return {@code true} if no ERROR-level violations were found
     */
    public boolean validate() {
        violations.clear();
        for (SchemaEntry<?> entry : entries) validate(entry);

        if (violations.isEmpty()) {
            log.info("[ConfigSchema] All " + entries.size() + " checks passed.");
            return true;
        }
        long errors   = violations.stream().filter(v -> v.severity() == Severity.ERROR).count();
        long warnings = violations.stream().filter(v -> v.severity() == Severity.WARNING).count();
        for (Violation v : violations) {
            if (v.severity() == Severity.ERROR)   log.severe(v.toString());
            else                                   log.warning(v.toString());
        }
        log.warning("[ConfigSchema] " + errors + " error(s), " + warnings + " warning(s).");
        return errors == 0;
    }

    /** Returns all violations found by the last {@link #validate()} call. */
    public List<Violation> getViolations() { return Collections.unmodifiableList(violations); }

    // ── Static convenience factory ─────────────────────────────────────────────

    /**
     * Builds and runs the standard HungerGamesSSS config schema validation.
     * Called from {@code Main.validateConfig()}.
     */
    public static boolean validateDefault(FileConfiguration config, Logger log) {
        return new ConfigSchemaValidator(config, log)
            // ── Game settings ──
            .require("game.min-players-to-start",      Integer.class,  n -> n >= 2 && n <= 100)
            .require("game.max-players",                Integer.class,  n -> n >= 2 && n <= 200)
            .require("game.countdown-seconds",          Integer.class,  n -> n >= 5 && n <= 120)
            .require("game.reset-delay-seconds",        Integer.class,  n -> n >= 1 && n <= 60)
            .require("game.border-initial-size",        Double.class,   d -> d >= 50 && d <= 10_000)
            .require("game.border-min-size",            Double.class,   d -> d >= 5  && d <= 500)
            .require("game.border-shrink-phase-seconds",Integer.class,  n -> n >= 30 && n <= 3_600)
            .require("game.feast-delay-seconds",        Long.class,     n -> n >= 30 && n <= 1_800)
            // ── Arena settings ──
            .require("arena.veinminer-max-size",        Integer.class,  n -> n >= 1  && n <= 128)
            .optional("arena.builtin-veinminer",        Boolean.class,  null)
            .optional("arena.show-build-progress",      Boolean.class,  null)
            .optional("arena.cornucopia-radius",        Integer.class,  n -> n >= 10 && n <= 300)
            // ── Performance settings ──
            .optional("performance.block-processing.max-blocks-per-tick", Integer.class, n -> n >= 50 && n <= 2_000)
            .optional("performance.effects-optimization.particle-reduction-threshold", Integer.class, n -> n >= 1)
            // ── Ability settings ──
            .optional("abilities.spi-override-allow",   Boolean.class,  null)
            .validate();
    }

    // ── Internals ─────────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private <T> void validate(SchemaEntry<T> entry) {
        boolean present = config.contains(entry.path());
        if (!present) {
            if (entry.required()) {
                violations.add(new Violation(entry.path(),
                        "required key is missing from config.yml", entry.severity()));
            }
            return; // optional + absent = OK
        }
        Object raw = config.get(entry.path());
        T value;
        try {
            value = (T) coerce(raw, entry.type());
        } catch (ClassCastException | NullPointerException e) {
            violations.add(new Violation(entry.path(),
                    "expected " + entry.type().getSimpleName() + " but got "
                    + (raw == null ? "null" : raw.getClass().getSimpleName()),
                    entry.severity()));
            return;
        }
        if (entry.constraint() != null && !entry.constraint().test(value)) {
            violations.add(new Violation(entry.path(),
                    "value " + value + " failed constraint check", entry.severity()));
        }
    }

    @SuppressWarnings("unchecked")
    private <T> T coerce(Object raw, Class<T> type) {
        if (type == Integer.class) return (T) Integer.valueOf(raw instanceof Number n ? n.intValue() : Integer.parseInt(raw.toString()));
        if (type == Long.class)    return (T) Long.valueOf(raw instanceof Number n ? n.longValue() : Long.parseLong(raw.toString()));
        if (type == Double.class)  return (T) Double.valueOf(raw instanceof Number n ? n.doubleValue() : Double.parseDouble(raw.toString()));
        if (type == Boolean.class) return (T) Boolean.valueOf(raw instanceof Boolean b ? b : Boolean.parseBoolean(raw.toString()));
        if (type == String.class)  return (T) raw.toString();
        return type.cast(raw);
    }

    // ── Schema entry record ───────────────────────────────────────────────────

    private record SchemaEntry<T>(
            String path,
            Class<T> type,
            Predicate<T> constraint,
            boolean required,
            Severity severity
    ) {}
}
