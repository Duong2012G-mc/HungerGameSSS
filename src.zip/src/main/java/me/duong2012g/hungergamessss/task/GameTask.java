package me.duong2012g.hungergamessss.task;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * GameTask handles per-tick arena logic: timer, phase transitions, win condition, auto-reset.
 */
public class GameTask extends BukkitRunnable {
    private final Main plugin;
    private final Arena arena;
    private final Logger log;
    private static final int DEFAULT_STRUCTURE_INTERVAL = 300;
    private static final int STRUCTURE_MIN_RADIUS = 20;
    private static final int STRUCTURE_MAX_RADIUS = 100;
    // FIX H-01: was 120 — config.yml declares grace: 30. Fallback must match to avoid
    // a mismatched grace window when the config key is absent.
    private static final int DEFAULT_GRACE_TIME = 30;
    private static final int DEFAULT_MAIN_TIME = 600;
    private static final int DEFAULT_DEATHMATCH_TIME = 300;

    // Static tick method to avoid object creation overhead
    public static void tick(Arena arena) {
        Main plugin = Main.getInstance();
        MatchState state = arena.getState();
        if (state == MatchState.WAITING || state == MatchState.ENDING || state == MatchState.STARTING) return;

        // Increment timer only during PLAYING/DEATHMATCH
        arena.setTimer(arena.getTimer() + 1);
        
        // Update Scoreboards (Time/Stats changed)
        if (plugin.getScoreboardManager() != null) {
            plugin.getScoreboardManager().updateScoreboards(arena);
        }

        // 1. Initial Match Setup (Second 1)
        if (arena.getTimer() == 1) {
            setupInitialMatchState(arena, plugin);
        }

        // 2. Phase transitions
        handlePhaseTransitions(arena, plugin);

        // 3. World Border Management
        handleWorldBorder(arena, plugin);

        // 3. Other Logic
        if (state == MatchState.PLAYING || state == MatchState.DEATHMATCH) {
            // Stats are now in GamePlayer, we don't need checkWin every tick if we use handleDeath,
            // but we can keep it as a safety check.
            plugin.getMatchService().checkWin(arena);
            
            // Auto Save Arena (every 60 seconds)
            if (arena.getTimer() % 60 == 0) {
                 plugin.getArenaManager().saveArena(arena);
            }

            // High-tier loot Feast event
            if (plugin.getFeastManager() != null) {
                plugin.getFeastManager().tick(arena);
            }

            // Auto Spawn Structures
            int interval = plugin.getConfig().getInt("game.structure-spawn-interval", DEFAULT_STRUCTURE_INTERVAL);
            if (interval > 0 && arena.getTimer() % interval == 0) {
                if (plugin.getStructureManager() != null) {
                    plugin.getStructureManager().spawnRandomStructureNearPlayers(arena, STRUCTURE_MIN_RADIUS, STRUCTURE_MAX_RADIUS);
                }
            }
        }
    }

    private static void setupInitialMatchState(Arena arena, Main plugin) {
        // BroadCast Grace Period Start
        broadcast(arena, plugin.getMessageManager().getMessage("grace_period_started"));
        
        // Initial Border
        if (arena.getWorld() != null) {
            org.bukkit.WorldBorder border = arena.getWorld().getWorldBorder();
            border.setCenter(arena.getCornucopia());
            border.setSize(plugin.getConfig().getDouble("game.initial-border-size", 1000.0));
        }
    }

    private static void handleWorldBorder(Arena arena, Main plugin) {
        if (arena.getWorld() == null) return;
        
        int timer = arena.getTimer();
        int grace = plugin.getConfig().getInt("game.phases.grace", DEFAULT_GRACE_TIME);
        int main = plugin.getConfig().getInt("game.phases.main", DEFAULT_MAIN_TIME);
        double initialSize = plugin.getConfig().getDouble("game.border.initial-size", 1000.0);
        double middleSize = plugin.getConfig().getDouble("game.border.middle-size", 500.0);
        double dmSize = plugin.getConfig().getDouble("game.border.dm-size", 100.0);
        
        org.bukkit.WorldBorder border = arena.getWorld().getWorldBorder();

        // BUG-GT-01 Fix: Phase 1 and Phase 2 previously both ran during the last 60s of main
        // (dmStartShrink..main overlap with grace..main), causing Phase 2 to overwrite Phase 1
        // each tick, making the border jump to middleSize then fast-shrink to dmSize.
        // Fix: make the ranges mutually exclusive — Phase 1 only up to dmStartShrink,
        // Phase 2 takes over for the final 60 seconds.
        int dmStartShrink = main - 60;

        if (timer > grace && timer <= dmStartShrink) {
            // Phase 1: Slow shrink — initialSize → middleSize over (grace..dmStartShrink)
            double progress = (double)(timer - grace) / (dmStartShrink - grace);
            double currentSize = initialSize - (initialSize - middleSize) * progress;
            border.setSize(currentSize);

            if (timer == grace + 1) {
                arena.broadcast(plugin.getMessageManager().getMessage("border_shrinking_main"));
            }
        } else if (timer > dmStartShrink && timer <= main) {
            // Phase 2: Fast shrink — middleSize → dmSize over the final 60 seconds
            double progress = (double)(timer - dmStartShrink) / 60.0;
            double currentSize = middleSize - (middleSize - dmSize) * progress;
            border.setSize(currentSize);

            if (timer == dmStartShrink + 1) {
                arena.broadcast(plugin.getMessageManager().getMessage("border_shrinking_dm"));
            }
        }
    }

    private static void handlePhaseTransitions(Arena arena, Main plugin) {
        int timer = arena.getTimer();
        int grace = plugin.getConfig().getInt("game.phases.grace", DEFAULT_GRACE_TIME);
        int main = plugin.getConfig().getInt("game.phases.main", DEFAULT_MAIN_TIME);
        int deathmatch = plugin.getConfig().getInt("game.phases.deathmatch", DEFAULT_DEATHMATCH_TIME);

        // Grace Period Ended
        if (arena.getState() == MatchState.PLAYING && timer == grace) {
            broadcast(arena, plugin.getMessageManager().getMessage("grace_period_ended"));
            for (UUID uuid : arena.getPlayers()) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null) p.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_WITHER_SPAWN, 1f, 1f);
            }
        }

        // PLAYING -> DEATHMATCH
        if (arena.getState() == MatchState.PLAYING && timer >= main) {
            arena.setState(MatchState.DEATHMATCH);
            broadcast(arena, plugin.getMessageManager().getMessage("deathmatch_started"));
            // Teleport survivors to center? Optional but recommended for DM
        }

        // DEATHMATCH -> ENDING
        if (arena.getState() == MatchState.DEATHMATCH && (timer - main) >= deathmatch) {
            plugin.getMatchService().endGame(arena, null);
        }
    }

    // Removed checkWinCondition as it's handled by MatchService
    
    private static void broadcast(Arena arena, String message) {
        for (UUID uuid : arena.getPlayers()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                p.sendMessage(message);
            }
        }
    }

    // Keep constructor/run for compatibility if needed, but we prefer static usage
    public GameTask(Arena arena) {
        this.arena = arena;
        this.plugin = Main.getInstance();
        this.log = plugin.getLogger();
    }

    /**
     * FIX L-10: GameTask extends BukkitRunnable but is NEVER independently scheduled.
     * All arena ticking is driven exclusively by the single 20-tick global loop in
     * {@code Main.onEnable()} via {@code ArenaManager.tick()} → {@code GameTask.tick(Arena)}.
     *
     * If this method is ever called it means someone accidentally scheduled a GameTask
     * instance directly, which would cause every arena to tick twice per second.
     * We throw immediately so the bug is caught during development rather than silently
     * doubling arena timer speed in production.
     */
    @Override
    public void run() {
        throw new UnsupportedOperationException(
            "GameTask must not be scheduled directly. Use GameTask.tick(arena) " +
            "or let ArenaManager.tick() drive the game loop.");
    }
}
