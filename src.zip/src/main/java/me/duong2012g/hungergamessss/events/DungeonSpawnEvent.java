package me.duong2012g.hungergamessss.events;

import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.Location;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class DungeonSpawnEvent extends Event implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Arena arena;
    private final Location location;
    private final String type;
    private boolean cancelled;

    public DungeonSpawnEvent(Arena arena, Location location, String type) {
        this.arena = arena;
        this.location = location;
        this.type = type;
    }

    public Arena getArena() {
        return this.arena;
    }

    public Location getLocation() {
        return this.location;
    }

    public String getType() {
        return this.type;
    }

    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
