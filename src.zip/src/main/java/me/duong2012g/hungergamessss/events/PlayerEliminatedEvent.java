package me.duong2012g.hungergamessss.events;

import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class PlayerEliminatedEvent extends Event {
    private static final HandlerList handlers = new HandlerList();
    private final Arena arena;
    private final Player player;
    private final Player killer;

    public PlayerEliminatedEvent(Arena arena, Player player, Player killer) {
        this.arena = arena;
        this.player = player;
        this.killer = killer;
    }

    public Arena getArena() {
        return arena;
    }

    public Player getPlayer() {
        return player;
    }

    public Player getKiller() {
        return killer;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}
