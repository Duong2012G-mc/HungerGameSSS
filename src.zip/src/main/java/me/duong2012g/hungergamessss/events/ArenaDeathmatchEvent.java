package me.duong2012g.hungergamessss.events;

import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * ARCH-MS-03: Fired when an arena transitions from PLAYING → DEATHMATCH.
 * External plugins can listen to this event to:
 *   – apply deathmatch-specific buffs / debuffs
 *   – announce deathmatch in chat bridges
 *   – trigger mini-boss spawns
 */
public class ArenaDeathmatchEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Arena arena;

    public ArenaDeathmatchEvent(Arena arena) {
        this.arena = arena;
    }

    /** @return The arena entering deathmatch phase. */
    public Arena getArena() { return arena; }

    @Override
    public HandlerList getHandlers() { return HANDLERS; }

    public static HandlerList getHandlerList() { return HANDLERS; }
}
