package me.duong2012g.hungergamessss;

import me.duong2012g.hungergamessss.command.*;
import me.duong2012g.hungergamessss.database.DatabaseManager;
import me.duong2012g.hungergamessss.listener.*;
import me.duong2012g.hungergamessss.manager.*;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.service.MatchService;
import me.duong2012g.hungergamessss.task.GameTask;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.File;
import java.util.logging.Logger;

public class Main extends JavaPlugin {
    private static Main instance;
    private final Logger log = getLogger();
    // A2-4: Paper SLF4J ComponentLogger — structured, MDC-compatible logging.
    // Lazy-initialised in clog() so class load doesn't fail on older Paper builds.
    private net.kyori.adventure.text.logger.slf4j.ComponentLogger componentLog;
    private FileConfiguration performanceConfig;
    
    private AbilityManager abilityManager;
    private ArenaManager arenaManager;
    private DungeonManager dungeonManager;
    private LobbyManager lobbyManager;
    private MessageManager messageManager;
    private PerformanceOptimizer performanceOptimizer;
    private PlayerManager playerManager;
    private ScoreboardManager scoreboardManager;
    private SelectionManager selectionManager;
    private ArenaEntityTracker entityTracker; // A1-S3: unified custom-entity lifecycle manager
    private StructureManager structureManager;
    private SchematicManager schematicManager;
    private CornucopiaBuilder cornucopiaBuilder;
    private MatchService matchService;
    private CooldownManager cooldownManager;
    private DatabaseManager databaseManager;
    private HologramManager hologramManager;
    private TeamManager teamManager;
    private RecipeManager recipeManager;
    private PortalManager portalManager;
    private me.duong2012g.hungergamessss.listener.ArenaSetupListener arenaSetupListener;
    private FeastManager feastManager;
    private AbilityListener abilityListener;
    private LootTableManager lootTableManager;
    private UpdateManager updateManager;
    // FIX BUG-MAIN-01: store game-loop task reference so it can be cancelled in onDisable()
    private org.bukkit.scheduler.BukkitTask gameLoopTask;

    @Override
    public void onEnable() {
        instance = this;

        // IMP-MAIN-01: validate hard requirements before initialising anything
        if (!validateEnvironment()) return;

        saveDefaultConfig();
        loadPerformanceConfig();
        loadCornucopiaConfig();

        registerManagers();
        registerListeners();
        registerCommands();
        postStartup();

        log.info("HungerGamesSSS v" + getDescription().getVersion() + " enabled.");
    }

    /** SLF4J-backed structured logger (Paper 1.21+). Falls back gracefully on older builds. */
    public net.kyori.adventure.text.logger.slf4j.ComponentLogger clog() {
        if (componentLog == null) {
            try { componentLog = getComponentLogger(); } catch (NoSuchMethodError ignored) {}
        }
        return componentLog;
    }

    /** Checks Java 21 + Paper API presence. Disables the plugin and returns false if unmet. */
    private boolean validateEnvironment() {
        int javaVersion = Runtime.version().feature();
        if (javaVersion < 21) {
            log.severe("Java 21+ required. Current: Java " + javaVersion + ". Disabling.");
            getServer().getPluginManager().disablePlugin(this); return false;
        }
        try { Class.forName("io.papermc.paper.event.player.AsyncChatEvent"); }
        catch (ClassNotFoundException e) {
            log.severe("Paper 1.21+ required (Spigot not supported). Disabling.");
            getServer().getPluginManager().disablePlugin(this); return false;
        }
        return true;
    }

    /**
     * IMP-CFG-01: validates critical numerical config values at startup.
     * Out-of-range values are logged as warnings so admins can fix them before
     * a match starts rather than discovering they silently cap at runtime.
     */
    private void validateConfig() {
        int warnings = 0;
        warnings += assertRange("game.min-players-to-start", 2, 2, 100);
        warnings += assertRange("game.max-players", 24, 2, 200);
        warnings += assertRange("game.countdown-seconds", 20, 5, 120);
        warnings += assertRange("game.reset-delay-seconds", 5, 1, 60);
        warnings += assertRange("game.border-initial-size", 1000, 50, 10000);
        warnings += assertRange("game.border-min-size", 20, 5, 500);
        warnings += assertRange("game.border-shrink-phase-seconds", 300, 30, 3600);
        warnings += assertRange("game.feast-delay-seconds", 180, 30, 1800);
        warnings += assertRange("arena.veinminer-max-size", 64, 1, 128);
        // Ability-specific range checks
        for (String key : getConfig().getKeys(true)) {
            if (!key.startsWith("abilities.")) continue;
            if (key.endsWith(".damage") || key.endsWith(".explosion_damage") || key.endsWith(".direct_damage")) {
                warnings += assertRange(key, 10, 0, 400);
            }
            if (key.endsWith(".radius") || key.endsWith(".explosion_radius") || key.endsWith(".splash_radius")) {
                warnings += assertRange(key, 5, 0, 50);
            }
        }
        if (warnings > 0) {
            log.warning("[Config] " + warnings + " config value(s) out of expected range — check above warnings.");
        }
    }

    /** Returns 1 and logs a warning if the config value is outside [min, max]; 0 otherwise. */
    private int assertRange(String path, double defaultVal, double min, double max) {
        double val = getConfig().getDouble(path, defaultVal);
        if (val < min || val > max) {
            log.warning("[Config] '" + path + "' = " + val
                    + " is outside expected range [" + min + ", " + max + "]. Using as-is.");
            return 1;
        }
        return 0;
    }

    private boolean checkCompatibility() {
        int javaVersion = Runtime.version().feature();
        if (javaVersion < 21) {
            log.severe("Java 21+ required. Current: Java " + javaVersion + ". Disabling.");
            getServer().getPluginManager().disablePlugin(this); return false;
        }
        try { Class.forName("io.papermc.paper.event.player.AsyncChatEvent"); }
        catch (ClassNotFoundException e) {
            log.severe("Paper 1.21+ required (Spigot not supported). Disabling.");
            getServer().getPluginManager().disablePlugin(this); return false;
        }
        return true;
    }

    private void registerManagers() {
        this.messageManager = new MessageManager(this);
        this.databaseManager = new DatabaseManager(this);
        this.playerManager = new PlayerManager(this);
        this.teamManager = new TeamManager(this);
        this.arenaManager = new ArenaManager(this);
        this.abilityManager = new AbilityManager(this);
        this.lootTableManager = new LootTableManager(this);
        this.cooldownManager = new CooldownManager(this);
        this.dungeonManager = new DungeonManager(this);
        this.lobbyManager = new LobbyManager(this);
        this.hologramManager = new HologramManager(this);
        this.recipeManager = new RecipeManager(this, this.abilityManager);
        this.portalManager = new PortalManager(this);
        this.structureManager = new StructureManager(this);
        this.performanceOptimizer = new PerformanceOptimizer(this);
        this.matchService = new MatchService(this);
        this.feastManager = new FeastManager(this);
        this.abilityListener = new AbilityListener(this);
        this.updateManager = new UpdateManager(this);
        this.updateManager.checkForUpdates();

        if (getServer().getPluginManager().getPlugin("FastAsyncWorldEdit") != null) {
            this.schematicManager = new SchematicManager(this);
            log.info("FastAsyncWorldEdit found — structure system enhanced.");
        }
        this.cornucopiaBuilder = new CornucopiaBuilder(this);
        this.scoreboardManager = new ScoreboardManager(this);
        this.selectionManager = new SelectionManager(this);
        this.entityTracker = new ArenaEntityTracker(this); // A1-S3

        this.databaseManager.loadArenas(this.arenaManager);
        this.databaseManager.loadTeams(this.teamManager);
        this.arenaSetupListener = new me.duong2012g.hungergamessss.listener.ArenaSetupListener(this);
    }

    private void registerListeners() {
        org.bukkit.plugin.PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(lobbyManager, this);
        pm.registerEvents(playerManager, this);
        pm.registerEvents(dungeonManager, this);
        pm.registerEvents(abilityListener, this);
        pm.registerEvents(new PlayerJoinListener(this), this);
        pm.registerEvents(new PlayerQuitListener(this), this);
        pm.registerEvents(new ConnectionListener(this), this);
        pm.registerEvents(new PlayerRespawnListener(this), this);
        pm.registerEvents(new ArenaListener(this), this);
        pm.registerEvents(new PlayerDeathListener(this), this);
        pm.registerEvents(new BlockBreakListener(this), this);
        pm.registerEvents(new EntityDamageListener(this), this);
        // A2-22: VeinMiner is now opt-in (disabled by default).
        // Set arena.builtin-veinminer: true to enable the built-in implementation.
        // For production servers, use a dedicated VeinMiner plugin and integrate
        // via HungerGamesAPI.isInMatch() to restrict it to arena players.
        if (getConfig().getBoolean("arena.builtin-veinminer", false)) {
            pm.registerEvents(new VeinMinerListener(this), this);
            log.info("[HG] Built-in VeinMiner enabled via config (arena.builtin-veinminer: true).");
        }
        pm.registerEvents(arenaSetupListener, this);
        pm.registerEvents(new SelectionListener(this), this);
        pm.registerEvents(new AnvilListener(this), this);
    }

    private void registerCommands() {
        registerCommand("hg",          new HGCommand(this),          new HGTabCompleter());
        registerCommand("team",        new TeamCommand(this),         new TeamTabCompleter());
        registerCommand("tc",          new TCCommand(this),           new TCTabCompleter());
        registerCommand("perf",        new PerformanceCommand(this),  new PerformanceTabCompleter());
        registerCommand("structure",   new StructureCommand(this),    new StructureTabCompleter());
        registerCommand("locate",      new LocateCommand(this),       new LocateTabCompleter());
        registerCommand("autofix",     new AutoFixCommand(this),      new EmptyTabCompleter());
        registerCommand("startserver", new StartServerCommand(this),  new EmptyTabCompleter());
        registerCommand("debug",       new DebugCommand(this),        new EmptyTabCompleter());
        registerCommand("withdraw",    new WithdrawCommand(this),     new WithdrawTabCompleter());
        registerCommand("migrate",     new MigrateCommand(this),      new EmptyTabCompleter());
        registerCommand("dn",          new me.duong2012g.hungergamessss.command.DeathNoteCommand(this),
                new me.duong2012g.hungergamessss.command.DeathNoteTabCompleter(this));
    }

    private void postStartup() {
        this.recipeManager.registerRecipes();
        // IMP-CFG-01: validate config ranges before the game can start
        validateConfig();

        for (me.duong2012g.hungergamessss.model.Arena arena : arenaManager.getArenas().values()) {
            if (arena.getState() == me.duong2012g.hungergamessss.model.MatchState.ENDING) {
                matchService.resetArena(arena);
                log.info("Reset stuck arena '" + arena.getName() + "' from ENDING state.");
            }
        }

        gameLoopTask = new org.bukkit.scheduler.BukkitRunnable() {
            @Override public void run() { if (arenaManager != null) arenaManager.tick(); }
        }.runTaskTimer(this, 20L, 20L);

        for (org.bukkit.entity.Player player : org.bukkit.Bukkit.getOnlinePlayers()) {
            me.duong2012g.hungergamessss.model.Arena arena = arenaManager.getArenaByPlayer(player);
            if (arena != null && matchService != null) {
                matchService.restoreSession(player, arena);
                log.info("Restored session for " + player.getName() + " in arena " + arena.getName());
            }
        }
    }

        
    private void registerCommand(String name, org.bukkit.command.CommandExecutor executor, org.bukkit.command.TabCompleter tabCompleter) {
        org.bukkit.command.PluginCommand command = getCommand(name);
        if (command != null) {
            command.setExecutor(executor);
            if (tabCompleter != null) {
                command.setTabCompleter(tabCompleter);
            }
        } else {
            getLogger().warning("Command '" + name + "' not found in plugin.yml!");
        }
    }

    @Override
    public void onDisable() {
        // FIX BUG-MAIN-01: cancel game loop task to prevent orphaned repeating tasks on reload
        if (gameLoopTask != null && !gameLoopTask.isCancelled()) {
            gameLoopTask.cancel();
        }
        // FIX BUG-CM-01: shut down cooldown manager (cancels display task, clears state)
        if (cooldownManager != null) {
            cooldownManager.shutdown();
        }
        // FIX M-01: cancel the unified passive ticker and any legacy ability tasks
        // FIX: AbilityManager.shutdown() now calls cleanup() on ALL abilities via
        // AbilityRegistry.shutdownAll(). Manual per-ability calls are no longer needed.
        if (abilityManager != null) {
            abilityManager.shutdown();
        }
        // A2-S5: invalidate Developer API singleton
        me.duong2012g.hungergamessss.api.HungerGamesAPI.invalidate();
        if (entityTracker != null) {
            entityTracker.shutdown();
        }
        
        if (hologramManager != null) {
            hologramManager.removeAllHolograms();
        }
        if (databaseManager != null) {
            // Save stats for all online players before shutdown
            for (org.bukkit.entity.Player player : org.bukkit.Bukkit.getOnlinePlayers()) {
                databaseManager.savePlayerStats(player);
            }
            databaseManager.saveAllArenas();
            databaseManager.close();
        }
        getLogger().info("HungerGames plugin disabled!");
    }

    public static Main getInstance() {
        return instance;
    }

    public AbilityManager getAbilityManager() {
        return abilityManager;
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public ArenaManager getArenaManager() {
        return arenaManager;
    }

    public DungeonManager getDungeonManager() {
        return dungeonManager;
    }

    public LobbyManager getLobbyManager() {
        return lobbyManager;
    }

    public UpdateManager getUpdateManager() {
        return updateManager;
    }

    public MessageManager getMessageManager() {
        return messageManager;
    }

    public PerformanceOptimizer getPerformanceOptimizer() {
        return performanceOptimizer;
    }

    public PlayerManager getPlayerManager() {
        return playerManager;
    }

    public ScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }

    public SelectionManager getSelectionManager() {
        return selectionManager;
    }

    /** A1-S3: Unified tracker for all custom entities spawned by abilities. */
    public ArenaEntityTracker getEntityTracker() { return entityTracker; }

    public StructureManager getStructureManager() {
        return structureManager;
    }

    public SchematicManager getSchematicManager() {
        return schematicManager;
    }

    public CornucopiaBuilder getCornucopiaBuilder() {
        return cornucopiaBuilder;
    }

    public MatchService getMatchService() {
        return matchService;
    }

    public FeastManager getFeastManager() {
        return feastManager;
    }

    public LootTableManager getLootTableManager() {
        return lootTableManager;
    }

    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }

    public TeamManager getTeamManager() {
        return teamManager;
    }
    
    public HologramManager getHologramManager() {
        return hologramManager;
    }
    
    public me.duong2012g.hungergamessss.listener.ArenaSetupListener getArenaSetupListener() {
        return arenaSetupListener;
    }

    public PortalManager getPortalManager() { return portalManager; }

    public void loadPerformanceConfig() {
        File file = new File(getDataFolder(), "performance.yml");
        if (!file.exists()) {
            saveResource("performance.yml", false);
        }
        performanceConfig = YamlConfiguration.loadConfiguration(file);
    }

    public void loadCornucopiaConfig() {
        File file = new File(getDataFolder(), "cornucopia.yml");
        if (!file.exists()) {
            saveResource("cornucopia.yml", false);
        }
        // Merge into main config for easier access
        FileConfiguration cornucopiaConfig = YamlConfiguration.loadConfiguration(file);
        for (String key : cornucopiaConfig.getKeys(true)) {
            if (!getConfig().contains(key)) {
                getConfig().set(key, cornucopiaConfig.get(key));
            }
        }
    }

    public FileConfiguration getPerformanceConfig() {
        if (performanceConfig == null) {
            loadPerformanceConfig();
        }
        return performanceConfig;
    }
}
