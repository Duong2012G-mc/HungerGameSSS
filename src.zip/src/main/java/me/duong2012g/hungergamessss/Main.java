package me.duong2012g.hungergamessss;

import me.duong2012g.hungergamessss.command.*;
import me.duong2012g.hungergamessss.database.DatabaseManager;
import me.duong2012g.hungergamessss.listener.*;
import me.duong2012g.hungergamessss.manager.*;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.service.MatchService;
import me.duong2012g.hungergamessss.task.GameTask;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.File;
import java.util.logging.Logger;

public class Main extends JavaPlugin {
    private static Main instance;
    private final Logger log = getLogger();
    private FileConfiguration performanceConfig;
    
    private AbilityManager abilityManager;
    private ArenaManager arenaManager;
    private DungeonManager dungeonManager;
    private LobbyManager lobbyManager;
    private MessageManager messageManager;
    private PerformanceOptimizer performanceOptimizer;
    private PlayerManager playerManager;
    private ScoreboardManager scoreboardManager;
    private SelectionManager selectionManager;
    private StructureManager structureManager;
    private SchematicManager schematicManager;
    private CornucopiaBuilder cornucopiaBuilder;
    private MatchService matchService;
    private CooldownManager cooldownManager;
    private DatabaseManager databaseManager;
    private HologramManager hologramManager;
    private TeamManager teamManager;
    private RecipeManager recipeManager;
    private PortalManager portalManager;
    private me.duong2012g.hungergamessss.listener.ArenaSetupListener arenaSetupListener;
    private FeastManager feastManager;
    private AbilityListener abilityListener;
    private LootTableManager lootTableManager;
    private UpdateManager updateManager;

    @Override
    public void onEnable() {
        instance = this;
        
        saveDefaultConfig();
        loadPerformanceConfig();
        loadCornucopiaConfig();
        
        // Initialize Managers
        this.messageManager = new MessageManager(this);
        this.databaseManager = new DatabaseManager(this);
        this.playerManager = new PlayerManager(this);
        this.teamManager = new TeamManager(this);
        this.arenaManager = new ArenaManager(this);
        this.abilityManager = new AbilityManager(this);
        this.lootTableManager = new LootTableManager(this);
        this.cooldownManager = new CooldownManager(this);
        this.dungeonManager = new DungeonManager(this);
        this.lobbyManager = new LobbyManager(this);
        this.hologramManager = new HologramManager(this);
        this.recipeManager = new RecipeManager(this, this.abilityManager);
        this.portalManager = new PortalManager(this);
        this.structureManager = new StructureManager(this);
        this.performanceOptimizer = new PerformanceOptimizer(this);
        this.matchService = new MatchService(this);
        this.feastManager = new FeastManager(this);
        this.abilityListener = new AbilityListener(this);
        this.updateManager = new UpdateManager(this);
        this.updateManager.checkForUpdates();
        
        // Check for FastAsyncWorldEdit (Optional but recommended)
        if (getServer().getPluginManager().getPlugin("FastAsyncWorldEdit") != null) {
            this.schematicManager = new SchematicManager(this);
            log.info("FastAsyncWorldEdit found! Structure system enhanced.");
        }

        this.cornucopiaBuilder = new CornucopiaBuilder(this);
        this.scoreboardManager = new ScoreboardManager(this);
        this.selectionManager = new SelectionManager(this);
        
        this.databaseManager.loadArenas(this.arenaManager);
        this.databaseManager.loadTeams(this.teamManager);
        this.arenaSetupListener = new me.duong2012g.hungergamessss.listener.ArenaSetupListener(this);
        
        // Register All Listeners
        registerListeners();
        
        // Register Recipes
        this.recipeManager.registerRecipes();
        
        // Reset stuck arenas (e.g. from crash during ENDING)
        for (me.duong2012g.hungergamessss.model.Arena arena : arenaManager.getArenas().values()) {
            if (arena.getState() == me.duong2012g.hungergamessss.model.MatchState.ENDING) {
                matchService.resetArena(arena);
                getLogger().info("Reset stuck arena " + arena.getName() + " from ENDING state");
            }
        }

        // Start Global Game Loop
        new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                if (arenaManager != null) {
                    arenaManager.tick();
                }
                // BUG-PERF-01: Removed hologramManager.updateHolograms() - already done in ArenaManager.tickHolograms()
            }
        }.runTaskTimer(this, 20L, 20L); // Run every second (20 ticks)
        
        // Handle reload: check for online players in loaded arenas
        for (org.bukkit.entity.Player player : org.bukkit.Bukkit.getOnlinePlayers()) {
            me.duong2012g.hungergamessss.model.Arena arena = arenaManager.getArenaByPlayer(player);
            if (arena != null) {
                 // Re-initialize player view if needed (scoreboard, bossbar)
                 if (matchService != null) {
                     matchService.restoreSession(player, arena);
                 }
                 getLogger().info("Restored game session for player " + player.getName() + " in arena " + arena.getName());
            }
        }
        
        // Register Commands
        registerCommand("hg", new HGCommand(this), new HGTabCompleter());
        registerCommand("team", new TeamCommand(this), new TeamTabCompleter());
        registerCommand("tc", new TCCommand(this), new TCTabCompleter());
        registerCommand("perf", new PerformanceCommand(this), new PerformanceTabCompleter());
        registerCommand("structure", new StructureCommand(this), new StructureTabCompleter());
        registerCommand("locate", new LocateCommand(this), new LocateTabCompleter());
        registerCommand("autofix", new AutoFixCommand(this), new EmptyTabCompleter());
        registerCommand("startserver", new StartServerCommand(this), new EmptyTabCompleter());
        registerCommand("debug", new DebugCommand(this), new EmptyTabCompleter());
        registerCommand("withdraw", new WithdrawCommand(this), new WithdrawTabCompleter());
        registerCommand("migrate", new MigrateCommand(this), new EmptyTabCompleter());
        registerCommand("dn", new me.duong2012g.hungergamessss.command.DeathNoteCommand(this),
                new me.duong2012g.hungergamessss.command.DeathNoteTabCompleter(this));
        
        log.info("HungerGamesSSS has been enabled!");
    }

    private void registerListeners() {
        org.bukkit.plugin.PluginManager pm = getServer().getPluginManager();
        
        // Core Managers
        pm.registerEvents(lobbyManager, this);
        pm.registerEvents(playerManager, this);
        pm.registerEvents(dungeonManager, this);
        pm.registerEvents(abilityListener, this);
        
        // Connection & Session
        pm.registerEvents(new PlayerJoinListener(this), this);
        pm.registerEvents(new PlayerQuitListener(this), this);
        pm.registerEvents(new ConnectionListener(this), this);
        pm.registerEvents(new PlayerRespawnListener(this), this);
        
        // Gameplay & World
        pm.registerEvents(new ArenaListener(this), this);
        pm.registerEvents(new PlayerDeathListener(this), this);
        pm.registerEvents(new BlockBreakListener(this), this);
        pm.registerEvents(new EntityDamageListener(this), this);
        pm.registerEvents(new VeinMinerListener(this), this);
        
        // Setup
        pm.registerEvents(arenaSetupListener, this);
        pm.registerEvents(new SelectionListener(this), this);

        // Anvil — custom upgrade rules for legendary items
        pm.registerEvents(new AnvilListener(this), this);
    }

    private void registerCommand(String name, org.bukkit.command.CommandExecutor executor, org.bukkit.command.TabCompleter tabCompleter) {
        org.bukkit.command.PluginCommand command = getCommand(name);
        if (command != null) {
            command.setExecutor(executor);
            if (tabCompleter != null) {
                command.setTabCompleter(tabCompleter);
            }
        } else {
            getLogger().warning("Command '" + name + "' not found in plugin.yml!");
        }
    }

    @Override
    public void onDisable() {
        // FIX M-01: cancel the unified passive ticker and any legacy ability tasks
        // FIX: AbilityManager.shutdown() now calls cleanup() on ALL abilities via
        // AbilityRegistry.shutdownAll(). Manual per-ability calls are no longer needed.
        if (abilityManager != null) {
            abilityManager.shutdown();
        }
        
        if (hologramManager != null) {
            hologramManager.removeAllHolograms();
        }
        if (databaseManager != null) {
            // Save stats for all online players before shutdown
            for (org.bukkit.entity.Player player : org.bukkit.Bukkit.getOnlinePlayers()) {
                databaseManager.savePlayerStats(player);
            }
            databaseManager.saveAllArenas();
            databaseManager.close();
        }
        getLogger().info("HungerGames plugin disabled!");
    }

    public static Main getInstance() {
        return instance;
    }

    public AbilityManager getAbilityManager() {
        return abilityManager;
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public ArenaManager getArenaManager() {
        return arenaManager;
    }

    public DungeonManager getDungeonManager() {
        return dungeonManager;
    }

    public LobbyManager getLobbyManager() {
        return lobbyManager;
    }

    public UpdateManager getUpdateManager() {
        return updateManager;
    }

    public MessageManager getMessageManager() {
        return messageManager;
    }

    public PerformanceOptimizer getPerformanceOptimizer() {
        return performanceOptimizer;
    }

    public PlayerManager getPlayerManager() {
        return playerManager;
    }

    public ScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }

    public SelectionManager getSelectionManager() {
        return selectionManager;
    }

    public StructureManager getStructureManager() {
        return structureManager;
    }

    public SchematicManager getSchematicManager() {
        return schematicManager;
    }

    public CornucopiaBuilder getCornucopiaBuilder() {
        return cornucopiaBuilder;
    }

    public MatchService getMatchService() {
        return matchService;
    }

    public FeastManager getFeastManager() {
        return feastManager;
    }

    public LootTableManager getLootTableManager() {
        return lootTableManager;
    }

    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }

    public TeamManager getTeamManager() {
        return teamManager;
    }
    
    public HologramManager getHologramManager() {
        return hologramManager;
    }
    
    public me.duong2012g.hungergamessss.listener.ArenaSetupListener getArenaSetupListener() {
        return arenaSetupListener;
    }

    public PortalManager getPortalManager() { return portalManager; }

    public void loadPerformanceConfig() {
        File file = new File(getDataFolder(), "performance.yml");
        if (!file.exists()) {
            saveResource("performance.yml", false);
        }
        performanceConfig = YamlConfiguration.loadConfiguration(file);
    }

    public void loadCornucopiaConfig() {
        File file = new File(getDataFolder(), "cornucopia.yml");
        if (!file.exists()) {
            saveResource("cornucopia.yml", false);
        }
        // Merge into main config for easier access
        FileConfiguration cornucopiaConfig = YamlConfiguration.loadConfiguration(file);
        for (String key : cornucopiaConfig.getKeys(true)) {
            if (!getConfig().contains(key)) {
                getConfig().set(key, cornucopiaConfig.get(key));
            }
        }
    }

    public FileConfiguration getPerformanceConfig() {
        if (performanceConfig == null) {
            loadPerformanceConfig();
        }
        return performanceConfig;
    }
}
