package me.duong2012g.hungergamessss.api;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.entity.Player;

public class HopliteAPI {
    
    public static Main getPlugin() {
        return Main.getInstance();
    }

    public static Arena getPlayerArena(Player player) {
        if (Main.getInstance() == null || Main.getInstance().getArenaManager() == null) {
            return null;
        }
        return Main.getInstance().getArenaManager().getArenaByPlayer(player);
    }
}
