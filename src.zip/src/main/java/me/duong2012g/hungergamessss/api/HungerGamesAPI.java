package me.duong2012g.hungergamessss.api;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.Ability;
import me.duong2012g.hungergamessss.ability.AbilityServices;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.List;
import java.util.Optional;

/**
 * A2-S5: Public Developer API for the HungerGamesSSS plugin.
 *
 * <p>Third-party plugins can use this API to:
 * <ul>
 *   <li>Register and unregister custom {@link Ability} implementations at runtime.</li>
 *   <li>Query arena state and player participation.</li>
 *   <li>Obtain a typed {@link AbilityServices} context for writing abilities.</li>
 * </ul>
 *
 * <h3>Getting an instance</h3>
 * <pre>{@code
 * // In your plugin's onEnable():
 * Plugin hgPlugin = Bukkit.getPluginManager().getPlugin("HungerGamesSSS");
 * if (hgPlugin instanceof Main hg) {
 *     HungerGamesAPI api = HungerGamesAPI.get();
 *     api.registerAbility(myPlugin, new MyCustomAbility(api.services()));
 * }
 * }</pre>
 *
 * <h3>Writing a custom ability</h3>
 * <pre>{@code
 * public class MyAbility extends BaseAbility implements Ability.ActiveAbility {
 *     public MyAbility(AbilityServices svc) { super(svc); }
 *
 *     @Override public String getName()    { return "My Custom Ability"; }
 *     @Override public long  getCooldown() { return 5_000L; }
 *
 *     @Override
 *     protected void performRightClick(Player p, ItemStack item, PlayerInteractEvent e) {
 *         p.sendMessage("My ability fired!");
 *     }
 * }
 * }</pre>
 */
public final class HungerGamesAPI {

    private static HungerGamesAPI instance;
    private final Main plugin;

    private HungerGamesAPI(Main plugin) {
        this.plugin = plugin;
    }

    /**
     * Returns the singleton API instance.
     * @throws IllegalStateException if HungerGamesSSS is not enabled.
     */
    public static HungerGamesAPI get() {
        if (instance == null) {
            Main main = Main.getInstance();
            if (main == null)
                throw new IllegalStateException("HungerGamesSSS is not enabled or not yet initialised.");
            instance = new HungerGamesAPI(main);
        }
        return instance;
    }

    /** @return a fully initialised {@link AbilityServices} context ready to pass to custom abilities. */
    public AbilityServices services() {
        return AbilityServices.of(plugin);
    }

    // ── Ability registration ──────────────────────────────────────────────────

    /**
     * Registers a custom ability with HungerGamesSSS.
     *
     * <p>If an ability with the same name is already registered, this method
     * throws an {@link IllegalArgumentException}. Call {@link #unregisterAbility}
     * first if you want to replace it.
     *
     * @param owner   your plugin (used for logging)
     * @param ability the ability to register
     */
    public void registerAbility(Plugin owner, Ability ability) {
        String key = ability.getName();
        Ability existing = plugin.getAbilityManager().getRegistry().getAbility(key);
        if (existing != null) {
            throw new IllegalArgumentException(
                    "[HungerGamesAPI] Ability '" + key + "' is already registered. "
                    + "Call unregisterAbility(name) first if you intend to replace it.");
        }
        plugin.getAbilityManager().getRegistry().register(ability);
        plugin.getLogger().info("[HungerGamesAPI] " + owner.getName()
                + " registered custom ability: " + key);
    }

    /**
     * Unregisters a custom ability by name.
     * Calls {@link Ability#cleanup()} before removing it.
     *
     * @param abilityName the ability's display name (case-insensitive)
     * @return {@code true} if an ability with that name was found and removed
     */
    public boolean unregisterAbility(String abilityName) {
        Ability existing = plugin.getAbilityManager().getRegistry().getAbility(abilityName);
        if (existing == null) return false;
        plugin.getAbilityManager().getRegistry().unregister(abilityName);
        return true;
    }

    /**
     * Returns the registered ability with the given name, or empty if not found.
     */
    public Optional<Ability> getAbility(String name) {
        return Optional.ofNullable(plugin.getAbilityManager().getRegistry().getAbility(name));
    }

    /**
     * Returns an unmodifiable view of all currently registered ability names.
     */
    public List<String> getRegisteredAbilityNames() {
        return plugin.getAbilityManager().getRegistry().getAllAbilityNames();
    }

    // ── Arena queries ─────────────────────────────────────────────────────────

    /**
     * Returns {@code true} if the player is currently participating in an active
     * arena match (state PLAYING or DEATHMATCH, not spectating).
     */
    public boolean isInMatch(Player player) {
        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        if (arena == null) return false;
        if (arena.getSpectators().contains(player.getUniqueId())) return false;
        return arena.getState() == MatchState.PLAYING || arena.getState() == MatchState.DEATHMATCH;
    }

    /**
     * Returns the arena the player is currently in, or empty if not in any arena.
     */
    public Optional<Arena> getArenaOf(Player player) {
        return Optional.ofNullable(plugin.getArenaManager().getArenaByPlayer(player));
    }

    /**
     * Returns all arenas currently in the given state.
     */
    public List<Arena> getArenasInState(MatchState state) {
        return plugin.getArenaManager().getArenas().values().stream()
                .filter(a -> a.getState() == state)
                .toList();
    }

    // ── Internal ──────────────────────────────────────────────────────────────

    /** Called by {@code Main.onDisable()} to invalidate the singleton. */
    public static void invalidate() {
        instance = null;
    }
}
