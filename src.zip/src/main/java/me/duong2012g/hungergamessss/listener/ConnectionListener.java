package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.net.URI;
import java.util.UUID;

/**
 * Handles player join events: resource-pack push and mid-match reconnect restore.
 *
 * FIX L-03: {@code Player.setResourcePack(url)} and {@code setResourcePack(url, hash)}
 * are deprecated on Paper 1.21. The replacement is Adventure's ResourcePackRequest API.
 *
 * FIX L-08: When a player reconnects during an active match they were previously dropped
 * to a default state (Adventure mode, no scoreboard, wrong location). Now we call
 * {@code MatchService.restoreSession()} to re-apply their game state, and move them back
 * to their last known location if they were alive.
 */
public class ConnectionListener implements Listener {
    private final Main plugin;

    public ConnectionListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // FIX L-03: Use Adventure ResourcePackRequest instead of deprecated setResourcePack()
        sendResourcePack(player);

        // FIX L-08: Restore in-match state on reconnect (delay 1 tick so world is loaded)
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;
                Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
                if (arena == null) return;

                plugin.getLogger().info("[Reconnect] " + player.getName()
                        + " rejoined arena " + arena.getName()
                        + " in state " + arena.getState());

                // Restore scoreboard, bossbar, and gamemode
                if (plugin.getMatchService() != null) {
                    plugin.getMatchService().restoreSession(player, arena);
                }

                // If the player was alive, teleport them back to the arena
                // (they may have spawned at world spawn on reconnect)
                if (arena.getState() == MatchState.PLAYING || arena.getState() == MatchState.DEATHMATCH) {
                    me.duong2012g.hungergamessss.model.GamePlayer gp =
                            arena.getGamePlayers().get(player.getUniqueId());
                    if (gp != null && gp.isAlive() && gp.getLastLocation() != null) {
                        player.teleport(gp.getLastLocation());
                        player.sendMessage("§a[Arena] §7Reconnected to match — you're back in the fight!");
                    } else if (gp != null && !gp.isAlive()) {
                        // Dead/spectator — just confirm spectator mode
                        player.sendMessage("§7[Arena] §7Reconnected as spectator.");
                    }
                }
            }
        }.runTaskLater(plugin, 1L);
    }

    // -------------------------------------------------------------------------

    private void sendResourcePack(Player player) {
        String url = plugin.getConfig().getString("resource-pack.url", "");
        if (url.isEmpty()) return;

        String hash = plugin.getConfig().getString("resource-pack.hash", "");

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;
                try {
                    // FIX L-03: Adventure ResourcePackRequest (Paper 1.21 native)
                    ResourcePackInfo.Builder infoBuilder = ResourcePackInfo.resourcePackInfo()
                            .id(UUID.nameUUIDFromBytes(url.getBytes()))
                            .uri(URI.create(url));

                    if (!hash.isEmpty()) {
                        infoBuilder.hash(hash);
                    }

                    ResourcePackRequest request = ResourcePackRequest.resourcePackRequest()
                            .packs(infoBuilder.build())
                            .required(plugin.getConfig().getBoolean("resource-pack.required", false))
                            .prompt(net.kyori.adventure.text.Component.text(
                                    plugin.getConfig().getString("resource-pack.prompt", "")))
                            .build();

                    player.sendResourcePacks(request);
                } catch (Exception e) {
                    plugin.getLogger().warning("Failed to send resource pack to "
                            + player.getName() + ": " + e.getMessage());
                }
            }
        }.runTaskLater(plugin, 20L);
    }
}
