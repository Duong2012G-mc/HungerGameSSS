package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class PlayerDeathListener implements Listener {
    private final Main plugin;

    public PlayerDeathListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        org.bukkit.entity.Player player = event.getEntity();
        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        if (arena == null) return;

        // Update Arena stats
        arena.addDeath(player.getUniqueId());
        // FIX C-06: player.getKiller() only returns a Player if they dealt damage in the last few seconds.
        // Deaths by border, mobs, or fall-after-knockback lose the killer reference.
        // Use the arena's lastAttackers map as a reliable fallback.
        org.bukkit.entity.Player killer = player.getKiller();
        if (killer == null) {
            java.util.UUID lastAttackerId = arena.getLastAttacker(player.getUniqueId());
            if (lastAttackerId != null) {
                killer = org.bukkit.Bukkit.getPlayer(lastAttackerId);
            }
        }
        if (killer != null && !killer.equals(player)) {
            arena.addKill(killer.getUniqueId());
        }

        // ── Player head drop on PvP kill ─────────────────────────────────────
        // Only drop if: killed by another player, config enabled, and RNG passes.
        boolean dropHead = plugin.getConfig().getBoolean("game.death.drop-head", true);
        if (dropHead && killer != null && !killer.equals(player)) {
            double chance = plugin.getConfig().getDouble("game.death.head-drop-chance", 1.0);
            if (Math.random() < chance) {
                ItemStack head = createPlayerHead(player);
                event.getDrops().add(head);
            }
        }

        // Delegate game logic to MatchService
        if (plugin.getMatchService() != null) {
            plugin.getMatchService().handleDeath(player);
        }

        if (plugin.getAbilityManager() != null) {
            plugin.getAbilityManager().handleDeath(player, event);
        }
        
        // Respect config for item/exp drops
        boolean dropItems = plugin.getConfig().getBoolean("game.death.drop-items", true);
        boolean dropExp = plugin.getConfig().getBoolean("game.death.drop-exp", true);
        if (!dropItems) {
            // Remove all drops EXCEPT the player head (already added above) so head
            // always drops on PvP kill regardless of drop-items setting.
            event.getDrops().removeIf(is -> is.getType() != Material.PLAYER_HEAD);
        }
        if (!dropExp) {
            event.setDroppedExp(0);
        }
    }

    /**
     * Creates a player head ItemStack with the victim's skin and a display name.
     * Uses SkullMeta.setOwningPlayer() — works on Paper 1.21 without ProtocolLib.
     */
    private ItemStack createPlayerHead(org.bukkit.entity.Player victim) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(victim);
            // Display name: "§c<PlayerName>'s Head" — non-italic via Component API
            meta.displayName(
                me.duong2012g.hungergamessss.util.ColorUtil.component(
                    "§c" + victim.getName() + "'s Head"));
            // Lore hint for crafting usage
            java.util.List<net.kyori.adventure.text.Component> lore = new java.util.ArrayList<>();
            lore.add(me.duong2012g.hungergamessss.util.ColorUtil.component(
                "§7Dropped by §f" + victim.getName() + " §7on death."));
            lore.add(me.duong2012g.hungergamessss.util.ColorUtil.component(
                "§8Used in: §6Warpick §8crafting recipe."));
            meta.lore(lore);
            head.setItemMeta(meta);
        }
        return head;
    }
}

