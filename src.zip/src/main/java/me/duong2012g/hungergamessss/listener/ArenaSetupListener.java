package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ArenaSetupListener implements Listener {
    private final Main plugin;
    private final Map<UUID, Arena> setupMode = new HashMap<>();

    public ArenaSetupListener(Main plugin) {
        this.plugin = plugin;
    }

    public void toggleSetupMode(Player player, Arena arena) {
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
        if (setupMode.containsKey(player.getUniqueId())) {
            setupMode.remove(player.getUniqueId());
            player.getInventory().remove(Material.BLAZE_ROD);
            player.sendMessage(mm.getMessage("arena_setup_exited", Map.of("arena", arena.getName())));
        } else {
            setupMode.put(player.getUniqueId(), arena);
            
            ItemStack wand = new ItemStack(Material.BLAZE_ROD);
            ItemMeta meta = wand.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(mm.getMessage("arena_setup_wand_name"));
                meta.setLore(java.util.List.of(
                    mm.getMessage("arena_setup_wand_lore_add"),
                    mm.getMessage("arena_setup_wand_lore_remove")
                ));
                wand.setItemMeta(meta);
            }
            
            player.getInventory().addItem(wand);
            player.sendMessage(mm.getMessage("arena_setup_entered", Map.of("arena", arena.getName())));
            player.sendMessage(mm.getMessage("arena_setup_instruction"));
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!setupMode.containsKey(player.getUniqueId())) return;

        Arena arena = setupMode.get(player.getUniqueId());
        ItemStack item = event.getItem();
        me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();

        if (item != null && item.getType() == Material.BLAZE_ROD && item.hasItemMeta() && 
            item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals(mm.getMessage("arena_setup_wand_name"))) {
            
            event.setCancelled(true);
            
            if (event.getAction() == Action.LEFT_CLICK_BLOCK || event.getAction() == Action.LEFT_CLICK_AIR) {
                // Add spawn at player location to capture yaw/pitch
                Location spawnLoc = player.getLocation();
                arena.addConfiguredSpawn(spawnLoc);
                player.sendMessage(mm.getMessage("arena_spawn_added", Map.of("count", String.valueOf(arena.getConfiguredSpawns().size()))));
                plugin.getDatabaseManager().saveArena(arena);
            } else if (event.getAction() == Action.RIGHT_CLICK_BLOCK || event.getAction() == Action.RIGHT_CLICK_AIR) {
                // Remove spawn near player
                Location playerLoc = player.getLocation();
                Location toRemove = null;
                for (Location loc : arena.getConfiguredSpawns()) {
                    if (loc.distance(playerLoc) < 2) {
                        toRemove = loc;
                        break;
                    }
                }
                
                if (toRemove != null) {
                    arena.removeConfiguredSpawn(toRemove);
                    player.sendMessage(mm.getMessage("arena_spawn_removed", Map.of("count", String.valueOf(arena.getConfiguredSpawns().size()))));
                    plugin.getDatabaseManager().saveArena(arena);
                } else {
                    player.sendMessage(mm.getMessage("arena_spawn_not_found"));
                }
            }
        }
    }
}
