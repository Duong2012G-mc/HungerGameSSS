package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class VeinMinerListener implements Listener {
    private final Main plugin;
    // FIX M-06: removed cached maxVeinSize field — was read once in constructor so
    // /perf reload had no effect. Now read from config on each break event.

    public VeinMinerListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        
        if (arena == null || !arena.isVeinminerEnabled() || !player.isSneaking()) return;
        
        Block block = event.getBlock();
        Material type = block.getType();
        
        if (!isOre(type)) return;

        ItemStack tool = player.getInventory().getItemInMainHand();
        // Check tool capability (CS-04)
        if (!canMinerMine(tool, type)) return;

        // FIX M-06: read config live — honours /perf reload without restart
        int maxVeinSize = plugin.getConfig().getInt("arena.veinminer-max-size", 64);
        
        // BUG-NEW-18: Use HashSet for O(1) contains + iterative BFS to avoid stack overflow
        Set<Block> vein = new HashSet<>();
        findVein(block, type, vein, maxVeinSize);
        
        if (vein.size() > 1) {
            int brokenCount = 0;
            for (Block b : vein) {
                if (b.equals(block)) continue;
                if (b.getType() == type) {
                    b.breakNaturally(tool);
                    brokenCount++;
                }
            }
            
            // FIX HG-01: Apply durability damage to tool
            if (brokenCount > 0 && tool != null && tool.getType() != Material.AIR) {
                ItemMeta meta = tool.getItemMeta();
                if (meta instanceof Damageable damageable) {
                    // Simple 1 damage per extra block for HG (no unbreaking logic for simplicity in HG)
                    int currentDamage = damageable.getDamage();
                    int newDamage = currentDamage + brokenCount;
                    
                    if (newDamage >= tool.getType().getMaxDurability()) {
                        player.getInventory().setItemInMainHand(null);
                        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
                    } else {
                        damageable.setDamage(newDamage);
                        tool.setItemMeta(meta);
                    }
                }
            }
        }
    }

    private boolean isOre(Material type) {
        String name = type.name();
        return name.endsWith("_ORE") || name.equals("DEEP_SLATE_COAL_ORE") || name.equals("DEEP_SLATE_IRON_ORE") || 
               name.equals("DEEP_SLATE_GOLD_ORE") || name.equals("DEEP_SLATE_DIAMOND_ORE") || 
               name.equals("DEEP_SLATE_EMERALD_ORE") || name.equals("DEEP_SLATE_LAPIS_ORE") || 
               name.equals("DEEP_SLATE_REDSTONE_ORE") || name.equals("DEEP_SLATE_COPPER_ORE") ||
               name.equals("ANCIENT_DEBRIS") || name.equals("RAW_IRON_BLOCK") || 
               name.equals("RAW_GOLD_BLOCK") || name.equals("RAW_COPPER_BLOCK");
    }

    private boolean canMinerMine(ItemStack tool, Material block) {
        if (tool == null) return false;
        // Basic Minecraft mining levels logic
        String blockName = block.name();
        String toolName = tool.getType().name();

        if (blockName.contains("DIAMOND") || blockName.contains("EMERALD") || blockName.contains("GOLD") || blockName.contains("REDSTONE")) {
            return toolName.contains("IRON_PICKAXE") || toolName.contains("DIAMOND_PICKAXE") || toolName.contains("NETHERITE_PICKAXE");
        }
        if (blockName.contains("IRON") || blockName.contains("LAPIS") || blockName.contains("COPPER")) {
            return toolName.contains("STONE_PICKAXE") || toolName.contains("IRON_PICKAXE") || toolName.contains("DIAMOND_PICKAXE") || toolName.contains("NETHERITE_PICKAXE");
        }
        if (blockName.contains("OBSIDIAN") || blockName.contains("DEBRIS")) {
            return toolName.contains("DIAMOND_PICKAXE") || toolName.contains("NETHERITE_PICKAXE");
        }
        return toolName.contains("PICKAXE"); // Coal etc
    }

    // BUG-NEW-18: Iterative BFS with HashSet to avoid O(n) contains and stack overflow
    // FIX M-06: maxVeinSize is now a parameter (not a cached field) for hot-reload support
    private void findVein(Block startBlock, Material type, Set<Block> vein, int maxVeinSize) {
        Queue<Block> queue = new LinkedList<>();
        queue.add(startBlock);
        vein.add(startBlock);
        
        while (!queue.isEmpty() && vein.size() < maxVeinSize) {
            Block current = queue.poll();
            for (int x = -1; x <= 1; x++) {
                for (int y = -1; y <= 1; y++) {
                    for (int z = -1; z <= 1; z++) {
                        if (x == 0 && y == 0 && z == 0) continue;
                        Block neighbor = current.getRelative(x, y, z);
                        if (neighbor.getType() == type && vein.add(neighbor)) {
                            if (vein.size() < maxVeinSize) {
                                queue.add(neighbor);
                            }
                        }
                    }
                }
            }
        }
    }
}
