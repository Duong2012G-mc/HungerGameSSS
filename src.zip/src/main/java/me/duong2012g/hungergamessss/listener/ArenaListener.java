package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.metadata.FixedMetadataValue;

public class ArenaListener implements Listener {
    private final Main plugin;

    public ArenaListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteractAtEntity(org.bukkit.event.player.PlayerInteractAtEntityEvent event) {
        if (event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        if (event.getRightClicked() instanceof org.bukkit.entity.ArmorStand stand) {
            me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(event.getPlayer());
            if (arena != null && arena.getHologramMap().containsKey(stand)) {
                event.setCancelled(true);
                handleLegendaryCrafting(event.getPlayer(), arena.getHologramMap().get(stand));
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(event.getPlayer());
        
        // Dispatch to arena if needed (e.g. for legendary crafting blocks)
        if (arena != null && event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null) {
            org.bukkit.Location loc = event.getClickedBlock().getLocation();
            if (arena.getLegendaryLocations().containsKey(loc)) {
                event.setCancelled(true);
                String itemName = arena.getLegendaryLocations().get(loc);
                
                // Find recipe
                me.duong2012g.hungergamessss.model.LegendaryRecipe rec = null;
                for (me.duong2012g.hungergamessss.model.LegendaryRecipe r : plugin.getAbilityManager().getAllLegendaries()) {
                    if (r.id.equalsIgnoreCase(itemName) || r.name.equalsIgnoreCase(itemName.replace("_", " "))) {
                        rec = r;
                        break;
                    }
                }
                
                if (rec != null) {
                    handleLegendaryCrafting(event.getPlayer(), rec);
                } else {
                    event.getPlayer().sendMessage(plugin.getMessageManager().getMessage("recipe_not_found", java.util.Map.of("item", itemName)));
                }
                return;
            }
        }
        
        // Dispatch ability right/left-click (works both in and out of arena — validateCanUse handles gating)
        ItemStack item = event.getItem();
        if (item != null && item.hasItemMeta()) {
            plugin.getAbilityManager().handleAbility(event.getPlayer(), item, event);
        }
    }

    private void handleStolenHeart(Player player, ItemStack item, me.duong2012g.hungergamessss.manager.MessageManager mm) {
        item.setAmount(item.getAmount() - 1);
        
        double maxHealth = player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue();
        double newMax = maxHealth + 2.0;
        double cap = plugin.getConfig().getDouble("arena.lifesteal-max-health", 40.0);
        
        if (newMax > cap) {
            player.sendMessage(mm.getMessage("stolen_heart_max_health"));
            if (maxHealth >= cap) {
                item.setAmount(item.getAmount() + 1);
                return;
            }
            newMax = cap;
        }
        
        player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).setBaseValue(newMax);
        player.setHealth(Math.min(player.getHealth() + 2.0, newMax));
        player.sendMessage(mm.getMessage("stolen_heart_consumed"));
    }

    private void handleLegendaryCrafting(Player player, me.duong2012g.hungergamessss.model.LegendaryRecipe rec) {
        if (rec == null) return;
        
        // 🔒 Synchronized on recipe to prevent race conditions during crafting
        synchronized (rec) {
            me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
            
            // Check if still available (hasn't been removed by another player)
            if (arena != null && !arena.getHolograms().containsKey(rec)) {
                player.sendMessage(plugin.getMessageManager().getMessage("already_crafted"));
                return;
            }

            // Check XP
            int xpCost = (Integer) rec.config.getOrDefault("xp-cost", plugin.getConfig().getInt("legendary.crafting-xp-cost", 15));
            if (player.getLevel() < xpCost) {
                player.sendMessage(plugin.getMessageManager().getMessage("not_enough_xp", java.util.Map.of("xp", String.valueOf(xpCost))));
                return;
            }

            // Check ingredients
            if (rec.ingredients != null) {
                for (me.duong2012g.hungergamessss.model.Ingredient ing : rec.ingredients) {
                    if (!player.getInventory().contains(ing.mat, ing.amount)) {
                        String matName = ing.mat.name().replace("_", " ").toLowerCase();
                        player.sendMessage(plugin.getMessageManager().getMessage("not_enough_material", java.util.Map.of("amount", String.valueOf(ing.amount), "material", matName)));
                        return;
                    }
                }
            }

            // Check Heart Cost
            int heartCost = rec.heartCost;
            if (heartCost > 0) {
                me.duong2012g.hungergamessss.model.PlayerData data = plugin.getPlayerManager().getPlayerData(player);
                // current hearts = 10 (base) + lifestealHearts
                int currentHearts = 10 + data.getLifestealHearts();
                if (currentHearts <= heartCost + 1) { // Keep at least 1 heart (2 HP)
                    player.sendMessage(plugin.getMessageManager().getMessage("not_enough_hearts"));
                    return;
                }
            }

            // Success - remove ingredients
            if (rec.ingredients != null) {
                for (me.duong2012g.hungergamessss.model.Ingredient ing : rec.ingredients) {
                    int toRemove = ing.amount;
                    ItemStack[] contents = player.getInventory().getContents();
                    for (int i = 0; i < contents.length; i++) {
                        ItemStack is = contents[i];
                        if (is != null && is.getType() == ing.mat) {
                            if (is.getAmount() > toRemove) {
                                is.setAmount(is.getAmount() - toRemove);
                                toRemove = 0;
                                break;
                            } else {
                                toRemove -= is.getAmount();
                                player.getInventory().setItem(i, null);
                            }
                        }
                        if (toRemove <= 0) break;
                    }
                }
            }

            // Take XP
            player.setLevel(player.getLevel() - xpCost);

            // Take Hearts via PlayerManager
            if (heartCost > 0) {
                me.duong2012g.hungergamessss.model.PlayerData data = plugin.getPlayerManager().getPlayerData(player);
                data.setLifestealHearts(data.getLifestealHearts() - heartCost);
                plugin.getPlayerManager().updateHealth(player);
                player.sendMessage(plugin.getMessageManager().getMessage("heart_sacrificed", java.util.Map.of("hearts", String.valueOf(heartCost))));
            }

            // Cleanup Holograms if spawned via ArenaManager
            if (arena != null && arena.getHolograms().containsKey(rec)) {
                for (org.bukkit.entity.ArmorStand stand : arena.getHolograms().get(rec)) {
                    arena.getHologramMap().remove(stand);
                    stand.remove();
                }
                arena.getHolograms().remove(rec);
            }

            // Give item
            plugin.getAbilityManager().giveLegendaryItem(player, rec.id);
            me.duong2012g.hungergamessss.manager.MessageManager mm = plugin.getMessageManager();
            player.sendMessage(mm.getMessage("craft_success_item", java.util.Map.of("item", rec.name)));
            
            // Effects and Broadcast
            org.bukkit.Location loc = player.getLocation();
            player.getWorld().strikeLightningEffect(loc);
            for (int i = 0; i < 4; i++) {
                double angle = (double) i * 1.57;
                player.getWorld().strikeLightningEffect(loc.clone().add(Math.cos(angle) * 2, 0, Math.sin(angle) * 2));
            }
            
            player.getWorld().spawnParticle(org.bukkit.Particle.EXPLOSION_EMITTER, loc, 5, 0.5, 0.5, 0.5, 0.1);
            player.getWorld().spawnParticle(org.bukkit.Particle.FLAME, loc, 100, 1.0, 1.0, 1.0, 0.2);
            player.getWorld().spawnParticle(org.bukkit.Particle.END_ROD, loc, 50, 1.0, 1.0, 1.0, 0.1);
            
            player.playSound(loc, org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.5f, 1.0f);
            player.playSound(loc, org.bukkit.Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.0f);
            
            if (arena != null) {
                String broadcast = mm.getMessage("legend_craft_broadcast", java.util.Map.of("player", player.getName(), "item", rec.name));
                for (java.util.UUID uuid : arena.getPlayers()) {
                    org.bukkit.entity.Player p = org.bukkit.Bukkit.getPlayer(uuid);
                    if (p != null) {
                        p.sendMessage(broadcast);
                        p.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 0.5f);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByEntity(event.getEntity());
        if (arena == null) arena = plugin.getArenaManager().getArenaByEntity(event.getDamager());
        
        if (arena != null) {
            arena.handleDamage(event);
        }

        // Hologram Crafting (Left Click)
        if (event.getDamager() instanceof Player p && event.getEntity() instanceof org.bukkit.entity.ArmorStand stand) {
            me.duong2012g.hungergamessss.model.Arena a = plugin.getArenaManager().getArenaByPlayer(p);
            if (a != null && a.getHologramMap().containsKey(stand)) {
                event.setCancelled(true);
                handleLegendaryCrafting(p, a.getHologramMap().get(stand));
                return;
            }
        }
    }

    @EventHandler
    public void onPlayerPortal(org.bukkit.event.player.PlayerPortalEvent event) {
        me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(event.getPlayer());
        if (arena != null) {
            arena.handlePortal(event);
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (event.getTo() == null) return;
        if (event.getFrom().getBlockX() == event.getTo().getBlockX() && 
            event.getFrom().getBlockY() == event.getTo().getBlockY() && 
            event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;

        // FIX L-08: Update lastLocation so reconnecting players return to where they were
        me.duong2012g.hungergamessss.model.Arena arena =
                plugin.getArenaManager().getArenaByPlayer(event.getPlayer());
        if (arena != null) {
            me.duong2012g.hungergamessss.model.GamePlayer gp =
                    arena.getGamePlayers().get(event.getPlayer().getUniqueId());
            if (gp != null && gp.isAlive()) {
                gp.setLastLocation(event.getTo().clone());
            }
        }

        Block block = event.getTo().getBlock();
        if (block.getType() == Material.END_GATEWAY) {
            if (plugin.getPortalManager() != null && plugin.getPortalManager().isPortalBlock(block.getLocation())) {
                plugin.getPortalManager().handlePortalTouch(event.getPlayer(), block.getLocation());
            }
        }
    }

    @EventHandler
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        if (event.getCause() == PlayerTeleportEvent.TeleportCause.END_GATEWAY) {
            Location from = event.getFrom();
            if (plugin.getPortalManager() != null && plugin.getPortalManager().isPortalBlock(from.getBlock().getLocation())) {
                event.setCancelled(true);
            }
        }
    }
}
