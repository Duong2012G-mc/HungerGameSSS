package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public class EntityDamageListener implements Listener {
    private final Main plugin;

    public EntityDamageListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        if (arena == null) return;

        MatchState state = arena.getState();

        // 1. Block damage in non-playing states (Logic Fix II.3)
        if (state == MatchState.WAITING || state == MatchState.STARTING || state == MatchState.ENDING) {
            event.setCancelled(true);
            return;
        }

        // CS-07: Protection for glitched spectators (not alive in system)
        me.duong2012g.hungergamessss.model.GamePlayer gp = arena.getGamePlayer(player.getUniqueId());
        if (gp == null || !gp.isAlive()) {
            event.setCancelled(true);
            return;
        }
        
        // 2. Grace Period Logic
        // FIX H-01: fallback was 120 — must match config.yml default of 30
        int graceSeconds = plugin.getConfig().getInt("game.phases.grace", 30);
        if (state == MatchState.PLAYING && arena.getTimer() < graceSeconds) {
            if (event.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK || 
                event.getCause() == EntityDamageEvent.DamageCause.PROJECTILE) {
                 event.setCancelled(true);
                 return;
            }
        }
        
        // 3. Team Friendly Fire Logic
        if (event instanceof org.bukkit.event.entity.EntityDamageByEntityEvent damageByEntityEvent) {
            // CS-07: Unwrap projectile to find the actual attacker
            org.bukkit.entity.Entity damagerEntity = damageByEntityEvent.getDamager();
            Player attacker = null;
            if (damagerEntity instanceof Player p) {
                attacker = p;
            } else if (damagerEntity instanceof org.bukkit.entity.Projectile proj && proj.getShooter() instanceof Player p) {
                attacker = p;
            }
            
            if (attacker != null) {
                // Use TeamManager helper (Code Style I.1 boundary fix)
                if (plugin.getTeamManager().isFriendlyFire(player, attacker)) {
                    event.setCancelled(true);
                    attacker.sendMessage(plugin.getMessageManager().getMessage("team_no_friendly_fire"));
                    return;
                }
                
                // 4. Track Combat Timestamp (for combat log detection)
                long now = System.currentTimeMillis();
                arena.getCombatTimestamps().put(player.getUniqueId(), now);
                arena.getCombatTimestamps().put(attacker.getUniqueId(), now);
                
                // CS-12: Track last attacker for kill credit
                arena.getLastAttackers().put(player.getUniqueId(), attacker.getUniqueId());
            }
        }
    }
}
