package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;

public class PlayerRespawnListener implements Listener {
    private final Main plugin;

    public PlayerRespawnListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        // If player is in an arena, set respawn to lobby or spectator spot
        org.bukkit.entity.Player player = event.getPlayer();
        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        
        if (arena != null) {
            // Player is technically still in arena object until unregistered?
            // If they died, they might be in spectator mode now.
            if (plugin.getLobbyManager().getLobbyLocation() != null) {
                event.setRespawnLocation(plugin.getLobbyManager().getLobbyLocation());
            }
        } else {
            // If not in arena but in arena world?
            // Safer to just send to lobby if it exists and they are not in a known arena
            // But we don't want to mess with normal survival world respawns.
            // Only capture if they were part of a game.
            
            // Check if they were just eliminated (PlayerDeathListener logic might have removed them or set them to spectator)
            // If PlayerDeath sets to Spectator, they don't see Respawn Screen usually if gamerule doImmediateRespawn is true.
            // But if they do click respawn, we want them at Lobby.
            if (plugin.getLobbyManager().getLobbyLocation() != null) {
                 // Check if player world is an arena world
                 if (plugin.getArenaManager().getArenas().values().stream().anyMatch(a -> a.getWorld() != null && a.getWorld().equals(player.getWorld()))) {
                     event.setRespawnLocation(plugin.getLobbyManager().getLobbyLocation());
                 }
            }
        }
    }
}
