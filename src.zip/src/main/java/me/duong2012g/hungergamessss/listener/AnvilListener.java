package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.ability.AbilityDispatcher;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/**
 * AnvilListener — custom anvil rules for legendary items.
 *
 * ARTEMIS BOW — Power upgrade cap
 *   The bow is crafted with Power III and can be upgraded via anvil up to
 *   Power VII (configurable via {@code max_power_level} in artemis_bow.yml).
 *   Vanilla Minecraft caps Power at V; this listener lifts the cap to VII
 *   by allowing the result through, and clamps it back down if the result
 *   would exceed VII.
 *
 *   Behaviour:
 *   - Artemis Bow + Power enchanted book → result is allowed up to Power VII.
 *   - Any result that would push Power above VII has its Power clamped to VII.
 *   - All other legendary items: anvil operations that would change the
 *     ability PDC tag are cancelled (prevents ability stripping via rename).
 */
public class AnvilListener implements Listener {

    private static final String ARTEMIS_ABILITY_ID = "artemis bow";

    private final Main plugin;

    public AnvilListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        AnvilInventory inv = event.getInventory();
        ItemStack first  = inv.getItem(0); // item being modified
        ItemStack second = inv.getItem(1); // item / book being applied
        ItemStack result = event.getResult();

        if (first == null || result == null) return;

        String abilityId = AbilityDispatcher.getItemId(first);
        if (abilityId == null) return; // not a legendary item — leave vanilla alone

        // ── Artemis Bow: allow Power upgrade, clamp at max_power_level ─────────
        if (ARTEMIS_ABILITY_ID.equalsIgnoreCase(abilityId)) {
            handleArtemisBowAnvil(first, second, result, event);
            return;
        }

        // ── All other legendary items ──────────────────────────────────────────
        // Block any anvil result that strips or alters the ability PDC tag.
        // Rename-only (second = null) is fine — players can rename their items.
        if (second != null) {
            // A book or second item is being combined — verify the PDC tag is preserved
            ItemMeta resultMeta = result.getItemMeta();
            NamespacedKey key = new NamespacedKey(plugin, "hg_ability");
            if (resultMeta != null && !resultMeta.getPersistentDataContainer().has(key,
                    org.bukkit.persistence.PersistentDataType.STRING)) {
                // PDC tag was lost in the result — cancel the operation
                event.setResult(null);
            }
        }
    }

    private void handleArtemisBowAnvil(ItemStack first, ItemStack second,
                                       ItemStack result, PrepareAnvilEvent event) {
        if (second == null) return; // rename-only, nothing to do

        ItemMeta resultMeta = result.getItemMeta();
        if (resultMeta == null) return;

        int maxPower = getArtemisMaxPower();

        int resultPowerLevel = resultMeta.getEnchantLevel(Enchantment.POWER);

        if (resultPowerLevel <= 0) {
            // No Power on result — different enchant combination, nothing to clamp.
            return;
        }

        if (resultPowerLevel > maxPower) {
            // Clamp Power to the configured maximum — vanilla would allow up to 5,
            // but we lift the cap to maxPower (default 7) and enforce that ceiling.
            resultMeta.addEnchant(Enchantment.POWER, maxPower, true);
            result.setItemMeta(resultMeta);
            event.setResult(result);
        }
        // resultPowerLevel <= maxPower — allow the upgrade normally (even if > vanilla max 5)
    }

    /**
     * Reads max_power_level from the artemis bow recipe config stored in AbilityManager.
     * Falls back to 7 if not found.
     */
    private int getArtemisMaxPower() {
        if (plugin.getAbilityManager() == null) return 7;
        java.util.Map<String, java.util.Map<String, Object>> recipes =
                plugin.getAbilityManager().getRecipes();
        // Recipe keys are stored as lowercase names, e.g. "artemis bow"
        for (java.util.Map.Entry<String, java.util.Map<String, Object>> entry : recipes.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(ARTEMIS_ABILITY_ID)) {
                Object val = entry.getValue().get("max_power_level");
                if (val instanceof Number n) return n.intValue();
                break;
            }
        }
        return 7; // hard default
    }
}
