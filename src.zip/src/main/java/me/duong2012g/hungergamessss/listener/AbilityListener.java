package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import me.duong2012g.hungergamessss.ability.AbilityContext;
import me.duong2012g.hungergamessss.ability.TriggerType;
import me.duong2012g.hungergamessss.ability.Ability;
import me.duong2012g.hungergamessss.ability.AbilityDispatcher;

public class AbilityListener implements Listener {
    private final Main plugin;

    public AbilityListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (item == null) return;

        me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        TriggerType trigger = event.getAction().name().contains("RIGHT") ? TriggerType.RIGHT_CLICK : TriggerType.LEFT_CLICK;
        
        AbilityContext ctx = new AbilityContext(player.getUniqueId(), null, player.getLocation(), arena, trigger, item, event);
        me.duong2012g.hungergamessss.ability.AbilityDispatcher.handle(trigger, ctx);
        
        // Track last held legendary item for projectile launch handling (mostly for Tridents)
        if (item.getType() == org.bukkit.Material.TRIDENT && trigger == TriggerType.RIGHT_CLICK) {
            String id = me.duong2012g.hungergamessss.ability.AbilityDispatcher.getItemId(item);
            if (id != null) {
                player.setMetadata("hg_last_legend_trident", new org.bukkit.metadata.FixedMetadataValue(plugin, id));
            }
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player) {
            ItemStack item = player.getInventory().getItemInMainHand();
            if (item != null && item.hasItemMeta()) {
                me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
                AbilityContext ctx = new AbilityContext(player.getUniqueId(), event.getEntity().getUniqueId(), event.getEntity().getLocation(), arena, TriggerType.HIT, item, event);
                me.duong2012g.hungergamessss.ability.AbilityDispatcher.handle(TriggerType.HIT, ctx);
            }
        }
    }

    @EventHandler
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        if (event.getEntity().getShooter() instanceof Player player) {
            ItemStack item = player.getInventory().getItemInMainHand();
            
            // For Tridents, we need special handling if it's already gone from hand
            if (event.getEntity() instanceof org.bukkit.entity.Trident trident && (item == null || item.getType() == org.bukkit.Material.AIR)) {
                if (player.hasMetadata("hg_last_legend_trident")) {
                    String id = player.getMetadata("hg_last_legend_trident").get(0).asString();
                    event.getEntity().setMetadata("hg_ability", new org.bukkit.metadata.FixedMetadataValue(plugin, id));
                    player.removeMetadata("hg_last_legend_trident", plugin);
                    return;
                }
            }

            handleLaunch(player, event.getEntity(), item, event);
        }
    }

    @EventHandler
    public void onShootBow(EntityShootBowEvent event) {
        if (event.getEntity() instanceof Player player) {
            handleLaunch(player, event.getProjectile(), event.getBow(), event);
        }
    }

    private void handleLaunch(Player player, org.bukkit.entity.Entity projectile, ItemStack item, org.bukkit.event.Event event) {
        if (item != null && item.hasItemMeta()) {
            me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
            AbilityContext ctx = new AbilityContext(player.getUniqueId(), null, projectile.getLocation(), arena, TriggerType.PROJECTILE_LAUNCH, item, event);
            me.duong2012g.hungergamessss.ability.AbilityDispatcher.handle(TriggerType.PROJECTILE_LAUNCH, ctx);
            
            // Tag projectile
            String id = me.duong2012g.hungergamessss.ability.AbilityDispatcher.getItemId(item);
            if (id != null) {
                projectile.setMetadata("hg_ability", new org.bukkit.metadata.FixedMetadataValue(plugin, id));
            }
        }
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent event) {
        if (event.getEntity().getShooter() instanceof Player player && event.getEntity().hasMetadata("hg_ability")) {
            String id = event.getEntity().getMetadata("hg_ability").get(0).asString();
            me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
            // We don't have the original item easily, but the dispatcher can handle it if we modify it or just call ability directly
            me.duong2012g.hungergamessss.ability.Ability ability = plugin.getAbilityManager().getRegistry().getAbility(id);
            if (ability != null) {
                AbilityContext ctx = new AbilityContext(player.getUniqueId(), null, event.getEntity().getLocation(), arena, TriggerType.PROJECTILE_HIT, null, event);
                ability.execute(ctx);
            }
        }
    }
    
    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player) {
            ItemStack item = player.getInventory().getItemInMainHand();
            if (item != null) {
                plugin.getAbilityManager().handleDamage(player, item, event);
            }
        }
        plugin.getAbilityManager().handleEntityDamage(event.getEntity(), event);
    }

    @EventHandler
    public void onPlayerRiptide(PlayerRiptideEvent event) {
        ItemStack item = event.getItem();
        plugin.getAbilityManager().handleRiptide(event.getPlayer(), item, event);
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item != null && item.hasItemMeta()) {
            me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
            AbilityContext ctx = new AbilityContext(player.getUniqueId(), null, player.getLocation(), arena, TriggerType.SNEAK, item, event);
            me.duong2012g.hungergamessss.ability.AbilityDispatcher.handle(TriggerType.SNEAK, ctx);
        }
    }

    @EventHandler
    public void onEntityTarget(EntityTargetEvent event) {
        plugin.getAbilityManager().handleEntityTarget(event.getEntity(), event);
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (event.getFrom().getBlockX() == event.getTo().getBlockX() &&
            event.getFrom().getBlockY() == event.getTo().getBlockY() &&
            event.getFrom().getBlockZ() == event.getTo().getBlockZ()) {
            return;
        }

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item != null && item.hasItemMeta()) {
            me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
            AbilityContext ctx = new AbilityContext(player.getUniqueId(), null, event.getTo(), arena, TriggerType.MOVE, item, event);
            me.duong2012g.hungergamessss.ability.AbilityDispatcher.handle(TriggerType.MOVE, ctx);
            plugin.getAbilityManager().handleMove(player, item, event);
        }
        ItemStack offHand = player.getInventory().getItemInOffHand();
        if (offHand != null && offHand.hasItemMeta()) {
            plugin.getAbilityManager().handleMove(player, offHand, event);
        }
    }

    @EventHandler
    public void onDeath(org.bukkit.event.entity.PlayerDeathEvent event) {
        plugin.getAbilityManager().handleDeath(event.getEntity(), event);
    }

    @EventHandler
    public void onQuit(org.bukkit.event.player.PlayerQuitEvent event) {
        plugin.getAbilityManager().handleQuit(event.getPlayer(), event);
    }

    @EventHandler
    public void onEntityChangeBlock(org.bukkit.event.entity.EntityChangeBlockEvent event) {
        plugin.getAbilityManager().handleEntityChangeBlock(event.getEntity(), event);
    }
}
