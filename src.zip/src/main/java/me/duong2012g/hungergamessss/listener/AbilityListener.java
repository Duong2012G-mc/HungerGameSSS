package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import me.duong2012g.hungergamessss.ability.AbilityContext;
import me.duong2012g.hungergamessss.ability.TriggerType;
import me.duong2012g.hungergamessss.ability.Ability;
import me.duong2012g.hungergamessss.ability.AbilityDispatcher;

public class AbilityListener implements Listener {
    private final Main plugin;

    public AbilityListener(Main plugin) {
        this.plugin = plugin;
    }

    // IMP-LISTENER-01: ignoreCancelled=true on all combat/interact handlers.
    // Previously a cancelled PlayerInteractEvent (e.g. blocked by WorldGuard or another
    // ability) would still trigger the ability, causing double-fires and silent bypasses.
    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (item == null) return;

        me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        TriggerType trigger = event.getAction().name().contains("RIGHT") ? TriggerType.RIGHT_CLICK : TriggerType.LEFT_CLICK;
        
        AbilityContext ctx = new AbilityContext(player.getUniqueId(), null, player.getLocation(), arena, trigger, item, event);
        me.duong2012g.hungergamessss.ability.AbilityDispatcher.handle(trigger, ctx);
        
        if (item.getType() == org.bukkit.Material.TRIDENT && trigger == TriggerType.RIGHT_CLICK) {
            String id = me.duong2012g.hungergamessss.ability.AbilityDispatcher.getItemId(item);
            if (id != null) {
                player.setMetadata("hg_last_legend_trident", new org.bukkit.metadata.FixedMetadataValue(plugin, id));
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player) {
            ItemStack item = player.getInventory().getItemInMainHand();
            if (item != null && item.hasItemMeta()) {
                me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
                AbilityContext ctx = new AbilityContext(player.getUniqueId(), event.getEntity().getUniqueId(), event.getEntity().getLocation(), arena, TriggerType.HIT, item, event);
                me.duong2012g.hungergamessss.ability.AbilityDispatcher.handle(TriggerType.HIT, ctx);
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        if (event.getEntity().getShooter() instanceof Player player) {
            ItemStack item = player.getInventory().getItemInMainHand();
            
            if (event.getEntity() instanceof org.bukkit.entity.Trident && (item == null || item.getType() == org.bukkit.Material.AIR)) {
                if (player.hasMetadata("hg_last_legend_trident")) {
                    String id = player.getMetadata("hg_last_legend_trident").get(0).asString();
                    event.getEntity().setMetadata("hg_ability", new org.bukkit.metadata.FixedMetadataValue(plugin, id));
                    player.removeMetadata("hg_last_legend_trident", plugin);
                    return;
                }
            }

            handleLaunch(player, event.getEntity(), item, event);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onShootBow(EntityShootBowEvent event) {
        if (event.getEntity() instanceof Player player) {
            handleLaunch(player, event.getProjectile(), event.getBow(), event);
        }
    }

    private void handleLaunch(Player player, org.bukkit.entity.Entity projectile, ItemStack item, org.bukkit.event.Event event) {
        if (item != null && item.hasItemMeta()) {
            me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
            AbilityContext ctx = new AbilityContext(player.getUniqueId(), null, projectile.getLocation(), arena, TriggerType.PROJECTILE_LAUNCH, item, event);
            me.duong2012g.hungergamessss.ability.AbilityDispatcher.handle(TriggerType.PROJECTILE_LAUNCH, ctx);
            
            String id = me.duong2012g.hungergamessss.ability.AbilityDispatcher.getItemId(item);
            if (id != null) {
                projectile.setMetadata("hg_ability", new org.bukkit.metadata.FixedMetadataValue(plugin, id));
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onProjectileHit(ProjectileHitEvent event) {
        if (event.getEntity().getShooter() instanceof Player player && event.getEntity().hasMetadata("hg_ability")) {
            String id = event.getEntity().getMetadata("hg_ability").get(0).asString();
            me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
            me.duong2012g.hungergamessss.ability.Ability ability = plugin.getAbilityManager().getRegistry().getAbility(id);
            if (ability != null) {
                AbilityContext ctx = new AbilityContext(player.getUniqueId(), null, event.getEntity().getLocation(), arena, TriggerType.PROJECTILE_HIT, null, event);
                ability.execute(ctx);
            }
        }
    }
    
    // Not ignoreCancelled — we still want to process damage to player (e.g. fall cancel abilities)
    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player) {
            ItemStack item = player.getInventory().getItemInMainHand();
            if (item != null) {
                plugin.getAbilityManager().handleDamage(player, item, event);
            }
        }
        plugin.getAbilityManager().handleEntityDamage(event.getEntity(), event);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerRiptide(PlayerRiptideEvent event) {
        ItemStack item = event.getItem();
        plugin.getAbilityManager().handleRiptide(event.getPlayer(), item, event);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSneak(PlayerToggleSneakEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item != null && item.hasItemMeta()) {
            me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
            AbilityContext ctx = new AbilityContext(player.getUniqueId(), null, player.getLocation(), arena, TriggerType.SNEAK, item, event);
            me.duong2012g.hungergamessss.ability.AbilityDispatcher.handle(TriggerType.SNEAK, ctx);
        }
    }

    @EventHandler
    public void onEntityTarget(EntityTargetEvent event) {
        plugin.getAbilityManager().handleEntityTarget(event.getEntity(), event);
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        // FIX OPT-LISTENER-01: null guard + block-only filter reduces call volume ~95%
        if (event.getTo() == null) return;
        if (event.getFrom().getBlockX() == event.getTo().getBlockX() &&
            event.getFrom().getBlockY() == event.getTo().getBlockY() &&
            event.getFrom().getBlockZ() == event.getTo().getBlockZ()) {
            return;
        }

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item != null && item.hasItemMeta()) {
            me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
            AbilityContext ctx = new AbilityContext(player.getUniqueId(), null, event.getTo(), arena, TriggerType.MOVE, item, event);
            me.duong2012g.hungergamessss.ability.AbilityDispatcher.handle(TriggerType.MOVE, ctx);
            plugin.getAbilityManager().handleMove(player, item, event);
        }
        ItemStack offHand = player.getInventory().getItemInOffHand();
        if (offHand != null && offHand.hasItemMeta()) {
            plugin.getAbilityManager().handleMove(player, offHand, event);
        }
    }

    // A1-23: Global cloud-walk fall-cancel (moved from CloudSword's own @EventHandler)
    @EventHandler(priority = org.bukkit.event.EventPriority.LOW)
    public void onFallDamageCancelCloud(org.bukkit.event.entity.EntityDamageEvent event) {
        if (event.getCause() != org.bukkit.event.entity.EntityDamageEvent.DamageCause.FALL) return;
        me.duong2012g.hungergamessss.ability.Ability a =
                plugin.getAbilityManager().getRegistry().getAbility("Cloud Sword");
        if (!(a instanceof me.duong2012g.hungergamessss.ability.impl.CloudSword cs)) return;
        org.bukkit.block.Block below = event.getEntity().getLocation()
                .getBlock().getRelative(org.bukkit.block.BlockFace.DOWN);
        if (cs.getActiveClouds().containsKey(below)) event.setCancelled(true);
    }

    @EventHandler
    public void onDeath(org.bukkit.event.entity.PlayerDeathEvent event) {
        plugin.getAbilityManager().handleDeath(event.getEntity(), event);
    }

    @EventHandler
    public void onQuit(org.bukkit.event.player.PlayerQuitEvent event) {
        plugin.getAbilityManager().handleQuit(event.getPlayer(), event);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityChangeBlock(org.bukkit.event.entity.EntityChangeBlockEvent event) {
        plugin.getAbilityManager().handleEntityChangeBlock(event.getEntity(), event);
    }
}
