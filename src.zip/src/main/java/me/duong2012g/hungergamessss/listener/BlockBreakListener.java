package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

public class BlockBreakListener implements Listener {
    private final Main plugin;

    public BlockBreakListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Arena arena = plugin.getArenaManager().getArenaByPlayer(event.getPlayer());
        if (arena != null) {
            if (arena.getState() == MatchState.WAITING || arena.getState() == MatchState.STARTING || arena.getState() == MatchState.ENDING) {
                if (!event.getPlayer().hasPermission("hoplitebr.admin")) {
                    event.setCancelled(true);
                }
            }
        }
    }
}
