package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.manager.SelectionManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class SelectionListener implements Listener {
    private final Main plugin;
    private final SelectionManager selectionManager;
    private static final String WAND_NAME_PART = "HG Selection Wand";

    public SelectionListener(Main plugin) {
        this.plugin = plugin;
        this.selectionManager = plugin.getSelectionManager();
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (event.getHand() != EquipmentSlot.HAND) return;
        
        ItemStack item = player.getInventory().getItemInMainHand();
        boolean isWand = item.getType() == Material.WOODEN_AXE || 
                        (item.getType() == Material.GOLDEN_AXE && item.hasItemMeta() && 
                         item.getItemMeta().getDisplayName().contains(WAND_NAME_PART));

        if (isWand && player.hasPermission("hg.admin")) {
            me.duong2012g.hungergamessss.manager.MessageManager mm = Main.getInstance().getMessageManager();
            if (event.getAction() == Action.LEFT_CLICK_BLOCK) {
                event.setCancelled(true);
                selectionManager.setPos1(player.getUniqueId(), event.getClickedBlock().getLocation());
                player.sendMessage(mm.getMessage("selection_pos1_set", java.util.Map.of("location", formatLoc(event.getClickedBlock().getLocation()))));
            } else if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                event.setCancelled(true);
                selectionManager.setPos2(player.getUniqueId(), event.getClickedBlock().getLocation());
                player.sendMessage(mm.getMessage("selection_pos2_set", java.util.Map.of("location", formatLoc(event.getClickedBlock().getLocation()))));
            }
        }
    }
    
    private String formatLoc(org.bukkit.Location loc) {
        return loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ();
    }
}
