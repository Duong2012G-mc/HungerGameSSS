package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import me.duong2012g.hungergamessss.model.Arena;
import me.duong2012g.hungergamessss.model.MatchState;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class PlayerQuitListener implements Listener {
    private final Main plugin;

    public PlayerQuitListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        // Handle Team Leave
        // Handle Team Leave (Only if not in active match or dead/eliminated)
        // If in match and just disconnected, we want to KEEP the team for reconnection
        Arena arena = plugin.getArenaManager().getArenaByPlayer(player);
        if (arena == null) {
            plugin.getTeamManager().leaveTeam(player);
        }

        // Handle Arena Leave + Combat Log
        if (arena != null) {
            // Combat Log Check
            if (arena.getState() == MatchState.PLAYING || arena.getState() == MatchState.DEATHMATCH) {
                boolean isCombatLog = false;
                
                if (plugin.getConfig().getBoolean("game.combat.combat-log-kill", true)) {
                    int logDuration = plugin.getConfig().getInt("game.combat.log-duration", 10);
                    Long lastCombat = arena.getCombatTimestamps().get(player.getUniqueId());
                    
                    if (lastCombat != null) {
                        long elapsed = (System.currentTimeMillis() - lastCombat) / 1000;
                        if (elapsed <= logDuration) {
                            isCombatLog = true; 
                            // Player combat-logged! Drop their items and count as death
                            for (ItemStack item : player.getInventory().getContents()) {
                                if (item != null) {
                                    player.getWorld().dropItemNaturally(player.getLocation(), item);
                                }
                            }
                            for (ItemStack item : player.getInventory().getArmorContents()) {
                                if (item != null) {
                                    player.getWorld().dropItemNaturally(player.getLocation(), item);
                                }
                            }
                            ItemStack offHand = player.getInventory().getItemInOffHand();
                            if (offHand != null && offHand.getType() != org.bukkit.Material.AIR) {
                                player.getWorld().dropItemNaturally(player.getLocation(), offHand);
                            }
                            player.getInventory().clear();
                            
                            // Count as death
                            arena.addDeath(player.getUniqueId());
                            
                            // CS-12: Credit kill to last attacker if trackable
                            java.util.UUID lastAttackerId = arena.getLastAttacker(player.getUniqueId());
                            if (lastAttackerId != null) {
                                arena.addKill(lastAttackerId);
                                Player killer = org.bukkit.Bukkit.getPlayer(lastAttackerId);
                                if (killer != null && plugin.getMessageManager() != null) {
                                    killer.sendMessage(plugin.getMessageManager().getMessage("combat_log_kill_credit",
                                        java.util.Map.of("player", player.getName())));
                                }
                            }
                            
                            // Broadcast combat log
                            if (plugin.getMessageManager() != null) {
                                String broadcastMsg = plugin.getMessageManager().getMessage("combat_log_death",
                                    java.util.Map.of("player", player.getName()));
                                for (java.util.UUID uuid : arena.getPlayers()) {
                                    Player p = org.bukkit.Bukkit.getPlayer(uuid);
                                    if (p != null) p.sendMessage(broadcastMsg);
                                }
                            }
                            
                            plugin.getLogger().info(player.getName() + " combat-logged in arena " + arena.getName());
                            arena.getCombatTimestamps().remove(player.getUniqueId());
                            arena.getLastAttackers().remove(player.getUniqueId()); // Cleanup lookup
                        }
                    }
                }
                
                if (isCombatLog) {
                    plugin.getMatchService().playerLeave(player);
                } else {
                    // Safe Disconnect - Allow Reconnection
                    arena.setDisconnected(player.getUniqueId(), System.currentTimeMillis());
                    for (java.util.UUID uuid : arena.getPlayers()) {
                        Player p = org.bukkit.Bukkit.getPlayer(uuid);
                        if (p != null) {
                            p.sendMessage(plugin.getMessageManager().getMessage("player_disconnected",
                                java.util.Map.of("player", player.getName())));
                        }
                    }
                }
            } else {
                plugin.getMatchService().playerLeave(player);
            }
        }
        
        if (plugin.getAbilityManager() != null) {
            plugin.getAbilityManager().handleQuit(player, event);
        }
        
        // Clean up Managers (Lifecycle Fix IV.7)
        if (plugin.getCooldownManager() != null) {
            plugin.getCooldownManager().removePlayer(player.getUniqueId());
        }
        if (plugin.getScoreboardManager() != null) {
            plugin.getScoreboardManager().removePlayer(player.getUniqueId());
        }
        if (plugin.getSelectionManager() != null) {
            plugin.getSelectionManager().clearSelection(player);
        }
    }
}
