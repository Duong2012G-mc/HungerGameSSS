package me.duong2012g.hungergamessss.listener;

import me.duong2012g.hungergamessss.Main;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerJoinListener implements Listener {
    private final Main plugin;

    public PlayerJoinListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        org.bukkit.entity.Player player = event.getPlayer();
        
        // Update Checker Notification
        if (player.isOp() || player.hasPermission("hungergames.admin")) {
            if (plugin.getUpdateManager() != null && plugin.getUpdateManager().isUpdateAvailable()) {
                player.sendMessage("§6[HungerGamesSSS] §aA new version §e(" + plugin.getUpdateManager().getLatestVersion() + ") §ais available!");
                player.sendMessage("§aDownload it at: §b§nhttps://modrinth.com/plugin/hungergamessss");
            }
        }

        if (plugin.getDatabaseManager() != null) {
            // FIX BUG-JOIN-01: loadPlayerStats was called synchronously on the main thread,
            // blocking the server tick for the full query duration (especially bad with remote MySQL).
            // FIX BUG-JOIN-02: savePlayerStats was called immediately after load, writing zeros
            // back to the DB before the load completed — overwriting legitimate stats.
            // Fix: load async; only create a new record if the player is genuinely new (handled
            // inside executeSave with INSERT … ON CONFLICT DO UPDATE which is a no-op when the
            // record already exists and stats match).
            // Keep DB query async, but apply PlayerData on main thread inside DatabaseManager.
            plugin.getDatabaseManager().loadPlayerStatsAsync(event.getPlayer());
        }

        me.duong2012g.hungergamessss.model.Arena arena = plugin.getArenaManager().getArenaByPlayer(event.getPlayer());
        if (arena != null) {
            // Reconnecting to match
            if (arena.isDisconnected(event.getPlayer().getUniqueId())) {
                arena.removeDisconnected(event.getPlayer().getUniqueId());
                event.getPlayer().sendMessage("§aWelcome back! You have reconnected to the match.");
            }
            
            event.getPlayer().sendMessage(plugin.getMessageManager().getMessage("reconnect_message", java.util.Map.of("arena", arena.getName())));
            if (plugin.getMatchService() != null) {
                plugin.getMatchService().restoreSession(event.getPlayer(), arena);
            }
        } else {
            // Teleport to lobby
            if (plugin.getLobbyManager() != null && plugin.getLobbyManager().getLobbyLocation() != null) {
                event.getPlayer().teleport(plugin.getLobbyManager().getLobbyLocation());
            }
        }
    }
}
